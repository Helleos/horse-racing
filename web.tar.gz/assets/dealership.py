"""Dealership showroom and map art; its stock uses ordinary creature records."""
from __future__ import annotations

import pygame

from racing_constants import CAR_CATALOG, PHYS_W, SCENE_SCALE, SCREEN_W, SCREEN_H

DEALERSHIP_FLOOR_Y = 780.0
DEALERSHIP_DISPLAY_XS = (450.0, 1370.0)


def add_showroom(scene, shop):
    scene.add_floor_slab(-40, PHYS_W + 40, DEALERSHIP_FLOOR_Y, thickness=36, friction=1.0)
    for entry in shop.creatures:
        index = next(i for i, offer in enumerate(CAR_CATALOG) if offer[2] == entry.price)
        horse = scene.spawn_horse(entry, DEALERSHIP_DISPLAY_XS[index], DEALERSHIP_FLOOR_Y, False)
        horse.home_x = DEALERSHIP_DISPLAY_XS[index]


def draw_world_dealership(screen, x, y, font):
    pygame.draw.rect(screen, (80, 90, 100), (x + 4, y + 48, 58, 12), border_radius=2)
    pygame.draw.rect(screen, (224, 232, 238), (x + 5, y + 16, 54, 35), border_radius=2)
    pygame.draw.rect(screen, (72, 104, 126), (x + 5, y + 16, 54, 35), 2, border_radius=2)
    for offset, color in ((10, (210, 142, 40)), (35, (72, 136, 192))):
        pygame.draw.rect(screen, (132, 198, 224), (x + offset - 2, y + 28, 23, 20))
        pygame.draw.rect(screen, color, (x + offset, y + 38, 19, 7))
        pygame.draw.rect(screen, color, (x + offset + 5, y + 34, 10, 7))
        pygame.draw.circle(screen, (24, 26, 32), (x + offset + 4, y + 46), 3)
        pygame.draw.circle(screen, (24, 26, 32), (x + offset + 16, y + 46), 3)
    sign = pygame.Rect(x + 8, y + 5, 48, 13)
    pygame.draw.rect(screen, (38, 68, 90), sign, border_radius=2)
    text = font.render("CARS", True, (246, 220, 128))
    screen.blit(text, text.get_rect(center=sign.center))


def draw_showroom(screen, shop, bankroll, notice, exit_sign, mouse_pos, font_med, font_small, font_badge):
    from scene_ui import draw_wood_sign
    screen.fill((198, 214, 222))
    pygame.draw.rect(screen, (38, 64, 82), (0, 0, SCREEN_W, 84))
    title = font_med.render("DEALERSHIP", True, (246, 228, 152))
    screen.blit(title, title.get_rect(center=(SCREEN_W * 0.5, 26)))
    help_text = font_small.render("Drag a car into your truck to buy.", True, (224, 236, 242))
    screen.blit(help_text, help_text.get_rect(center=(SCREEN_W * 0.5, 55)))
    floor_y = DEALERSHIP_FLOOR_Y * SCENE_SCALE
    for index, (_, name, price) in enumerate(CAR_CATALOG):
        center = DEALERSHIP_DISPLAY_XS[index] * SCENE_SCALE
        panel = pygame.Rect(center - 215, 110, 430, floor_y - 110)
        pygame.draw.rect(screen, (226, 237, 242), panel, border_radius=6)
        pygame.draw.rect(screen, (116, 148, 164), panel, 3, border_radius=6)
        pygame.draw.rect(screen, (94, 115, 125), (center - 215, floor_y - 8, 430, 18))
        stock = any(entry.price == price for entry in shop.creatures)
        label = font_med.render(f"{name}  ${price}", True, (38, 64, 82))
        screen.blit(label, label.get_rect(center=(center, 166)))
        if not stock:
            sold = font_med.render("SOLD", True, (130, 76, 58))
            screen.blit(sold, sold.get_rect(center=(center, 310)))
    pygame.draw.rect(screen, (118, 134, 142), (0, floor_y + 10, SCREEN_W, SCREEN_H - floor_y))
    if notice:
        text = font_small.render(notice, True, (28, 48, 60))
        screen.blit(text, (30, 493))
    draw_wood_sign(screen, exit_sign, "EXIT", font_badge, exit_sign.collidepoint(mouse_pos), with_post=False)
    screen.blit(font_med.render(f"${bankroll}", True, (246, 228, 152)), (1105, 16))
