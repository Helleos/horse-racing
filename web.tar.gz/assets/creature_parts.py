"""Pymunk part constructors for torsos, limbs, hooves, and joints."""
from __future__ import annotations

import math
import pygame
import pymunk

from creature_config import (
    JointConfig,
    PartConfig,
)

# --- PHYSICS HELPERS ---


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def create_part(
    space: pymunk.Space,
    pos: tuple[float, float],
    part_cfg: PartConfig,
    shape_filter: pymunk.ShapeFilter,
    bottom_trim: float = 0.0,
) -> tuple[pymunk.Body, pymunk.Poly]:
    """Creates a box (or rounded-bottom) body part from a PartConfig."""
    body = pymunk.Body()
    body.position = pos
    w, h = part_cfg.size

    if bottom_trim > 0.0:
        y_bottom = max(-h / 2.0 + 1.0, h / 2.0 - bottom_trim)
        verts = [
            (-w / 2.0, -h / 2.0),
            (w / 2.0, -h / 2.0),
            (w / 2.0, y_bottom),
            (-w / 2.0, y_bottom),
        ]
        shape = pymunk.Poly(body, verts)
    elif part_cfg.shape_style == "rounded":
        radius = min(w, h) * 0.24
        verts = []
        for cx, cy, start in (
            (w / 2 - radius, -h / 2 + radius, -math.pi / 2),
            (w / 2 - radius, h / 2 - radius, 0.0),
            (-w / 2 + radius, h / 2 - radius, math.pi / 2),
            (-w / 2 + radius, -h / 2 + radius, math.pi),
        ):
            for i in range(4):
                angle = start + i * math.pi / 6
                verts.append((cx + radius * math.cos(angle), cy + radius * math.sin(angle)))
        shape = pymunk.Poly(body, verts)
    elif part_cfg.shape_style == "tapered":
        shape = pymunk.Poly(body, [(-w / 2, -h / 2), (w / 2, -h * 0.30),
                                  (w / 2, h * 0.30), (-w / 2, h / 2)])
    elif part_cfg.rounded_bottom:
        r = w / 2.0
        y_arc_center = h / 2.0 - r
        verts = [(-w / 2.0, -h / 2.0), (w / 2.0, -h / 2.0), (w / 2.0, y_arc_center)]
        for i in range(1, 6):
            angle = i * math.pi / 6.0
            verts.append((r * math.cos(angle), y_arc_center + r * math.sin(angle)))
        verts.append((-w / 2.0, y_arc_center))
        shape = pymunk.Poly(body, verts)
    else:
        shape = pymunk.Poly.create_box(body, part_cfg.size)

    shape.mass = part_cfg.mass
    shape.friction = part_cfg.friction
    shape.filter = shape_filter
    space.add(body, shape)
    return body, shape


def create_bent_leg(
    space: pymunk.Space,
    pos: tuple[float, float],
    part_cfg: PartConfig,
    shape_filter: pymunk.ShapeFilter,
    bottom_trim: float = 0.0,
) -> tuple[pymunk.Body, pymunk.Poly, pymunk.Poly, tuple[float, float], float, float]:
    """
    Creates a single rigid limb body composed of two segments (upper + lower)
    bent at a fixed knee/elbow angle (-15 to +15 deg). The bend is NOT a joint.
    Returns (body, upper_shape, lower_shape, foot_tip, knee_y, knee_radius).
    """
    body = pymunk.Body()
    body.position = pos
    w, h = part_cfg.size

    knee_ratio = max(0.25, min(0.75, part_cfg.knee_ratio))
    upper_h = h * knee_ratio
    lower_h = h - upper_h
    y_top = -h / 2.0
    y_knee = y_top + upper_h

    w_knee = w * (0.85 + 0.15 * part_cfg.lower_width_scale)
    w_low_bot = w * part_cfg.lower_width_scale

    upper_verts = [
        (-w / 2.0, y_top),
        (w / 2.0, y_top),
        (w_knee / 2.0, y_knee),
        (-w_knee / 2.0, y_knee),
    ]
    upper_shape = pymunk.Poly(body, upper_verts)
    upper_shape.mass = part_cfg.mass * (upper_h / h)
    upper_shape.friction = part_cfg.friction
    upper_shape.filter = shape_filter

    knee_rad = math.radians(max(-15.0, min(15.0, part_cfg.knee_deg)))
    dx, dy = math.sin(knee_rad), math.cos(knee_rad)
    px, py = dy, -dx

    eff_lower_h = max(4.0, lower_h - bottom_trim)
    tx_tip = dx * eff_lower_h
    ty_tip = y_knee + dy * eff_lower_h

    if bottom_trim <= 0.0 and part_cfg.rounded_bottom and eff_lower_h > w_low_bot * 0.6:
        r = w_low_bot / 2.0
        arc_len = eff_lower_h - r
        cx_arc = dx * arc_len
        cy_arc = y_knee + dy * arc_len
        lower_verts = [
            (-px * w_knee / 2.0, y_knee - py * w_knee / 2.0),
            (px * w_knee / 2.0, y_knee + py * w_knee / 2.0),
            (cx_arc + px * r, cy_arc + py * r),
        ]
        for i in range(1, 5):
            a = i * math.pi / 5.0
            lx = r * math.cos(a)
            ly = r * math.sin(a)
            lower_verts.append((cx_arc + lx * px + ly * dx, cy_arc + lx * py + ly * dy))
        lower_verts.append((cx_arc - px * r, cy_arc - py * r))
    else:
        lower_verts = [
            (-px * w_knee / 2.0, y_knee - py * w_knee / 2.0),
            (px * w_knee / 2.0, y_knee + py * w_knee / 2.0),
            (tx_tip + px * w_low_bot / 2.0, ty_tip + py * w_low_bot / 2.0),
            (tx_tip - px * w_low_bot / 2.0, ty_tip - py * w_low_bot / 2.0),
        ]
    lower_shape = pymunk.Poly(body, lower_verts)
    lower_shape.mass = part_cfg.mass * (lower_h / h)
    lower_shape.friction = part_cfg.friction
    lower_shape.filter = shape_filter

    space.add(body, upper_shape, lower_shape)

    foot_tip = (dx * lower_h, y_knee + dy * lower_h)
    return body, upper_shape, lower_shape, foot_tip, y_knee, w_knee / 2.0


def create_tail_part(
    space: pymunk.Space,
    pos: tuple[float, float],
    part_cfg: PartConfig,
    shape_filter: pymunk.ShapeFilter,
) -> tuple[pymunk.Body, pymunk.Poly]:
    """Creates a shaped tail Poly (dock on +x side, tip on -x side)."""
    body = pymunk.Body()
    body.position = pos
    w, h = part_cfg.size
    hw, hh = w / 2.0, h / 2.0
    style = part_cfg.shape_style

    if style == "tapered":
        verts = [
            (hw, -hh * 0.45),
            (hw, hh * 0.45),
            (0.0, hh * 0.85),
            (-hw, 0.0),
            (0.0, -hh * 0.85),
        ]
    elif style == "bushy":
        verts = [
            (hw, -hh * 0.40),
            (hw, hh * 0.40),
            (-hw * 0.25, hh * 1.15),
            (-hw, hh * 0.65),
            (-hw, -hh * 0.65),
            (-hw * 0.25, -hh * 1.15),
        ]
    elif style == "flowing":
        verts = [
            (hw, -hh * 0.42),
            (hw, hh * 0.42),
            (-hw * 0.25, hh * 0.95),
            (-hw, hh * 1.0),
            (-hw * 0.85, -hh * 0.15),
            (-hw * 0.15, -hh * 0.70),
        ]
    elif style == "forked":
        verts = [(hw, -hh * 0.40), (hw, hh * 0.40),
                 (-hw * 0.25, hh * 0.35), (-hw * 0.25, -hh * 0.35)]
    elif style == "ribbon":
        verts = [(hw, -hh * 0.25), (hw, hh * 0.25),
                 (-hw * 0.50, hh * 1.2), (-hw, hh * 0.75),
                 (-hw * 0.75, -hh * 0.45)]
    elif style == "rabbit":
        verts = [
            (hw, -hh * 0.45),
            (hw, hh * 0.45),
            (-hw * 0.72, hh * 0.48),
            (-hw, 0.0),
            (-hw * 0.72, -hh * 0.48),
        ]
    else:
        verts = [
            (hw, -hh * 0.50),
            (hw, hh * 0.50),
            (-hw, hh * 0.25),
            (-hw, -hh * 0.25),
        ]

    shape = pymunk.Poly(body, verts)
    shape.mass = part_cfg.mass
    shape.friction = part_cfg.friction
    shape.filter = shape_filter
    space.add(body, shape)
    return body, shape


def create_tooth_shape(
    body: pymunk.Body,
    center: tuple[float, float],
    size: tuple[float, float],
    mass: float,
    friction: float,
    shape_filter: pymunk.ShapeFilter,
    style: str,
    point_down: bool = True,
) -> pymunk.Poly:
    """A rectangular block, or a triangle aimed at the other row. Sensor tooth."""
    cx, cy = center
    w, h = size
    if style == "triangular":
        if point_down:
            verts = [
                (cx - w * 0.5, cy - h * 0.5),
                (cx + w * 0.5, cy - h * 0.5),
                (cx, cy + h * 0.5),
            ]
        else:
            verts = [
                (cx - w * 0.5, cy + h * 0.5),
                (cx + w * 0.5, cy + h * 0.5),
                (cx, cy - h * 0.5),
            ]
        shape = pymunk.Poly(body, verts)
        shape.mass = mass
        shape.friction = friction
        shape.filter = shape_filter
        shape.sensor = True
        return shape
    return create_offset_box(body, center, size, mass, friction, shape_filter, sensor=True)


def create_offset_box(
    body: pymunk.Body,
    center: tuple[float, float],
    size: tuple[float, float],
    mass: float,
    friction: float,
    shape_filter: pymunk.ShapeFilter,
    sensor: bool = False,
) -> pymunk.Poly:
    """Creates an axis-aligned box Poly attached at an offset on an existing body."""
    cx, cy = center
    hw, hh = size[0] / 2.0, size[1] / 2.0
    verts = [
        (cx - hw, cy - hh),
        (cx + hw, cy - hh),
        (cx + hw, cy + hh),
        (cx - hw, cy + hh),
    ]
    shape = pymunk.Poly(body, verts)
    shape.mass = mass
    shape.friction = friction
    shape.filter = shape_filter
    shape.sensor = sensor
    return shape


def create_ear_shape(
    body: pymunk.Body,
    ear_cfg: PartConfig,
    head_size: tuple[float, float],
    shape_filter: pymunk.ShapeFilter,
) -> pymunk.Poly:
    """Creates a convex ear Poly in head-local space according to shape_style."""
    hw, hh = head_size
    ew, eh = ear_cfg.size
    x0 = -hw / 2.0 + 2.0 + ear_cfg.anchor_offset[0]
    y0 = -hh / 2.0 + 3.0 + ear_cfg.anchor_offset[1]
    tip = max(0.1, min(0.85, ear_cfg.tip_offset))
    style = ear_cfg.shape_style
    carriage = max(0.0, min(1.0, ear_cfg.carriage))

    if carriage <= 0.0 and style == "curved":
        verts = [
            (x0, y0),
            (x0 + ew, y0),
            (x0 + ew * 0.88, y0 - eh * 0.55),
            (x0 + ew * (tip * 0.9), y0 - eh),
            (x0 + ew * 0.08, y0 - eh * 0.48),
        ]
    elif carriage <= 0.0 and style == "rounded":
        verts = [
            (x0, y0),
            (x0 + ew, y0),
            (x0 + ew * 0.92, y0 - eh * 0.72),
            (x0 + ew * 0.52, y0 - eh),
            (x0 + ew * 0.08, y0 - eh * 0.72),
        ]
    elif style == "rabbit":
        x_base = -hw * 0.16 + ear_cfg.anchor_offset[0]
        y_base = -hh * 0.40 + ear_cfg.anchor_offset[1]
        ux, uy = 0.54, -0.842
        px, py = -uy, ux
        half_w = ew * 0.5
        verts = [
            (x_base - px * half_w, y_base - py * half_w),
            (x_base + px * half_w, y_base + py * half_w),
            (x_base + ux * eh + px * half_w * 0.92, y_base + uy * eh + py * half_w * 0.92),
            (x_base + ux * eh - px * half_w * 0.92, y_base + uy * eh - py * half_w * 0.92),
        ]
    elif carriage <= 0.0:
        verts = [
            (x0, y0),
            (x0 + ew, y0),
            (x0 + ew * tip, y0 - eh),
        ]
    else:
        # Side-pointed ear swept toward the upright oval. carriage 0 keeps the
        # branches above; 1 is that oval. In between is the same interpolation.
        side = [
            (x0, y0),
            (x0 + ew, y0),
            (x0 + ew * (0.5 + 0.5 * tip), y0 - eh),
            (x0 + ew * tip * 0.35, y0 - eh),
        ]
        x_base = -hw * 0.16 + ear_cfg.anchor_offset[0]
        y_base = -hh * 0.40 + ear_cfg.anchor_offset[1]
        ux, uy = 0.54, -0.842
        px, py = -uy, ux
        half_w = ew * 0.5
        upright = [
            (x_base - px * half_w, y_base - py * half_w),
            (x_base + px * half_w, y_base + py * half_w),
            (x_base + ux * eh + px * half_w * 0.92, y_base + uy * eh + py * half_w * 0.92),
            (x_base + ux * eh - px * half_w * 0.92, y_base + uy * eh - py * half_w * 0.92),
        ]
        verts = [
            (
                side[i][0] + (upright[i][0] - side[i][0]) * carriage,
                side[i][1] + (upright[i][1] - side[i][1]) * carriage,
            )
            for i in range(4)
        ]

    shape = pymunk.Poly(body, verts)
    shape.mass = ear_cfg.mass
    shape.friction = ear_cfg.friction
    shape.filter = shape_filter
    return shape


def create_hoof_shape(
    body: pymunk.Body,
    leg_cfg: PartConfig,
    hoof_cfg: PartConfig,
    shape_filter: pymunk.ShapeFilter,
    foot_tip: tuple[float, float] | None = None,
) -> pymunk.Poly:
    """Creates a right-trapezoid hoof Poly aligned with the bottom of a (possibly bent) leg."""
    lw, lh = leg_cfg.size
    lower_w = lw * leg_cfg.lower_width_scale
    hw, hh = hoof_cfg.size
    ox, oy = hoof_cfg.anchor_offset

    if foot_tip is None:
        foot_tip = (0.0, lh / 2.0)

    knee_rad = math.radians(max(-15.0, min(15.0, leg_cfg.knee_deg)))
    dx, dy = math.sin(knee_rad), math.cos(knee_rad)
    px, py = dy, -dx

    x_left = -lower_w / 2.0 + ox
    x_top_right = lower_w / 2.0 + ox
    x_bot_right = max(x_top_right + 2.0, x_left + hw)
    style = hoof_cfg.shape_style

    if style == "thick":
        local_verts = [
            (x_left - 1.5, -hh + oy),
            (x_top_right + 1.5, -hh + oy),
            (x_bot_right + 3.0, oy - 1.5),
            (x_bot_right + 1.5, oy),
            (x_left - 1.5, oy),
        ]
    elif style == "thin":
        local_verts = [
            (x_left + 1.5, -hh + oy),
            (max(x_left + 4.0, x_top_right - 1.0), -hh + oy),
            (max(x_left + 6.0, x_bot_right - 2.0), oy),
            (x_left + 1.5, oy),
        ]
    elif style == "cloven":
        local_verts = [
            (x_left, -hh + oy),
            (x_top_right, -hh + oy),
            (x_bot_right + 4.0, oy - 2.5),
            (x_bot_right + 1.5, oy),
            (x_left - 1.5, oy),
        ]
    elif style == "rocker":
        local_verts = [
            (x_left, -hh + oy),
            (x_top_right, -hh + oy),
            (x_bot_right, oy - hh * 0.28),
            (x_left + hw * 0.62, oy + 1.5),
            (x_left + hw * 0.25, oy + 1.0),
            (x_left, oy - hh * 0.22),
        ]
    elif style == "pointed":
        local_verts = [
            (x_left, -hh + oy),
            (x_top_right, -hh + oy),
            (x_bot_right + hw * 0.45, oy - hh * 0.18),
            (x_bot_right + hw * 0.22, oy),
            (x_left, oy),
        ]
    elif style == "rabbit":
        toe_x = max(x_top_right + 6.0, x_left + hw)
        local_verts = [
            (x_left, -hh + oy),
            (toe_x * 0.86, -hh + oy),
            (toe_x, oy),
            (x_left, oy),
        ]
    else:
        local_verts = [
            (x_left, -hh + oy),
            (x_top_right, -hh + oy),
            (x_bot_right, oy),
            (x_left, oy),
        ]

    verts = [
        (foot_tip[0] + lx * px + ly * dx, foot_tip[1] + lx * py + ly * dy)
        for lx, ly in local_verts
    ]

    shape = pymunk.Poly(body, verts)
    shape.mass = hoof_cfg.mass
    shape.friction = hoof_cfg.friction
    shape.elasticity = hoof_cfg.elasticity
    shape.filter = shape_filter
    shape.sensor = False
    return shape


def create_hand_shape(
    body: pymunk.Body,
    arm_cfg: PartConfig,
    hand_cfg: PartConfig,
    shape_filter: pymunk.ShapeFilter,
    foot_tip: tuple[float, float] | None = None,
) -> pymunk.Poly:
    """Creates a tapered hand Poly aligned with the tip of a (possibly bent) arm."""
    aw, ah = arm_cfg.size
    hw, hh = hand_cfg.size
    if foot_tip is None:
        foot_tip = (0.0, ah / 2.0)

    knee_rad = math.radians(max(-15.0, min(15.0, arm_cfg.knee_deg)))
    dx, dy = math.sin(knee_rad), math.cos(knee_rad)
    px, py = dy, -dx

    wrist_half = max(aw * 0.48, hw * 0.42)
    palm_half = max(wrist_half, hw * 0.58)
    local_verts = [
        (-wrist_half, -hh),
        (wrist_half, -hh),
        (palm_half, -hh * 0.48),
        (0.0, 0.0),
        (-palm_half, -hh * 0.48),
    ]
    verts = [
        (foot_tip[0] + lx * px + ly * dx, foot_tip[1] + lx * py + ly * dy)
        for lx, ly in local_verts
    ]

    shape = pymunk.Poly(body, verts)
    shape.mass = hand_cfg.mass
    shape.friction = hand_cfg.friction
    shape.filter = shape_filter
    return shape


def attach_part(
    space: pymunk.Space,
    body_a: pymunk.Body,
    body_b: pymunk.Body,
    anchor_world_pos: tuple[float, float],
    joint_cfg: JointConfig | None,
) -> tuple[pymunk.DampedRotarySpring | None, pymunk.RotaryLimitJoint, list[pymunk.Constraint]]:
    """Pins two bodies together with joint limits/spring, or rigidly if joint_cfg is None."""
    pivot = pymunk.PivotJoint(body_a, body_b, anchor_world_pos)

    if joint_cfg is None:
        weld = pymunk.RotaryLimitJoint(body_a, body_b, 0.0, 0.0)
        space.add(pivot, weld)
        return None, weld, [pivot, weld]

    min_rad = math.radians(joint_cfg.min_deg)
    max_rad = math.radians(joint_cfg.max_deg)
    rest_rad = math.radians(joint_cfg.rest_deg)
    limit = pymunk.RotaryLimitJoint(body_a, body_b, min_rad, max_rad)

    spring = pymunk.DampedRotarySpring(
        body_a,
        body_b,
        rest_angle=-rest_rad,
        stiffness=joint_cfg.stiffness,
        damping=joint_cfg.damping,
    )

    if joint_cfg.progressive:

        def progressive_torque(spring_obj, relative_angle):
            current_angle = -relative_angle
            angle_error = relative_angle - spring_obj.rest_angle

            cur_max = limit.max
            cur_min = limit.min
            if current_angle > 0 and cur_max > 0:
                ratio = current_angle / cur_max
            elif current_angle < 0 and cur_min < 0:
                ratio = current_angle / cur_min
            else:
                ratio = 0.0

            ratio = min(abs(ratio), 1.5)
            resistance_scale = 0.1 + 0.9 * (ratio**2)
            return angle_error * spring_obj.stiffness * resistance_scale

        spring.torque_func = progressive_torque

    space.add(pivot, limit, spring)
    return spring, limit, [pivot, limit, spring]


def is_body_touching(body: pymunk.Body, target_shape: pymunk.Shape) -> bool:
    """Returns True if the body has an active contact arbiter with target_shape."""
    touching = False

    def check(arbiter):
        nonlocal touching
        if target_shape in arbiter.shapes:
            touching = True

    body.each_arbiter(check)
    return touching


def draw_poly_shape(
    screen: pygame.Surface,
    shape: pymunk.Poly,
    color: tuple[int, int, int],
    camera_x: float,
):
    """Draws a Pymunk Poly shape in world coordinates offset by camera_x."""
    body = shape.body
    points = []
    for v in shape.get_vertices():
        wx, wy = body.local_to_world(v)
        points.append((wx - camera_x, wy))
    pygame.draw.polygon(screen, color, points)
