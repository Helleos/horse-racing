from __future__ import annotations

import sys
import weakref
import pygame


def enable_dpi_awareness():
    if sys.platform != "win32":
        return
    import ctypes

    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


class HiResSurface:
    def __init__(self, real_surface: pygame.Surface, scale: float):
        self._real = real_surface
        self.scale = scale

    def get_width(self) -> int:
        return max(1, int(round(self._real.get_width() / self.scale)))

    def get_height(self) -> int:
        return max(1, int(round(self._real.get_height() / self.scale)))

    def get_size(self) -> tuple[int, int]:
        return (self.get_width(), self.get_height())

    def get_rect(self, **kwargs) -> pygame.Rect:
        r = pygame.Rect(0, 0, self.get_width(), self.get_height())
        for k, v in kwargs.items():
            setattr(r, k, v)
        return r


class HiResFont:
    _instances: weakref.WeakSet["HiResFont"] = weakref.WeakSet()

    def __init__(self, name: str, size: int, scale: float, bold: bool = False, italic: bool = False):
        self._name = name
        self._size = size
        self._bold = bold
        self._italic = italic
        self.scale = scale
        self._font = pygame.font.SysFont(name, max(1, int(round(size * scale))), bold=bold, italic=italic)
        HiResFont._instances.add(self)

    def set_scale(self, scale: float):
        if abs(scale - self.scale) > 1e-3:
            self.scale = scale
            self._font = pygame.font.SysFont(
                self._name, max(1, int(round(self._size * scale))), bold=self._bold, italic=self._italic
            )

    @classmethod
    def update_all_scales(cls, scale: float):
        for f in list(cls._instances):
            f.set_scale(scale)

    def render(self, text: str, antialias: bool, color, background=None) -> HiResSurface:
        if background is None:
            surf = self._font.render(text, antialias, color)
        else:
            surf = self._font.render(text, antialias, color, background)
        return HiResSurface(surf, self.scale)

    def size(self, text: str) -> tuple[int, int]:
        w, h = self._font.size(text)
        return (max(0, int(round(w / self.scale))), max(0, int(round(h / self.scale))))

    def get_height(self) -> int:
        return max(1, int(round(self._font.get_height() / self.scale)))


class HiResScreen:
    _active: "HiResScreen | None" = None

    @classmethod
    def overlay(
        cls,
        real_surface: pygame.Surface,
        logical_size: tuple[int, int],
        scale: float,
        viewport: pygame.Rect | None = None,
    ) -> "HiResScreen":
        """Draw logical coordinates into a surface, optionally within a screen viewport."""
        view = cls.__new__(cls)
        view._real = real_surface
        view._logical_size = logical_size
        view.scale = max(1e-6, scale)
        view._viewport = real_surface.get_rect() if viewport is None else viewport.copy()
        view._ox = view._viewport.x
        view._oy = view._viewport.y
        return view

    def __init__(self, real_surface: pygame.Surface, logical_size: tuple[int, int], scale: float):
        self._real = real_surface
        self._logical_size = logical_size
        self.scale = scale
        self._ox = 0
        self._oy = 0
        self._viewport = real_surface.get_rect()
        HiResScreen._active = self
        self.set_viewport(*real_surface.get_size())

    def set_viewport(self, win_w: int, win_h: int):
        lw, lh = self._logical_size
        self.scale = min(win_w / lw, win_h / lh)
        vw = int(round(lw * self.scale))
        vh = int(round(lh * self.scale))
        self._ox = (win_w - vw) // 2
        self._oy = (win_h - vh) // 2
        self._viewport = pygame.Rect(self._ox, self._oy, vw, vh)
        self._real.set_clip(None)
        self._real.fill((10, 12, 18))
        self._real.set_clip(self._viewport)
        HiResFont.update_all_scales(self.scale)

    def clear_margins(self):
        if self._ox <= 0 and self._oy <= 0:
            return
        rw, rh = self._real.get_size()
        vp = self._viewport
        self._real.set_clip(None)
        if vp.left > 0:
            self._real.fill((10, 12, 18), (0, 0, vp.left, rh))
        if vp.right < rw:
            self._real.fill((10, 12, 18), (vp.right, 0, rw - vp.right, rh))
        if vp.top > 0:
            self._real.fill((10, 12, 18), (0, 0, rw, vp.top))
        if vp.bottom < rh:
            self._real.fill((10, 12, 18), (0, vp.bottom, rw, rh - vp.bottom))
        self._real.set_clip(vp)

    def to_logical(self, pos: tuple[int, int]) -> tuple[int, int]:
        lw, lh = self._logical_size
        lx = int((pos[0] - self._ox) / max(1e-6, self.scale))
        ly = int((pos[1] - self._oy) / max(1e-6, self.scale))
        return (max(0, min(lw - 1, lx)), max(0, min(lh - 1, ly)))

    def fill(self, color, rect=None):
        if rect is None:
            return self._real.fill(color, self._viewport)
        return self._real.fill(color, _scale_rect(rect, self.scale, self._ox, self._oy))

    def get_size(self) -> tuple[int, int]:
        return self._logical_size

    def get_width(self) -> int:
        return self._logical_size[0]

    def get_height(self) -> int:
        return self._logical_size[1]

    def get_clip(self) -> pygame.Rect:
        r = self._real.get_clip()
        return pygame.Rect(
            int(round((r.x - self._ox) / self.scale)),
            int(round((r.y - self._oy) / self.scale)),
            int(round(r.w / self.scale)),
            int(round(r.h / self.scale)),
        )

    def set_clip(self, rect):
        if rect is None:
            self._real.set_clip(self._viewport)
        else:
            self._real.set_clip(_scale_rect(rect, self.scale, self._ox, self._oy).clip(self._viewport))

    def blit(self, source, dest):
        s = self.scale
        if isinstance(dest, pygame.Rect):
            pos = (self._ox + int(round(dest.x * s)), self._oy + int(round(dest.y * s)))
        else:
            pos = (self._ox + int(round(dest[0] * s)), self._oy + int(round(dest[1] * s)))

        if isinstance(source, HiResSurface):
            return self._real.blit(source._real, pos)

        tw = max(1, int(round(source.get_width() * s)))
        th = max(1, int(round(source.get_height() * s)))
        scaled = pygame.transform.smoothscale(source, (tw, th))
        blend_flags = 0 if self._real.get_flags() & pygame.SRCALPHA else pygame.BLEND_ALPHA_SDL2
        return self._real.blit(scaled, pos, special_flags=blend_flags)


def _scale_pt(pt: tuple[float, float], s: float, ox: int = 0, oy: int = 0) -> tuple[int, int]:
    return (ox + int(round(pt[0] * s)), oy + int(round(pt[1] * s)))


def _scale_rect(rect, s: float, ox: int = 0, oy: int = 0) -> pygame.Rect:
    x, y, w, h = rect[0], rect[1], rect[2], rect[3]
    x0 = int(round(x * s))
    y0 = int(round(y * s))
    x1 = int(round((x + w) * s))
    y1 = int(round((y + h) * s))
    return pygame.Rect(ox + x0, oy + y0, max(1, x1 - x0), max(1, y1 - y0))


def _scale_w(w: int, s: float) -> int:
    return 0 if w == 0 else max(1, int(round(w * s)))


def install_hires_hooks():
    if getattr(pygame.draw, "_hires_installed", False):
        return
    pygame.draw._hires_installed = True  # type: ignore[attr-defined]

    orig_rect = pygame.draw.rect
    orig_circle = pygame.draw.circle
    orig_ellipse = pygame.draw.ellipse
    orig_arc = pygame.draw.arc
    orig_line = pygame.draw.line
    orig_lines = pygame.draw.lines
    orig_polygon = pygame.draw.polygon
    orig_rotozoom = pygame.transform.rotozoom
    orig_flip = pygame.transform.flip

    def draw_rect(surface, color, rect, width=0, **kwargs):
        if isinstance(surface, HiResScreen):
            s = surface.scale
            kw = dict(kwargs)
            for rk in (
                "border_radius",
                "border_top_left_radius",
                "border_top_right_radius",
                "border_bottom_left_radius",
                "border_bottom_right_radius",
            ):
                if rk in kw and kw[rk] > 0:
                    kw[rk] = max(1, int(round(kw[rk] * s)))
            return orig_rect(surface._real, color, _scale_rect(rect, s, surface._ox, surface._oy), _scale_w(width, s), **kw)
        return orig_rect(surface, color, rect, width, **kwargs)

    def draw_circle(surface, color, center, radius, width=0, **kwargs):
        if isinstance(surface, HiResScreen):
            s = surface.scale
            return orig_circle(
                surface._real,
                color,
                _scale_pt(center, s, surface._ox, surface._oy),
                max(1, int(round(radius * s))),
                _scale_w(width, s),
                **kwargs,
            )
        return orig_circle(surface, color, center, radius, width, **kwargs)

    def draw_ellipse(surface, color, rect, width=0):
        if isinstance(surface, HiResScreen):
            s = surface.scale
            return orig_ellipse(surface._real, color, _scale_rect(rect, s, surface._ox, surface._oy), _scale_w(width, s))
        return orig_ellipse(surface, color, rect, width)

    def draw_arc(surface, color, rect, start_angle, stop_angle, width=1):
        if isinstance(surface, HiResScreen):
            s = surface.scale
            return orig_arc(surface._real, color, _scale_rect(rect, s, surface._ox, surface._oy), start_angle, stop_angle, max(1, int(round(width * s))))
        return orig_arc(surface, color, rect, start_angle, stop_angle, width)

    def draw_line(surface, color, start_pos, end_pos, width=1):
        if isinstance(surface, HiResScreen):
            s = surface.scale
            return orig_line(
                surface._real,
                color,
                _scale_pt(start_pos, s, surface._ox, surface._oy),
                _scale_pt(end_pos, s, surface._ox, surface._oy),
                max(1, int(round(width * s))),
            )
        return orig_line(surface, color, start_pos, end_pos, width)

    def draw_lines(surface, color, closed, points, width=1):
        if isinstance(surface, HiResScreen):
            s = surface.scale
            return orig_lines(
                surface._real,
                color,
                closed,
                [_scale_pt(p, s, surface._ox, surface._oy) for p in points],
                max(1, int(round(width * s))),
            )
        return orig_lines(surface, color, closed, points, width)

    def draw_polygon(surface, color, points, width=0):
        if isinstance(surface, HiResScreen):
            s = surface.scale
            return orig_polygon(
                surface._real,
                color,
                [_scale_pt(p, s, surface._ox, surface._oy) for p in points],
                _scale_w(width, s),
            )
        return orig_polygon(surface, color, points, width)

    def tx_rotozoom(surface, angle, scale):
        if isinstance(surface, HiResSurface):
            return HiResSurface(orig_rotozoom(surface._real, angle, scale), surface.scale)
        return orig_rotozoom(surface, angle, scale)

    def tx_flip(surface, flip_x, flip_y):
        if isinstance(surface, HiResSurface):
            return HiResSurface(orig_flip(surface._real, flip_x, flip_y), surface.scale)
        return orig_flip(surface, flip_x, flip_y)

    pygame.draw.rect = draw_rect
    pygame.draw.circle = draw_circle
    pygame.draw.ellipse = draw_ellipse
    pygame.draw.arc = draw_arc
    pygame.draw.line = draw_line
    pygame.draw.lines = draw_lines
    pygame.draw.polygon = draw_polygon
    pygame.transform.rotozoom = tx_rotozoom
    pygame.transform.flip = tx_flip

    orig_display_flip = pygame.display.flip

    def display_flip():
        active = HiResScreen._active
        if active is not None:
            active.clear_margins()
        return orig_display_flip()

    pygame.display.flip = display_flip
