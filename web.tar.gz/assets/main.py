# /// script
# dependencies = [
#   "pygame-ce",
#   "cffi",
# ]
# ///
"""Browser entry point. The desktop game in the repo root is left unchanged."""
import asyncio

import cffi  # wasm cffi must be imported before pymunk's extension
import pygame  # noqa: F401
import pymunk  # noqa: F401

from horse_racing import main

asyncio.run(main())
