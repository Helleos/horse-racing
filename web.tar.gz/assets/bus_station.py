"""Bus-station dialogue and a balloon ride over the actual frontier map."""
from __future__ import annotations

from dataclasses import dataclass
import math
import pygame

from racing_constants import (
    OW_COLS, OW_ROWS, OW_TILE, OW_WIDTH, OW_HEIGHT,
    PATH_COLOR, SCENE_SCALE, SCREEN_W, SCREEN_H, TERRAIN_COLORS,
)
from scene_ui import draw_speech_bubble, draw_wood_sign

BUS_DIALOGUE = (
    "Hey partner, you lost?",
    "I'll give you a ride back to your ranch",
    "Hop in",
)
BUS_FLOOR_Y = 1195.0
BUS_NPC_X = 420.0
BUS_EXIT_RECT = pygame.Rect(24, 18, 110, 38)
BUS_BOARD_RECT = pygame.Rect(650, 82, 390, 520)
BUS_RIDE_RECT = pygame.Rect(755, 613, 245, 46)


@dataclass
class BusStationVisit:
    dialogue_index: int = 0
    dialogue_time: float = 0.0

    @property
    def speech(self) -> str:
        return BUS_DIALOGUE[self.dialogue_index]

    @property
    def ready(self) -> bool:
        return self.dialogue_index == len(BUS_DIALOGUE) - 1

    def advance(self):
        self.dialogue_index = min(len(BUS_DIALOGUE) - 1, self.dialogue_index + 1)
        self.dialogue_time = 0.0

    def update(self, dt: float):
        self.dialogue_time += max(0.0, dt)
        if self.dialogue_time >= 3.0 and not self.ready:
            self.advance()


def _smooth(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return t * t * (3.0 - 2.0 * t)


def home_landing_point(ranch_pos: tuple[float, float]) -> tuple[float, float]:
    return (max(80.0, min(OW_WIDTH - 80.0, ranch_pos[0] - 112.0)),
            max(80.0, min(OW_HEIGHT - 80.0, ranch_pos[1] + 96.0)))


@dataclass
class BalloonFlight:
    origin: tuple[float, float]
    destination: tuple[float, float]
    elapsed: float = 0.0
    duration: float = 6.4

    def update(self, dt: float):
        self.elapsed = min(self.duration, self.elapsed + max(0.0, dt))

    @property
    def complete(self) -> bool:
        return self.elapsed >= self.duration

    @property
    def position(self) -> tuple[float, float]:
        t = _smooth((self.elapsed - 1.1) / (self.duration - 2.2))
        return (self.origin[0] + (self.destination[0] - self.origin[0]) * t,
                self.origin[1] + (self.destination[1] - self.origin[1]) * t)

    @property
    def airborne(self) -> float:
        return min(_smooth(self.elapsed / 1.1), _smooth((self.duration - self.elapsed) / 1.1))

    @property
    def zoom(self) -> float:
        return 1.0 - 0.78 * self.airborne

    @property
    def lift(self) -> float:
        return 82.0 * self.airborne

    def camera(self) -> tuple[float, float]:
        x, y = self.position
        view_w, view_h = SCREEN_W / self.zoom, SCREEN_H / self.zoom
        return (max(0.0, min(OW_WIDTH - view_w, x - view_w * 0.5)),
                max(0.0, min(OW_HEIGHT - view_h, y - view_h * 0.5)))


def draw_truck(screen, x: float, y: float, scale: float = 1.0, facing: int = 1):
    def point(px, py):
        return (x + (px - 55) * scale * facing, y + (py - 32) * scale)

    def rect(color, px, py, w, h, border=0):
        sx = x + (px - 55) * scale if facing > 0 else x - (px + w - 55) * scale
        sy = y + (py - 32) * scale
        pygame.draw.rect(screen, color, (sx, sy, w * scale, h * scale), border,
                         border_radius=max(1, int(4 * scale)))

    rect((218, 222, 232), 6, 12, 58, 32)
    rect((92, 102, 124), 6, 12, 58, 32, max(1, int(2 * scale)))
    rect((206, 62, 54), 64, 20, 38, 24)
    rect((206, 62, 54), 66, 10, 22, 14)
    rect((152, 212, 244), 72, 12, 13, 9)
    for px in (22, 50, 88):
        pygame.draw.circle(screen, (28, 28, 34), point(px, 44), 7 * scale)


def draw_balloon(screen, x: float, y: float, width: float, height: float):
    envelope = pygame.Rect(0, 0, int(width), int(height))
    envelope.center = (int(x), int(y))
    pygame.draw.ellipse(screen, (190, 56, 48), envelope)
    pygame.draw.ellipse(screen, (240, 170, 58), envelope.inflate(-width * 0.38, 0))
    pygame.draw.ellipse(screen, (220, 92, 52), envelope.inflate(-width * 0.70, 0))
    bottom = y + height * 0.42
    pygame.draw.polygon(screen, (156, 52, 46),
                        [(x - width * 0.28, bottom), (x + width * 0.28, bottom),
                         (x + width * 0.08, bottom + height * 0.12),
                         (x - width * 0.08, bottom + height * 0.12)])
    return (x, bottom + height * 0.12)


def draw_world_bus_station(screen, x: float, y: float, font):
    bx, by = draw_balloon(screen, x + 32, y - 70, 60, 78)
    for offset in (-16, 16):
        pygame.draw.line(screen, (116, 86, 54), (bx + offset * .3, by),
                         (x + 32 + offset, y + 30), 2)
    pygame.draw.rect(screen, (224, 198, 148), (x + 5, y + 33, 54, 26), border_radius=2)
    pygame.draw.rect(screen, (98, 70, 46), (x + 10, y + 44, 10, 15))
    pygame.draw.rect(screen, (124, 184, 202), (x + 28, y + 42, 20, 10))
    pygame.draw.polygon(screen, (190, 64, 50), [(x + 2, y + 34), (x + 12, y + 25),
                                              (x + 53, y + 25), (x + 62, y + 34)])
    label = font.render("BUS", True, (255, 242, 202))
    screen.blit(label, label.get_rect(center=(int(x + 31), int(y + 31))))


def station_hit_rect(x: float, y: float) -> pygame.Rect:
    """The station building and its visible balloon both open the stop."""
    return pygame.Rect(int(x // OW_TILE) * OW_TILE, int(y // OW_TILE) * OW_TILE - 110,
                       OW_TILE, OW_TILE + 110)


def draw_bus_direction_sign(screen, sign, camera_x, camera_y, font):
    dx, dy = sign.direction
    # Stand on the verge, leaving the road and its landmark tiles clear.
    x = sign.x - camera_x + (60 if dy else 0)
    y = sign.y - camera_y + (60 if dx else 0)
    board = pygame.Rect(int(x - 24), int(y - 26), 48, 18)
    pygame.draw.line(screen, (104, 78, 48), (x, board.bottom), (x, y + 6), 3)
    pygame.draw.rect(screen, (112, 84, 52), board, border_radius=2)
    pygame.draw.rect(screen, (152, 122, 82), board, 1, border_radius=2)
    ink = (222, 208, 174)
    label = font.render("BUS", True, ink)
    screen.blit(label, (board.x + 4, board.y + 2))
    ax, ay = board.right - 10, board.centery
    pygame.draw.line(screen, ink, (ax - dx * 4, ay - dy * 4),
                     (ax + dx * 4, ay + dy * 4), 1)
    pygame.draw.polygon(screen, ink,
                        [(ax + dx * 6, ay + dy * 6),
                         (ax - dy * 3, ay + dx * 3),
                         (ax + dy * 3, ay - dx * 3)])
    return board


def draw_bus_station_scene(screen, phys, visit, mouse_pos, font_med, font_badge, bankroll):
    screen.fill((122, 180, 206))
    pygame.draw.rect(screen, (192, 176, 136), (0, 400, SCREEN_W, SCREEN_H - 400))
    pygame.draw.rect(screen, (116, 94, 70), (0, 669, SCREEN_W, 51))
    pygame.draw.rect(screen, (218, 196, 154), (46, 168, 446, 348), border_radius=4)
    pygame.draw.rect(screen, (124, 88, 56), (46, 168, 446, 348), 4, border_radius=4)
    pygame.draw.polygon(screen, (178, 58, 48), [(30, 181), (70, 132), (466, 132), (509, 181)])
    pygame.draw.rect(screen, (72, 50, 34), (83, 286, 112, 230))
    pygame.draw.rect(screen, (154, 206, 220), (240, 253, 198, 110), border_radius=3)
    pygame.draw.line(screen, (84, 112, 120), (339, 253), (339, 363), 4)
    pygame.draw.rect(screen, (98, 68, 42), (268, 458, 183, 20), border_radius=2)
    for bx in (285, 426):
        pygame.draw.line(screen, (98, 68, 42), (bx, 478), (bx, 522), 6)
    sign = pygame.Rect(91, 197, 356, 45)
    draw_wood_sign(screen, sign, "BUS STATION", font_med, False, with_post=False)

    bx, by = draw_balloon(screen, 858, 242, 274, 323)
    pygame.draw.line(screen, (116, 86, 54), (bx - 30, by), (696, 544), 4)
    pygame.draw.line(screen, (116, 86, 54), (bx + 30, by), (917, 544), 4)
    pygame.draw.rect(screen, (104, 72, 44), (666, 612, 342, 15), border_radius=3)
    draw_truck(screen, 838, 579, 3.1)

    phys.draw_horses(screen)
    npc = next(iter(phys.horses), None)
    if npc is not None:
        head = npc.creature.bodies.get("head", npc.creature.bodies["torso"])
        bubble = pygame.Rect(int(head.position.x * SCENE_SCALE + 46),
                             int(head.position.y * SCENE_SCALE - 118), 355, 100)
        draw_speech_bubble(screen, bubble, visit.speech, font_med)
    draw_wood_sign(screen, BUS_RIDE_RECT, "HOP IN", font_med,
                   visit.ready and (BUS_RIDE_RECT.collidepoint(mouse_pos) or BUS_BOARD_RECT.collidepoint(mouse_pos)),
                   text_color=(255, 238, 188) if visit.ready else (180, 164, 128), with_post=False)
    draw_wood_sign(screen, BUS_EXIT_RECT, "EXIT", font_badge, BUS_EXIT_RECT.collidepoint(mouse_pos), with_post=False)
    screen.blit(font_med.render(f"${bankroll}", True, (255, 240, 186)), (SCREEN_W - 104, 27))


def draw_balloon_world(screen, world, flight, font):
    zoom = flight.zoom
    camera_x, camera_y = flight.camera()
    view_w, view_h = SCREEN_W / zoom, SCREEN_H / zoom

    def project(x, y):
        return ((x - camera_x) * zoom, (y - camera_y) * zoom)

    # At a distance, sample terrain in small blocks rather than drawing
    # thousands of full-resolution tiles. Roads still use their real tiles.
    group = 1 if zoom > 0.6 else (2 if zoom > 0.35 else 4)
    c0, c1 = max(0, int(camera_x // OW_TILE)), min(OW_COLS - 1, int((camera_x + view_w) // OW_TILE))
    r0, r1 = max(0, int(camera_y // OW_TILE)), min(OW_ROWS - 1, int((camera_y + view_h) // OW_TILE))
    for r in range((r0 // group) * group, r1 + 1, group):
        for c in range((c0 // group) * group, c1 + 1, group):
            terrain = world.get_tile_terrain(c, r)
            sx, sy = project(c * OW_TILE, r * OW_TILE)
            pygame.draw.rect(screen, TERRAIN_COLORS[terrain],
                             (sx, sy, OW_TILE * group * zoom + 1, OW_TILE * group * zoom + 1))
    for r in range(r0, r1 + 1):
        for c in range(c0, c1 + 1):
            if (c, r) in world.path_tiles:
                sx, sy = project(c * OW_TILE, r * OW_TILE)
                pygame.draw.rect(screen, PATH_COLOR, (sx, sy, OW_TILE * zoom + 1, OW_TILE * zoom + 1))

    for tree in world.trees:
        sx, sy = project(tree.x, tree.y)
        if -8 <= sx <= SCREEN_W + 8 and -8 <= sy <= SCREEN_H + 8:
            pygame.draw.circle(screen, (48, 104, 57), (sx, sy), max(1.5, 12 * zoom))
    landmarks = [(r.x, r.y, (172, 68, 52)) for r in world.ranches]
    landmarks += [(s.x, s.y, (224, 202, 142)) for s in world.shops]
    landmarks += [(s.x, s.y, (224, 148, 64)) for s in world.bus_stations]
    landmarks += [(c.x, c.y, (94, 120, 168)) for c in world.racecourses]
    landmarks += [(*world.gene_factory_pos, (172, 112, 214)), (*world.dna_lab_pos, (94, 200, 164))]
    for x, y, color in landmarks:
        sx, sy = project(x, y)
        if -12 <= sx <= SCREEN_W + 12 and -12 <= sy <= SCREEN_H + 12:
            pygame.draw.rect(screen, color, (sx - 5, sy - 5, 10, 10), border_radius=2)
    home_x, home_y = project(*world.your_ranch_pos)
    pygame.draw.polygon(screen, (230, 178, 66), [(home_x - 12, home_y - 3),
                                              (home_x, home_y - 16), (home_x + 12, home_y - 3)])
    pygame.draw.rect(screen, (74, 124, 180), (home_x - 9, home_y - 3, 18, 17))
    if 30 <= home_x <= SCREEN_W - 30 and 30 <= home_y <= SCREEN_H - 30:
        label = font.render("Your Ranch", True, (255, 245, 202))
        screen.blit(label, label.get_rect(midbottom=(int(home_x), int(home_y - 21))))

    tx, ty = project(*flight.position)
    sway = math.sin(flight.elapsed * 2.1) * 3 * flight.airborne
    airborne_y = ty - flight.lift + sway
    pygame.draw.ellipse(screen, (88, 88, 64), (tx - 46, ty + 11, 92, 18))
    bx, by = draw_balloon(screen, tx, airborne_y - 134, 112, 134)
    facing = 1 if flight.destination[0] >= flight.origin[0] else -1
    for offset in (-34, 32):
        pygame.draw.line(screen, (112, 80, 48), (bx + offset * 0.35, by),
                         (tx + offset, airborne_y - 17), 2)
    draw_truck(screen, tx, airborne_y, facing=facing)
    badge = pygame.Rect(18, 18, 236, 40)
    draw_wood_sign(screen, badge, "HEADING HOME", font, False, with_post=False)
