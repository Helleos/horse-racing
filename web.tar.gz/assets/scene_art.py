"""Horse previews, world sprites, potion flasks, and the rancher hat."""
from __future__ import annotations

import hashlib
import math
import random
import pygame
import pymunk

from gene import Genome

from creature import (
    Creature,
    build_creature,
    compute_spawn_y,
)

from hires import HiResScreen

from racing_constants import (
    HORSE_CANVAS_H,
    HORSE_CANVAS_W,
    HORSE_CENTER_X,
    HORSE_FLOOR_Y,
)

from racing_models import (
    FossilNode,
    HorseEntry,
    TreeData,
    WildHorse,
    _PREVIEW_CACHE,
)

def get_horse_preview(entry: HorseEntry, target_size: tuple[int, int] = (84, 66)) -> pygame.Surface:
    key = (entry.entry_id, target_size[0], target_size[1], entry.is_dead)
    if key in _PREVIEW_CACHE:
        return _PREVIEW_CACHE[key]

    sp = pymunk.Space()
    sp.gravity = (0, 900)
    fl = pymunk.Segment(sp.static_body, (-600, HORSE_FLOOR_Y), (600, HORSE_FLOOR_Y), 5.0)
    fl.friction = 1.0
    sp.add(fl)

    spawn_y = compute_spawn_y(entry.config, floor_y=HORSE_FLOOR_Y)
    cfg = entry.config.with_(
        spawn_pos=(0.0, spawn_y),
        gait=entry.config.gait.with_(mode="walk", enabled=False),
    )
    c = build_creature(sp, cfg)
    for _ in range(18):
        c.update(1.0 / 60.0, fl)
        sp.step(1.0 / 60.0)
        t = c.bodies["torso"]
        t.velocity = (0.0, t.velocity.y)
        t.angular_velocity *= 0.7

    tw, th = target_size
    canvas = pygame.Surface((max(1, tw), max(1, th)), pygame.SRCALPHA)
    view = HiResScreen.overlay(canvas, (HORSE_CANVAS_W, HORSE_CANVAS_H), tw / HORSE_CANVAS_W)
    torso = c.bodies["torso"]
    c.dead = entry.is_dead
    c.draw(view, torso.position.x - HORSE_CENTER_X)
    c.remove_from_space(sp)

    _PREVIEW_CACHE[key] = canvas
    return canvas


def draw_world_tree(screen: pygame.Surface, tr: TreeData, sx: float, sy: float):
    sc = tr.scale
    pygame.draw.ellipse(screen, (0, 0, 0, 55), (sx - 24 * sc, sy + 2 * sc, 48 * sc, 12 * sc))
    if tr.kind == "cactus":
        pygame.draw.rect(screen, (62, 134, 68), (sx - 6 * sc, sy - 54 * sc, 12 * sc, 58 * sc), border_radius=6)
        pygame.draw.rect(screen, (62, 134, 68), (sx - 18 * sc, sy - 38 * sc, 14 * sc, 8 * sc), border_radius=4)
        pygame.draw.rect(screen, (62, 134, 68), (sx - 18 * sc, sy - 50 * sc, 8 * sc, 18 * sc), border_radius=4)
        pygame.draw.rect(screen, (62, 134, 68), (sx + 4 * sc, sy - 32 * sc, 14 * sc, 8 * sc), border_radius=4)
        pygame.draw.rect(screen, (62, 134, 68), (sx + 10 * sc, sy - 46 * sc, 8 * sc, 20 * sc), border_radius=4)
        pygame.draw.line(screen, (88, 162, 92), (sx - 2 * sc, sy - 48 * sc), (sx - 2 * sc, sy - 4 * sc), 2)
    elif tr.kind == "pine":
        pygame.draw.rect(screen, (78, 52, 32), (sx - 5 * sc, sy - 26 * sc, 10 * sc, 32 * sc), border_radius=2)
        pygame.draw.polygon(screen, (26, 66, 34), [(sx, sy - 74 * sc), (sx - 26 * sc, sy - 38 * sc), (sx + 26 * sc, sy - 38 * sc)])
        pygame.draw.polygon(screen, (32, 78, 40), [(sx, sy - 60 * sc), (sx - 30 * sc, sy - 22 * sc), (sx + 30 * sc, sy - 22 * sc)])
    elif tr.kind == "palm":
        pygame.draw.line(screen, (124, 88, 52), (sx, sy + 2 * sc), (sx + 5 * sc, sy - 48 * sc), max(4, int(7 * sc)))
        top_x, top_y = sx + 5 * sc, sy - 48 * sc
        for ang_deg in (-155, -120, -45, 0, 30):
            r = math.radians(ang_deg)
            ex = top_x + math.cos(r) * 28 * sc
            ey = top_y + math.sin(r) * 20 * sc
            pygame.draw.line(screen, (64, 148, 58), (top_x, top_y), (ex, ey), max(3, int(5 * sc)))
    elif tr.kind == "acacia" or tr.terrain in ("desert", "savanna"):
        pygame.draw.rect(screen, (112, 82, 54), (sx - 5 * sc, sy - 38 * sc, 10 * sc, 44 * sc), border_radius=3)
        pygame.draw.line(screen, (112, 82, 54), (sx, sy - 22 * sc), (sx - 16 * sc, sy - 40 * sc), max(2, int(4 * sc)))
        pygame.draw.line(screen, (112, 82, 54), (sx, sy - 26 * sc), (sx + 16 * sc, sy - 42 * sc), max(2, int(4 * sc)))
        canopy = (122, 138, 58) if tr.terrain == "savanna" else (104, 126, 62)
        canopy_hi = (144, 156, 72) if tr.terrain == "savanna" else (124, 142, 74)
        pygame.draw.ellipse(screen, canopy, (sx - 34 * sc, sy - 58 * sc, 68 * sc, 24 * sc))
        pygame.draw.ellipse(screen, canopy_hi, (sx - 24 * sc, sy - 66 * sc, 48 * sc, 18 * sc))
    else:
        pygame.draw.rect(screen, (96, 64, 38), (sx - 6 * sc, sy - 36 * sc, 12 * sc, 42 * sc), border_radius=3)
        pygame.draw.circle(screen, (42, 92, 42), (int(sx), int(sy - 48 * sc)), int(28 * sc))
        pygame.draw.circle(screen, (52, 108, 48), (int(sx - 14 * sc), int(sy - 42 * sc)), int(19 * sc))
        pygame.draw.circle(screen, (52, 108, 48), (int(sx + 14 * sc), int(sy - 42 * sc)), int(19 * sc))
        pygame.draw.circle(screen, (66, 128, 56), (int(sx - 4 * sc), int(sy - 56 * sc)), int(18 * sc))

    for dx, dy in tr.apples:
        ax = int(sx + dx)
        ay = int(sy + dy)
        if tr.kind == "cactus":
            pygame.draw.ellipse(screen, (226, 72, 108), (ax - 3, ay - 4, 6, 8))
            pygame.draw.circle(screen, (248, 168, 118), (ax - 1, ay - 1), 1)
        else:
            pygame.draw.circle(screen, (218, 44, 46), (ax, ay), 4)
            pygame.draw.circle(screen, (248, 118, 112), (ax - 1, ay - 1), 1)
            pygame.draw.circle(screen, (78, 168, 66), (ax + 2, ay - 4), 2)


def draw_world_apple(screen: pygame.Surface, ax: float, ay: float, kind: str = "apple"):
    pygame.draw.ellipse(screen, (25, 35, 22), (ax - 6, ay + 4, 12, 4))
    if kind == "prickly_pear":
        pygame.draw.ellipse(screen, (226, 72, 108), (int(ax - 5), int(ay - 6), 10, 12))
        pygame.draw.circle(screen, (248, 178, 120), (int(ax - 2), int(ay - 2)), 2)
        return
    pygame.draw.circle(screen, (216, 44, 46), (int(ax), int(ay)), 6)
    pygame.draw.circle(screen, (248, 112, 108), (int(ax - 2), int(ay - 2)), 2)
    pygame.draw.line(screen, (96, 62, 34), (ax, ay - 5), (ax + 1, ay - 8), 2)
    pygame.draw.circle(screen, (78, 168, 66), (int(ax + 3), int(ay - 7)), 2)


_FOSSIL_SURFACE_CACHE: dict[tuple[int, int, tuple[int, int]], pygame.Surface] = {}

_FOSSIL_ROCK_PALETTES: tuple[
    tuple[tuple[int, int, int], tuple[int, int, int], tuple[int, int, int], tuple[int, int, int]],
    ...,
] = (
    ((168, 156, 134), (118, 108, 90), (198, 186, 162), (76, 68, 56)),
    ((126, 130, 140), (84, 88, 98), (156, 162, 174), (54, 58, 66)),
    ((176, 138, 98), (128, 96, 66), (206, 168, 126), (86, 62, 42)),
    ((104, 102, 110), (68, 66, 74), (136, 134, 144), (44, 42, 50)),
    ((156, 152, 142), (112, 108, 100), (186, 182, 170), (74, 72, 64)),
)


def fossil_visual_params(
    genome: Genome | None,
    fallback_variant: int = 0,
    fallback_seed: int = 0,
) -> tuple[int, int]:
    if genome is None:
        return (fallback_variant % 5, fallback_seed)
    sig = "|".join(
        f"{k}:{genome.genes[k].allele_a[:8]}{genome.genes[k].allele_b[:8]}"
        for k in ("size_somatic", "horn_dev", "neck_morph", "wing_dev", "bone_density")
        if k in genome.genes
    )
    digest = hashlib.blake2b(sig.encode("ascii"), digest_size=4).digest()
    seed = int.from_bytes(digest, "big")
    return (seed % 5, seed)


def build_fossil_surface(
    variant: int = 0,
    seed: int = 0,
    target_size: tuple[int, int] = (48, 40),
) -> pygame.Surface:
    v_idx = variant % 5
    key = (v_idx, seed, target_size)
    cached = _FOSSIL_SURFACE_CACHE.get(key)
    if cached is not None:
        return cached

    rng_loc = random.Random(seed * 7919 + v_idx * 131)
    pal_base, pal_dark, pal_light, pal_rim = _FOSSIL_ROCK_PALETTES[(seed >> 3) % len(_FOSSIL_ROCK_PALETTES)]

    sp = pygame.Surface((96, 80), pygame.SRCALPHA)
    cx, cy = 48.0, 39.0
    rock_pts: list[tuple[float, float]] = []
    for i in range(9):
        ang = (i / 9.0) * 2.0 * math.pi + rng_loc.uniform(-0.14, 0.14)
        rx = rng_loc.uniform(36.0, 44.0)
        ry = rng_loc.uniform(28.0, 35.0)
        rock_pts.append((cx + math.cos(ang) * rx, cy + math.sin(ang) * ry))

    bevel_pts = [(x, y + 4.5) for x, y in rock_pts]
    pygame.draw.polygon(sp, pal_dark, bevel_pts)
    pygame.draw.polygon(sp, pal_rim, bevel_pts, 3)
    pygame.draw.polygon(sp, pal_base, rock_pts)

    hi_pts = [
        (cx + (x - cx) * 0.82 - 2.0, cy + (y - cy) * 0.78 - 2.0)
        for x, y in rock_pts[:5]
    ]
    if len(hi_pts) >= 3:
        pygame.draw.polygon(sp, pal_light, hi_pts)
        pygame.draw.polygon(sp, pal_base, [
            (cx + (x - cx) * 0.70, cy + (y - cy) * 0.66) for x, y in rock_pts
        ])

    for _ in range(2):
        idx_c = rng_loc.randrange(len(rock_pts))
        p_edge = rock_pts[idx_c]
        p_in = (
            p_edge[0] + (cx - p_edge[0]) * rng_loc.uniform(0.22, 0.40),
            p_edge[1] + (cy - p_edge[1]) * rng_loc.uniform(0.22, 0.40),
        )
        pygame.draw.line(sp, pal_rim, p_edge, p_in, 2)
    for _ in range(4):
        fx = cx + rng_loc.uniform(-28.0, 28.0)
        fy = cy + rng_loc.uniform(-20.0, 20.0)
        pygame.draw.circle(sp, pal_dark if rng_loc.random() < 0.5 else pal_light, (int(fx), int(fy)), 2)

    pygame.draw.polygon(sp, pal_rim, rock_pts, 3)

    rot = rng_loc.uniform(-0.24, 0.24)
    flip_x = -1.0 if (seed & 16) else 1.0
    cr, sr = math.cos(rot), math.sin(rot)
    bone_col = (238, 228, 202)
    bone_hi = (250, 244, 226)
    bone_rim = (72, 60, 48)

    def fp(lx: float, ly: float) -> tuple[float, float]:
        sx = lx * flip_x
        return (cx + sx * cr - ly * sr, cy + sx * sr + ly * cr)

    if v_idx == 0:
        spiral_pts: list[tuple[float, float]] = []
        steps = 26
        for i in range(steps):
            t = i / (steps - 1)
            th = t * 3.5 * math.pi
            rad = 2.0 + t * 21.0
            spiral_pts.append(fp(math.cos(th) * rad, math.sin(th) * rad * 0.88))
        for i in range(len(spiral_pts) - 1):
            t = i / (len(spiral_pts) - 1)
            w_rim = max(4, int(round(5 + 9 * t)))
            w_in = max(2, w_rim - 3)
            pygame.draw.line(sp, bone_rim, spiral_pts[i], spiral_pts[i + 1], w_rim)
            pygame.draw.line(sp, bone_col, spiral_pts[i], spiral_pts[i + 1], w_in)
        for i in range(8, len(spiral_pts), 2):
            p_out = spiral_pts[i]
            dx_r, dy_r = p_out[0] - cx, p_out[1] - cy
            d_r = max(1.0, math.hypot(dx_r, dy_r))
            p_in = (p_out[0] - (dx_r / d_r) * 5.0, p_out[1] - (dy_r / d_r) * 5.0)
            pygame.draw.line(sp, bone_rim, p_in, p_out, 2)
        pygame.draw.circle(sp, bone_hi, (int(spiral_pts[-1][0]), int(spiral_pts[-1][1])), 4)

    elif v_idx == 1:
        horn_pts = [fp(-10, -10), fp(-18, -18), fp(-28, -20), fp(-22, -11), fp(-12, -5)]
        pygame.draw.polygon(sp, bone_hi, horn_pts)
        pygame.draw.polygon(sp, bone_rim, horn_pts, 2)
        skull_pts = [
            fp(-18, -9), fp(-4, -14), fp(10, -8), fp(24, -1),
            fp(22, 6), fp(7, 8), fp(-4, 12), fp(-16, 7),
        ]
        pygame.draw.polygon(sp, bone_col, skull_pts)
        pygame.draw.polygon(sp, bone_rim, skull_pts, 2)
        eye_p = fp(-2, -3)
        pygame.draw.circle(sp, bone_rim, (int(eye_p[0]), int(eye_p[1])), 5)
        pygame.draw.circle(sp, pal_dark, (int(eye_p[0]), int(eye_p[1])), 3)
        for tx in (8, 13, 18):
            pygame.draw.line(sp, bone_rim, fp(tx, 3), fp(tx, 7), 2)

    elif v_idx == 2:
        spine = [fp(-22 + i * 9, -6 + math.sin(i * 0.7) * 4) for i in range(6)]
        for i in range(len(spine) - 1):
            pygame.draw.line(sp, bone_rim, spine[i], spine[i + 1], 5)
            pygame.draw.line(sp, bone_col, spine[i], spine[i + 1], 3)
        for i, vp in enumerate(spine[:-1]):
            rib_len = 13.0 + (2 - abs(i - 2)) * 3.5
            rib_a = fp(-22 + i * 9 - 2, -6 + math.sin(i * 0.7) * 4 + rib_len)
            rib_b = fp(-22 + i * 9 + 4, -6 + math.sin(i * 0.7) * 4 - rib_len * 0.65)
            pygame.draw.line(sp, bone_rim, vp, rib_a, 5)
            pygame.draw.line(sp, bone_col, vp, rib_a, 3)
            pygame.draw.line(sp, bone_rim, vp, rib_b, 5)
            pygame.draw.line(sp, bone_col, vp, rib_b, 3)
            pygame.draw.circle(sp, bone_hi, (int(vp[0]), int(vp[1])), 3)

    elif v_idx == 3:
        body_pts = [
            fp(-22, 0), fp(-15, -13), fp(2, -13), fp(21, -7),
            fp(24, 0), fp(21, 7), fp(2, 13), fp(-15, 13),
        ]
        pygame.draw.polygon(sp, bone_col, body_pts)
        pygame.draw.polygon(sp, bone_rim, body_pts, 2)
        for sx in (-8, -1, 6, 13):
            hw = 12 - max(0, (sx + 4) // 3)
            pygame.draw.line(sp, bone_rim, fp(sx, -hw), fp(sx + 2, 0), 2)
            pygame.draw.line(sp, bone_rim, fp(sx, hw), fp(sx + 2, 0), 2)
        pygame.draw.line(sp, bone_rim, fp(-16, 0), fp(19, 0), 5)
        pygame.draw.line(sp, bone_hi, fp(-16, 0), fp(19, 0), 3)
        pygame.draw.line(sp, bone_rim, fp(-12, -11), fp(-12, 11), 2)

    else:
        b0, b1 = fp(-20, -11), fp(8, 7)
        pygame.draw.line(sp, bone_rim, b0, b1, 10)
        pygame.draw.line(sp, bone_col, b0, b1, 6)
        for kx, ky in ((-21, -14), (-18, -7)):
            kp = fp(kx, ky)
            pygame.draw.circle(sp, bone_rim, (int(kp[0]), int(kp[1])), 5)
            pygame.draw.circle(sp, bone_hi, (int(kp[0]), int(kp[1])), 3)
        hoof_pts = [fp(8, 2), fp(22, 0), fp(24, 9), fp(13, 14), fp(7, 10)]
        pygame.draw.polygon(sp, bone_col, hoof_pts)
        pygame.draw.polygon(sp, bone_rim, hoof_pts, 2)
        pygame.draw.line(sp, bone_rim, fp(14, 7), fp(23, 5), 2)

    scaled = pygame.transform.smoothscale(sp, target_size)
    _FOSSIL_SURFACE_CACHE[key] = scaled
    return scaled


def draw_world_fossil(screen: pygame.Surface, fos: FossilNode, sx: float, sy: float):
    f_var, f_seed = fossil_visual_params(fos.genome, fos.variant, fos.fossil_id)
    sp = build_fossil_surface(f_var, f_seed, (42, 35))
    pygame.draw.ellipse(screen, (25, 28, 26), (sx - 17, sy + 9, 34, 9))
    screen.blit(sp, sp.get_rect(center=(int(sx), int(sy))))


def draw_wild_horse_actual(screen: pygame.Surface, wh: WildHorse, sx: float, sy: float):
    s = getattr(screen, "scale", 1.0)
    img = get_horse_preview(wh.entry, (int(round(84 * s)), int(round(66 * s))))
    if wh.facing < 0:
        img = pygame.transform.flip(img, True, False)
    if wh.flipped or wh.entry.is_dead:
        img = pygame.transform.flip(img, False, True)
    else:
        pygame.draw.ellipse(screen, (25, 35, 22), (sx - 20, sy + 18, 40, 9))
    if hasattr(screen, "_real"):
        screen._real.blit(img, (screen._ox + int(round((sx - 42) * s)), screen._oy + int(round((sy - 44) * s))))
    else:
        screen.blit(img, (sx - 42, sy - 44))


_CARCASS_SURFACE_CACHE: dict[tuple[int, int], pygame.Surface] = {}


def build_carcass_surface(target_size: tuple[int, int] = (168, 112)) -> pygame.Surface:
    cached = _CARCASS_SURFACE_CACHE.get(target_size)
    if cached is not None:
        return cached

    sp = pygame.Surface((168, 112), pygame.SRCALPHA)
    pygame.draw.ellipse(sp, (24, 14, 14, 72), (10, 86, 148, 18))

    outer_pts = [
        (16, 92),
        (14, 68),
        (22, 42),
        (44, 24),
        (78, 20),
        (114, 24),
        (138, 38),
        (150, 62),
        (152, 92),
    ]
    pygame.draw.polygon(sp, (226, 154, 140), outer_pts)
    hi_pts = [
        (26, 46),
        (48, 28),
        (80, 24),
        (112, 28),
        (132, 40),
        (114, 38),
        (74, 34),
        (42, 40),
    ]
    pygame.draw.polygon(sp, (244, 186, 172), hi_pts)

    cavity_pts = [
        (30, 88),
        (32, 54),
        (56, 42),
        (96, 44),
        (124, 58),
        (138, 76),
        (134, 88),
    ]
    pygame.draw.polygon(sp, (162, 34, 48), cavity_pts)
    inner_pts = [
        (40, 84),
        (44, 58),
        (68, 48),
        (98, 52),
        (122, 68),
        (120, 84),
    ]
    pygame.draw.polygon(sp, (112, 20, 32), inner_pts)
    pygame.draw.polygon(sp, (88, 18, 26), cavity_pts, 2)

    bone_rim = (158, 138, 118)
    bone_col = (244, 234, 214)
    bone_hi = (254, 248, 236)

    rib_arcs = (
        [(44, 44), (37, 58), (36, 74), (45, 86)],
        [(62, 42), (55, 58), (54, 75), (63, 86)],
        [(80, 42), (74, 58), (74, 75), (82, 86)],
        [(98, 45), (94, 59), (94, 73), (100, 82)],
    )
    for arc in rib_arcs:
        pygame.draw.lines(sp, bone_rim, False, arc, 9)
        pygame.draw.lines(sp, bone_col, False, arc, 6)
        pygame.draw.lines(sp, bone_hi, False, arc[:3], 2)
        pygame.draw.circle(sp, bone_col, arc[-1], 3)

    spine_pts = [(42, 42), (62, 40), (82, 40), (100, 44)]
    for vx, vy in spine_pts:
        pygame.draw.circle(sp, bone_rim, (vx, vy), 6)
        pygame.draw.circle(sp, bone_col, (vx, vy), 4)

    hip_pts = [(108, 60), (124, 62), (132, 70), (118, 72)]
    pygame.draw.polygon(sp, bone_rim, hip_pts)
    pygame.draw.polygon(sp, bone_col, [(110, 62), (123, 63), (129, 69), (118, 70)])
    leg_pts = [(106, 78), (126, 76), (132, 83), (108, 84)]
    pygame.draw.polygon(sp, bone_rim, leg_pts)
    pygame.draw.polygon(sp, bone_col, [(108, 79), (125, 78), (129, 82), (109, 83)])

    pygame.draw.polygon(sp, (108, 36, 40), outer_pts, 3)

    scaled = pygame.transform.smoothscale(sp, target_size)
    _CARCASS_SURFACE_CACHE[target_size] = scaled
    return scaled


def build_potion_flask_surface(fill_frac: float = 1.0) -> pygame.Surface:
    fill_frac = max(0.0, min(1.0, fill_frac))
    sp = pygame.Surface((52, 62), pygame.SRCALPHA)
    # Neck & conical glass flask body
    pygame.draw.rect(sp, (190, 226, 242, 215), (20, 4, 12, 16))
    pygame.draw.rect(sp, (220, 242, 250, 240), (18, 2, 16, 4), border_radius=2)
    flask_pts = [(20, 18), (32, 18), (46, 54), (6, 54)]
    pygame.draw.polygon(sp, (186, 224, 242, 175), flask_pts)
    if fill_frac > 0.02:
        y_surf = 52.0 - 20.0 * fill_frac
        lx = 8.0 + 7.0 * fill_frac
        rx = 44.0 - 7.0 * fill_frac
        liq_pts = [(lx, y_surf), (rx, y_surf), (44, 52), (8, 52)]
        pygame.draw.polygon(sp, (186, 52, 226, 240), liq_pts)
        pygame.draw.line(sp, (232, 146, 252), (lx, y_surf), (rx, y_surf), 2)
        for bx, by, bc in (
            (18, 44, (255, 224, 96)),
            (28, 40, (124, 244, 255)),
            (33, 48, (255, 160, 232)),
            (22, 49, (255, 255, 255)),
        ):
            if by >= y_surf + 3:
                pygame.draw.circle(sp, bc, (bx, by), 2)
    pygame.draw.polygon(sp, (140, 194, 218), flask_pts, 2)
    return sp

def draw_rancher_hat(screen: pygame.Surface, rancher: Creature, cam_x: float = 0.0):
    head = rancher.bodies.get("head")
    if head is None:
        return
    hw, hh = rancher.config.head.size
    brim_x = max(16.0, hw * 0.78)
    brim_y = max(10.0, hh * 0.46)
    crown_x = brim_x * 0.50
    crown_top = brim_y + max(12.0, hh * 0.55)
    brim_pts = [
        (wx - cam_x, wy)
        for wx, wy in (
            head.local_to_world((-brim_x, -brim_y)),
            head.local_to_world((brim_x, -brim_y)),
            head.local_to_world((brim_x * 0.90, -brim_y - 5.0)),
            head.local_to_world((-brim_x * 0.90, -brim_y - 5.0)),
        )
    ]
    crown_pts = [
        (wx - cam_x, wy)
        for wx, wy in (
            head.local_to_world((-crown_x, -brim_y - 4.0)),
            head.local_to_world((crown_x, -brim_y - 4.0)),
            head.local_to_world((crown_x * 0.72, -crown_top)),
            head.local_to_world((-crown_x * 0.72, -crown_top)),
        )
    ]
    pygame.draw.polygon(screen, (116, 72, 36), brim_pts)
    pygame.draw.polygon(screen, (134, 86, 44), crown_pts)

def draw_world_oasis_tile(
    screen: pygame.Surface,
    sx: float,
    sy: float,
    h_val: int,
    u: bool,
    d: bool,
    l: bool,
    r: bool,
    ul: bool,
    ur: bool,
    dl: bool,
    dr: bool,
):
    grass = (72, 160, 74)
    sand = (206, 184, 126)
    water = (44, 174, 202)
    water_edge = (34, 148, 180)

    # Continuous turquoise water base
    pygame.draw.rect(screen, water, (sx, sy, 65, 65))

    # Subtle shallow-water border along exposed edges
    if not u:
        pygame.draw.rect(screen, water_edge, (sx, sy, 65, 20))
    if not d:
        pygame.draw.rect(screen, water_edge, (sx, sy + 45, 65, 20))
    if not l:
        pygame.draw.rect(screen, water_edge, (sx, sy, 20, 65))
    if not r:
        pygame.draw.rect(screen, water_edge, (sx + 45, sy, 20, 65))

    # Sand shoreline (only on borders/inner corners adjacent to non-oasis tiles)
    if not u:
        pygame.draw.rect(screen, sand, (sx, sy, 65, 16))
    if not d:
        pygame.draw.rect(screen, sand, (sx, sy + 49, 65, 16))
    if not l:
        pygame.draw.rect(screen, sand, (sx, sy, 16, 65))
    if not r:
        pygame.draw.rect(screen, sand, (sx + 49, sy, 16, 65))

    if u and l and not ul:
        pygame.draw.rect(screen, sand, (sx, sy, 16, 16), border_bottom_right_radius=14)
    if u and r and not ur:
        pygame.draw.rect(screen, sand, (sx + 49, sy, 16, 16), border_bottom_left_radius=14)
    if d and l and not dl:
        pygame.draw.rect(screen, sand, (sx, sy + 49, 16, 16), border_top_right_radius=14)
    if d and r and not dr:
        pygame.draw.rect(screen, sand, (sx + 49, sy + 49, 16, 16), border_top_left_radius=14)

    # Gentle corner bevels on convex shoreline bends
    if not u and not l:
        pygame.draw.polygon(screen, sand, [(sx + 16, sy + 16), (sx + 23, sy + 16), (sx + 16, sy + 23)])
    if not u and not r:
        pygame.draw.polygon(screen, sand, [(sx + 49, sy + 16), (sx + 42, sy + 16), (sx + 49, sy + 23)])
    if not d and not l:
        pygame.draw.polygon(screen, sand, [(sx + 16, sy + 49), (sx + 23, sy + 49), (sx + 16, sy + 42)])
    if not d and not r:
        pygame.draw.polygon(screen, sand, [(sx + 49, sy + 49), (sx + 42, sy + 49), (sx + 49, sy + 42)])

    # Lush green grass rim outside the sand
    if not u:
        pygame.draw.rect(screen, grass, (sx, sy, 65, 11))
    if not d:
        pygame.draw.rect(screen, grass, (sx, sy + 54, 65, 11))
    if not l:
        pygame.draw.rect(screen, grass, (sx, sy, 11, 65))
    if not r:
        pygame.draw.rect(screen, grass, (sx + 54, sy, 11, 65))

    if u and l and not ul:
        pygame.draw.rect(screen, grass, (sx, sy, 11, 11), border_bottom_right_radius=10)
    if u and r and not ur:
        pygame.draw.rect(screen, grass, (sx + 54, sy, 11, 11), border_bottom_left_radius=10)
    if d and l and not dl:
        pygame.draw.rect(screen, grass, (sx, sy + 54, 11, 11), border_top_right_radius=10)
    if d and r and not dr:
        pygame.draw.rect(screen, grass, (sx + 54, sy + 54, 11, 11), border_top_left_radius=10)

    if not u and not l:
        pygame.draw.polygon(screen, grass, [(sx + 11, sy + 11), (sx + 17, sy + 11), (sx + 11, sy + 17)])
    if not u and not r:
        pygame.draw.polygon(screen, grass, [(sx + 54, sy + 11), (sx + 48, sy + 11), (sx + 54, sy + 17)])
    if not d and not l:
        pygame.draw.polygon(screen, grass, [(sx + 11, sy + 54), (sx + 17, sy + 54), (sx + 11, sy + 48)])
    if not d and not r:
        pygame.draw.polygon(screen, grass, [(sx + 54, sy + 54), (sx + 48, sy + 54), (sx + 54, sy + 48)])

    # Sparse, clean water & shore accents
    if u and d and l and r:
        if h_val % 5 == 0:
            rx = sx + 20 + (h_val % 15)
            ry = sy + 24 + ((h_val >> 3) % 15)
            pygame.draw.line(screen, (156, 232, 244), (rx, ry), (rx + 12, ry), 2)
        elif h_val % 9 == 0:
            lx, ly = int(sx + 28 + (h_val % 9)), int(sy + 30)
            pygame.draw.circle(screen, (70, 168, 76), (lx, ly), 4)
            if h_val % 2 == 0:
                pygame.draw.circle(screen, (248, 178, 202), (lx + 1, ly - 1), 2)
    elif not u and h_val % 3 == 0:
        bx, by = sx + 26 + (h_val % 12), sy + 12
        pygame.draw.line(screen, (42, 108, 44), (bx, by), (bx - 2, by - 6), 2)
        pygame.draw.line(screen, (42, 108, 44), (bx + 3, by), (bx + 4, by - 7), 2)


def draw_world_forest_tile(screen: pygame.Surface, sx: float, sy: float, h_val: int):
    # Subtle mossy patch on ~half of tiles
    if h_val % 2 == 0:
        ox = 12 + (h_val % 18)
        oy = 16 + ((h_val >> 3) % 18)
        pygame.draw.ellipse(screen, (22, 54, 28), (sx + ox, sy + oy, 28, 20))

    # Keep ground simple: at most 1 clean foliage accent on select tiles
    if h_val % 3 == 0:
        cx = sx + 22 + (h_val % 20)
        cy = sy + 28 + ((h_val >> 4) % 18)
        pygame.draw.circle(screen, (22, 58, 30), (int(cx - 5), int(cy + 2)), 7)
        pygame.draw.circle(screen, (26, 68, 34), (int(cx + 5), int(cy + 2)), 7)
        pygame.draw.circle(screen, (36, 86, 42), (int(cx), int(cy - 3)), 8)
    elif h_val % 5 == 0:
        cx = sx + 24 + (h_val % 18)
        cy = sy + 38 + ((h_val >> 5) % 12)
        pygame.draw.rect(screen, (66, 46, 28), (cx - 2, cy - 3, 4, 6))
        pygame.draw.polygon(screen, (24, 64, 32), [(cx, cy - 18), (cx - 9, cy - 3), (cx + 9, cy - 3)])
        pygame.draw.polygon(screen, (34, 84, 40), [(cx, cy - 23), (cx - 6, cy - 12), (cx + 6, cy - 12)])
    elif h_val % 11 == 0:
        fx = sx + 20 + (h_val % 20)
        fy = sy + 36 + ((h_val >> 2) % 14)
        pygame.draw.line(screen, (52, 112, 48), (fx, fy), (fx - 5, fy - 6), 2)
        pygame.draw.line(screen, (52, 112, 48), (fx, fy), (fx + 5, fy - 6), 2)


def draw_world_racecourse(screen: pygame.Surface, rsx: float, rsy: float, is_arena: bool):
    if is_arena:
        # Clean stone Colosseum Arena
        pygame.draw.ellipse(screen, (118, 108, 96), (rsx + 4, rsy + 14, 56, 42))
        pygame.draw.ellipse(screen, (168, 158, 142), (rsx + 4, rsy + 9, 56, 38))
        pygame.draw.ellipse(screen, (72, 64, 56), (rsx + 4, rsy + 9, 56, 38), 2)
        # Three clean front arches
        for ax, ay in ((rsx + 14, rsy + 41), (rsx + 29, rsy + 44), (rsx + 44, rsy + 41)):
            pygame.draw.rect(screen, (48, 42, 40), (ax, ay, 6, 8), border_radius=2)
        # Crimson border & sandy arena floor
        pygame.draw.ellipse(screen, (172, 64, 52), (rsx + 12, rsy + 15, 40, 26))
        pygame.draw.ellipse(screen, (208, 176, 124), (rsx + 16, rsy + 18, 32, 20))
        # Two crisp banner flags
        for fx in (rsx + 16, rsx + 48):
            pygame.draw.line(screen, (72, 58, 44), (fx, rsy + 12), (fx, rsy + 3), 2)
            pygame.draw.polygon(screen, (206, 54, 48), [(fx, rsy + 3), (fx + 6, rsy + 5), (fx, rsy + 8)])
    else:
        # Clean Horse Racecourse
        pygame.draw.ellipse(screen, (238, 236, 228), (rsx + 3, rsy + 16, 58, 42))
        pygame.draw.ellipse(screen, (154, 110, 70), (rsx + 5, rsy + 18, 54, 38))
        pygame.draw.ellipse(screen, (238, 236, 228), (rsx + 13, rsy + 26, 38, 22))
        pygame.draw.ellipse(screen, (68, 144, 62), (rsx + 15, rsy + 28, 34, 18))
        # Checkered finish line
        for row_i in range(4):
            for col_i in range(2):
                chk_col = (246, 246, 248) if (row_i + col_i) % 2 == 0 else (28, 28, 32)
                pygame.draw.rect(screen, chk_col, (rsx + 30 + col_i * 3, rsy + 48 + row_i * 2, 3, 2))
        # Grandstand with red-and-white striped canopy
        pygame.draw.rect(screen, (192, 182, 164), (rsx + 10, rsy + 11, 44, 11), border_radius=2)
        roof_pts = [(rsx + 7, rsy + 12), (rsx + 13, rsy + 4), (rsx + 51, rsy + 4), (rsx + 57, rsy + 12)]
        pygame.draw.polygon(screen, (192, 52, 48), roof_pts)
        for sx_stripe in (rsx + 19, rsx + 30, rsx + 41):
            pygame.draw.rect(screen, (244, 238, 226), (sx_stripe, rsy + 5, 4, 7))
        pygame.draw.polygon(screen, (112, 30, 28), roof_pts, 2)


def draw_world_convenience_store(screen: pygame.Surface, ssx: float, ssy: float, font_badge):
    # Simple shadow base & building box
    pygame.draw.rect(screen, (72, 76, 84), (ssx + 5, ssy + 49, 54, 7), border_radius=3)
    pygame.draw.rect(screen, (232, 234, 238), (ssx + 7, ssy + 16, 50, 35), border_radius=3)
    pygame.draw.rect(screen, (78, 86, 98), (ssx + 7, ssy + 16, 50, 35), 2, border_radius=3)
    # Iconic 3-color convenience-store stripe fascia
    pygame.draw.rect(screen, (236, 114, 38), (ssx + 7, ssy + 18, 50, 3))
    pygame.draw.rect(screen, (42, 168, 88), (ssx + 7, ssy + 21, 50, 3))
    pygame.draw.rect(screen, (214, 54, 52), (ssx + 7, ssy + 24, 50, 3))
    # Clean blue windows & center glass door
    for wx in (ssx + 11, ssx + 39):
        pygame.draw.rect(screen, (124, 202, 228), (wx, ssy + 32, 14, 12), border_radius=2)
        pygame.draw.line(screen, (226, 248, 255), (wx + 3, ssy + 41), (wx + 10, ssy + 34), 2)
        pygame.draw.rect(screen, (68, 82, 96), (wx, ssy + 32, 14, 12), 1, border_radius=2)
    pygame.draw.rect(screen, (92, 170, 198), (ssx + 27, ssy + 32, 10, 18), border_radius=1)
    pygame.draw.rect(screen, (58, 72, 86), (ssx + 27, ssy + 32, 10, 18), 1, border_radius=1)
    # Crisp "24H" sign on top
    sign_r = pygame.Rect(int(ssx + 16), int(ssy + 4), 32, 14)
    pygame.draw.rect(screen, (24, 96, 104), sign_r, border_radius=3)
    pygame.draw.rect(screen, (246, 238, 206), sign_r, 1, border_radius=3)
    badge = font_badge.render("24H", True, (255, 244, 198))
    screen.blit(badge, badge.get_rect(center=sign_r.center))
