"""Physics creature. Configuration, parts, and drawing live in sibling modules."""
from __future__ import annotations

from creature_config import *
from creature_blueprints import *
from creature_parts import *
from creature_parts import _lerp
from creature_draw import CreatureDrawMixin

@dataclass
class Creature(CreatureDrawMixin):
    config: CreatureConfig
    bodies: dict[str, pymunk.Body]
    shapes: dict[str, pymunk.Shape]
    springs: dict[str, pymunk.DampedRotarySpring]
    limits: dict[str, pymunk.RotaryLimitJoint]
    constraints: list[pymunk.Constraint]
    knee_caps: dict[str, tuple[float, float]] = field(default_factory=dict)
    total_mass: float = 30.0
    gait_phase: float = 0.0
    gait_blend: float = 0.0
    run_blend: float = 0.0
    drunk: bool = False
    tired: bool = False
    hungry: bool = False
    unconscious: bool = False
    frenzied: bool = False
    dead: bool = False
    swirl_phase: float = 0.0
    eat_time: float = 0.0
    wing_phase: float = 0.0
    wing_angle_deg: float = 12.0
    track_progress: float = 0.0
    nearest_ahead_dist: float = 9999.0
    asleep_timer: float = 0.0
    asleep_cooldown: float = 3.2
    bolt_timer: float = 0.0
    bolted: bool = False
    balk_timer: float = 0.0
    balk_cooldown: float = 3.8
    spasm: float = 0.0
    spasm_left: float = 0.0
    spasm_cooldown: float = 12.0
    spasm_mode: str = ""
    sentience: float = 0.0
    can_speak: bool = False
    quip: str = ""
    quip_timer: float = 0.0
    quip_cooldown: float = 16.0
    refuse_timer: float = 0.0
    skittish_jumped: bool = False
    _beh_rng_seed: float = 0.0
    _prev_leg_touching: dict[str, bool] = field(default_factory=dict, repr=False)
    _hop_launched: bool = field(default=False, repr=False)
    _base_spring_stiffness: dict[str, float] = field(default_factory=dict, repr=False)
    _torso_surface: pygame.Surface | None = field(default=None, repr=False)
    strand_hitboxes: list[tuple[str, list[tuple[float, float]]]] = field(default_factory=list, repr=False)

    def __post_init__(self):
        self._base_spring_stiffness = {
            k: sp.stiffness for k, sp in self.springs.items()
        }
        self._base_spring_damping = {
            k: sp.damping for k, sp in self.springs.items()
        }
        self._beh_rng_seed = sum(ord(ch) for ch in self.config.label) * 0.37
        self.asleep_cooldown = 16.0 + (int(self._beh_rng_seed * 10.0) % 25) * 0.7
        self.balk_cooldown = 2.8 + (int(self._beh_rng_seed * 7.0) % 22) * 0.1
        self.spasm = self.config.gait.spasm
        self.sentience = self.config.gait.sentience
        self.can_speak = self.config.gait.can_speak
        self.spasm_cooldown = 8.0 + (int(self._beh_rng_seed * 5.0) % 12)
        self.quip_cooldown = 12.0 + (int(self._beh_rng_seed * 3.0) % 10)

    def _locus_alleles(self, locus: str) -> tuple[str, str]:
        if self.config.genome is not None and locus in self.config.genome.genes:
            g = self.config.genome.genes[locus]
            return g.allele_a, g.allele_b
        if self.config.strand_alleles is not None:
            return self.config.strand_alleles
        return ("-" * 24, "-" * 24)

    def _locus_for_slot(self, slot: str) -> str | None:
        for loc in self.config.strand_loci:
            if STRAND_SLOT_BY_LOCUS.get(loc, "tendril") == slot:
                return loc
        return None

    def _loci_for_slot(self, slot: str) -> tuple[str, ...]:
        return tuple(
            loc for loc in self.config.strand_loci
            if STRAND_SLOT_BY_LOCUS.get(loc, "tendril") == slot
        )

    def _is_locus_functional(self, locus: str | None) -> bool:
        if locus is None:
            return True
        if locus in self.config.incomplete_strand_loci:
            return False
        a, b = self._locus_alleles(locus)
        return is_strand_complete(a) and is_strand_complete(b)

    def _broken_slots(self) -> set[str]:
        return {
            STRAND_SLOT_BY_LOCUS.get(loc, "tendril")
            for loc in self.config.incomplete_strand_loci
        }

    def _all_strands_functional(self) -> bool:
        if self.config.incomplete_strand_loci:
            return False
        for loc in self.config.strand_loci:
            if not self._is_locus_functional(loc):
                return False
        if self.config.strand_alleles is not None:
            return (
                is_strand_complete(self.config.strand_alleles[0])
                and is_strand_complete(self.config.strand_alleles[1])
            )
        return True

    def find_strand_at_point(
        self, world_pos: tuple[float, float], radius: float = 14.0
    ) -> str | None:
        px, py = world_pos

        def point_to_seg_dist(ax: float, ay: float, bx: float, by: float) -> float:
            vx, vy = bx - ax, by - ay
            denom = vx * vx + vy * vy
            if denom <= 1e-6:
                return math.hypot(px - ax, py - ay)
            t = max(0.0, min(1.0, ((px - ax) * vx + (py - ay) * vy) / denom))
            return math.hypot(px - (ax + vx * t), py - (ay + vy * t))

        def point_in_poly(poly: list[tuple[float, float]]) -> bool:
            inside = False
            n = len(poly)
            j = n - 1
            for i in range(n):
                xi, yi = poly[i]
                xj, yj = poly[j]
                if ((yi > py) != (yj > py)) and (
                    px < (xj - xi) * (py - yi) / ((yj - yi) if abs(yj - yi) > 1e-6 else 1e-6) + xi
                ):
                    inside = not inside
                j = i
            return inside

        best_locus: str | None = None
        best_dist = radius
        for locus, poly in reversed(self.strand_hitboxes):
            if len(poly) < 2:
                continue
            if len(poly) >= 3 and point_in_poly(poly):
                return locus
            d_min = min(
                point_to_seg_dist(
                    poly[i][0], poly[i][1], poly[(i + 1) % len(poly)][0], poly[(i + 1) % len(poly)][1]
                )
                for i in range(len(poly))
            )
            if d_min <= best_dist:
                best_dist = d_min
                best_locus = locus
        return best_locus

    def _aim_joint(self, name: str, desired_rel: float, effort: float) -> None:
        """Pull a rotary spring to desired_rel. Equilibrium sits at -rest_angle."""
        spring = self.springs.get(name)
        limit = self.limits.get(name)
        if spring is None or limit is None:
            return
        desired = max(limit.min, min(limit.max, desired_rel))
        spring.rest_angle = -desired
        spring.stiffness = self._base_spring_stiffness.get(name, spring.stiffness) * effort
        spring.damping = self._base_spring_damping.get(name, spring.damping) * effort
        spring.torque_func = type(spring).spring_torque

    def remove_from_space(self, space: pymunk.Space):
        """Cleanly removes all physics bodies, shapes, and constraints for this creature."""
        for constraint in self.constraints:
            if constraint in space.constraints:
                space.remove(constraint)
        for shape in self.shapes.values():
            if shape in space.shapes:
                space.remove(shape)
        unique_bodies = set(self.bodies.values())
        for body in unique_bodies:
            if body in space.bodies:
                space.remove(body)

    def update(self, dt: float, floor_shape: pymunk.Shape):
        """Updates walk/gallop cycle, joint dynamics, traction, push-off, and balance."""
        torso = self.bodies.get("torso")
        if torso is None:
            return

        self.swirl_phase = (self.swirl_phase + dt * 5.2) % (2.0 * math.pi)

        if self.asleep_timer > 0.0:
            self.asleep_timer = max(0.0, self.asleep_timer - dt)
            if self.asleep_timer <= 0.0 and not self.unconscious:
                torso.apply_impulse_at_world_point(
                    (self.total_mass * 38.0, -self.total_mass * 72.0), torso.position
                )

        if self.unconscious or self.dead or self.asleep_timer > 0.0:
            self.run_blend = 0.0
            self.gait_blend = 0.0
            for k, sp in self.springs.items():
                base_k = self._base_spring_stiffness.get(k, sp.stiffness)
                sp.stiffness = base_k * 0.06
            for leg_name, hoof_name, part_cfg in (
                ("leg_front", "hoof_front", self.config.leg_front),
                ("leg_mid", "hoof_mid", self.config.leg_mid),
                ("leg_back", "hoof_back", self.config.leg_back),
            ):
                if leg_name in self.shapes:
                    self.shapes[leg_name].friction = part_cfg.friction
                lower_name = f"{leg_name}_lower"
                if lower_name in self.shapes:
                    self.shapes[lower_name].friction = part_cfg.friction
                if hoof_name in self.shapes:
                    self.shapes[hoof_name].friction = self.config.hoof.friction
            return
        else:
            for k, sp in self.springs.items():
                if k in self._base_spring_stiffness:
                    sp.stiffness = self._base_spring_stiffness[k]
                if k in self._base_spring_damping:
                    sp.damping = self._base_spring_damping[k]

        broken_slots = self._broken_slots()
        pure_incomplete = self.config.pure_strand and (not self._all_strands_functional())
        pure_left_broken = False
        pure_right_broken = False
        if self.config.pure_strand and self.config.strand_alleles is not None:
            pure_left_broken = not is_strand_complete(self.config.strand_alleles[0])
            pure_right_broken = not is_strand_complete(self.config.strand_alleles[1])

        if pure_left_broken or ("leg_back" in broken_slots) or ("legs_both" in broken_slots):
            if "leg_back" in self.springs:
                self.springs["leg_back"].stiffness = self._base_spring_stiffness.get("leg_back", 0.0) * 0.04
        if pure_right_broken or ("leg_front" in broken_slots) or ("legs_both" in broken_slots):
            if "leg_front" in self.springs:
                self.springs["leg_front"].stiffness = self._base_spring_stiffness.get("leg_front", 0.0) * 0.04
        if pure_left_broken or ("arms" in broken_slots):
            if "arm_back" in self.springs:
                self.springs["arm_back"].stiffness = self._base_spring_stiffness.get("arm_back", 0.0) * 0.04
        if pure_right_broken or ("arms" in broken_slots):
            if "arm_front" in self.springs:
                self.springs["arm_front"].stiffness = self._base_spring_stiffness.get("arm_front", 0.0) * 0.04
        if "tail" in broken_slots and "tail" in self.springs:
            self.springs["tail"].stiffness = self._base_spring_stiffness.get("tail", 0.0) * 0.04
        if "neck" in broken_slots and "neck" in self.springs:
            self.springs["neck"].stiffness = self._base_spring_stiffness.get("neck", 0.0) * 0.04

        gait = self.config.gait
        gait_allowed = gait.enabled and (not pure_incomplete)
        run_target = 1.0 if (gait_allowed and gait.mode == "run") else 0.0
        if run_target > self.run_blend:
            self.run_blend = min(1.0, self.run_blend + dt * 2.0)
        else:
            self.run_blend = max(0.0, self.run_blend - dt * 2.5)

        torso_tilt = math.atan2(math.sin(torso.angle), math.cos(torso.angle))
        upright = abs(torso_tilt) < math.radians(60.0 if self.run_blend > 0.1 else 42.0)

        leg_touching = {
            leg: (leg in self.bodies and is_body_touching(self.bodies[leg], floor_shape))
            for leg in ("leg_front", "leg_mid", "leg_back")
        }
        has_any_legs = any(leg in self.bodies for leg in ("leg_front", "leg_mid", "leg_back"))
        feet_touching = any(leg_touching.values())
        if not has_any_legs:
            torso_touching = is_body_touching(torso, floor_shape)
            arm_touching = any(
                (arm in self.bodies and is_body_touching(self.bodies[arm], floor_shape))
                for arm in ("arm_front", "arm_back")
            )
            feet_touching = torso_touching or arm_touching
        beh = gait.behavior
        hop = max(0.0, min(1.0, gait.hop_blend))
        active_locomotion = (upright or hop > 0.45 or beh == "hop") and (
            feet_touching or self.run_blend > 0.25 or hop > 0.45 or beh == "hop"
        )

        beh_freq_mult = {"gallop": 1.0, "trot": 1.14, "bound": 0.96, "pace": 1.06, "pronk": 0.92, "hop": 1.08}.get(beh, 1.0)
        beh_stride_mult = {"gallop": 1.0, "trot": 0.88, "bound": 1.18, "pace": 1.10, "pronk": 0.95, "hop": 1.05}.get(beh, 1.0)
        beh_pitch_mult = {"gallop": 1.0, "trot": 0.45, "bound": 1.45, "pace": 0.30, "pronk": 1.25, "hop": 1.60}.get(beh, 1.0)
        beh_lift_mult = {"gallop": 1.0, "trot": 0.85, "bound": 1.55, "pace": 0.78, "pronk": 1.95, "hop": 1.0}.get(beh, 1.0)
        beh_phase_deg = {
            "gallop": gait.run_phase_offset_deg,
            "trot": 180.0,
            "bound": 22.0,
            "pace": 8.0,
            "pronk": 0.0,
            "hop": 20.0,
        }.get(beh, gait.run_phase_offset_deg)

        eff_progress = (
            self.track_progress
            if self.track_progress > 0.0
            else max(0.0, min(1.0, torso.position.x / 4200.0))
        )
        trait_freq_mult = 1.0
        trait_speed_mult = 1.0
        trait_stride_mult = 1.0
        neuro = gait.neuro_trait
        meta = gait.metabolic_trait
        reflex = gait.reflex_trait

        if self.quip_timer > 0.0:
            self.quip_timer = max(0.0, self.quip_timer - dt)
        if self.spasm > 0.02 and "torso" in self.bodies:
            torso_body = self.bodies["torso"]
            if self.spasm_left > 0.0:
                self.spasm_left = max(0.0, self.spasm_left - dt)
                if self.spasm_mode == "stiff":
                    for name, spring in self.springs.items():
                        base_k = self._base_spring_stiffness.get(name, spring.stiffness)
                        spring.stiffness = base_k * (1.0 + 5.0 * self.spasm)
                else:
                    wobble = math.sin(self.swirl_phase * 17.0 + self._beh_rng_seed)
                    torso_body.torque += wobble * self.total_mass * 380.0 * self.spasm
                    for leg_name in ("leg_front", "leg_back", "arm_front", "arm_back", "neck"):
                        if leg_name in self.bodies:
                            self.bodies[leg_name].torque += math.sin(
                                self.gait_phase * 21.0 + self._beh_rng_seed + len(leg_name)
                            ) * 9000.0 * self.spasm
                if self.spasm_left <= 0.0 and self.spasm_mode == "stiff":
                    for name, spring in self.springs.items():
                        if name in self._base_spring_stiffness:
                            spring.stiffness = self._base_spring_stiffness[name]
                    self.spasm_mode = ""
            else:
                self.spasm_cooldown -= dt
                if self.spasm_cooldown <= 0.0:
                    self.spasm_left = 0.35 + 0.50 * self.spasm
                    self.spasm_mode = (
                        "stiff" if math.sin(self._beh_rng_seed * 2.0 + self.swirl_phase) > 0.0 else "flail"
                    )
                    span = abs(math.sin(self._beh_rng_seed * 1.7 + torso_body.position.x * 0.01))
                    lo = 28.0 + (8.0 - 28.0) * self.spasm
                    hi = 48.0 + (20.0 - 48.0) * self.spasm
                    self.spasm_cooldown = lo + (hi - lo) * span

        if gait_allowed and gait.mode == "run" and self.run_blend > 0.20:
            if neuro == "narcoleptic":
                self.asleep_cooldown -= dt
                if self.asleep_cooldown <= 0.0:
                    self.asleep_timer = 5.5 + 3.5 * (0.5 + 0.5 * math.sin(self.gait_phase + self._beh_rng_seed))
                    self.asleep_cooldown = 24.0 + 18.0 * (0.5 + 0.5 * math.cos(self.swirl_phase + self._beh_rng_seed))
                    return
            elif neuro == "bolter":
                if eff_progress > 0.30 and not self.bolted:
                    self.bolt_timer = 3.2
                    self.bolted = True
                if self.bolt_timer > 0.0:
                    self.bolt_timer = max(0.0, self.bolt_timer - dt)
                    trait_speed_mult *= 1.26
                    trait_freq_mult *= 1.18
                elif eff_progress < 0.30:
                    trait_speed_mult *= 0.90
            elif neuro == "stubborn":
                if not self.frenzied:
                    self.balk_cooldown -= dt
                    if self.balk_cooldown <= 0.0:
                        self.balk_timer = 0.65
                        self.balk_cooldown = 4.2 + 2.2 * (0.5 + 0.5 * math.sin(self._beh_rng_seed + torso.position.x * 0.01))
                if self.balk_timer > 0.0:
                    self.balk_timer = max(0.0, self.balk_timer - dt)
                    trait_speed_mult *= 0.22
                    trait_freq_mult *= 0.35
            elif neuro == "prancer":
                trait_stride_mult *= 1.18
                if eff_progress > 0.72:
                    trait_speed_mult *= 1.12

            if self.sentience > 0.35 and self.can_speak and 0.08 < eff_progress < 0.90:
                self.quip_cooldown -= dt
                if self.quip_cooldown <= 0.0:
                    roll = abs(math.sin(self._beh_rng_seed * 4.0 + eff_progress * 11.0 + self.swirl_phase))
                    self.quip_cooldown = 14.0 + 14.0 * roll
                    if roll > 0.42:
                        self.refuse_timer = 1.05 + 0.35 * self.sentience
                        self.quip = ("This is embarassing", "I don't want to do this", "This sucks")[
                            int(self._beh_rng_seed * 3.0 + eff_progress * 10.0) % 3
                        ]
                        self.quip_timer = 2.4
            if self.refuse_timer > 0.0:
                self.refuse_timer = max(0.0, self.refuse_timer - dt)
                trait_speed_mult *= 0.08
                trait_freq_mult *= 0.22

            if meta == "second_wind":
                if eff_progress > 0.55:
                    trait_speed_mult *= 1.18
                    trait_freq_mult *= 1.14
                else:
                    trait_speed_mult *= 0.94
            elif meta == "front_runner":
                if eff_progress < 0.35:
                    trait_speed_mult *= 1.20
                    trait_freq_mult *= 1.12
                elif eff_progress > 0.68:
                    trait_speed_mult *= 0.86
                    trait_freq_mult *= 0.90
            elif meta == "fiery":
                trait_freq_mult *= 1.14
                trait_speed_mult *= 1.10 + 0.08 * math.sin(self.swirl_phase * 1.8)
            elif meta == "sedate":
                trait_freq_mult *= 0.90
                trait_speed_mult *= 0.88

            if reflex == "competitive" and 15.0 < self.nearest_ahead_dist < 190.0:
                trait_speed_mult *= 1.14
            elif reflex == "skittish" and (not self.skittish_jumped) and (eff_progress > 0.01 or floor_shape.friction >= 3.0) and feet_touching:
                self.skittish_jumped = True
                torso.apply_impulse_at_world_point(
                    (self.total_mass * 45.0, -self.total_mass * 135.0), torso.position
                )

        if gait_allowed and active_locomotion:
            eff_freq = _lerp(gait.walk_freq, gait.run_freq * beh_freq_mult * trait_freq_mult, self.run_blend)
            if self.drunk:
                eff_freq *= 1.24 + 0.26 * math.sin(self.swirl_phase * 1.3)
            if self.frenzied:
                eff_freq *= 1.28
            self.gait_phase = (
                self.gait_phase + dt * 2.0 * math.pi * eff_freq
            ) % (2.0 * math.pi)
            self.gait_blend = min(1.0, self.gait_blend + dt * 4.5)

            hop_pitch = math.radians(-6.5 * math.sin(self.gait_phase))
            gallop_pitch = self.run_blend * math.radians(
                (-1.0 + 2.8 * math.sin(self.gait_phase + 0.65)) * beh_pitch_mult
            )
            target_pitch = hop_pitch if beh == "hop" else _lerp(gallop_pitch, hop_pitch, hop)
            if self.drunk:
                target_pitch += math.radians(8.5 * math.sin(self.swirl_phase * 1.9))
            pitch_error = torso_tilt - target_pitch
            bal_stiff = gait.balance_stiffness * (1.0 + 1.10 * self.run_blend)
            if self.drunk:
                bal_stiff *= 0.68
            if "leg_mid" in self.bodies:
                bal_stiff *= 1.12
            bal_damp = gait.balance_damping * (1.0 + 0.85 * self.run_blend)
            bal_max = gait.balance_max_torque * (1.0 + 1.40 * self.run_blend)
            raw_balance = -bal_stiff * pitch_error - bal_damp * torso.angular_velocity
            torso.torque += max(-bal_max, min(bal_max, raw_balance))

            if beh == "hop" or hop > 0.02:
                if self.gait_phase >= math.pi:
                    self._hop_launched = False
                elif (
                    (not self._hop_launched)
                    and feet_touching
                    and self.gait_phase < 0.45 * math.pi
                    and torso.velocity.y > -80.0
                ):
                    hop_share = 1.0 if beh == "hop" else hop
                    hop_vy = -_lerp(130.0, 205.0, self.run_blend) * hop_share
                    target_vx = _lerp(55.0, gait.run_target_speed, self.run_blend)
                    dvx = max(0.0, target_vx - torso.velocity.x) * hop_share
                    torso.apply_impulse_at_world_point(
                        (self.total_mass * dvx * 0.72, self.total_mass * hop_vy * 0.78),
                        torso.position,
                    )
                    self._hop_launched = True
        else:
            self.gait_blend = max(0.0, self.gait_blend - dt * 6.0)

        back_phase_offset = _lerp(
            math.pi, math.radians(beh_phase_deg), self.run_blend
        )

        leg_specs = (
            (
                "leg_front",
                "hoof_front",
                0.0,
                gait.front_leg_center_deg,
                -2.0,
                self.config.leg_front,
                -36.0,
                36.0,
            ),
            (
                "leg_mid",
                "hoof_mid",
                0.5 * back_phase_offset,
                0.0,
                0.0,
                self.config.leg_mid,
                -30.0,
                30.0,
            ),
            (
                "leg_back",
                "hoof_back",
                back_phase_offset,
                gait.back_leg_center_deg,
                2.0,
                self.config.leg_back,
                -35.0,
                38.0,
            ),
        )

        push_lift_applied = False
        drunk_stride_mult = (1.42 if self.drunk else 1.0) * (1.18 if self.frenzied else 1.0) * trait_stride_mult
        for (
            leg_name,
            hoof_name,
            phase_offset,
            walk_center,
            run_center,
            part_cfg,
            run_min_deg,
            run_max_deg,
        ) in leg_specs:
            if leg_name not in self.bodies:
                continue

            leg_broken = (
                (leg_name == "leg_back" and (pure_left_broken or "leg_back" in broken_slots or "legs_both" in broken_slots))
                or (leg_name == "leg_front" and (pure_right_broken or "leg_front" in broken_slots or "legs_both" in broken_slots))
            )

            if self.config.strand_alleles is not None and part_cfg.joint is not None:
                rest_center = part_cfg.joint.rest_deg
                extra_lim = 14.0 if self.drunk else 0.0
                self.limits[leg_name].min = math.radians(
                    min(part_cfg.joint.min_deg, rest_center - 30.0 * self.run_blend) - extra_lim
                )
                self.limits[leg_name].max = math.radians(
                    max(part_cfg.joint.max_deg, rest_center + 30.0 * self.run_blend) + extra_lim
                )
                if leg_name in self.springs:
                    base_k = self._base_spring_stiffness.get(leg_name, part_cfg.joint.stiffness)
                    self.springs[leg_name].stiffness = base_k * (1.0 + 0.35 * self.run_blend)
                    self.springs[leg_name].damping = part_cfg.joint.damping * (1.0 + 0.25 * self.run_blend)
                leg_phase = self.gait_phase + phase_offset
                swing_amp = _lerp(gait.stride_deg, gait.run_stride_deg, self.run_blend) * drunk_stride_mult
                target_deg = rest_center + self.gait_blend * swing_amp * math.sin(leg_phase)
                if self.drunk:
                    target_deg += 12.0 * math.sin(
                        self.swirl_phase * 2.3 + (1.7 if leg_name == "leg_back" else 0.0)
                    )
                if leg_name in self.springs:
                    self.springs[leg_name].rest_angle = -math.radians(target_deg)
            else:
                if leg_name in self.limits and part_cfg.joint is not None:
                    extra_lim = 14.0 if self.drunk else 0.0
                    self.limits[leg_name].min = math.radians(
                        _lerp(part_cfg.joint.min_deg, run_min_deg, self.run_blend) - extra_lim
                    )
                    self.limits[leg_name].max = math.radians(
                        _lerp(part_cfg.joint.max_deg, run_max_deg, self.run_blend) + extra_lim
                    )

                if leg_name in self.springs and part_cfg.joint is not None:
                    base_k = self._base_spring_stiffness.get(leg_name, part_cfg.joint.stiffness)
                    self.springs[leg_name].stiffness = base_k * (
                        1.0 + 0.45 * self.run_blend
                    )
                    self.springs[leg_name].damping = part_cfg.joint.damping * (
                        1.0 + 0.30 * self.run_blend
                    )

                leg_phase = self.gait_phase + phase_offset
                base_rest = part_cfg.joint.rest_deg if part_cfg.joint is not None else 0.0
                amp = _lerp(gait.stride_deg, gait.run_stride_deg, self.run_blend) * drunk_stride_mult
                if leg_name == "leg_back":
                    hop_wave = base_rest + 8.0 + amp * math.sin(self.gait_phase)
                else:
                    hop_wave = base_rest - 4.0 * math.cos(self.gait_phase) - 0.45 * amp * math.sin(self.gait_phase)
                if self.drunk:
                    hop_wave += 12.0 * math.sin(self.swirl_phase * 2.3)
                hop_target = _lerp(base_rest, hop_wave, self.gait_blend)
                walk_wave = walk_center + gait.stride_deg * drunk_stride_mult * math.sin(leg_phase)
                run_wave = run_center + gait.run_stride_deg * beh_stride_mult * drunk_stride_mult * (
                    math.sin(leg_phase) - 0.14 * math.sin(2.0 * leg_phase)
                )
                if self.drunk:
                    wobble = 14.0 * math.sin(
                        self.swirl_phase * 2.3 + (1.7 if leg_name == "leg_back" else 0.0)
                    )
                    walk_wave += wobble
                    run_wave += wobble
                gallop_target = _lerp(base_rest, _lerp(walk_wave, run_wave, self.run_blend), self.gait_blend)
                target_deg = hop_target if beh == "hop" else _lerp(gallop_target, hop_target, hop)

                if leg_name in self.springs:
                    self.springs[leg_name].rest_angle = -math.radians(target_deg)

            d_wave = math.cos(leg_phase) - 0.28 * self.run_blend * math.cos(
                2.0 * leg_phase
            )

            if gait_allowed and active_locomotion and (not leg_broken):
                rel_ang_vel = (
                    self.bodies[leg_name].angular_velocity - torso.angular_velocity
                )
                push_thresh = _lerp(0.0, 0.22, self.run_blend)
                pushing_back = (
                    d_wave >= push_thresh
                    and rel_ang_vel >= _lerp(-0.2, 0.0, self.run_blend)
                )

                stance_fric = _lerp(
                    part_cfg.friction, gait.run_stance_friction, self.run_blend
                )
                hoof_stance_fric = _lerp(
                    self.config.hoof.friction, gait.run_stance_friction, self.run_blend
                )
                fric = stance_fric if pushing_back else gait.swing_friction
                hoof_fric = hoof_stance_fric if pushing_back else gait.swing_friction

                gallop_drive = 0.0 if beh == "hop" else (1.0 - hop)
                if gallop_drive > 0.02 and self.run_blend > 0.05 and leg_touching[leg_name] and d_wave > 0.18:
                    speed_mult = (
                        0.72 + 0.58 * abs(math.sin(self.swirl_phase * 1.5))
                        if self.drunk
                        else 1.0
                    ) * (1.24 if self.frenzied else 1.0)
                    target_vx = gait.run_target_speed * self.run_blend * speed_mult * trait_speed_mult
                    if torso.velocity.x < target_vx:
                        deficit = target_vx - torso.velocity.x
                        frenzy_drive = 1.35 if self.frenzied else 1.0
                        drive_x = (
                            min(self.total_mass * 550.0 * frenzy_drive, deficit * self.total_mass * 4.0 * frenzy_drive)
                            * self.run_blend
                            * gallop_drive
                        )
                        torso.apply_force_at_world_point((drive_x, 0.0), torso.position)

                    if (
                        not push_lift_applied
                        and d_wave > (0.25 if beh == "pronk" else 0.45)
                        and torso.velocity.y > -55.0
                    ):
                        lift_mult = (1.35 if self.drunk else 1.0) * beh_lift_mult
                        lift_y = -self.total_mass * 1150.0 * self.run_blend * lift_mult * gallop_drive
                        torso.apply_force_at_world_point((0.0, lift_y), torso.position)
                        push_lift_applied = True
            else:
                fric = part_cfg.friction
                hoof_fric = self.config.hoof.friction

            if leg_broken:
                fric = 0.04
            if leg_broken or ("hooves" in broken_slots):
                hoof_fric = 0.04

            self.shapes[leg_name].friction = fric
            lower_name = f"{leg_name}_lower"
            if lower_name in self.shapes:
                self.shapes[lower_name].friction = fric
            if hoof_name in self.shapes:
                self.shapes[hoof_name].friction = hoof_fric

        # Physical springy-hoof rebound on impact and stride push-off
        spring_bounce = 0.0 if ("hooves" in broken_slots) else self.config.hoof.spring_bounce
        if spring_bounce > 0.0 and (not self.unconscious):
            for leg_name in ("leg_front", "leg_mid", "leg_back"):
                if leg_name not in self.bodies:
                    continue
                was_touching = self._prev_leg_touching.get(leg_name, False)
                now_touching = leg_touching.get(leg_name, False)
                leg_body = self.bodies[leg_name]
                if now_touching and (not was_touching) and leg_body.velocity.y > 40.0:
                    bounce_vy = min(420.0, leg_body.velocity.y * spring_bounce * 1.15)
                    torso.apply_impulse_at_world_point(
                        (0.0, -self.total_mass * bounce_vy * 0.52), torso.position
                    )
                elif now_touching and gait.enabled and self.run_blend > 0.25 and torso.velocity.y > -45.0:
                    phase_off = 0.0 if leg_name == "leg_front" else back_phase_offset
                    if math.sin(self.gait_phase + phase_off) > 0.72:
                        torso.apply_force_at_world_point(
                            (0.0, -self.total_mass * 740.0 * spring_bounce * self.run_blend),
                            torso.position,
                        )
                self._prev_leg_touching[leg_name] = now_touching

        if floor_shape.friction >= 3.0 and feet_touching and torso.velocity.x > 0.0:
            mud_factor = 0.35 if gait.reflex_trait == "sure_footed" else 1.35
            mud_drag = -torso.velocity.x * self.total_mass * mud_factor
            torso.apply_force_at_world_point((mud_drag, 0.0), torso.position)

        # Wing autonomous flapping when airborne (lift + forward flight thrust)
        airborne = (not feet_touching) and (not is_body_touching(torso, floor_shape))
        wing = self.config.wing
        if wing.enabled and (not self.unconscious) and ("wing" not in broken_slots) and (not pure_incomplete):
            if airborne:
                self.wing_phase = (
                    self.wing_phase + dt * 2.0 * math.pi * wing.flap_freq
                ) % (2.0 * math.pi)
                flap_sin = math.sin(self.wing_phase)
                downstroke = max(0.0, -math.cos(self.wing_phase))
                self.wing_angle_deg = 16.0 + 52.0 * flap_sin

                # Gently taper lift at higher altitude so horses skim in-lane instead of floating off-canvas
                floor_surface_y = min(floor_shape.bb.bottom, floor_shape.bb.top)
                clearance = floor_surface_y - torso.position.y
                alt_scale = max(0.20, min(1.0, 1.0 - (clearance - 155.0) / 90.0))

                lift_force = (
                    self.total_mass
                    * 900.0
                    * (0.45 + 0.80 * downstroke)
                    * wing.lift_power
                    * alt_scale
                )
                drag_y = -torso.velocity.y * self.total_mass * wing.drag * 2.10

                if gait.enabled and self.run_blend > 0.05:
                    wing_speed_mult = (
                        0.72 + 0.58 * abs(math.sin(self.swirl_phase * 1.5))
                        if self.drunk
                        else 1.0
                    )
                    # Grounded horses average ~0.75-0.82x run_target_speed due to stride gaps & friction
                    flight_target_vx = (
                        gait.run_target_speed
                        * self.run_blend
                        * wing_speed_mult
                        * (0.80 + 0.10 * wing.lift_power)
                    )
                    air_drag_x = -torso.velocity.x * self.total_mass * wing.drag * 0.28
                    if torso.velocity.x < flight_target_vx and downstroke > 0.0:
                        deficit = flight_target_vx - torso.velocity.x
                        flap_thrust = min(
                            self.total_mass * 420.0,
                            deficit * self.total_mass * 3.0,
                        ) * self.run_blend * downstroke
                    else:
                        flap_thrust = 0.0
                    thrust_x = flap_thrust + air_drag_x
                else:
                    # Idle / dropped in pen: gentle glide drag toward rest
                    thrust_x = -torso.velocity.x * self.total_mass * wing.drag * 0.65

                torso.apply_force_at_world_point(
                    (thrust_x, -lift_force + drag_y), torso.position
                )

                bal_scale = 0.85 if (gait.enabled and self.run_blend > 0.05) else 0.45
                raw_air_bal = (
                    -gait.balance_stiffness * bal_scale * torso_tilt
                    - gait.balance_damping * 0.65 * torso.angular_velocity
                )
                torso.torque += max(
                    -gait.balance_max_torque * 0.85,
                    min(gait.balance_max_torque * 0.85, raw_air_bal),
                )
            else:
                self.wing_angle_deg += (12.0 - self.wing_angle_deg) * min(1.0, dt * 8.0)
                if (
                    gait.enabled
                    and self.run_blend > 0.35
                    and wing.lift_power > 0.85
                    and torso.velocity.y > -35.0
                    and math.sin(self.gait_phase) > 0.88
                ):
                    torso.apply_force_at_world_point(
                        (0.0, -self.total_mass * 520.0 * wing.lift_power), torso.position
                    )
        else:
            target_fold = -26.0 if ("wing" in broken_slots or pure_incomplete) else 12.0
            self.wing_angle_deg += (target_fold - self.wing_angle_deg) * min(1.0, dt * 8.0)

        # Limbless wriggle / arm-crawl fallback when creature has no legs
        if (("tendril" in broken_slots) or ("torso" in broken_slots)) and self.run_blend > 0.05:
            if torso.velocity.x > gait.run_target_speed * 0.25:
                torso.velocity = (torso.velocity.x * 0.96, torso.velocity.y)

        if (not has_any_legs) and gait.enabled and active_locomotion and self.run_blend > 0.05 and feet_touching:
            has_strand_arms = (
                ("arm_dev" in self.config.strand_loci)
                and (("arm_front" in self.bodies) or ("arm_back" in self.bodies))
                and ("arms" not in broken_slots)
            )
            crawl_mult = 0.44 if has_strand_arms else 0.26
            crawl_target = gait.run_target_speed * crawl_mult * self.run_blend
            if torso.velocity.x < crawl_target:
                pulse = 0.55 + 0.45 * max(0.0, math.sin(self.gait_phase))
                drive_x = min(
                    self.total_mass * (340.0 if has_strand_arms else 240.0),
                    (crawl_target - torso.velocity.x) * self.total_mass * 2.6,
                ) * pulse
                torso.apply_force_at_world_point((drive_x, 0.0), torso.position)

        # Arm swing (opposite to corresponding legs when walking/running; holds rest_deg when idle)
        arm_specs = (
            ("arm_front", math.pi, self.config.arm_front),
            ("arm_back", 0.0, self.config.arm_back),
        )
        for arm_name, phase_offset, arm_cfg in arm_specs:
            if arm_name in self.springs and arm_cfg.joint is not None:
                swing = (
                    self.gait_blend
                    * _lerp(gait.stride_deg, gait.run_stride_deg, self.run_blend)
                    * 0.85
                    * drunk_stride_mult
                    * math.sin(self.gait_phase + phase_offset)
                )
                self.springs[arm_name].rest_angle = -math.radians(
                    arm_cfg.joint.rest_deg + swing
                )

        # The neck keeps its forward carriage. Only the head turns up so the
        # muzzle, and the gaze, stay straight ahead.
        flail = (2.4 if self.drunk else 1.0) * (1.45 if self.frenzied else 1.0)
        if "neck" in self.limits and self.config.neck.joint is not None:
            self.limits["neck"].max = math.radians(
                _lerp(self.config.neck.joint.max_deg, 42.0, self.run_blend)
            )
        if "neck" in self.springs and self.config.neck.joint is not None:
            base = _lerp(self.config.neck.joint.rest_deg, 25.0, self.run_blend)
            walk_bob = gait.neck_bob_deg * math.sin(2.0 * self.gait_phase)
            run_bob = 4.5 * math.sin(self.gait_phase + 0.3)
            self.springs["neck"].rest_angle = -math.radians(
                base + self.gait_blend * flail * _lerp(walk_bob, run_bob, self.run_blend)
            )

        holding_head = (
            self.config.erectness < 0.5
            and "neck" not in broken_slots
            and "neck" in self.bodies
            and "head" in self.bodies
        )
        if holding_head:
            bob = 2.0 * math.sin(self.gait_phase) * self.gait_blend
            if self.eat_time > 0.0:
                head_world = math.radians(22.0)
                effort = 2.2
            else:
                head_world = math.radians(max(-4.0, min(4.0, bob)))
                effort = 4.0
            self._aim_joint("head", head_world - self.bodies["neck"].angle, effort)
        elif "head" in self.springs and self.config.head.joint is not None:
            base = _lerp(self.config.head.joint.rest_deg, -26.0, self.run_blend)
            walk_bob = gait.head_bob_deg * math.sin(2.0 * self.gait_phase)
            run_bob = -4.0 * math.sin(self.gait_phase + 0.3)
            self.springs["head"].rest_angle = -math.radians(
                base + self.gait_blend * flail * _lerp(walk_bob, run_bob, self.run_blend)
            )

        if "tail" in self.limits and self.config.tail.joint is not None:
            self.limits["tail"].max = math.radians(
                _lerp(self.config.tail.joint.max_deg, 25.0, self.run_blend)
            )
        if "tail" in self.springs and self.config.tail.joint is not None:
            base = _lerp(self.config.tail.joint.rest_deg, -18.0, self.run_blend)
            sway = _lerp(gait.tail_sway_deg, 10.0, self.run_blend) * flail * math.sin(
                self.gait_phase
            )
            self.springs["tail"].rest_angle = -math.radians(
                base + self.gait_blend * sway
            )

        if "lower_jaw" in self.springs and self.config.lower_jaw.joint is not None:
            if self.eat_time > 0.0:
                if "lower_jaw" in self.limits:
                    self.limits["lower_jaw"].min = math.radians(-18.0)
                    self.limits["lower_jaw"].max = math.radians(48.0)
                self.springs["lower_jaw"].rest_angle = -math.radians(
                    self.config.lower_jaw.joint.rest_deg + 38.0 * self.chew_amount()
                )
            else:
                jaw_bob = 7.0 * abs(math.sin(self.gait_phase)) * self.run_blend * self.gait_blend
                self.springs["lower_jaw"].rest_angle = -math.radians(
                    self.config.lower_jaw.joint.rest_deg + jaw_bob
                )

from creature_build import (
    build_creature,
    build_creature_from_genome,
    draw_scrolling_scenery,
)
