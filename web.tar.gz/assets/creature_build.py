"""Assemble a Creature in a Pymunk space and draw scrolling scenery."""
from __future__ import annotations

import math
import random
import pygame
import pymunk


from creature_config import CreatureConfig

from gene import (
    Genome,
    random_horse_genome,
)

from creature_parts import (
    attach_part,
    create_bent_leg,
    create_ear_shape,
    create_hand_shape,
    create_hoof_shape,
    create_offset_box,
    create_part,
    create_tail_part,
    create_tooth_shape,
)

from creature_blueprints import config_from_genome

def build_creature(space: pymunk.Space, cfg: CreatureConfig) -> Creature:
    from creature import Creature
    """Builds a creature from a CreatureConfig, auto-aligning enabled parts."""
    shape_filter = pymunk.ShapeFilter(group=cfg.collision_group)
    bodies: dict[str, pymunk.Body] = {}
    shapes: dict[str, pymunk.Shape] = {}
    springs: dict[str, pymunk.DampedRotarySpring] = {}
    limits: dict[str, pymunk.RotaryLimitJoint] = {}
    constraints: list[pymunk.Constraint] = []
    knee_caps: dict[str, tuple[float, float]] = {}
    rotary_motors: dict[str, pymunk.SimpleMotor] = {}

    tx, ty = cfg.spawn_pos
    tw, th = cfg.torso.size

    torso, torso_shape = create_part(space, (tx, ty), cfg.torso, shape_filter)
    bodies["torso"] = torso
    shapes["torso"] = torso_shape
    for index, extra in enumerate(torso.shapes):
        if extra is not torso_shape:
            shapes[f"torso_component_{index}"] = extra

    neck = None
    neck_pos = (tx + tw / 2, ty - th / 2)
    nh = 0.0
    nw = 0.0
    if cfg.neck.enabled:
        nw, nh = cfg.neck.size
        neck_pin_inset = min(5.0, th * 0.25, nh * 0.25)
        neck_anchor = (
            tx + tw / 2 - nw / 2 + cfg.neck.anchor_offset[0],
            ty - th / 2 + neck_pin_inset + cfg.neck.anchor_offset[1],
        )
        neck_pos = (neck_anchor[0], neck_anchor[1] - nh / 2 + neck_pin_inset * 0.5)
        neck, neck_shape = create_part(space, neck_pos, cfg.neck, shape_filter)
        neck_spring, neck_limit, neck_cons = attach_part(
            space, torso, neck, neck_anchor, cfg.neck.joint
        )
        bodies["neck"] = neck
        shapes["neck"] = neck_shape
        limits["neck"] = neck_limit
        constraints.extend(neck_cons)
        if neck_spring is not None:
            springs["neck"] = neck_spring

    if cfg.head.enabled:
        hw, hh = cfg.head.size
        parent_for_head = neck if neck is not None else torso
        ref_w = nw if neck is not None else tw * 0.3
        ref_h = nh if neck is not None else th
        head_pin_y_inset = min(5.0, ref_h * 0.2, hh * 0.3)
        head_pin_x_inset = min(ref_w * 0.4, hw * 0.2)
        head_anchor = (
            neck_pos[0] + cfg.head.anchor_offset[0],
            neck_pos[1] - ref_h / 2 + head_pin_y_inset + cfg.head.anchor_offset[1],
        )
        muzzle_shift = (hw / 2 - head_pin_x_inset) * (1.0 - cfg.head_center)
        head_pos = (
            head_anchor[0] + muzzle_shift,
            head_anchor[1] - hh / 2 + head_pin_y_inset,
        )
        head, head_shape = create_part(space, head_pos, cfg.head, shape_filter)
        head_spring, head_limit, head_cons = attach_part(
            space, parent_for_head, head, head_anchor, cfg.head.joint
        )
        bodies["head"] = head
        shapes["head"] = head_shape
        limits["head"] = head_limit
        constraints.extend(head_cons)
        if head_spring is not None:
            springs["head"] = head_spring

        if cfg.ear.enabled:
            ear_shape = create_ear_shape(head, cfg.ear, cfg.head.size, shape_filter)
            space.add(ear_shape)
            shapes["ear"] = ear_shape

        ljw, ljh = cfg.lower_jaw.size
        lj_overlap = 1.0
        lj_offset_x = (
            hw / 2.0 + ljw / 2.0 - lj_overlap + cfg.lower_jaw.anchor_offset[0] - cfg.bite * 10.0
        )
        lj_offset_y = hh / 2.0 - ljh / 2.0 + cfg.lower_jaw.anchor_offset[1]

        ujw, ujh = cfg.upper_jaw.size
        uj_overlap = 1.0
        uj_offset_x = hw / 2.0 + ujw / 2.0 - uj_overlap + cfg.upper_jaw.anchor_offset[0] + cfg.bite * 8.0
        uj_offset_y = (
            lj_offset_y - ljh / 2.0 - ujh / 2.0 + cfg.upper_jaw.anchor_offset[1]
        )
        upper_jaw_body = head
        uj_local_center = (uj_offset_x, uj_offset_y)

        if cfg.upper_jaw.enabled:
            if cfg.upper_jaw.joint is None:
                upper_jaw_shape = create_offset_box(
                    head,
                    uj_local_center,
                    cfg.upper_jaw.size,
                    cfg.upper_jaw.mass,
                    cfg.upper_jaw.friction,
                    shape_filter,
                )
                space.add(upper_jaw_shape)
            else:
                uj_pos = (head_pos[0] + uj_offset_x, head_pos[1] + uj_offset_y)
                uj_anchor = (
                    head_pos[0] + hw / 2.0 - uj_overlap,
                    head_pos[1] + uj_offset_y,
                )
                upper_jaw_body, upper_jaw_shape = create_part(
                    space, uj_pos, cfg.upper_jaw, shape_filter
                )
                uj_local_center = (0.0, 0.0)
                uj_spring, uj_limit, uj_cons = attach_part(
                    space, head, upper_jaw_body, uj_anchor, cfg.upper_jaw.joint
                )
                limits["upper_jaw"] = uj_limit
                constraints.extend(uj_cons)
                if uj_spring is not None:
                    springs["upper_jaw"] = uj_spring
            bodies["upper_jaw"] = upper_jaw_body
            shapes["upper_jaw"] = upper_jaw_shape

        if cfg.nose.enabled:
            nose_w, nose_h = cfg.nose.size
            if cfg.upper_jaw.enabled:
                nose_center = (
                    uj_local_center[0] + ujw / 2.0 + nose_w / 2.0 + cfg.nose.anchor_offset[0],
                    uj_local_center[1] - ujh / 2.0 + nose_h / 2.0 + cfg.nose.anchor_offset[1],
                )
            else:
                nose_center = (
                    hw / 2.0 + nose_w * 0.4 + cfg.nose.anchor_offset[0],
                    -hh * 0.15 + cfg.nose.anchor_offset[1],
                )
            nose_shape = create_offset_box(
                upper_jaw_body,
                nose_center,
                cfg.nose.size,
                cfg.nose.mass,
                cfg.nose.friction,
                shape_filter,
                sensor=True,
            )
            space.add(nose_shape)
            shapes["nose"] = nose_shape

        if cfg.lower_jaw.enabled:
            if cfg.lower_jaw.joint is None:
                lower_jaw = head
                lower_jaw_shape = create_offset_box(
                    head,
                    (lj_offset_x, lj_offset_y),
                    cfg.lower_jaw.size,
                    cfg.lower_jaw.mass,
                    cfg.lower_jaw.friction,
                    shape_filter,
                )
                space.add(lower_jaw_shape)
            else:
                lj_anchor = (
                    head_pos[0] + hw / 2.0 - lj_overlap + cfg.lower_jaw.anchor_offset[0],
                    head_pos[1] + lj_offset_y,
                )
                lj_pos = (lj_anchor[0] + ljw / 2.0, lj_anchor[1])
                lower_jaw, lower_jaw_shape = create_part(
                    space, lj_pos, cfg.lower_jaw, shape_filter
                )
                lj_spring, lj_limit, lj_cons = attach_part(
                    space, head, lower_jaw, lj_anchor, cfg.lower_jaw.joint
                )
                limits["lower_jaw"] = lj_limit
                constraints.extend(lj_cons)
                if lj_spring is not None:
                    springs["lower_jaw"] = lj_spring
            bodies["lower_jaw"] = lower_jaw
            shapes["lower_jaw"] = lower_jaw_shape

        if cfg.teeth.enabled and (cfg.upper_teeth or cfg.lower_teeth):
            tooth_w, tooth_h = cfg.teeth.size
            both_rows = cfg.upper_teeth and cfg.lower_teeth
            row_h = tooth_h * 0.5 if both_rows else tooth_h
            # The old single tooth sat on the lip where the jaws meet. Each row
            # takes half of that same bar, so the two halves share an edge.
            if cfg.upper_jaw.enabled:
                seam_x = uj_offset_x + ujw / 2.0 - tooth_w / 2.0 - 3.0 + cfg.teeth.anchor_offset[0]
                seam_y = uj_offset_y + ujh / 2.0 + cfg.teeth.anchor_offset[1]
            else:
                seam_x = hw / 2.0 - tooth_w * 0.2 + cfg.teeth.anchor_offset[0]
                seam_y = hh * 0.25 + cfg.teeth.anchor_offset[1]
            row_size = (tooth_w, row_h)

            def tooth_local(body_center: tuple[float, float], hx: float, hy: float) -> tuple[float, float]:
                return (hx - body_center[0], hy - body_center[1])

            if cfg.upper_teeth:
                upper_head = (seam_x, seam_y - (row_h * 0.5 if both_rows else 0.0))
                if cfg.upper_jaw.joint is None:
                    upper_local = upper_head
                else:
                    upper_local = tooth_local((uj_offset_x, uj_offset_y), *upper_head)
                tooth_shape = create_tooth_shape(
                    upper_jaw_body,
                    upper_local,
                    row_size,
                    cfg.teeth.mass,
                    cfg.teeth.friction,
                    shape_filter,
                    cfg.teeth.shape_style,
                    point_down=True,
                )
                space.add(tooth_shape)
                shapes["tooth"] = tooth_shape
            if cfg.lower_teeth:
                # Fused jaws slide with the bite. A hinged jaw stays on its anchor,
                # so only undo the upper jaw's share of the bite.
                bite_slide = cfg.bite * (18.0 if cfg.lower_jaw.joint is None else 8.0)
                lower_head = (seam_x - bite_slide, seam_y + (row_h * 0.5 if both_rows else 0.0))
                if cfg.lower_jaw.joint is None or "lower_jaw" not in bodies:
                    lower_body = head
                    lower_local = lower_head
                else:
                    lower_body = bodies["lower_jaw"]
                    jaw_cx = hw / 2.0 - lj_overlap + cfg.lower_jaw.anchor_offset[0] + ljw / 2.0
                    lower_local = tooth_local((jaw_cx, lj_offset_y), *lower_head)
                lower_tooth = create_tooth_shape(
                    lower_body,
                    lower_local,
                    row_size,
                    cfg.teeth.mass,
                    cfg.teeth.friction,
                    shape_filter,
                    cfg.teeth.shape_style,
                    point_down=False,
                )
                space.add(lower_tooth)
                shapes["tooth_lower"] = lower_tooth

    hoof_trim = (
        max(0.0, cfg.hoof.size[1] - cfg.hoof.anchor_offset[1] - 1.0)
        if cfg.hoof.enabled
        else 0.0
    )

    leg_specs = (
        ("leg_front", "hoof_front", cfg.leg_front, 1.0),
        ("leg_mid", "hoof_mid", cfg.leg_mid, 0.0),
        ("leg_back", "hoof_back", cfg.leg_back, -1.0),
    )
    for leg_name, hoof_name, leg_cfg, side_sign in leg_specs:
        if not leg_cfg.enabled:
            continue
        lw, lh = leg_cfg.size
        roundness = leg_cfg.roundness
        pin_inset = min(5.0, th * 0.25, lh * 0.15) * (1 - roundness)
        anchor = (
            tx + side_sign * (tw / 2.0 - lw * (1 - 0.45 * roundness)) + leg_cfg.anchor_offset[0],
            ty + th / 2.0 - pin_inset + leg_cfg.anchor_offset[1],
        )
        leg_pos = (anchor[0], anchor[1] + (lh / 2.0 - pin_inset * 0.5) * (1 - roundness))
        trim = (
            0.0
            if (cfg.hoof.shape_style == "rabbit" and leg_name == "leg_front")
            else min(hoof_trim, lh * 0.4)
        )
        leg_body, upper_shape, lower_shape, foot_tip, y_knee, knee_r = create_bent_leg(
            space, leg_pos, leg_cfg, shape_filter, bottom_trim=trim
        )
        spring, limit, cons = attach_part(space, torso, leg_body, anchor, leg_cfg.joint)
        bodies[leg_name] = leg_body
        shapes[leg_name] = upper_shape
        if lower_shape is not None:
            shapes[f"{leg_name}_lower"] = lower_shape
        limits[leg_name] = limit
        if lower_shape is not None:
            knee_caps[leg_name] = (y_knee, knee_r)
        constraints.extend(cons)
        if spring is not None:
            springs[leg_name] = spring
            if leg_cfg.joint is not None and abs(leg_cfg.joint.rest_deg) > 5.0:
                hip = leg_body.local_to_world((0.0, -lh / 2.0))
                leg_body.angle = torso.angle - spring.rest_angle
                new_hip = leg_body.local_to_world((0.0, -lh / 2.0))
                leg_body.position = (
                    leg_body.position.x + hip.x - new_hip.x,
                    leg_body.position.y + hip.y - new_hip.y,
                )
                leg_body.angular_velocity = 0.0

        if cfg.hoof.enabled and not (cfg.hoof.shape_style == "rabbit" and hoof_name == "hoof_front"):
            hoof_shape = create_hoof_shape(
                leg_body, leg_cfg, cfg.hoof, shape_filter, foot_tip=foot_tip
            )
            space.add(hoof_shape)
            shapes[hoof_name] = hoof_shape

        rotary = getattr(cfg.gait, {"leg_front": "rotary_front", "leg_back": "rotary_back", "leg_mid": "rotary_mid"}[leg_name])
        if rotary:
            motor = pymunk.SimpleMotor(torso, leg_body, 0.0)
            motor.max_force = 0.0
            space.add(motor)
            constraints.append(motor)
            rotary_motors[leg_name] = motor

    arm_specs = (
        ("arm_back", "hand_back", cfg.arm_back, -1.0),
        ("arm_front", "hand_front", cfg.arm_front, 1.0),
    )
    for arm_name, hand_name, arm_cfg, side_sign in arm_specs:
        if not arm_cfg.enabled:
            continue
        _, ah = arm_cfg.size
        hand_trim = min(max(0.0, cfg.hand.size[1] - 1.0), ah * 0.4) if cfg.hand.enabled else 0.0
        pin_inset = min(6.0, th * 0.20, ah * 0.20)
        anchor = (
            tx + side_sign * min(tw * 0.22, 6.0) + arm_cfg.anchor_offset[0],
            ty - th / 2.0 + pin_inset + arm_cfg.anchor_offset[1],
        )
        arm_pos = (anchor[0], anchor[1] + ah / 2.0 - pin_inset * 0.5)
        if abs(arm_cfg.knee_deg) > 0.05:
            arm_body, upper_shape, lower_shape, arm_tip, y_knee, knee_r = create_bent_leg(
                space, arm_pos, arm_cfg, shape_filter, bottom_trim=hand_trim
            )
            shapes[arm_name] = upper_shape
            shapes[f"{arm_name}_lower"] = lower_shape
            knee_caps[arm_name] = (y_knee, knee_r)
        else:
            arm_body, arm_shape = create_part(
                space, arm_pos, arm_cfg, shape_filter, bottom_trim=hand_trim
            )
            shapes[arm_name] = arm_shape
            arm_tip = (0.0, ah / 2.0)

        if cfg.hand.enabled:
            hand_shape = create_hand_shape(
                arm_body, arm_cfg, cfg.hand, shape_filter, foot_tip=arm_tip
            )
            space.add(hand_shape)
            shapes[hand_name] = hand_shape

        spring, limit, cons = attach_part(space, torso, arm_body, anchor, arm_cfg.joint)
        bodies[arm_name] = arm_body
        limits[arm_name] = limit
        constraints.extend(cons)
        if spring is not None:
            springs[arm_name] = spring
            if arm_cfg.joint is not None and abs(arm_cfg.joint.rest_deg) > 45.0:
                # Begin already at the outstretched rest so the spring does not wrench the torso.
                shoulder = arm_body.local_to_world((0.0, -ah / 2.0))
                arm_body.angle = torso.angle - spring.rest_angle
                new_shoulder = arm_body.local_to_world((0.0, -ah / 2.0))
                arm_body.position = (
                    arm_body.position.x + shoulder.x - new_shoulder.x,
                    arm_body.position.y + shoulder.y - new_shoulder.y,
                )
                arm_body.angular_velocity = 0.0

    if cfg.tail.enabled:
        tail_w, _ = cfg.tail.size
        tail_pin_inset = min(5.0, th * 0.25)
        tail_end_inset = min(5.0, tail_w * 0.15)
        tail_anchor = (
            tx - tw / 2.0 + cfg.tail.anchor_offset[0],
            ty - th / 2.0 + tail_pin_inset + cfg.tail.anchor_offset[1],
        )
        tail_pos = (tail_anchor[0] - tail_w / 2.0 + tail_end_inset, tail_anchor[1])
        tail, tail_shape = create_tail_part(space, tail_pos, cfg.tail, shape_filter)
        tail_spring, tail_limit, tail_cons = attach_part(
            space, torso, tail, tail_anchor, cfg.tail.joint
        )
        bodies["tail"] = tail
        shapes["tail"] = tail_shape
        if cfg.tail.shape_style == "forked":
            tail_h = cfg.tail.size[1]
            for side, sign in (("upper", -1.0), ("lower", 1.0)):
                fork = pymunk.Poly(tail, [(-tail_w * 0.10, 0.0),
                                         (-tail_w * 0.50, sign * tail_h),
                                         (-tail_w * 0.36, sign * tail_h * 0.16)])
                fork.mass = cfg.tail.mass * 0.12
                fork.friction = cfg.tail.friction
                fork.filter = shape_filter
                space.add(fork)
                shapes[f"tail_fork_{side}"] = fork
        limits["tail"] = tail_limit
        constraints.extend(tail_cons)
        if tail_spring is not None:
            springs["tail"] = tail_spring

    total_mass = sum(s.mass for s in shapes.values() if not s.sensor)

    return Creature(
        config=cfg,
        bodies=bodies,
        shapes=shapes,
        springs=springs,
        limits=limits,
        constraints=constraints,
        knee_caps=knee_caps,
        total_mass=total_mass,
        rotary_motors=rotary_motors,
    )


def build_creature_from_genome(
    space: pymunk.Space,
    genome: Genome | None = None,
    *,
    spawn_x: float = 400.0,
    floor_y: float = 550.0,
    mode: str = "walk",
    collision_group: int = 1,
    rng: random.Random | None = None,
) -> Creature:
    """Builds a physics Creature directly from a nucleotide Genome."""
    if genome is None:
        genome = random_horse_genome(rng=rng)
    cfg = config_from_genome(
        genome,
        spawn_x=spawn_x,
        floor_y=floor_y,
        mode=mode,
        collision_group=collision_group,
    )
    return build_creature(space, cfg)


def draw_scrolling_scenery(screen: pygame.Surface, camera_x: float, floor_y: int = 550):
    """Draws subtle parallax hills, fence posts, and ground markers for infinite scrolling."""
    width, height = screen.get_size()

    hill_points = [(0, floor_y)]
    for sx in range(0, width + 20, 20):
        wx = sx + camera_x * 0.25
        hy = floor_y - 60 - 30 * math.sin(wx * 0.004) - 18 * math.cos(wx * 0.011)
        hill_points.append((sx, hy))
    hill_points.append((width, floor_y))
    pygame.draw.polygon(screen, (36, 38, 52), hill_points)

    fence_spacing = 160
    first_post = math.floor(camera_x / fence_spacing) * fence_spacing
    pygame.draw.line(screen, (48, 50, 64), (0, floor_y - 38), (width, floor_y - 38), 3)
    for wx in range(int(first_post), int(camera_x + width + fence_spacing), fence_spacing):
        sx = wx - camera_x
        pygame.draw.rect(screen, (52, 54, 70), (sx - 3, floor_y - 52, 6, 52))

    pygame.draw.rect(screen, (22, 24, 32), (0, floor_y, width, height - floor_y))
    pygame.draw.line(screen, (85, 95, 115), (0, floor_y), (width, floor_y), 4)
    tick_spacing = 80
    first_tick = math.floor(camera_x / tick_spacing) * tick_spacing
    for wx in range(int(first_tick), int(camera_x + width + tick_spacing), tick_spacing):
        sx = wx - camera_x
        pygame.draw.line(screen, (55, 60, 75), (sx, floor_y + 4), (sx - 10, floor_y + 18), 2)
