"""Build a CreatureConfig from a phenotype, genome, or nucleotide strand."""
from __future__ import annotations

import math

from allele import _flex_limits, _flex_stiffness, _lerp
from gene import (
    ALL_LOCI,
    Genome,
    Phenotype,
    is_strand_complete,
)

from creature_config import (
    AppearanceConfig,
    CreatureConfig,
    CrestConfig,
    EyeConfig,
    GaitConfig,
    HornConfig,
    JointConfig,
    OrnamentConfig,
    PartConfig,
    PatternConfig,
    STRAND_SLOT_BY_LOCUS,
    WingConfig,
)

def config_from_phenotype(
    pheno: Phenotype,
    *,
    spawn_pos: tuple[float, float] = (0.0, 0.0),
    collision_group: int = 1,
    mode: str = "walk",
    genome: Genome | None = None,
) -> CreatureConfig:
    """Converts an evaluated genetic Phenotype into a physics/rendering CreatureConfig."""
    _arm_pose = min(1.0, pheno.erectness + 0.70 * pheno.grasp * (1.0 - pheno.erectness))
    neck_lo, neck_hi = _flex_limits(pheno.flex_neck, pheno.neck_min_deg, pheno.neck_max_deg)
    neck_stiff = _flex_stiffness(pheno.flex_neck)
    leg_stiff = _flex_stiffness(pheno.flex_leg)
    arm_lo, arm_hi = _flex_limits(pheno.flex_arm, -_lerp(55.0, 110.0, _arm_pose), _lerp(55.0, 110.0, _arm_pose))
    arm_stiff = _flex_stiffness(pheno.flex_arm)
    tail_lo, tail_hi = _flex_limits(pheno.flex_tail, -75.0, 15.0)
    tail_stiff = _flex_stiffness(pheno.flex_tail)
    lower_jaw_joint = (
        JointConfig(
            min_deg=-15.0,
            max_deg=35.0,
            rest_deg=5.0,
            stiffness=65000.0 * pheno.mass_scale,
            damping=4200.0 * pheno.mass_scale,
        )
        if pheno.lower_jaw_jointed
        else None
    )

    return CreatureConfig(
        spawn_pos=spawn_pos,
        collision_group=collision_group,
        label=pheno.label,
        genome=genome,
        trait_tags=pheno.trait_tags,
        centered_head=pheno.erectness >= 0.5,
        head_center=pheno.head_center,
        erectness=pheno.erectness,
        strand_loci=pheno.strand_loci,
        pure_strand=pheno.pure_strand,
        incomplete_strand_loci=pheno.incomplete_strand_loci,
        contour_seed=pheno.contour_seed,
        torso=PartConfig(
            size=pheno.torso_size,
            mass=pheno.torso_mass,
            friction=0.7,
            color=pheno.torso_color,
            shape_style=pheno.torso_style,
            components=pheno.torso_components,
            surface_regions=pheno.surface_regions,
        ),
        neck=PartConfig(
            size=pheno.neck_size,
            mass=pheno.neck_mass,
            anchor_offset=pheno.neck_anchor_offset,
            color=pheno.neck_color,
            enabled=pheno.neck_enabled,
            joint=JointConfig(
                min_deg=neck_lo,
                max_deg=neck_hi,
                rest_deg=pheno.neck_rest_deg,
                stiffness=400000.0 * pheno.joint_stiffness_scale * neck_stiff,
                damping=15000.0 * pheno.joint_damping_scale,
                progressive=pheno.erectness < 0.5,
            ),
        ),
        head=PartConfig(
            size=pheno.head_size,
            mass=pheno.head_mass,
            color=pheno.head_color,
            enabled=pheno.head_enabled,
            shape_style=pheno.head_style,
            joint=JointConfig(
                min_deg=pheno.head_min_deg,
                max_deg=pheno.head_max_deg,
                rest_deg=pheno.head_rest_deg,
                stiffness=150000.0 * pheno.joint_stiffness_scale,
                damping=7000.0 * pheno.joint_damping_scale,
                progressive=pheno.erectness < 0.5,
            ),
        ),
        upper_jaw=PartConfig(
            size=pheno.upper_jaw_size,
            mass=pheno.upper_jaw_mass,
            color=pheno.upper_jaw_color,
            enabled=pheno.upper_jaw_enabled,
        ),
        lower_jaw=PartConfig(
            size=pheno.lower_jaw_size,
            mass=pheno.lower_jaw_mass,
            color=pheno.lower_jaw_color,
            enabled=pheno.lower_jaw_enabled,
            joint=lower_jaw_joint,
        ),
        ear=PartConfig(
            size=pheno.ear_size,
            mass=pheno.ear_mass,
            color=pheno.ear_color,
            enabled=pheno.ear_enabled,
            shape_style=pheno.ear_style,
            tip_offset=pheno.ear_tip_offset,
            carriage=pheno.ear_carriage,
        ),
        teeth=PartConfig(
            size=pheno.teeth_size,
            mass=pheno.teeth_mass,
            color=pheno.teeth_color,
            enabled=pheno.teeth_enabled,
            shape_style=pheno.teeth_style,
        ),
        nose=PartConfig(
            size=pheno.nose_size,
            mass=pheno.nose_mass,
            color=pheno.nose_color,
            enabled=pheno.nose_enabled,
        ),
        leg_front=PartConfig(
            size=pheno.leg_front_size,
            mass=pheno.leg_front_mass,
            friction=1.0,
            anchor_offset=pheno.leg_front_anchor_offset,
            rounded_bottom=True,
            color=pheno.leg_front_color,
            enabled=pheno.leg_front_enabled,
            roundness=pheno.limb_roundness,
            inset_outline=pheno.limb_inset,
            knee_deg=pheno.leg_front_knee_deg,
            knee_ratio=pheno.leg_front_knee_ratio,
            lower_width_scale=pheno.leg_front_lower_scale,
            joint=JointConfig(
                min_deg=_flex_limits(
                    pheno.flex_leg,
                    min(-25.0, pheno.leg_front_rest_deg - 18.0),
                    max(25.0, pheno.leg_front_rest_deg + 18.0),
                )[0],
                max_deg=_flex_limits(
                    pheno.flex_leg,
                    min(-25.0, pheno.leg_front_rest_deg - 18.0),
                    max(25.0, pheno.leg_front_rest_deg + 18.0),
                )[1],
                rest_deg=pheno.leg_front_rest_deg,
                stiffness=pheno.leg_front_stiffness * leg_stiff,
                damping=pheno.leg_front_damping,
                progressive=False,
            ),
        ),
        leg_back=PartConfig(
            size=pheno.leg_back_size,
            mass=pheno.leg_back_mass,
            friction=1.0,
            anchor_offset=pheno.leg_back_anchor_offset,
            rounded_bottom=True,
            color=pheno.leg_back_color,
            enabled=pheno.leg_back_enabled,
            roundness=pheno.limb_roundness,
            inset_outline=pheno.limb_inset,
            knee_deg=pheno.leg_back_knee_deg,
            knee_ratio=pheno.leg_back_knee_ratio,
            lower_width_scale=pheno.leg_back_lower_scale,
            joint=JointConfig(
                min_deg=_flex_limits(
                    pheno.flex_leg,
                    _lerp(-16.0, -20.0, pheno.erectness),
                    _lerp(30.0, 20.0, pheno.erectness),
                )[0],
                max_deg=_flex_limits(
                    pheno.flex_leg,
                    _lerp(-16.0, -20.0, pheno.erectness),
                    _lerp(30.0, 20.0, pheno.erectness),
                )[1],
                rest_deg=pheno.leg_back_rest_deg,
                stiffness=pheno.leg_back_stiffness * leg_stiff,
                damping=pheno.leg_back_damping,
                progressive=False,
            ),
        ),
        leg_mid=PartConfig(
            size=pheno.leg_mid_size,
            mass=pheno.leg_mid_mass,
            friction=1.0,
            anchor_offset=pheno.leg_mid_anchor_offset,
            rounded_bottom=True,
            color=pheno.leg_mid_color,
            enabled=pheno.leg_mid_enabled,
            roundness=pheno.limb_roundness,
            inset_outline=pheno.limb_inset,
            knee_deg=pheno.leg_mid_knee_deg,
            knee_ratio=pheno.leg_mid_knee_ratio,
            lower_width_scale=pheno.leg_mid_lower_scale,
            joint=JointConfig(
                min_deg=-25.0,
                max_deg=25.0,
                rest_deg=pheno.leg_mid_rest_deg,
                stiffness=pheno.leg_mid_stiffness,
                damping=pheno.leg_mid_damping,
                progressive=False,
            ),
        ),
        arm_front=PartConfig(
            size=pheno.arm_front_size,
            mass=pheno.arm_front_mass,
            friction=0.4,
            rounded_bottom=True,
            anchor_offset=pheno.arm_front_anchor_offset,
            color=pheno.arm_front_color,
            enabled=pheno.arm_front_enabled,
            knee_deg=pheno.arm_front_knee_deg,
            joint=JointConfig(
                min_deg=arm_lo,
                max_deg=arm_hi,
                rest_deg=pheno.arm_front_rest_deg,
                stiffness=_lerp(120000.0, 280000.0, pheno.erectness) * pheno.mass_scale * arm_stiff * pheno.response_strength,
                damping=9000.0 * pheno.mass_scale * pheno.response_damping,
                progressive=False,
            ),
        ),
        arm_back=PartConfig(
            size=pheno.arm_back_size,
            mass=pheno.arm_back_mass,
            friction=0.4,
            rounded_bottom=True,
            anchor_offset=pheno.arm_back_anchor_offset,
            color=pheno.arm_back_color,
            enabled=pheno.arm_back_enabled,
            knee_deg=pheno.arm_back_knee_deg,
            joint=JointConfig(
                min_deg=arm_lo,
                max_deg=arm_hi,
                rest_deg=pheno.arm_back_rest_deg,
                stiffness=_lerp(120000.0, 280000.0, pheno.erectness) * pheno.mass_scale * arm_stiff * pheno.response_strength,
                damping=9000.0 * pheno.mass_scale * pheno.response_damping,
                progressive=False,
            ),
        ),
        hoof=PartConfig(
            size=pheno.hoof_size,
            mass=pheno.hoof_mass,
            friction=pheno.hoof_friction,
            enabled=pheno.hoof_enabled,
            shape_style=pheno.hoof_style,
            elasticity=pheno.hoof_elasticity,
            spring_bounce=pheno.hoof_spring_bounce,
        ),
        hand=PartConfig(
            size=pheno.hand_size,
            mass=0.04 * pheno.mass_scale,
            friction=0.4,
            enabled=pheno.hand_enabled,
        ),
        tail=PartConfig(
            size=pheno.tail_size,
            mass=pheno.tail_mass,
            anchor_offset=pheno.tail_anchor_offset,
            enabled=pheno.tail_enabled,
            shape_style=pheno.tail_style,
            joint=JointConfig(
                min_deg=tail_lo,
                max_deg=tail_hi,
                rest_deg=pheno.tail_rest_deg,
                stiffness=160000.0 * pheno.joint_stiffness_scale * tail_stiff,
                damping=7000.0 * pheno.joint_damping_scale,
            ),
        ),
        eye=EyeConfig(
            enabled=pheno.eye_enabled,
            offset=pheno.eye_offset,
            radius=pheno.eye_radius,
            pupil_offset=pheno.eye_pupil_offset,
            pupil_radius=pheno.eye_pupil_radius,
            sclera_color=pheno.eye_sclera_color,
            pupil_color=pheno.eye_pupil_color,
            lid=pheno.eye_lid,
            gaze=pheno.eye_gaze,
            brow=pheno.eye_brow,
        ),
        wing=WingConfig(
            enabled=pheno.wing_enabled,
            style=pheno.wing_style,
            span=pheno.wing_span,
            chord=pheno.wing_chord,
            color=pheno.wing_color,
            secondary_color=pheno.wing_secondary_color,
            lift_power=pheno.wing_lift,
            flap_freq=pheno.wing_flap_freq,
            drag=pheno.wing_drag,
            scallop=pheno.wing_scallop,
        ),
        horn=HornConfig(
            enabled=pheno.horn_enabled,
            kind=pheno.horn_kind,
            length=pheno.horn_length,
            thickness=pheno.horn_thickness,
            curve=pheno.horn_curve,
            tines=pheno.horn_tines,
            spread=pheno.horn_spread,
            color=pheno.horn_color,
            tip_color=pheno.horn_tip_color,
            seed=pheno.horn_seed,
            twist=pheno.horn_twist,
        ),
        crest=CrestConfig(
            enabled=pheno.crest_enabled,
            style=pheno.crest_style,
            size=pheno.crest_size,
            spread=pheno.crest_spread,
            count=pheno.crest_count,
            color=pheno.crest_color,
            tip_color=pheno.crest_tip_color,
            has_poms=pheno.crest_has_poms,
            branches=pheno.crest_branches,
            seed=pheno.crest_seed,
            pom_scale=pheno.crest_pom_scale,
            pom_style=pheno.crest_pom_style,
            pendants=pheno.crest_pendants,
        ),
        appearance=AppearanceConfig(
            coat_color=pheno.coat_color,
            back_leg_color=pheno.back_leg_color,
            hoof_front_color=pheno.hoof_front_color,
            hoof_back_color=pheno.hoof_back_color,
            hand_color=pheno.hand_color,
            hand_back_color=pheno.hand_back_color,
            tail_color=pheno.tail_color,
            tooth_color=pheno.tooth_color,
            nose_color=pheno.nose_color,
            pattern=PatternConfig(
                style=pheno.pattern_style,
                color=pheno.pattern_color,
                density=pheno.pattern_density,
                scale=pheno.pattern_scale,
                seed=pheno.pattern_seed,
            ),
        ),
        gait=GaitConfig(
            enabled=pheno.gait_enabled,
            mode=mode,
            behavior=pheno.behavior,
            walk_freq=pheno.walk_freq,
            stride_deg=pheno.stride_deg,
            run_freq=pheno.run_freq,
            run_stride_deg=pheno.run_stride_deg,
            run_target_speed=pheno.run_target_speed,
            run_phase_offset_deg=pheno.run_phase_offset_deg,
            tail_sway_deg=pheno.tail_sway_deg,
            balance_stiffness=pheno.balance_stiffness,
            balance_damping=pheno.balance_damping,
            balance_max_torque=pheno.balance_max_torque,
            hop_blend=pheno.lagomorph,
            spasm=pheno.spasm,
            sentience=pheno.sentience,
            can_speak=pheno.sentience > 0.35 and (pheno.upper_jaw_enabled or pheno.lower_jaw_enabled),
            diet=pheno.diet,
            neuro_trait=pheno.neuro_trait,
            metabolic_trait=pheno.metabolic_trait,
            reflex_trait=pheno.reflex_trait,
            rotary_front=pheno.rotary_front,
            rotary_back=pheno.rotary_back,
            rotary_mid=pheno.rotary_mid,
            leg_flex=pheno.flex_leg,
            head_pitch_deg=pheno.head_pitch_deg,
            neck_carriage_deg=pheno.neck_carriage_deg,
        ),
        upper_teeth=pheno.upper_teeth,
        lower_teeth=pheno.lower_teeth,
        bite=pheno.bite,
        spike_amp=pheno.osteoderm_amp,
        spike_freq=pheno.osteoderm_freq,
        spike_color=pheno.osteoderm_color,
        ornament=OrnamentConfig(
            enabled=pheno.ornament_enabled,
            style=pheno.ornament_style,
            count=pheno.ornament_count,
            size=pheno.ornament_size,
            color=pheno.pattern_color,
            seed=pheno.contour_seed,
        ),
    )


def config_from_genome(
    genome: Genome,
    *,
    spawn_x: float = 0.0,
    floor_y: float = 550.0,
    mode: str = "walk",
    collision_group: int = 1,
    age: int = 1,
) -> CreatureConfig:
    """Evaluates a Genome into a ground-aligned CreatureConfig."""
    pheno = genome.evaluate(age=age)
    cfg = config_from_phenotype(
        pheno,
        spawn_pos=(spawn_x, 0.0),
        collision_group=collision_group,
        mode=mode,
        genome=genome,
    )
    spawn_y = compute_spawn_y(cfg, floor_y=floor_y)
    return cfg.with_(spawn_pos=(spawn_x, spawn_y))


def _scale_part(
    part: PartConfig,
    scale: float,
    *,
    length_mul: float = 1.0,
    width_mul: float = 1.0,
    shape_style: str | None = None,
) -> PartConfig:
    w, h = part.size
    joint = part.joint
    if joint is not None:
        joint = joint.with_(
            stiffness=joint.stiffness * scale * scale,
            damping=joint.damping * scale * scale,
        )
    changes: dict = {
        "size": (w * scale * width_mul, h * scale * length_mul),
        "mass": max(0.02, part.mass * scale * scale),
        "anchor_offset": (part.anchor_offset[0] * scale, part.anchor_offset[1] * scale),
        "joint": joint,
    }
    if shape_style is not None:
        changes["shape_style"] = shape_style
    return part.with_(**changes)


def rabbit_config_from_genome(
    genome: Genome,
    *,
    spawn_x: float = 0.0,
    floor_y: float = 550.0,
    mode: str = "walk",
    collision_group: int = 1,
    age: int = 1,
) -> CreatureConfig:
    """Shape comes from the genome. A rabbit genome already carries the saltatory axis."""
    return config_from_genome(
        genome,
        spawn_x=spawn_x,
        floor_y=floor_y,
        mode=mode,
        collision_group=collision_group,
        age=age,
    )


def strand_creature_config(
    locus_num: int,
    alleles: tuple[str, str],
    *,
    spawn_x: float = 0.0,
    floor_y: float = 550.0,
    collision_group: int = 1,
    genome: Genome | None = None,
) -> CreatureConfig:
    """Builds a CreatureConfig for a single- or multi-locus X-chromosome strand creature."""
    disabled = PartConfig(size=(4.0, 4.0), mass=0.01, enabled=False)
    if genome is not None and genome.strand_loci:
        loci = genome.strand_loci
    else:
        idx = max(0, min(len(ALL_LOCI) - 1, locus_num - 1))
        loci = (ALL_LOCI[idx],)

    is_multi = len(loci) > 1
    slots = {STRAND_SLOT_BY_LOCUS.get(l, "tendril") for l in loci}
    incomplete_loci = tuple(
        l for l in loci
        if genome is not None and l in genome.genes and not genome.genes[l].is_complete()
    )
    if genome is None and not (is_strand_complete(alleles[0]) and is_strand_complete(alleles[1])):
        incomplete_loci = loci

    label_str = "#" + "+".join(str(ALL_LOCI.index(l) + 1) for l in loci[:4])
    if len(loci) > 4:
        label_str += "+"

    drive_pheno = genome.evaluate(age=1) if genome is not None else None
    pheno = drive_pheno if is_multi else None
    scale_mult = max(0.78, min(1.32, pheno.overall_scale)) if pheno is not None else 1.0

    # A single captured strand is purely a standalone X-strand in the truck to edit;
    # appendages only emerge when combined into a multi-locus strand via breeding.
    wing_cfg = (
        WingConfig(
            enabled=True,
            style=pheno.wing_style if pheno is not None else "feathery",
            span=(pheno.wing_span if pheno is not None else 74.0),
            chord=(pheno.wing_chord if pheno is not None else 30.0),
            lift_power=(pheno.wing_lift if pheno is not None else 1.0),
            flap_freq=(pheno.wing_flap_freq if pheno is not None else 3.4),
            drag=(pheno.wing_drag if pheno is not None else 0.22),
        )
        if (is_multi and "wing" in slots and (pheno is None or pheno.wing_enabled))
        else WingConfig(enabled=False)
    )
    horn_cfg = (
        HornConfig(
            enabled=True,
            kind=pheno.horn_kind if pheno is not None else "pointed",
            length=pheno.horn_length if pheno is not None else 34.0,
            thickness=pheno.horn_thickness if pheno is not None else 6.0,
            curve=pheno.horn_curve if pheno is not None else 0.0,
            tines=pheno.horn_tines if pheno is not None else 3,
            spread=pheno.horn_spread if pheno is not None else 0.6,
            seed=pheno.horn_seed if pheno is not None else 0,
        )
        if (is_multi and "horn" in slots and (pheno is None or pheno.horn_enabled))
        else HornConfig(enabled=False)
    )
    tail_cfg = (
        PartConfig(
            size=(
                max(40.0, min(92.0, pheno.tail_size[0] if pheno is not None else 56.0)),
                max(8.0, min(20.0, pheno.tail_size[1] if pheno is not None else 11.0)),
            ),
            mass=0.65 * scale_mult,
            anchor_offset=(0.0, 10.0),
            enabled=True,
            shape_style=pheno.tail_style if pheno is not None else "tapered",
            joint=JointConfig(
                min_deg=-70.0,
                max_deg=20.0,
                rest_deg=pheno.tail_rest_deg if pheno is not None else -35.0,
                stiffness=130000.0 * scale_mult,
                damping=6500.0 * scale_mult,
            ),
        )
        if (is_multi and "tail" in slots and (pheno is None or pheno.tail_enabled))
        else disabled
    )

    arm_h = 68.0 * scale_mult
    leg_h = 128.0 * scale_mult
    torso_s = 38.0 * scale_mult

    cfg = CreatureConfig(
        spawn_pos=(spawn_x, 0.0),
        collision_group=collision_group,
        label=label_str,
        genome=genome,
        trait_tags=pheno.trait_tags if pheno is not None else (),
        strand_locus_num=locus_num,
        strand_alleles=alleles,
        strand_loci=loci,
        pure_strand=True,
        incomplete_strand_loci=incomplete_loci,
        torso=PartConfig(
            size=(torso_s, torso_s),
            mass=12.0 * (scale_mult**2),
            friction=0.75,
            color=(16, 16, 22),
        ),
        neck=disabled,
        head=disabled,
        upper_jaw=disabled,
        lower_jaw=disabled,
        ear=disabled,
        teeth=disabled,
        nose=disabled,
        tail=tail_cfg,
        hoof=disabled,
        hand=disabled,
        eye=EyeConfig(enabled=False),
        wing=wing_cfg,
        horn=horn_cfg,
        arm_back=PartConfig(
            size=(13.0 * scale_mult, arm_h),
            mass=0.85 * scale_mult,
            friction=0.5,
            anchor_offset=(-8.0 * scale_mult, -2.0 * scale_mult),
            rounded_bottom=False,
            enabled=True,
            joint=JointConfig(
                min_deg=114.0,
                max_deg=170.0,
                rest_deg=142.0,
                stiffness=220000.0 * scale_mult,
                damping=12000.0 * scale_mult,
                progressive=False,
            ),
        ),
        arm_front=PartConfig(
            size=(13.0 * scale_mult, arm_h),
            mass=0.85 * scale_mult,
            friction=0.5,
            anchor_offset=(8.0 * scale_mult, -2.0 * scale_mult),
            rounded_bottom=False,
            enabled=True,
            joint=JointConfig(
                min_deg=-170.0,
                max_deg=-114.0,
                rest_deg=-142.0,
                stiffness=220000.0 * scale_mult,
                damping=12000.0 * scale_mult,
                progressive=False,
            ),
        ),
        leg_back=PartConfig(
            size=(14.0 * scale_mult, leg_h),
            mass=2.2 * scale_mult,
            friction=1.0,
            anchor_offset=(-9.0 * scale_mult, 2.0 * scale_mult),
            rounded_bottom=False,
            enabled=True,
            knee_deg=-9.0,
            knee_ratio=0.5,
            lower_width_scale=1.0,
            joint=JointConfig(
                min_deg=6.0,
                max_deg=48.0,
                rest_deg=24.0,
                stiffness=1150000.0 * (scale_mult**2),
                damping=22000.0 * (scale_mult**2),
                progressive=False,
            ),
        ),
        leg_front=PartConfig(
            size=(14.0 * scale_mult, leg_h),
            mass=2.2 * scale_mult,
            friction=1.0,
            anchor_offset=(9.0 * scale_mult, 2.0 * scale_mult),
            rounded_bottom=False,
            enabled=True,
            knee_deg=9.0,
            knee_ratio=0.5,
            lower_width_scale=1.0,
            joint=JointConfig(
                min_deg=-48.0,
                max_deg=-6.0,
                rest_deg=-24.0,
                stiffness=1150000.0 * (scale_mult**2),
                damping=22000.0 * (scale_mult**2),
                progressive=False,
            ),
        ),
        gait=GaitConfig(
            enabled=False,
            mode="walk",
            behavior=pheno.behavior if pheno is not None else "gallop",
            walk_freq=pheno.walk_freq if pheno is not None else 1.25,
            stride_deg=pheno.stride_deg if pheno is not None else 14.0,
            front_leg_center_deg=-24.0,
            back_leg_center_deg=24.0,
            run_freq=pheno.run_freq if pheno is not None else 1.95,
            run_stride_deg=pheno.run_stride_deg if pheno is not None else 20.0,
            run_target_speed=pheno.run_target_speed if pheno is not None else 280.0,
            run_phase_offset_deg=155.0,
            balance_stiffness=(pheno.balance_stiffness * 0.75) if pheno is not None else 420000.0,
            balance_damping=(pheno.balance_damping * 0.75) if pheno is not None else 42000.0,
            balance_max_torque=(pheno.balance_max_torque * 0.80) if pheno is not None else 260000.0,
            rotary_front=drive_pheno.rotary_front if drive_pheno is not None else 0.0,
            rotary_back=drive_pheno.rotary_back if drive_pheno is not None else 0.0,
            rotary_mid=drive_pheno.rotary_mid if drive_pheno is not None else 0.0,
        ),
    )
    spawn_y = compute_spawn_y(cfg, floor_y=floor_y)
    return cfg.with_(spawn_pos=(spawn_x, spawn_y))

def compute_spawn_y(cfg: CreatureConfig, floor_y: float = 550.0) -> float:
    """Computes torso spawn y so the creature's hooves/feet start just above floor_y."""
    th = cfg.torso.size[1]
    reaches = [th / 2.0]

    for leg_cfg in (cfg.leg_front, cfg.leg_back, cfg.leg_mid):
        if not leg_cfg.enabled:
            continue
        lh = leg_cfg.size[1]
        if leg_cfg.roundness > 0.0:
            pin = min(5.0, th * 0.25, lh * 0.15) * (1 - leg_cfg.roundness)
            reaches.append(th / 2.0 - pin + leg_cfg.anchor_offset[1]
                           + (lh / 2 - pin * 0.5) * (1 - leg_cfg.roundness) + lh / 2)
            continue
        pin_inset = min(5.0, th * 0.25, lh * 0.15)
        knee_ratio = max(0.25, min(0.75, leg_cfg.knee_ratio))
        upper_h = lh * knee_ratio
        lower_h = lh - upper_h
        knee_rad = math.radians(max(-15.0, min(15.0, leg_cfg.knee_deg)))
        rest_rad = (
            math.radians(leg_cfg.joint.rest_deg)
            if (leg_cfg.joint is not None and abs(leg_cfg.joint.rest_deg) > 5.0)
            else 0.0
        )
        leg_reach = (
            th / 2.0
            - pin_inset
            + leg_cfg.anchor_offset[1]
            + (upper_h + lower_h * math.cos(knee_rad) - 0.5 * pin_inset) * math.cos(rest_rad)
        )
        reaches.append(leg_reach)

    return floor_y - max(reaches) - 2.0
