"""Nucleotide primitives, allele decode, and diploid genes."""
from __future__ import annotations

from dataclasses import dataclass
import random

NUCLEOTIDES: tuple[str, ...] = ("A", "C", "G", "T")
BASE_TO_INT: dict[str, int] = {"A": 0, "C": 1, "G": 2, "T": 3}
GAP_BASE = "-"
VALID_STRAND_CHARS: frozenset[str] = frozenset(NUCLEOTIDES) | {GAP_BASE}
STOP_CODONS: tuple[str, ...] = ("TAA", "TAG", "TGA")
ALLELE_LENGTH = 24  # 8 triplet codons per strand


def is_strand_complete(seq: str) -> bool:
    return len(seq) == ALLELE_LENGTH and all(ch in BASE_TO_INT for ch in seq)

# Canonical 64-locus universal genome. Append new loci to preserve strand numbers.
ALL_LOCI: tuple[str, ...] = (
    # Group 1: Master Body Plan & Hox Regulators
    "hox_posture",
    "hox_limb_gate",
    "hox_cranial",
    "hox_caudal",
    "size_somatic",
    "build_robust",
    # Group 2: Skeletal Proportions & Cranial Morphology
    "torso_len",
    "torso_depth",
    "body_contour",
    "neck_morph",
    "head_size",
    "jaw_morph",
    "teeth_dev",
    "nose_dev",
    "ear_form",
    # Group 3: Limbs, Hooves & Tail
    "limb_fore",
    "limb_hind",
    "limb_extra",
    "arm_dev",
    "hoof_dev",
    "tail_form",
    "symmetry_mod",
    # Group 4: Ocular, Iris & Sensory Reflex
    "eye_dev",
    "iris_chrom",
    "sense_reflex",
    # Group 5: Pigmentation, Markings & Mutators
    "pigment_base",
    "pigment_dilute",
    "pattern_locus",
    "pattern_chrom",
    "color_mutator",
    "tail_pigment",
    # Group 6: Locomotion, Balance, Physiology & Track Behavior
    "gait_cadence",
    "gait_power",
    "balance_core",
    "bone_density",
    "neuro_temperament",
    "metabolic_drive",
    # Group 7: Complex Appendages, Cranial Outgrowths & Gait Behaviors
    "wing_dev",
    "wing_chrom",
    "horn_dev",
    "crest_dev",
    "behavior_locus",
    # Neutral at 0.5. Primary biases erectness, secondary biases grasp.
    # Tertiary is the saltatory axis: 0.5 is horse-sized, toward 1 is rabbit-like.
    "axial_plan",
    # Diet axis. Low is herbivore, middle omnivore, high carnivore.
    "diet_guild",
    # Back armor. Inactive at wild type. Primary amplitude, secondary spacing, tertiary color.
    "osteoderm",
    # Joint range. 0.5 keeps the current limits. 0 locks, 1 opens to a full turn.
    # Primary legs, secondary neck, tertiary arms, UTR tail.
    "joint_flex",
    # Primary removes days from the 10-day life. Secondary is spasm intensity.
    "vital_span",
    # High on both alleles: white coat, crossed eyes, the foal is born dead.
    "lethal_white",
    # Primary is sentience. Secondary and tertiary reshape the head around 0.5.
    "sentience",
    # Primary tooth outline, secondary upper teeth, tertiary lower teeth, UTR bite.
    "dentition",
    # Group 8: Proportions, appendage geometry, ornament, and joint control.
    # Each quantitative channel is neutral at 0.5.
    "cranial_shape",   # head width, depth, outline
    "muzzle_shape",    # muzzle length, depth, nose scale
    "eye_expression",  # eye size, height, gaze / brow
    "ear_shape",       # ear length, width, carriage
    "limb_shape",      # limb thickness, taper, bend
    "tail_shape",      # tail length, plume width, curl / fork
    "wing_shape",      # span, chord, fan / scalloped outline
    "horn_shape",      # curl, spread, branching
    "crest_shape",     # fan / rosette / antenna outline, size, spread
    "crest_ornament",  # pom size, pendants, round / diamond tips
    "skin_ornament",   # ornament density, size, beads / rosettes / plates
    "joint_response",  # spring strength, damping, compliance
    "joint_pose",      # neck carriage, head pitch, arm repose
    "rotary_drive",    # front / hind / middle leg rotation; UTR sets speed
)

EXPRESSION_LOCI: tuple[str, ...] = ALL_LOCI[50:]

REGULATORY_MOTIFS: tuple[str, ...] = (
    "CGCG",
    "GGGG",
    "CCCC",
    "ATAT",
    "ATAC",
    "TTAA",
    "GTAC",
    "CATG",
    "ACGT",
)

EXOTIC_COLOR_MOTIFS: dict[str, str] = {
    "TTAGGG": "Albino",
    "CCCCCC": "Obsidian",
    "ACACAC": "Crimson",
    "GCGCGC": "Cobalt",
    "TGTGTG": "Lavender",
    "ATATAT": "Verdant",
    "GGGGGG": "Solar",
    "ACGTAC": "Chimera",
}

DOMINANT_EXOTIC_COLORS = {"Crimson", "Solar", "Chimera", "Obsidian"}


def _clamp(v: float, lo: float, hi: float) -> float:
    return lo if v < lo else (hi if v > hi else v)


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def _smoothstep(t: float) -> float:
    t = _clamp(t, 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def _flex_limits(channel: float, lo: float, hi: float) -> tuple[float, float]:
    """0.5 keeps lo/hi. Toward 0 the span shrinks to 0. Toward 1 it opens to 360°."""
    span = hi - lo
    mid = (lo + hi) * 0.5
    if abs(channel - 0.5) < 0.04:
        return lo, hi
    if channel > 0.5:
        span = _lerp(span, 360.0, (channel - 0.5) / 0.5)
    else:
        span = _lerp(0.0, span, channel / 0.5)
    return mid - span * 0.5, mid + span * 0.5


def _flex_stiffness(channel: float) -> float:
    """0.5 leaves stiffness alone. Wider joints loosen. Narrower joints tighten."""
    if abs(channel - 0.5) < 0.04:
        return 1.0
    if channel > 0.5:
        return _lerp(1.0, 0.30, (channel - 0.5) / 0.5)
    return _lerp(1.0, 1.75, (0.5 - channel) / 0.5)


def _rise(x: float, lo: float, hi: float) -> float:
    """0 at or below lo, 1 at or above hi, smooth between."""
    if hi <= lo:
        return 1.0 if x >= hi else 0.0
    return _smoothstep((x - lo) / (hi - lo))


def _int_to_codon(idx: int) -> str:
    idx = idx % 64
    return (
        NUCLEOTIDES[(idx >> 4) & 3]
        + NUCLEOTIDES[(idx >> 2) & 3]
        + NUCLEOTIDES[idx & 3]
    )


def _codon_to_int(codon: str) -> int:
    return (
        (BASE_TO_INT.get(codon[0], 0) << 4)
        | (BASE_TO_INT.get(codon[1], 0) << 2)
        | BASE_TO_INT.get(codon[2], 0)
    )


def _normalize_strand(seq: str) -> str:
    cleaned = "".join(ch for ch in seq.upper() if ch in VALID_STRAND_CHARS)
    if len(cleaned) < ALLELE_LENGTH:
        cleaned = (cleaned + GAP_BASE * ALLELE_LENGTH)[:ALLELE_LENGTH]
    elif len(cleaned) > ALLELE_LENGTH:
        cleaned = cleaned[:ALLELE_LENGTH]
    return cleaned


def _encode_pair(val: float, avoid_stop: bool = True) -> str:
    idx = int(round(_clamp(val, 0.0, 1.0) * 4095.0))
    c_hi = (idx >> 6) & 63
    c_lo = idx & 63
    cod_hi = _int_to_codon(c_hi)
    cod_lo = _int_to_codon(c_lo)
    if avoid_stop:
        while cod_hi in STOP_CODONS:
            c_hi = (c_hi + 1) % 64
            cod_hi = _int_to_codon(c_hi)
        while cod_lo in STOP_CODONS:
            c_lo = (c_lo + 1) % 64
            cod_lo = _int_to_codon(c_lo)
    return cod_hi + cod_lo


def encode_allele(
    primary: float,
    secondary: float = 0.5,
    tertiary: float = 0.5,
    promoter: str | None = None,
    utr: str | None = None,
    avoid_stop: bool = True,
    motif_patch: str | None = None,
    patch_offset: int = 9,
) -> str:
    """Encodes quantitative & regulatory traits directly into a 24-nt DNA strand."""
    if promoter is None:
        promoter = "TAC"
    if utr is None:
        utr = "CAG"
    p_str = _normalize_strand(promoter)[:3]
    u_str = _normalize_strand(utr)[:3]
    body = (
        _encode_pair(primary, avoid_stop=avoid_stop)
        + _encode_pair(secondary, avoid_stop=avoid_stop)
        + _encode_pair(tertiary, avoid_stop=avoid_stop)
    )
    seq = p_str + body + u_str
    if motif_patch:
        patch = "".join(ch for ch in motif_patch.upper() if ch in BASE_TO_INT)
        off = max(3, min(ALLELE_LENGTH - 3 - len(patch), patch_offset))
        seq = seq[:off] + patch + seq[off + len(patch) :]
    return seq[:ALLELE_LENGTH]


@dataclass(frozen=True)
class AlleleReadout:
    seq: str
    active: bool
    promoter_strength: float
    dominance: float
    primary: float
    secondary: float
    tertiary: float
    utr_val: float
    utr_code: int
    gc_content: float
    stop_count: int
    motifs: tuple[str, ...]
    exotic_motifs: tuple[str, ...]
    complete: bool = True


def decode_allele(seq: str) -> AlleleReadout:
    """Decodes a 24-nt DNA strand purely from its nucleotides."""
    s = _normalize_strand(seq)
    complete = is_strand_complete(s)
    codons = [s[i : i + 3] for i in range(0, ALLELE_LENGTH, 3)]
    prom = codons[0]

    if (not complete) or (prom in STOP_CODONS) or (GAP_BASE in prom):
        prom_strength = 0.0
    elif prom == "ATG":
        prom_strength = 1.25
    elif prom in ("GGG", "GGC", "CCG", "CCC"):
        prom_strength = 1.15
    elif prom in ("TAT", "TAC"):
        prom_strength = 1.05
    else:
        prom_strength = 0.58 + (_codon_to_int(prom) / 63.0) * 0.52

    inframe_stops = sum(
        1 for c in codons[1:7] if GAP_BASE not in c and c in STOP_CODONS
    )
    active = complete and (prom not in STOP_CODONS) and (inframe_stops < 2)

    c1, c2 = _codon_to_int(codons[1]), _codon_to_int(codons[2])
    c3, c4 = _codon_to_int(codons[3]), _codon_to_int(codons[4])
    c5, c6 = _codon_to_int(codons[5]), _codon_to_int(codons[6])
    c7 = _codon_to_int(codons[7])

    primary = ((c1 << 6) | c2) / 4095.0
    secondary = ((c3 << 6) | c4) / 4095.0
    tertiary = ((c5 << 6) | c6) / 4095.0
    utr_val = c7 / 63.0

    gc = sum(1 for ch in s if ch in ("G", "C")) / float(ALLELE_LENGTH)
    motifs = tuple(m for m in REGULATORY_MOTIFS if m in s) if complete else ()
    exotic_motifs = (
        tuple(name for motif, name in EXOTIC_COLOR_MOTIFS.items() if motif in s)
        if complete
        else ()
    )

    dominance = prom_strength * (0.75 + 0.5 * gc)
    if "GGGG" in motifs:
        dominance *= 1.20
    if "CCCC" in motifs:
        dominance *= 0.85

    return AlleleReadout(
        seq=s,
        active=active,
        promoter_strength=prom_strength,
        dominance=dominance if active else 0.05,
        primary=primary,
        secondary=secondary,
        tertiary=tertiary,
        utr_val=utr_val,
        utr_code=c7,
        gc_content=gc,
        stop_count=inframe_stops,
        motifs=motifs,
        exotic_motifs=exotic_motifs,
        complete=complete,
    )


@dataclass(frozen=True)
class GeneExpression:
    locus: str
    active: bool
    dosage: float  # 0.0 (null), ~0.78 (heterozygote), ~1.0+ (both active)
    primary: float
    secondary: float
    tertiary: float
    utr_val: float
    utr_code: int
    shared_motifs: tuple[str, ...]  # homozygous / present on both alleles
    any_motifs: tuple[str, ...]     # present on at least one allele
    homozygous_exotic: tuple[str, ...]
    any_exotic: tuple[str, ...]
    readout_a: AlleleReadout
    readout_b: AlleleReadout
    complete: bool = True


@dataclass(frozen=True)
class Gene:
    """A diploid gene locus consisting of two 24-nucleotide DNA strands."""

    locus: str
    allele_a: str
    allele_b: str

    def __post_init__(self):
        object.__setattr__(self, "allele_a", _normalize_strand(self.allele_a))
        object.__setattr__(self, "allele_b", _normalize_strand(self.allele_b))

    def is_complete(self) -> bool:
        return is_strand_complete(self.allele_a) and is_strand_complete(self.allele_b)

    def express(self) -> GeneExpression:
        ra = decode_allele(self.allele_a)
        rb = decode_allele(self.allele_b)
        both_complete = ra.complete and rb.complete

        if not ra.active and not rb.active:
            return GeneExpression(
                locus=self.locus,
                active=False,
                dosage=0.0,
                primary=0.5 * (ra.primary + rb.primary),
                secondary=0.5 * (ra.secondary + rb.secondary),
                tertiary=0.5 * (ra.tertiary + rb.tertiary),
                utr_val=0.5 * (ra.utr_val + rb.utr_val),
                utr_code=(ra.utr_code + rb.utr_code) // 2,
                shared_motifs=tuple(m for m in ra.motifs if m in rb.motifs),
                any_motifs=tuple(sorted(set(ra.motifs) | set(rb.motifs))),
                homozygous_exotic=tuple(m for m in ra.exotic_motifs if m in rb.exotic_motifs),
                any_exotic=tuple(sorted(set(ra.exotic_motifs) | set(rb.exotic_motifs))),
                readout_a=ra,
                readout_b=rb,
                complete=both_complete,
            )

        if ra.active and not rb.active:
            dosage = 0.72 * ra.promoter_strength
            wa, wb = 0.88, 0.12
        elif rb.active and not ra.active:
            dosage = 0.72 * rb.promoter_strength
            wa, wb = 0.12, 0.88
        else:
            dosage = 0.5 * (ra.promoter_strength + rb.promoter_strength)
            total_dom = ra.dominance + rb.dominance
            wa = ra.dominance / total_dom
            wb = rb.dominance / total_dom

        return GeneExpression(
            locus=self.locus,
            active=True,
            dosage=_clamp(dosage, 0.25, 1.5),
            primary=wa * ra.primary + wb * rb.primary,
            secondary=wa * ra.secondary + wb * rb.secondary,
            tertiary=wa * ra.tertiary + wb * rb.tertiary,
            utr_val=wa * ra.utr_val + wb * rb.utr_val,
            utr_code=ra.utr_code if wa >= wb else rb.utr_code,
            shared_motifs=tuple(m for m in ra.motifs if m in rb.motifs),
            any_motifs=tuple(sorted(set(ra.motifs) | set(rb.motifs))),
            homozygous_exotic=tuple(m for m in ra.exotic_motifs if m in rb.exotic_motifs),
            any_exotic=tuple(sorted(set(ra.exotic_motifs) | set(rb.exotic_motifs))),
            readout_a=ra,
            readout_b=rb,
            complete=both_complete,
        )

    def mutate(self, point_rate: float = 0.02, rng: random.Random | None = None) -> "Gene":
        rng = rng or random.Random()

        def mut_strand(seq: str) -> str:
            chars = list(seq)
            for idx in range(len(chars)):
                if chars[idx] in BASE_TO_INT and rng.random() < point_rate:
                    choices = [b for b in NUCLEOTIDES if b != chars[idx]]
                    chars[idx] = rng.choice(choices)
            return "".join(chars)

        return Gene(self.locus, mut_strand(self.allele_a), mut_strand(self.allele_b))

    def recombine_gamete(self, rng: random.Random | None = None) -> str:
        """Meiotic crossover between allele_a and allele_b to yield one haploid strand."""
        rng = rng or random.Random()
        a, b = (self.allele_a, self.allele_b) if rng.random() < 0.5 else (self.allele_b, self.allele_a)
        if rng.random() < 0.35:
            cut = rng.randint(1, ALLELE_LENGTH - 1)
            return a[:cut] + b[cut:]
        return a

    def crossover(self, other: "Gene", rng: random.Random | None = None) -> "Gene":
        rng = rng or random.Random()
        return Gene(
            locus=self.locus,
            allele_a=self.recombine_gamete(rng),
            allele_b=other.recombine_gamete(rng),
        )
