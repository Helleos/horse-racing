"""Creature part, gait, and appearance configuration."""
from __future__ import annotations

from dataclasses import dataclass, field, replace
import math
import pygame

from gene import Genome

@dataclass
class PatternConfig:
    style: str = "flat"  # "flat", "dotted", "striped", "blobs"
    color: tuple[int, int, int] = (242, 236, 224)
    density: float = 0.5  # 0.0 to 1.0
    scale: float = 1.0
    seed: int = 0

    def with_(self, **changes) -> "PatternConfig":
        return replace(self, **changes)


@dataclass
class JointConfig:
    min_deg: float = -30.0
    max_deg: float = 30.0
    rest_deg: float = 0.0
    stiffness: float = 150000.0
    damping: float = 8000.0
    progressive: bool = True

    def with_(self, **changes) -> "JointConfig":
        return replace(self, **changes)


@dataclass
class PartConfig:
    size: tuple[float, float]
    mass: float
    friction: float = 0.7
    joint: JointConfig | None = None
    anchor_offset: tuple[float, float] = (0.0, 0.0)
    rounded_bottom: bool = False
    color: tuple[int, int, int] | None = None
    enabled: bool = True
    # Leg / arm bend (purely geometric bend, NOT a joint)
    knee_deg: float = 0.0  # -15.0 to 15.0
    knee_ratio: float = 0.5
    lower_width_scale: float = 0.86
    # Optional shape variations for ears ("pointed", "curved", "rounded"),
    # tails ("sleek", "tapered", "bushy", "flowing"),
    # and hooves ("standard", "thick", "thin", "cloven", "rocker", "pointed")
    shape_style: str = "default"
    tip_offset: float = 0.35
    carriage: float = 0.0  # 0 side ear, 1 upright oval ear
    elasticity: float = 0.0
    spring_bounce: float = 0.0
    roundness: float = 0.0
    inset_outline: tuple[tuple[float, float], ...] = ()
    components: tuple[tuple[tuple[float, float], ...], ...] = ()
    surface_regions: tuple[tuple[tuple[float, float], ...], ...] = ()

    def with_(self, **changes) -> "PartConfig":
        return replace(self, **changes)


@dataclass
class EyeConfig:
    enabled: bool = True
    offset: tuple[float, float] = (7.0, -4.5)
    radius: float = 4.5
    pupil_offset: tuple[float, float] = (1.3, 0.0)
    pupil_radius: float = 2.4
    sclera_color: tuple[int, int, int] = (255, 255, 255)
    pupil_color: tuple[int, int, int] = (95, 105, 185)
    lid: str = "open"  # "open", "closed", "cross"
    gaze: float = 0.0
    brow: float = 0.0

    def with_(self, **changes) -> "EyeConfig":
        return replace(self, **changes)


@dataclass
class AppearanceConfig:
    coat_color: tuple[int, int, int] = (212, 144, 44)
    back_leg_color: tuple[int, int, int] = (182, 120, 34)
    hoof_front_color: tuple[int, int, int] = (44, 38, 36)
    hoof_back_color: tuple[int, int, int] = (34, 29, 28)
    hand_color: tuple[int, int, int] = (236, 194, 154)
    hand_back_color: tuple[int, int, int] = (220, 178, 138)
    tail_color: tuple[int, int, int] = (120, 74, 24)
    tooth_color: tuple[int, int, int] = (250, 250, 250)
    nose_color: tuple[int, int, int] = (20, 20, 24)
    pattern: PatternConfig = field(default_factory=PatternConfig)

    def with_(self, **changes) -> "AppearanceConfig":
        return replace(self, **changes)


@dataclass
class WingConfig:
    enabled: bool = False
    style: str = "feathery"  # "feathery", "leathery", "swept", "rounded"
    span: float = 78.0
    chord: float = 34.0
    color: tuple[int, int, int] = (242, 236, 224)
    secondary_color: tuple[int, int, int] = (210, 198, 180)
    lift_power: float = 0.95
    flap_freq: float = 3.2
    drag: float = 0.22
    scallop: float = 0.0

    def with_(self, **changes) -> "WingConfig":
        return replace(self, **changes)


@dataclass
class HornConfig:
    enabled: bool = False
    kind: str = "none"  # "pointed", "dull", "curved", "straight", "small_antlers", "branching_antlers"
    length: float = 28.0
    thickness: float = 6.0
    curve: float = 0.0
    tines: int = 3
    spread: float = 0.5
    color: tuple[int, int, int] = (218, 206, 182)
    tip_color: tuple[int, int, int] = (86, 72, 62)
    seed: int = 0
    twist: float = 0.0

    def with_(self, **changes) -> "HornConfig":
        return replace(self, **changes)


@dataclass
class CrestConfig:
    enabled: bool = False
    style: str = "tuft"  # "tuft", "crown_pom", "mane_plume", "spores"
    size: float = 22.0
    spread: float = 0.6
    count: int = 3
    color: tuple[int, int, int] = (72, 168, 74)
    tip_color: tuple[int, int, int] = (224, 56, 68)
    has_poms: bool = False
    branches: bool = False
    seed: int = 0
    pom_scale: float = 1.0
    pom_style: str = "round"
    pendants: int = 0

    def with_(self, **changes) -> "CrestConfig":
        return replace(self, **changes)


@dataclass
class OrnamentConfig:
    enabled: bool = False
    style: str = "beads"
    count: int = 0
    size: float = 0.0
    color: tuple[int, int, int] = (242, 236, 224)
    seed: int = 0


@dataclass
class GaitConfig:
    enabled: bool = True
    mode: str = "walk"  # "walk" or "run"
    behavior: str = "gallop"  # "gallop", "trot", "bound", "pace", "pronk"
    neuro_trait: str = "steady"        # "steady", "narcoleptic", "bolter", "stubborn", "prancer"
    metabolic_trait: str = "balanced"  # "balanced", "second_wind", "front_runner", "fiery", "sedate"
    reflex_trait: str = "focused"      # "focused", "competitive", "skittish", "sure_footed"
    # Walk settings
    walk_freq: float = 1.05  # cycles per second
    stride_deg: float = 12.0
    front_leg_center_deg: float = -2.0
    back_leg_center_deg: float = 4.0
    neck_bob_deg: float = 1.5
    head_bob_deg: float = -2.0
    tail_sway_deg: float = 5.0
    # Run / gallop settings
    run_freq: float = 1.80
    run_stride_deg: float = 23.0
    run_target_speed: float = 320.0
    run_phase_offset_deg: float = 122.0
    # Shared traction & balance
    swing_friction: float = 0.01
    run_stance_friction: float = 0.55
    balance_stiffness: float = 550000.0
    balance_damping: float = 55000.0
    balance_max_torque: float = 320000.0
    hop_blend: float = 0.0  # 0 gallop family, 1 saltatory hop
    spasm: float = 0.0
    sentience: float = 0.0
    can_speak: bool = False
    diet: str = "herbivore"
    rotary_front: float = 0.0
    rotary_back: float = 0.0
    rotary_mid: float = 0.0
    leg_flex: float = 0.5
    head_pitch_deg: float = 0.0
    neck_carriage_deg: float = 0.0

    def with_(self, **changes) -> "GaitConfig":
        return replace(self, **changes)


@dataclass
class CreatureConfig:
    spawn_pos: tuple[float, float] = (400, 440)
    collision_group: int = 1
    label: str = "Horse"

    torso: PartConfig = field(
        default_factory=lambda: PartConfig(size=(180, 80), mass=24.0, friction=0.7)
    )
    neck: PartConfig = field(
        default_factory=lambda: PartConfig(
            size=(20, 80),
            mass=1.6,
            anchor_offset=(-2, 5),
            joint=JointConfig(
                min_deg=-15,
                max_deg=32,
                rest_deg=15,
                stiffness=400000,
                damping=15000,
            ),
        )
    )
    head: PartConfig = field(
        default_factory=lambda: PartConfig(
            size=(60, 35),
            mass=0.55,
            joint=JointConfig(
                min_deg=-40,
                max_deg=25,
                rest_deg=-25,
                stiffness=150000,
                damping=7000,
            ),
        )
    )
    upper_jaw: PartConfig = field(
        default_factory=lambda: PartConfig(size=(27, 12), mass=0.20)
    )
    lower_jaw: PartConfig = field(
        default_factory=lambda: PartConfig(size=(25, 11), mass=0.12)
    )
    ear: PartConfig = field(
        default_factory=lambda: PartConfig(
            size=(14, 22), mass=0.04, shape_style="pointed", tip_offset=0.35
        )
    )
    teeth: PartConfig = field(
        default_factory=lambda: PartConfig(size=(11.0, 2.2), mass=0.002)
    )
    nose: PartConfig = field(
        default_factory=lambda: PartConfig(size=(5.0, 5.5), mass=0.002)
    )
    leg_front: PartConfig = field(
        default_factory=lambda: PartConfig(
            size=(13, 92),
            mass=2.0,
            friction=1.0,
            anchor_offset=(4, 0),
            rounded_bottom=True,
            joint=JointConfig(
                min_deg=-25,
                max_deg=25,
                rest_deg=0,
                stiffness=1500000,
                damping=25000,
                progressive=False,
            ),
        )
    )
    leg_back: PartConfig = field(
        default_factory=lambda: PartConfig(
            size=(15, 92),
            mass=3.2,
            friction=1.0,
            rounded_bottom=True,
            joint=JointConfig(
                min_deg=-16,
                max_deg=30,
                rest_deg=4,
                stiffness=1500000,
                damping=25000,
                progressive=False,
            ),
        )
    )
    leg_mid: PartConfig = field(
        default_factory=lambda: PartConfig(
            size=(14, 92),
            mass=2.4,
            friction=1.0,
            rounded_bottom=True,
            enabled=False,
            joint=JointConfig(
                min_deg=-25,
                max_deg=25,
                rest_deg=0,
                stiffness=1500000,
                damping=25000,
                progressive=False,
            ),
        )
    )
    arm_front: PartConfig = field(
        default_factory=lambda: PartConfig(
            size=(10, 52),
            mass=0.6,
            friction=0.4,
            rounded_bottom=True,
            enabled=False,
            joint=JointConfig(
                min_deg=-55,
                max_deg=55,
                rest_deg=14,
                stiffness=120000,
                damping=8000,
                progressive=False,
            ),
        )
    )
    arm_back: PartConfig = field(
        default_factory=lambda: PartConfig(
            size=(10, 52),
            mass=0.6,
            friction=0.4,
            rounded_bottom=True,
            enabled=False,
            joint=JointConfig(
                min_deg=-55,
                max_deg=55,
                rest_deg=-14,
                stiffness=120000,
                damping=8000,
                progressive=False,
            ),
        )
    )
    hoof: PartConfig = field(
        default_factory=lambda: PartConfig(
            size=(19.0, 11.0),
            mass=0.05,
            friction=1.0,
        )
    )
    hand: PartConfig = field(
        default_factory=lambda: PartConfig(
            size=(12.0, 11.0),
            mass=0.04,
            friction=0.4,
            enabled=False,
        )
    )
    tail: PartConfig = field(
        default_factory=lambda: PartConfig(
            size=(60, 9),
            mass=0.9,
            shape_style="tapered",
            joint=JointConfig(
                min_deg=-75,
                max_deg=15,
                rest_deg=-55,
                stiffness=160000,
                damping=7000,
            ),
        )
    )
    eye: EyeConfig = field(default_factory=EyeConfig)
    wing: WingConfig = field(default_factory=WingConfig)
    horn: HornConfig = field(default_factory=HornConfig)
    crest: CrestConfig = field(default_factory=CrestConfig)
    contour_seed: int = 0
    appearance: AppearanceConfig = field(default_factory=AppearanceConfig)
    gait: GaitConfig = field(default_factory=GaitConfig)
    genome: Genome | None = None
    trait_tags: tuple[str, ...] = ()
    centered_head: bool = False
    head_center: float = 0.0
    erectness: float = 0.0
    has_apron: bool = False
    strand_locus_num: int = 0
    strand_alleles: tuple[str, str] | None = None
    strand_loci: tuple[str, ...] = ()
    pure_strand: bool = False
    incomplete_strand_loci: tuple[str, ...] = ()
    upper_teeth: bool = True
    lower_teeth: bool = True
    bite: float = 0.0  # negative underbite, positive overbite, 0 even
    spike_amp: float = 0.0
    spike_freq: float = 0.0
    spike_color: tuple[int, int, int] = (120, 92, 64)
    ornament: OrnamentConfig = field(default_factory=OrnamentConfig)

    def with_(self, **changes) -> "CreatureConfig":
        return replace(self, **changes)


STRAND_SLOT_BY_LOCUS: dict[str, str] = {
    "hox_posture": "torso",
    "hox_limb_gate": "legs_both",
    "hox_cranial": "head",
    "hox_caudal": "tail",
    "size_somatic": "torso",
    "build_robust": "torso",
    "torso_len": "torso",
    "torso_depth": "torso",
    "body_contour": "torso",
    "neck_morph": "neck",
    "head_size": "head",
    "jaw_morph": "jaw",
    "teeth_dev": "jaw",
    "nose_dev": "nose",
    "ear_form": "ear",
    "limb_fore": "leg_front",
    "limb_hind": "leg_back",
    "limb_extra": "legs_both",
    "arm_dev": "arms",
    "hoof_dev": "hooves",
    "tail_form": "tail",
    "symmetry_mod": "tendril",
    "eye_dev": "eye",
    "iris_chrom": "eye",
    "sense_reflex": "eye",
    "pigment_base": "crest",
    "pigment_dilute": "crest",
    "pattern_locus": "crest",
    "pattern_chrom": "crest",
    "color_mutator": "crest",
    "tail_pigment": "tail",
    "gait_cadence": "tendril",
    "gait_power": "tendril",
    "balance_core": "tendril",
    "bone_density": "torso",
    "neuro_temperament": "tendril",
    "metabolic_drive": "tendril",
    "wing_dev": "wing",
    "wing_chrom": "wing",
    "horn_dev": "horn",
    "crest_dev": "crest",
    "behavior_locus": "tendril",
    "axial_plan": "torso",
    "diet_guild": "jaw",
    "osteoderm": "torso",
    "joint_flex": "legs_both",
    "vital_span": "torso",
    "lethal_white": "head",
    "sentience": "head",
    "dentition": "jaw",
    "cranial_shape": "head",
    "muzzle_shape": "jaw",
    "eye_expression": "eye",
    "ear_shape": "ear",
    "limb_shape": "legs_both",
    "tail_shape": "tail",
    "wing_shape": "wing",
    "horn_shape": "horn",
    "crest_shape": "crest",
    "crest_ornament": "crest",
    "skin_ornament": "torso",
    "joint_response": "tendril",
    "joint_pose": "neck",
    "rotary_drive": "legs_both",
}


STRAND_NT_COLORS: dict[str, tuple[int, int, int]] = {
    "A": (238, 214, 62),
    "G": (72, 208, 92),
    "C": (68, 126, 232),
    "T": (228, 68, 74),
}
_STRAND_GLYPH_CACHE: dict[tuple[str, int, tuple[int, int, int]], pygame.Surface] = {}
_STRAND_MAP_SURFACE_CACHE: dict[tuple[int, str, str, int], pygame.Surface] = {}


def get_strand_glyph(
    text: str,
    px_size: int,
    color: tuple[int, int, int],
) -> pygame.Surface:
    key = (text, px_size, color)
    cached = _STRAND_GLYPH_CACHE.get(key)
    if cached is not None:
        return cached
    font = pygame.font.SysFont("monospace", px_size, bold=True)
    surf = font.render(text, True, color)
    _STRAND_GLYPH_CACHE[key] = surf
    return surf


def _draw_rotated_glyph(
    screen: pygame.Surface,
    text: str,
    px_size: int,
    color: tuple[int, int, int],
    center_xy: tuple[float, float],
    angle_deg: float = 0.0,
):
    glyph = get_strand_glyph(text, px_size, color)
    if abs(angle_deg) > 1.0:
        glyph = pygame.transform.rotozoom(glyph, angle_deg, 1.0)
    screen.blit(glyph, glyph.get_rect(center=(int(round(center_xy[0])), int(round(center_xy[1])))))


def get_strand_map_surface(
    locus_num: int,
    allele_a: str,
    allele_b: str,
    size: int = 128,
) -> pygame.Surface:
    """Renders a crisp X-shaped chromosome graphic for a locus with raw A/G/C/T blocks and locus number."""
    key = (locus_num, allele_a, allele_b, size)
    cached = _STRAND_MAP_SURFACE_CACHE.get(key)
    if cached is not None:
        return cached

    surf = pygame.Surface((size, size), pygame.SRCALPHA)
    cx = size * 0.5
    cy = size * 0.37
    hub = size * 0.17

    def draw_arm(
        seq: str,
        p0: tuple[float, float],
        p1: tuple[float, float],
        p2: tuple[float, float] | None,
        tile_w: float,
    ):
        n = len(seq)
        for i, base in enumerate(seq):
            t0 = i / n
            t1 = (i + 1) / n
            if p2 is None:
                ax = p0[0] + (p1[0] - p0[0]) * t0
                ay = p0[1] + (p1[1] - p0[1]) * t0
                bx = p0[0] + (p1[0] - p0[0]) * t1
                by = p0[1] + (p1[1] - p0[1]) * t1
            else:
                def bez(t: float) -> tuple[float, float]:
                    mt = 1.0 - t
                    return (
                        mt * mt * p0[0] + 2.0 * mt * t * p1[0] + t * t * p2[0],
                        mt * mt * p0[1] + 2.0 * mt * t * p1[1] + t * t * p2[1],
                    )
                ax, ay = bez(t0)
                bx, by = bez(t1)

            dx = bx - ax
            dy = by - ay
            seg_len = max(1e-4, math.hypot(dx, dy))
            nx = -dy / seg_len
            ny = dx / seg_len
            hw = tile_w * 0.5
            pts = [
                (ax + nx * hw, ay + ny * hw),
                (bx + nx * hw, by + ny * hw),
                (bx - nx * hw, by - ny * hw),
                (ax - nx * hw, ay - ny * hw),
            ]
            if base in STRAND_NT_COLORS:
                col = STRAND_NT_COLORS[base]
                pygame.draw.polygon(surf, col, pts)
                pygame.draw.polygon(surf, (24, 20, 32), pts, 1)
            else:
                pygame.draw.polygon(surf, (26, 22, 34), pts)
                pygame.draw.polygon(surf, (172, 72, 84), pts, 1)
            mx = (ax + bx) * 0.5
            my = (ay + by) * 0.5
            ang = -math.degrees(math.atan2(dy, dx)) - 90.0
            _draw_rotated_glyph(
                surf,
                base,
                max(7, int(round(tile_w * 0.85))),
                (252, 252, 255) if base in STRAND_NT_COLORS else (196, 110, 120),
                (mx, my),
                ang,
            )

    tile_w = max(7.0, size * 0.072)
    # Top-left arm: allele_a[:8], Top-right arm: allele_b[:8]
    draw_arm(
        allele_a[:8],
        (cx - hub * 0.45, cy - hub * 0.45),
        (cx - size * 0.24, size * 0.06),
        None,
        tile_w,
    )
    draw_arm(
        allele_b[:8],
        (cx + hub * 0.45, cy - hub * 0.45),
        (cx + size * 0.24, size * 0.06),
        None,
        tile_w,
    )
    # Bottom-left leg: allele_a[8:], Bottom-right leg: allele_b[8:]
    draw_arm(
        allele_a[8:],
        (cx - hub * 0.45, cy + hub * 0.45),
        (cx - size * 0.20, cy + size * 0.28),
        (cx - size * 0.30, size * 0.94),
        tile_w,
    )
    draw_arm(
        allele_b[8:],
        (cx + hub * 0.45, cy + hub * 0.45),
        (cx + size * 0.20, cy + size * 0.28),
        (cx + size * 0.30, size * 0.94),
        tile_w,
    )

    hub_rect = pygame.Rect(0, 0, int(round(hub)), int(round(hub)))
    hub_rect.center = (int(round(cx)), int(round(cy)))
    pygame.draw.rect(surf, (14, 14, 20), hub_rect, border_radius=3)
    pygame.draw.rect(surf, (88, 66, 122), hub_rect, 2, border_radius=3)
    _draw_rotated_glyph(
        surf,
        str(locus_num),
        max(10, int(round(hub * 0.68))),
        (198, 132, 248),
        hub_rect.center,
        0.0,
    )

    _STRAND_MAP_SURFACE_CACHE[key] = surf
    return surf
