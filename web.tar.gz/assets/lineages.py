"""Random horse, herd-animal, and rancher genome builders."""
from __future__ import annotations

import random

from allele import (
    ALLELE_LENGTH,
    ALL_LOCI,
    EXOTIC_COLOR_MOTIFS,
    EXPRESSION_LOCI,
    GAP_BASE,
    Gene,
    _clamp,
    encode_allele,
)

from genome import Genome

# --- GENOME GENERATORS (HORSES, MUTANTS, RANCHERS) ---


def _diploid_gene(
    locus: str,
    rng: random.Random,
    p1: tuple[float, float, float],
    p2: tuple[float, float, float] | None = None,
    promoters: tuple[str, str] = ("TAC", "TAC"),
    utrs: tuple[str, str] = ("CAG", "CAG"),
    patches: tuple[str | None, str | None] = (None, None),
) -> Gene:
    if p2 is None:
        p2 = tuple(_clamp(v + rng.uniform(-0.08, 0.08), 0.02, 0.98) for v in p1)
    a = encode_allele(p1[0], p1[1], p1[2], promoter=promoters[0], utr=utrs[0], motif_patch=patches[0])
    b = encode_allele(p2[0], p2[1], p2[2], promoter=promoters[1], utr=utrs[1], motif_patch=patches[1])
    return Gene(locus, a, b)


def _rand_tri(rng: random.Random, lo: float = 0.1, hi: float = 0.9) -> tuple[float, float, float]:
    return (rng.uniform(lo, hi), rng.uniform(lo, hi), rng.uniform(lo, hi))


def car_genome(model: str = "compact") -> Genome:
    """Two curated cars built from the same 64 loci as every other creature."""
    profiles = {
        "compact": dict(seed=799, size=0.48, length=0.48, depth=0.64, contour=(0.50, 0.45, 0.26), cadence=0.66, power=0.72, drive_utr="TCT", pigment=None),
        "tourer": dict(seed=1299, size=0.60, length=0.94, depth=0.52, contour=(0.65, 0.30, 0.52), cadence=0.86, power=0.88, drive_utr="TTT", pigment="GCGCGC"),
    }
    if model not in profiles:
        raise ValueError(f"Unknown car model: {model}")
    profile = profiles[model]
    rng = random.Random(profile["seed"])
    base = random_horse_genome(rng=rng, rare_mutation_chance=0.0, force_mutation=False)
    genes = dict(base.genes)

    def set_gene(locus, values, *, patch=None, utr="CAG", promoter="TAC"):
        genes[locus] = _diploid_gene(locus, rng, values, values,
            promoters=(promoter, promoter), utrs=(utr, utr), patches=(patch, patch))

    for locus in ("hox_cranial", "neck_morph", "head_size", "jaw_morph", "teeth_dev",
                  "nose_dev", "ear_form", "arm_dev", "hoof_dev", "tail_form",
                  "wing_dev", "horn_dev", "crest_dev", "osteoderm", "skin_ornament"):
        set_gene(locus, (0.5, 0.5, 0.5), patch="TAATAA")
    for locus in ("axial_plan", "symmetry_mod", "joint_response", "joint_pose"):
        set_gene(locus, (0.5, 0.5, 0.5))
    set_gene("hox_posture", (0.12, 0.12, 0.5))
    set_gene("hox_limb_gate", (0.88, 0.85, 0.2))
    set_gene("size_somatic", (profile["size"], 0.5, 0.5))
    set_gene("build_robust", (0.5, 0.5, 0.5))
    set_gene("torso_len", (profile["length"], 0.5, 0.5))
    set_gene("torso_depth", (profile["depth"], 0.5, 0.5))
    set_gene("body_contour", profile["contour"], utr="TTT", promoter="ATG")
    set_gene("limb_shape", (0.98, 0.55, 0.96), utr="TTT", promoter="ATG")
    set_gene("eye_expression", (0.5, 0.5, 0.5), utr="TTT", promoter="ATG")
    set_gene("limb_fore", (0.48, 0.5, 0.5))
    set_gene("limb_hind", (0.48, 0.5, 0.5))
    set_gene("limb_extra", (0.12, 0.5, 0.5), patch="TAATAA")
    set_gene("rotary_drive", (0.98, 0.98, 0.5), utr=profile["drive_utr"])
    set_gene("joint_flex", (1.0, 0.5, 0.5))
    set_gene("gait_cadence", (profile["cadence"], 0.5, 0.5))
    set_gene("gait_power", (profile["power"], 0.70, 0.5))
    set_gene("balance_core", (0.70, 0.70, 0.70))
    set_gene("neuro_temperament", (0.5, 0.5, 0.5))
    set_gene("metabolic_drive", (0.5, 0.5, 0.5))
    set_gene("behavior_locus", (0.12, 0.12, 0.5))
    set_gene("vital_span", (0.5, 0.5, 0.5))
    set_gene("lethal_white", (0.5, 0.5, 0.5))
    set_gene("pigment_base", (0.90, 0.7, 0.5))
    set_gene("pigment_dilute", (0.42, 0.5, 0.5))
    set_gene("pattern_locus", (0.02, 0.5, 0.5))
    set_gene("color_mutator", (0.5, 0.5, 0.5), patch=profile["pigment"])
    set_gene("iris_chrom", (0.90, 0.5, 0.5))
    return Genome(genes={locus: genes[locus] for locus in ALL_LOCI}, lineage=model.title())


TERRAIN_PACK_SPECIES: dict[str, tuple[str, ...]] = {
    "grass": ("zebra", "deer", "burro", "bison"),
    "savanna": ("zebra", "gazelle", "bison"),
    "deep_forest": ("deer",),
    "desert": ("gazelle", "burro"),
    "oasis": ("gazelle", "burro"),
    "rock": ("bighorn", "burro"),
    "mountain": ("bighorn",),
    "snowy_peaks": ("bighorn",),
}


def random_herd_animal_genome(
    species: str,
    rng: random.Random | None = None,
) -> Genome:
    """
    Constructs a curated non-horse herd animal using the shared 64-locus Genome
    so it can still be lassoed, raced, bred, and gene-extracted.
    """
    rng = rng or random.Random()
    sp = species.lower()
    base = random_horse_genome(rng=rng, rare_mutation_chance=0.0, force_mutation=False)
    genes = dict(base.genes)

    # Start with calm wild-type horse defaults for horns/wings/coat mutators
    genes["color_mutator"] = _diploid_gene("color_mutator", rng, (0.5, 0.5, 0.5))
    genes["wing_dev"] = _diploid_gene("wing_dev", rng, (0.3, 0.5, 0.5), promoters=("TAC", "TAA"))
    genes["horn_dev"] = _diploid_gene("horn_dev", rng, (0.3, 0.5, 0.5), promoters=("TAA", "TAC"))

    if sp == "zebra":
        genes["pigment_base"] = _diploid_gene("pigment_base", rng, (0.05, 0.22, 0.50))
        genes["pigment_dilute"] = _diploid_gene("pigment_dilute", rng, (0.12, 0.15, 0.50))
        genes["pattern_locus"] = _diploid_gene(
            "pattern_locus", rng, (0.92, rng.uniform(0.65, 0.85), rng.uniform(0.45, 0.65))
        )
        genes["pattern_chrom"] = _diploid_gene("pattern_chrom", rng, (0.50, 0.50, 0.50))
        genes["size_somatic"] = _diploid_gene("size_somatic", rng, (rng.uniform(0.36, 0.50), 0.5, 0.5))
        genes["build_robust"] = _diploid_gene("build_robust", rng, (rng.uniform(0.42, 0.58), 0.5, 0.5))
        genes["ear_form"] = _diploid_gene("ear_form", rng, (0.60, 0.65, 0.82))  # rounded
        genes["tail_form"] = _diploid_gene("tail_form", rng, (0.58, 0.52, 0.12))  # sleek
        genes["hoof_dev"] = _diploid_gene("hoof_dev", rng, (0.45, 0.50, 0.42))    # thin
        genes["behavior_locus"] = _diploid_gene("behavior_locus", rng, (rng.choice([0.25, 0.52]), 0.5, 0.5))

    elif sp == "deer":
        genes["pigment_base"] = _diploid_gene("pigment_base", rng, (0.58, 0.55, 0.50))
        genes["pigment_dilute"] = _diploid_gene("pigment_dilute", rng, (0.38, 0.25, 0.50))
        spotted = rng.random() < 0.40
        genes["pattern_locus"] = _diploid_gene(
            "pattern_locus", rng, (0.72 if spotted else 0.18, 0.55, 0.45)
        )
        genes["pattern_chrom"] = _diploid_gene("pattern_chrom", rng, (0.20, 0.50, 0.50))
        genes["size_somatic"] = _diploid_gene("size_somatic", rng, (rng.uniform(0.26, 0.42), 0.5, 0.5))
        genes["build_robust"] = _diploid_gene("build_robust", rng, (rng.uniform(0.16, 0.28), 0.5, 0.5))
        genes["limb_fore"] = _diploid_gene("limb_fore", rng, (0.74, 0.28, 0.55))
        genes["limb_hind"] = _diploid_gene("limb_hind", rng, (0.76, 0.28, 0.55))
        genes["ear_form"] = _diploid_gene("ear_form", rng, (0.78, 0.48, 0.15))   # tall pointed
        genes["tail_form"] = _diploid_gene("tail_form", rng, (0.18, 0.80, 0.87))  # short bushy
        genes["hoof_dev"] = _diploid_gene("hoof_dev", rng, (0.38, 0.45, 0.58))    # cloven
        genes["behavior_locus"] = _diploid_gene("behavior_locus", rng, (rng.choice([0.68, 0.94]), 0.5, 0.5))
        if rng.random() < 0.45:
            antler_p = 0.45 if rng.random() < 0.6 else 0.37  # branching vs small antlers
            genes["horn_dev"] = _diploid_gene(
                "horn_dev",
                rng,
                (antler_p, rng.uniform(0.55, 0.85), rng.uniform(0.45, 0.75)),
                p2=(antler_p, 0.65, 0.60),
                promoters=("ATG", "ATG"),
                patches=("ATAC", "ATAC"),
            )

    elif sp == "gazelle":
        genes["pigment_base"] = _diploid_gene("pigment_base", rng, (0.48, 0.62, 0.50))
        genes["pigment_dilute"] = _diploid_gene("pigment_dilute", rng, (0.58, 0.30, 0.50))
        genes["pattern_locus"] = _diploid_gene("pattern_locus", rng, (0.20, 0.40, 0.40))
        genes["size_somatic"] = _diploid_gene("size_somatic", rng, (rng.uniform(0.20, 0.32), 0.5, 0.5))
        genes["build_robust"] = _diploid_gene("build_robust", rng, (rng.uniform(0.14, 0.24), 0.5, 0.5))
        genes["limb_fore"] = _diploid_gene("limb_fore", rng, (0.82, 0.24, 0.52))
        genes["limb_hind"] = _diploid_gene("limb_hind", rng, (0.84, 0.24, 0.52))
        genes["ear_form"] = _diploid_gene("ear_form", rng, (0.72, 0.46, 0.15))
        genes["tail_form"] = _diploid_gene("tail_form", rng, (0.24, 0.55, 0.12))
        genes["hoof_dev"] = _diploid_gene("hoof_dev", rng, (0.36, 0.42, 0.42))    # thin
        genes["gait_cadence"] = _diploid_gene("gait_cadence", rng, (0.78, 0.65, 0.75))
        genes["gait_power"] = _diploid_gene("gait_power", rng, (0.76, 0.68, 0.50))
        genes["behavior_locus"] = _diploid_gene("behavior_locus", rng, (rng.choice([0.68, 0.94]), 0.5, 0.5))
        horn_p = 0.20 if rng.random() < 0.6 else 0.04  # curved or pointed
        genes["horn_dev"] = _diploid_gene(
            "horn_dev",
            rng,
            (horn_p, rng.uniform(0.55, 0.85), 0.45),
            p2=(horn_p, 0.65, 0.45),
            promoters=("ATG", "ATG"),
            patches=("ATAC", "ATAC"),
        )

    elif sp == "bighorn":
        is_white = rng.random() < 0.35
        genes["pigment_base"] = _diploid_gene("pigment_base", rng, (0.45 if is_white else 0.24, 0.45, 0.50))
        genes["pigment_dilute"] = _diploid_gene(
            "pigment_dilute", rng, (0.88 if is_white else 0.55, 0.88, 0.50)
        )
        genes["pattern_locus"] = _diploid_gene("pattern_locus", rng, (0.15, 0.4, 0.4))
        genes["size_somatic"] = _diploid_gene("size_somatic", rng, (rng.uniform(0.30, 0.44), 0.5, 0.5))
        genes["build_robust"] = _diploid_gene("build_robust", rng, (rng.uniform(0.70, 0.88), 0.5, 0.5))
        genes["hoof_dev"] = _diploid_gene("hoof_dev", rng, (0.62, 0.68, 0.58))    # cloven
        genes["tail_form"] = _diploid_gene("tail_form", rng, (0.16, 0.68, 0.87))  # short bushy
        genes["behavior_locus"] = _diploid_gene("behavior_locus", rng, (0.68, 0.5, 0.5))  # bound
        if rng.random() < 0.75:
            genes["horn_dev"] = _diploid_gene(
                "horn_dev",
                rng,
                (0.20, 0.65, 0.88),
                p2=(0.20, 0.65, 0.88),
                promoters=("ATG", "ATG"),
                utrs=("CAG", "CAG"),
                patches=("ATAC", "ATAC"),
            )

    elif sp == "burro":
        genes["pigment_base"] = _diploid_gene("pigment_base", rng, (0.44, 0.48, 0.50))
        genes["pigment_dilute"] = _diploid_gene("pigment_dilute", rng, (0.56, 0.86, 0.50))
        genes["pattern_locus"] = _diploid_gene("pattern_locus", rng, (0.15, 0.4, 0.4))
        genes["size_somatic"] = _diploid_gene("size_somatic", rng, (rng.uniform(0.18, 0.30), 0.5, 0.5))
        genes["build_robust"] = _diploid_gene("build_robust", rng, (rng.uniform(0.60, 0.76), 0.5, 0.5))
        genes["ear_form"] = _diploid_gene(
            "ear_form", rng, (0.90, 0.60, 0.15), p2=(0.90, 0.60, 0.15), patches=("GGGG", "GGGG")
        )
        genes["tail_form"] = _diploid_gene("tail_form", rng, (0.50, 0.42, 0.12))
        genes["hoof_dev"] = _diploid_gene("hoof_dev", rng, (0.38, 0.55, 0.42))
        genes["behavior_locus"] = _diploid_gene("behavior_locus", rng, (rng.choice([0.52, 0.82]), 0.5, 0.5))

    elif sp == "bison":
        genes["pigment_base"] = _diploid_gene("pigment_base", rng, (0.18, 0.32, 0.50))
        genes["pigment_dilute"] = _diploid_gene("pigment_dilute", rng, (0.18, 0.18, 0.50))
        genes["pattern_locus"] = _diploid_gene("pattern_locus", rng, (0.12, 0.4, 0.4))
        genes["size_somatic"] = _diploid_gene("size_somatic", rng, (rng.uniform(0.82, 0.92), 0.5, 0.5))
        genes["build_robust"] = _diploid_gene("build_robust", rng, (rng.uniform(0.85, 0.95), 0.5, 0.5))
        genes["torso_depth"] = _diploid_gene("torso_depth", rng, (0.88, 0.5, 0.5))
        genes["neck_morph"] = _diploid_gene("neck_morph", rng, (0.35, 0.90, 0.25))
        genes["head_size"] = _diploid_gene("head_size", rng, (0.76, 0.84, 0.25))
        genes["hoof_dev"] = _diploid_gene("hoof_dev", rng, (0.75, 0.80, 0.25))    # thick
        genes["tail_form"] = _diploid_gene("tail_form", rng, (0.38, 0.65, 0.87))  # bushy
        genes["bone_density"] = _diploid_gene("bone_density", rng, (0.88, 0.75, 0.50))
        genes["horn_dev"] = _diploid_gene(
            "horn_dev",
            rng,
            (0.20, 0.25, 0.92),
            p2=(0.20, 0.25, 0.92),
            promoters=("ATG", "ATG"),
            patches=("ATAC", "ATAC"),
        )

    return Genome(genes=genes, lineage=sp.title(), generation=1)


def random_fossil_genome(rng: random.Random | None = None) -> Genome:
    """Prehistoric giant-horse / mega-horn genome with most nucleotides missing ('-')."""
    rng = rng or random.Random()
    base = random_horse_genome(rng=rng, rare_mutation_chance=0.0, force_mutation=False)
    genes = dict(base.genes)

    genes["size_somatic"] = _diploid_gene(
        "size_somatic",
        rng,
        (rng.uniform(0.92, 0.99), rng.uniform(0.65, 0.90), rng.uniform(0.65, 0.90)),
        promoters=("ATG", "ATG"),
        patches=("GGGG", "GGGG"),
    )
    genes["build_robust"] = _diploid_gene(
        "build_robust",
        rng,
        (rng.uniform(0.76, 0.95), rng.uniform(0.60, 0.90), rng.uniform(0.60, 0.90)),
        promoters=("ATG", "ATG"),
    )
    genes["bone_density"] = _diploid_gene(
        "bone_density",
        rng,
        (rng.uniform(0.84, 0.98), rng.uniform(0.75, 0.95), rng.uniform(0.65, 0.90)),
        promoters=("ATG", "ATG"),
    )
    genes["horn_dev"] = _diploid_gene(
        "horn_dev",
        rng,
        (rng.choice((0.04, 0.20, 0.45, 0.65)), rng.uniform(0.86, 0.99), rng.uniform(0.78, 0.98)),
        promoters=("ATG", "ATG"),
        patches=("ATAC", "ATAC"),
    )
    genes["gait_power"] = _diploid_gene(
        "gait_power",
        rng,
        (rng.uniform(0.78, 0.96), rng.uniform(0.70, 0.95), 0.52),
        promoters=("ATG", "ATG"),
    )
    if rng.random() < 0.45:
        genes["neck_morph"] = _diploid_gene(
            "neck_morph",
            rng,
            (rng.uniform(0.88, 0.97), 0.65, 0.60),
            promoters=("ATG", "ATG"),
            patches=("GGGG", "GGGG"),
        )
    if rng.random() < 0.35:
        genes["wing_dev"] = _diploid_gene(
            "wing_dev",
            rng,
            (rng.random(), rng.uniform(0.82, 0.98), rng.uniform(0.75, 0.95)),
            promoters=("ATG", "ATG"),
            patches=("GGGG", "GGGG"),
        )

    broken_genes: dict[str, Gene] = {}
    for locus in ALL_LOCI:
        g = genes[locus]
        miss_rate = 0.52 if locus in ("size_somatic", "horn_dev", "bone_density") else 0.62
        sa = "".join(GAP_BASE if rng.random() < miss_rate else ch for ch in g.allele_a)
        sb = "".join(GAP_BASE if rng.random() < miss_rate else ch for ch in g.allele_b)
        broken_genes[locus] = Gene(locus, sa, sb)

    return Genome(genes=broken_genes, lineage="Fossil", generation=0)


def random_horse_genome(
    rng: random.Random | None = None,
    rare_mutation_chance: float = 0.010,
    force_mutation: bool = False,
) -> Genome:
    """
    Generates a wild-type or rarely-mutated horse Genome using real nucleotide sequences.
    Most individuals (~95%) preserve realistic wild horse variety and charm,
    while rare individuals carry nucleotide mutations that switch off body parts,
    activate arms, or cause striking color mutations.
    """
    rng = rng or random.Random()
    genes: dict[str, Gene] = {}

    # Choose target classic coat tendency encoded into pigment_base x pigment_dilute
    # Weighted similarly to classic wild horse herd proportions
    coat_archetypes = [
        ((0.36, 0.60), (0.20, 0.25), 20),  # Bay
        ((0.64, 0.62), (0.22, 0.25), 16),  # Chestnut
        ((0.88, 0.70), (0.25, 0.25), 10),  # Sorrel
        ((0.66, 0.72), (0.72, 0.30), 10),  # Palomino
        ((0.40, 0.66), (0.72, 0.25), 10),  # Buckskin
        ((0.42, 0.56), (0.54, 0.32), 8),   # Dun
        ((0.06, 0.20), (0.15, 0.20), 9),   # Black
        ((0.45, 0.50), (0.55, 0.90), 9),   # Silver Grey
        ((0.20, 0.40), (0.22, 0.22), 6),   # Chocolate
        ((0.68, 0.80), (0.92, 0.30), 4),   # Cremello
        ((0.55, 0.55), (0.30, 0.74), 6),   # Red Roan
    ]
    weights = [a[2] for a in coat_archetypes]
    (pb_e, pb_d), (pd_c, pd_r), _ = rng.choices(coat_archetypes, weights=weights, k=1)[0]

    # Held below the erectness/humanity ramps so a horse stays a horse, while a
    # heterozygote with a rancher allele falls in the open middle of those ramps.
    p_post = (rng.uniform(0.10, 0.28), rng.uniform(0.05, 0.18), rng.uniform(0.2, 0.8))
    genes["hox_posture"] = _diploid_gene(
        "hox_posture", rng,
        p_post,
        p2=(
            _clamp(p_post[0] + rng.uniform(-0.08, 0.08), 0.08, 0.30),
            _clamp(p_post[1] + rng.uniform(-0.08, 0.08), 0.04, 0.20),
            _clamp(p_post[2] + rng.uniform(-0.08, 0.08), 0.02, 0.98),
        ),
        utrs=("CAA", "CAA"),
    )
    genes["hox_limb_gate"] = _diploid_gene(
        "hox_limb_gate", rng,
        (rng.uniform(0.45, 0.75), rng.uniform(0.35, 0.75), rng.uniform(0.35, 0.75)),
    )
    genes["hox_cranial"] = _diploid_gene(
        "hox_cranial", rng,
        (rng.uniform(0.35, 0.85), rng.uniform(0.35, 0.85), rng.uniform(0.35, 0.85)),
    )
    genes["hox_caudal"] = _diploid_gene(
        "hox_caudal", rng,
        (rng.uniform(0.35, 0.85), rng.uniform(0.25, 0.80), rng.uniform(0.25, 0.80)),
    )

    genes["size_somatic"] = _diploid_gene("size_somatic", rng, (rng.uniform(0.12, 0.92), rng.random(), rng.random()))
    genes["build_robust"] = _diploid_gene("build_robust", rng, (rng.uniform(0.12, 0.90), rng.random(), rng.random()))

    genes["torso_len"] = _diploid_gene("torso_len", rng, _rand_tri(rng))
    genes["torso_depth"] = _diploid_gene("torso_depth", rng, _rand_tri(rng))
    genes["neck_morph"] = _diploid_gene("neck_morph", rng, _rand_tri(rng, 0.15, 0.88))
    genes["head_size"] = _diploid_gene("head_size", rng, _rand_tri(rng, 0.15, 0.88))
    genes["jaw_morph"] = _diploid_gene("jaw_morph", rng, _rand_tri(rng, 0.18, 0.85))
    genes["teeth_dev"] = _diploid_gene("teeth_dev", rng, _rand_tri(rng, 0.25, 0.80))
    genes["nose_dev"] = _diploid_gene("nose_dev", rng, _rand_tri(rng, 0.25, 0.80))
    genes["ear_form"] = _diploid_gene("ear_form", rng, _rand_tri(rng, 0.15, 0.90))

    genes["limb_fore"] = _diploid_gene("limb_fore", rng, _rand_tri(rng, 0.15, 0.90))
    genes["limb_hind"] = _diploid_gene("limb_hind", rng, _rand_tri(rng, 0.15, 0.90))
    # Repressed wild-type arm_dev (can still be carrier!)
    genes["arm_dev"] = _diploid_gene(
        "arm_dev",
        rng,
        (rng.uniform(0.15, 0.65), rng.uniform(0.3, 0.7), rng.uniform(0.3, 0.7)),
        promoters=("TAA", "TAA"),
    )
    genes["hoof_dev"] = _diploid_gene("hoof_dev", rng, _rand_tri(rng, 0.18, 0.88))
    genes["tail_form"] = _diploid_gene("tail_form", rng, _rand_tri(rng, 0.18, 0.92))
    genes["symmetry_mod"] = _diploid_gene("symmetry_mod", rng, (rng.uniform(0.32, 0.68), rng.uniform(0.3, 0.7), rng.uniform(0.3, 0.7)))

    genes["eye_dev"] = _diploid_gene("eye_dev", rng, _rand_tri(rng, 0.25, 0.85))
    genes["iris_chrom"] = _diploid_gene("iris_chrom", rng, (rng.random(), rng.random(), rng.random()))

    genes["pigment_base"] = _diploid_gene(
        "pigment_base", rng,
        (_clamp(pb_e + rng.uniform(-0.04, 0.04), 0.02, 0.98), _clamp(pb_d + rng.uniform(-0.08, 0.08), 0.05, 0.95), rng.random()),
    )
    genes["pigment_dilute"] = _diploid_gene(
        "pigment_dilute", rng,
        (_clamp(pd_c + rng.uniform(-0.06, 0.06), 0.02, 0.98), _clamp(pd_r + rng.uniform(-0.06, 0.06), 0.02, 0.98), rng.random()),
    )

    # Pattern style distribution ~ 36% flat, 25% blobs, 25% dotted/dappled, 14% striped
    pat_p = rng.choices(
        [rng.uniform(0.05, 0.34), rng.uniform(0.38, 0.59), rng.uniform(0.63, 0.83), rng.uniform(0.87, 0.98)],
        weights=[36, 25, 25, 14],
        k=1,
    )[0]
    genes["pattern_locus"] = _diploid_gene("pattern_locus", rng, (pat_p, rng.uniform(0.2, 0.9), rng.uniform(0.2, 0.9)))
    genes["pattern_chrom"] = _diploid_gene("pattern_chrom", rng, _rand_tri(rng, 0.1, 0.9))
    genes["color_mutator"] = _diploid_gene("color_mutator", rng, (0.5, 0.5, 0.5), promoters=("TAC", "TAC"))
    genes["tail_pigment"] = _diploid_gene("tail_pigment", rng, _rand_tri(rng, 0.22, 0.78))

    genes["gait_cadence"] = _diploid_gene("gait_cadence", rng, _rand_tri(rng, 0.12, 0.92))
    genes["gait_power"] = _diploid_gene("gait_power", rng, _rand_tri(rng, 0.12, 0.92))
    genes["balance_core"] = _diploid_gene("balance_core", rng, _rand_tri(rng, 0.2, 0.85))
    genes["bone_density"] = _diploid_gene("bone_density", rng, _rand_tri(rng, 0.2, 0.85))

    # Repressed wild-type wings & horns (carriers exist naturally; rare enhancers express them)
    genes["wing_dev"] = _diploid_gene(
        "wing_dev", rng, (rng.uniform(0.12, 0.72), rng.random(), rng.random()), promoters=("TAC", "TAA")
    )
    genes["wing_chrom"] = _diploid_gene("wing_chrom", rng, (rng.random(), rng.random(), rng.random()))
    genes["horn_dev"] = _diploid_gene(
        "horn_dev", rng, (rng.uniform(0.12, 0.72), rng.random(), rng.random()), promoters=("TAA", "TAC")
    )
    beh_p = rng.choices(
        [
            rng.uniform(0.05, 0.42),
            rng.uniform(0.45, 0.61),
            rng.uniform(0.63, 0.76),
            rng.uniform(0.78, 0.89),
            rng.uniform(0.91, 0.99),
        ],
        weights=[44, 18, 15, 13, 10],
        k=1,
    )[0]
    genes["behavior_locus"] = _diploid_gene("behavior_locus", rng, (beh_p, rng.random(), rng.random()))
    genes["body_contour"] = _diploid_gene("body_contour", rng, (rng.uniform(0.05, 0.34), rng.random(), rng.random()))
    genes["limb_extra"] = _diploid_gene(
        "limb_extra", rng, (rng.uniform(0.12, 0.65), rng.random(), rng.random()), promoters=("TAA", "TAC")
    )
    genes["crest_dev"] = _diploid_gene(
        "crest_dev", rng, (rng.uniform(0.12, 0.65), rng.random(), rng.random()), promoters=("TAA", "TAC")
    )
    neuro_p = rng.choices(
        [rng.uniform(0.70, 0.95), rng.uniform(0.05, 0.20), rng.uniform(0.24, 0.38), rng.uniform(0.42, 0.52), rng.uniform(0.56, 0.66)],
        weights=[76, 6, 7, 5, 6],
        k=1,
    )[0]
    genes["neuro_temperament"] = _diploid_gene("neuro_temperament", rng, (neuro_p, rng.random(), rng.random()))
    meta_p = rng.choices(
        [rng.uniform(0.46, 0.70), rng.uniform(0.08, 0.22), rng.uniform(0.26, 0.42), rng.uniform(0.74, 0.85), rng.uniform(0.88, 0.97)],
        weights=[54, 10, 15, 13, 8],
        k=1,
    )[0]
    genes["metabolic_drive"] = _diploid_gene("metabolic_drive", rng, (meta_p, rng.random(), rng.random()))
    genes["sense_reflex"] = _diploid_gene("sense_reflex", rng, (rng.uniform(0.12, 0.92), rng.random(), rng.random()))

    # Rare genetic events via actual nucleotide mutations (stop codons, enhancers, color motifs)
    if force_mutation or rng.random() < rare_mutation_chance:
        mut_rolls = 2 if force_mutation and rng.random() < 0.45 else 1
        for _ in range(mut_rolls):
            category = rng.choices(
                [
                    "color_exotic",
                    "wings",
                    "horns_antlers",
                    "upright_horse",
                    "springy_hooves",
                    "third_leg",
                    "crest_pom",
                    "blob_body",
                    "narcoleptic",
                    "knockout_tail",
                    "knockout_ear",
                    "knockout_eye",
                    "knockout_hoof",
                    "knockout_teeth_nose",
                    "activate_arms",
                    "knockout_front_legs",
                    "knockout_back_legs",
                    "knockout_all_legs",
                    "knockout_neck",
                    "extreme_proportion",
                ],
                weights=[22, 14, 14, 9, 9, 5, 6, 5, 5, 7, 6, 5, 4, 4, 5, 2, 2, 2, 1, 8],
                k=1,
            )[0]

            if category == "color_exotic":
                motif = rng.choice(list(EXOTIC_COLOR_MOTIFS.keys()))
                genes["color_mutator"] = _diploid_gene(
                    "color_mutator", rng,
                    (rng.random(), rng.random(), rng.random()),
                    patches=(motif, motif),
                )
            elif category == "knockout_tail":
                genes["tail_form"] = _diploid_gene("tail_form", rng, (0.2, 0.5, 0.5), promoters=("TAA", "TGA"))
            elif category == "knockout_ear":
                genes["ear_form"] = _diploid_gene("ear_form", rng, (0.2, 0.5, 0.5), promoters=("TAG", "TAA"))
            elif category == "knockout_eye":
                genes["eye_dev"] = _diploid_gene("eye_dev", rng, (0.2, 0.5, 0.5), promoters=("TGA", "TAG"))
            elif category == "knockout_hoof":
                genes["hoof_dev"] = _diploid_gene("hoof_dev", rng, (0.2, 0.5, 0.5), promoters=("TAA", "TAG"))
            elif category == "knockout_teeth_nose":
                target = rng.choice(["teeth_dev", "nose_dev"])
                genes[target] = _diploid_gene(target, rng, (0.2, 0.5, 0.5), promoters=("TAA", "TAA"))
            elif category == "activate_arms":
                genes["arm_dev"] = _diploid_gene(
                    "arm_dev", rng,
                    (rng.uniform(0.65, 0.92), rng.uniform(0.55, 0.90), rng.uniform(0.55, 0.90)),
                    promoters=("ATG", "ATG"),
                    patches=("GGGG", "GGGG"),
                )
            elif category == "knockout_front_legs":
                genes["limb_fore"] = _diploid_gene("limb_fore", rng, (0.2, 0.5, 0.5), promoters=("TAA", "TGA"))
            elif category == "knockout_back_legs":
                genes["limb_hind"] = _diploid_gene("limb_hind", rng, (0.2, 0.5, 0.5), promoters=("TGA", "TAG"))
            elif category == "knockout_all_legs":
                genes["hox_limb_gate"] = _diploid_gene("hox_limb_gate", rng, (0.2, 0.5, 0.5), promoters=("TAA", "TAA"))
            elif category == "knockout_neck":
                genes["neck_morph"] = _diploid_gene("neck_morph", rng, (0.2, 0.5, 0.5), promoters=("TAG", "TGA"))
            elif category == "extreme_proportion":
                choice = rng.choice(["long_neck", "long_ears", "pygmy", "draft", "hinged_jaw"])
                if choice == "long_neck":
                    genes["neck_morph"] = _diploid_gene("neck_morph", rng, (0.94, 0.55, 0.65), patches=("GGGG", "GGGG"))
                elif choice == "long_ears":
                    genes["ear_form"] = _diploid_gene("ear_form", rng, (0.94, 0.65, 0.35), patches=("GGGG", "GGGG"))
                elif choice == "pygmy":
                    genes["size_somatic"] = _diploid_gene("size_somatic", rng, (0.05, 0.4, 0.4), promoters=("TAA", "TAG"))
                elif choice == "draft":
                    genes["size_somatic"] = _diploid_gene("size_somatic", rng, (0.97, 0.7, 0.7), promoters=("ATG", "ATG"))
                    genes["bone_density"] = _diploid_gene("bone_density", rng, (0.92, 0.8, 0.7), promoters=("ATG", "ATG"))
                elif choice == "hinged_jaw":
                    genes["jaw_morph"] = _diploid_gene("jaw_morph", rng, (0.65, 0.65, 0.5), patches=("GTAC", "GTAC"))
                    genes["hox_cranial"] = _diploid_gene("hox_cranial", rng, (0.85, 0.90, 0.75))
            elif category == "wings":
                genes["wing_dev"] = _diploid_gene(
                    "wing_dev",
                    rng,
                    (rng.random(), rng.uniform(0.2, 0.95), rng.uniform(0.2, 0.95)),
                    promoters=("ATG", "ATG"),
                    patches=("GGGG", "GGGG"),
                )
                genes["wing_chrom"] = _diploid_gene("wing_chrom", rng, (rng.random(), rng.random(), rng.random()))
            elif category == "horns_antlers":
                genes["horn_dev"] = _diploid_gene(
                    "horn_dev",
                    rng,
                    (rng.random(), rng.uniform(0.25, 0.95), rng.uniform(0.25, 0.95)),
                    promoters=("ATG", "ATG"),
                    patches=("ATAC", "ATAC"),
                )
            elif category == "upright_horse":
                genes["hox_posture"] = _diploid_gene(
                    "hox_posture",
                    rng,
                    (rng.uniform(0.84, 0.96), rng.random(), rng.random()),
                    promoters=("ATG", "ATG"),
                    utrs=("CAA", "CAA"),
                )
                if rng.random() < 0.5:
                    genes["arm_dev"] = _diploid_gene(
                        "arm_dev",
                        rng,
                        (rng.uniform(0.65, 0.92), rng.uniform(0.55, 0.88), rng.uniform(0.55, 0.88)),
                        promoters=("ATG", "ATG"),
                        patches=("GGGG", "GGGG"),
                    )
            elif category == "third_leg":
                genes["limb_extra"] = _diploid_gene(
                    "limb_extra",
                    rng,
                    (rng.uniform(0.60, 0.92), rng.uniform(0.45, 0.85), rng.random()),
                    promoters=("ATG", "ATG"),
                    patches=("GGGG", "GGGG"),
                )
            elif category == "crest_pom":
                genes["crest_dev"] = _diploid_gene(
                    "crest_dev",
                    rng,
                    (rng.random(), rng.uniform(0.45, 0.92), rng.uniform(0.40, 0.92)),
                    promoters=("ATG", "ATG"),
                    patches=("GGGG", "GGGG"),
                )
            elif category == "blob_body":
                genes["body_contour"] = _diploid_gene(
                    "body_contour",
                    rng,
                    (rng.uniform(0.80, 0.95), rng.uniform(0.5, 0.9), rng.random()),
                    promoters=("ATG", "ATG"),
                )
            elif category == "narcoleptic":
                genes["neuro_temperament"] = _diploid_gene(
                    "neuro_temperament", rng, (0.10, 0.4, 0.4), promoters=("TAA", "TGA")
                )
            elif category == "springy_hooves":
                genes["hoof_dev"] = _diploid_gene(
                    "hoof_dev",
                    rng,
                    (rng.uniform(0.25, 0.90), rng.uniform(0.25, 0.90), rng.random()),
                    promoters=("ATG", "ATG"),
                    utrs=("TTT", "TTT"),
                    patches=("GTAC", "GTAC"),
                )
                genes["gait_power"] = _diploid_gene("gait_power", rng, (rng.uniform(0.70, 0.95), rng.random(), rng.random()))

    _write_life_genes(genes, rng, kind="horse")
    _write_expression_genes(genes, rng)
    return Genome(genes=genes, lineage="Wild", generation=1)


def rabbit_genome(rng: random.Random | None = None) -> Genome:
    """A horse-like genome whose saltatory axis is pushed toward the rabbit end.

    Offspring with a horse average that axis, so the phenotype lands between them.
    """
    rng = rng or random.Random()
    base = random_horse_genome(rng=rng, rare_mutation_chance=0.004)
    genes = dict(base.genes)
    genes["axial_plan"] = _diploid_gene(
        "axial_plan",
        rng,
        (0.50, 0.50, 0.96),
        p2=(0.50, 0.50, 0.96),
        promoters=("TAC", "TAC"),
    )
    return Genome(genes=genes, lineage="Rabbit", generation=1)


def rancher_genome(
    rng: random.Random | None = None,
    rare_mutation_chance: float = 0.04,
    force_mutation: bool = False,
) -> Genome:
    """
    Constructs a varied Human/Rancher genome using the same 64 universal loci.
    Supports wide natural variation in height, build, facial traits, skin tones,
    eye colors, clothing, and rare exotic mutations (wings, horns, tails, colors).
    """
    rng = rng or random.Random(42)
    genes: dict[str, Gene] = {}

    genes["hox_posture"] = _diploid_gene(
        "hox_posture",
        rng,
        (rng.uniform(0.80, 0.96), rng.uniform(0.76, 0.96), rng.uniform(0.2, 0.8)),
        promoters=("ATG", "ATG"),
        utrs=("ATT", "ATT"),
    )
    genes["hox_limb_gate"] = _diploid_gene(
        "hox_limb_gate", rng, (0.65, 0.90, 0.65), promoters=("ATG", "ATG")
    )
    genes["hox_cranial"] = _diploid_gene(
        "hox_cranial", rng, (rng.uniform(0.45, 0.85), rng.uniform(0.45, 0.85), rng.uniform(0.45, 0.85))
    )
    genes["hox_caudal"] = _diploid_gene(
        "hox_caudal", rng, (0.10, 0.20, 0.20), promoters=("TAA", "TAA")
    )

    genes["size_somatic"] = _diploid_gene(
        "size_somatic", rng, (rng.uniform(0.14, 0.88), rng.random(), rng.random())
    )
    genes["build_robust"] = _diploid_gene(
        "build_robust", rng, (rng.uniform(0.12, 0.90), rng.random(), rng.random())
    )
    genes["torso_len"] = _diploid_gene("torso_len", rng, _rand_tri(rng, 0.14, 0.88))
    genes["torso_depth"] = _diploid_gene("torso_depth", rng, _rand_tri(rng, 0.14, 0.88))
    genes["neck_morph"] = _diploid_gene("neck_morph", rng, _rand_tri(rng, 0.16, 0.86))
    genes["head_size"] = _diploid_gene("head_size", rng, _rand_tri(rng, 0.16, 0.86))
    genes["jaw_morph"] = _diploid_gene("jaw_morph", rng, _rand_tri(rng, 0.15, 0.88))
    genes["teeth_dev"] = _diploid_gene("teeth_dev", rng, _rand_tri(rng, 0.20, 0.85))
    genes["nose_dev"] = _diploid_gene("nose_dev", rng, _rand_tri(rng, 0.18, 0.88))

    if rng.random() < 0.42:
        genes["ear_form"] = _diploid_gene("ear_form", rng, _rand_tri(rng, 0.22, 0.82))
    else:
        genes["ear_form"] = _diploid_gene(
            "ear_form", rng, (0.20, 0.20, 0.20), promoters=("TAG", "TAG")
        )

    genes["limb_fore"] = _diploid_gene("limb_fore", rng, _rand_tri(rng, 0.18, 0.86))
    genes["limb_hind"] = _diploid_gene("limb_hind", rng, _rand_tri(rng, 0.18, 0.86))
    genes["arm_dev"] = _diploid_gene(
        "arm_dev",
        rng,
        (rng.uniform(0.22, 0.86), rng.uniform(0.20, 0.88), rng.uniform(0.12, 0.90)),
        promoters=("ATG", "ATG"),
        utrs=(rng.choice(("CAG", "ACC", "GTT", "TTC")), rng.choice(("CAG", "ACC", "GTT", "TTC"))),
    )
    genes["hoof_dev"] = _diploid_gene(
        "hoof_dev", rng, (0.15, 0.15, 0.15), promoters=("TGA", "TGA")
    )
    genes["tail_form"] = _diploid_gene(
        "tail_form", rng, (0.10, 0.10, 0.10), promoters=("TAA", "TAA")
    )
    genes["symmetry_mod"] = _diploid_gene(
        "symmetry_mod", rng, (rng.uniform(0.38, 0.62), rng.uniform(0.3, 0.7), rng.uniform(0.3, 0.7))
    )

    genes["eye_dev"] = _diploid_gene("eye_dev", rng, _rand_tri(rng, 0.20, 0.88))
    genes["iris_chrom"] = _diploid_gene(
        "iris_chrom", rng, (rng.random(), rng.random(), rng.random())
    )

    # Full human melanin & undertone spectrum + varied trousers/sleeves/shirts
    genes["pigment_base"] = _diploid_gene(
        "pigment_base", rng, (rng.uniform(0.05, 0.95), rng.uniform(0.15, 0.85), rng.random())
    )
    genes["pigment_dilute"] = _diploid_gene(
        "pigment_dilute", rng, (rng.uniform(0.08, 0.92), rng.random(), rng.random())
    )
    genes["pattern_locus"] = _diploid_gene("pattern_locus", rng, (0.10, 0.20, 0.20))
    genes["pattern_chrom"] = _diploid_gene(
        "pattern_chrom", rng, (rng.random(), rng.random(), rng.random())
    )
    genes["color_mutator"] = _diploid_gene("color_mutator", rng, (0.50, 0.50, 0.50))
    genes["tail_pigment"] = _diploid_gene(
        "tail_pigment", rng, (rng.random(), rng.random(), rng.random())
    )

    # Keep average human running pace crisp while adding natural athletic variance
    genes["gait_cadence"] = _diploid_gene(
        "gait_cadence", rng, (rng.uniform(0.28, 0.54), rng.uniform(0.28, 0.56), rng.uniform(0.28, 0.56))
    )
    genes["gait_power"] = _diploid_gene(
        "gait_power", rng, (rng.uniform(0.28, 0.54), rng.uniform(0.28, 0.56), rng.uniform(0.35, 0.65))
    )
    genes["balance_core"] = _diploid_gene(
        "balance_core", rng, (rng.uniform(0.52, 0.82), rng.uniform(0.52, 0.82), rng.uniform(0.3, 0.7))
    )
    genes["bone_density"] = _diploid_gene(
        "bone_density", rng, (rng.uniform(0.35, 0.68), rng.uniform(0.35, 0.68), rng.uniform(0.35, 0.68))
    )
    genes["wing_dev"] = _diploid_gene(
        "wing_dev", rng, (0.10, 0.10, 0.10), promoters=("TAA", "TAA")
    )
    genes["wing_chrom"] = _diploid_gene(
        "wing_chrom", rng, (rng.random(), rng.random(), rng.random())
    )
    genes["horn_dev"] = _diploid_gene(
        "horn_dev", rng, (0.10, 0.10, 0.10), promoters=("TAA", "TAA")
    )
    genes["behavior_locus"] = _diploid_gene(
        "behavior_locus", rng, (rng.uniform(0.15, 0.85), rng.random(), rng.random())
    )
    genes["body_contour"] = _diploid_gene("body_contour", rng, (rng.uniform(0.08, 0.45), rng.random(), rng.random()))
    genes["limb_extra"] = _diploid_gene("limb_extra", rng, (0.10, 0.10, 0.10), promoters=("TAA", "TAA"))
    genes["crest_dev"] = _diploid_gene("crest_dev", rng, (0.10, 0.10, 0.10), promoters=("TAA", "TAA"))
    genes["neuro_temperament"] = _diploid_gene("neuro_temperament", rng, (rng.uniform(0.70, 0.95), rng.random(), rng.random()))
    genes["metabolic_drive"] = _diploid_gene("metabolic_drive", rng, (rng.uniform(0.45, 0.72), rng.random(), rng.random()))
    genes["sense_reflex"] = _diploid_gene("sense_reflex", rng, (rng.uniform(0.30, 0.75), rng.random(), rng.random()))

    if force_mutation or rng.random() < rare_mutation_chance:
        mut_rolls = 2 if force_mutation and rng.random() < 0.4 else 1
        for _ in range(mut_rolls):
            category = rng.choices(
                ["color_exotic", "wings", "horns_antlers", "tail", "hooves", "long_ears", "pattern"],
                weights=[24, 18, 18, 14, 10, 8, 8],
                k=1,
            )[0]
            if category == "color_exotic":
                motif = rng.choice(list(EXOTIC_COLOR_MOTIFS.keys()))
                genes["color_mutator"] = _diploid_gene(
                    "color_mutator",
                    rng,
                    (rng.random(), rng.random(), rng.random()),
                    patches=(motif, motif),
                )
            elif category == "wings":
                genes["wing_dev"] = _diploid_gene(
                    "wing_dev",
                    rng,
                    (rng.random(), rng.uniform(0.25, 0.90), rng.uniform(0.25, 0.90)),
                    promoters=("ATG", "ATG"),
                    patches=("GGGG", "GGGG"),
                )
                genes["wing_chrom"] = _diploid_gene(
                    "wing_chrom", rng, (rng.random(), rng.random(), rng.random())
                )
            elif category == "horns_antlers":
                genes["horn_dev"] = _diploid_gene(
                    "horn_dev",
                    rng,
                    (rng.random(), rng.uniform(0.25, 0.90), rng.uniform(0.25, 0.90)),
                    promoters=("ATG", "ATG"),
                    patches=("ATAC", "ATAC"),
                )
            elif category == "tail":
                genes["hox_caudal"] = _diploid_gene(
                    "hox_caudal", rng, (rng.uniform(0.50, 0.85), 0.6, 0.6), promoters=("ATG", "ATG")
                )
                genes["tail_form"] = _diploid_gene(
                    "tail_form", rng, _rand_tri(rng, 0.30, 0.90), promoters=("ATG", "ATG")
                )
            elif category == "hooves":
                genes["hoof_dev"] = _diploid_gene(
                    "hoof_dev",
                    rng,
                    (rng.uniform(0.35, 0.85), rng.uniform(0.35, 0.85), rng.random()),
                    promoters=("ATG", "ATG"),
                    patches=("GTAC", "GTAC"),
                )
            elif category == "long_ears":
                genes["ear_form"] = _diploid_gene(
                    "ear_form",
                    rng,
                    (0.92, 0.62, rng.uniform(0.1, 0.9)),
                    promoters=("ATG", "ATG"),
                    patches=("GGGG", "GGGG"),
                )
            elif category == "pattern":
                genes["pattern_locus"] = _diploid_gene(
                    "pattern_locus",
                    rng,
                    (rng.uniform(0.62, 0.96), rng.uniform(0.35, 0.85), rng.uniform(0.4, 0.9)),
                )

    _write_life_genes(genes, rng, kind="rancher")
    _write_expression_genes(genes, rng)
    return Genome(genes=genes, lineage="Human", generation=1)


def carnivore_genome(rng: random.Random | None = None) -> Genome:
    """A wild predator. Diet sits at the carnivore end of the same axis horses leave low."""
    rng = rng or random.Random()
    base = random_horse_genome(rng=rng, rare_mutation_chance=0.0)
    genes = dict(base.genes)
    genes["diet_guild"] = _diploid_gene(
        "diet_guild",
        rng,
        (rng.uniform(0.84, 0.96), 0.55, 0.40),
        p2=(rng.uniform(0.84, 0.96), 0.55, 0.40),
        promoters=("ATG", "ATG"),
    )
    genes["dentition"] = _diploid_gene(
        "dentition",
        rng,
        (rng.uniform(0.68, 0.90), rng.uniform(0.62, 0.88), rng.uniform(0.62, 0.88)),
        p2=(rng.uniform(0.68, 0.90), 0.70, 0.70),
        utrs=("GAA", "GAA"),
    )
    return Genome(genes=genes, lineage="Carnivore", generation=1)


def _write_expression_genes(genes: dict[str, Gene], rng: random.Random) -> None:
    """Small inherited variation, with rarer ornamental and rotary extremes."""
    for locus in EXPRESSION_LOCI:
        if locus in ("cranial_shape", "muzzle_shape", "eye_expression", "limb_shape", "joint_pose", "joint_response"):
            lo, hi = (0.42, 0.58) if locus in ("cranial_shape", "limb_shape", "joint_response") else (0.46, 0.54)
            channels = _rand_tri(rng, lo, hi)
            partner = tuple(_clamp(value + rng.uniform(-0.025, 0.025), lo, hi) for value in channels)
            genes[locus] = _diploid_gene(locus, rng, channels, p2=partner)
            continue
        if locus in ("tail_shape", "wing_shape", "horn_shape"):
            channels = _rand_tri(rng, 0.10, 0.90)
        elif locus == "rotary_drive":
            channels = (0.50, 0.50, 0.50)
            if rng.random() < 0.035:
                turn = rng.choice((0.06, 0.94))
                channels = (turn, turn, turn)
            genes[locus] = _diploid_gene(locus, rng, channels, p2=channels, utrs=("GAA", "GAA"))
            continue
        elif locus in ("crest_shape", "crest_ornament", "skin_ornament"):
            channels = _rand_tri(rng, 0.40, 0.62)
            if rng.random() < 0.07:
                channels = _rand_tri(rng, 0.04, 0.96)
        else:
            channels = _rand_tri(rng, 0.28, 0.72)
        genes[locus] = _diploid_gene(locus, rng, channels)


def _write_life_genes(genes: dict[str, Gene], rng: random.Random, kind: str) -> None:
    """Pin diet, joints, life, and teeth. Runs after the body is rolled so coats stay put.

    0.5 on joint_flex and on the head channels is the current body. Horses stay
    herbivores. Ranchers sit in the omnivore band and are sentient.
    """
    if kind == "rancher":
        diet_p = rng.uniform(0.44, 0.60)
        sent_p = rng.uniform(0.86, 0.97)
    else:
        diet_p = rng.uniform(0.06, 0.20)
        sent_p = rng.uniform(0.05, 0.22)
    genes["diet_guild"] = _diploid_gene(
        "diet_guild",
        rng,
        (diet_p, 0.45, 0.50),
        p2=(_clamp(diet_p + rng.uniform(-0.04, 0.04), 0.02, 0.98), 0.45, 0.50),
    )
    genes["osteoderm"] = _diploid_gene(
        "osteoderm", rng, (0.12, 0.30, 0.40), promoters=("TAA", "TAA")
    )
    genes["joint_flex"] = _diploid_gene(
        "joint_flex",
        rng,
        (0.50, 0.50, 0.50),
        p2=(0.50, 0.50, 0.50),
        utrs=("GAA", "GAA"),
    )
    genes["vital_span"] = _diploid_gene(
        "vital_span",
        rng,
        (rng.uniform(0.08, 0.28), rng.uniform(0.06, 0.26), 0.50),
        p2=(rng.uniform(0.08, 0.28), rng.uniform(0.06, 0.26), 0.50),
    )
    genes["lethal_white"] = _diploid_gene(
        "lethal_white",
        rng,
        (rng.uniform(0.05, 0.20), rng.uniform(0.08, 0.24), 0.40),
        p2=(rng.uniform(0.05, 0.20), rng.uniform(0.08, 0.24), 0.40),
    )
    genes["sentience"] = _diploid_gene(
        "sentience",
        rng,
        (sent_p, 0.50, 0.50),
        p2=(_clamp(sent_p + rng.uniform(-0.04, 0.04), 0.02, 0.98), 0.50, 0.50),
        promoters=("ATG", "ATG") if kind == "rancher" else ("TAC", "TAC"),
        utrs=("GAA", "GAA"),
    )
    genes["dentition"] = _diploid_gene(
        "dentition",
        rng,
        (rng.uniform(0.16, 0.42), rng.uniform(0.58, 0.84), rng.uniform(0.58, 0.84)),
        p2=(rng.uniform(0.16, 0.42), rng.uniform(0.58, 0.84), rng.uniform(0.58, 0.84)),
        utrs=("GAA", "GAA"),
    )


def prop_genome(kind: str, rng: random.Random | None = None) -> Genome:
    """
    Generates a 64-locus Genome from a consumable prop's genetic traits
    (Hay Bale, Apple, Beer, Chili) so creatures emerge purely from universal loci.
    """
    rng = rng or random.Random()
    base = random_horse_genome(rng=rng, rare_mutation_chance=0.0, force_mutation=False)
    genes = dict(base.genes)

    for loc in (
        "hox_limb_gate", "hox_caudal", "neck_morph", "head_size", "jaw_morph",
        "teeth_dev", "nose_dev", "ear_form", "eye_dev", "hoof_dev", "tail_form",
        "arm_dev", "limb_extra", "wing_dev", "horn_dev", "crest_dev",
    ):
        genes[loc] = _diploid_gene(loc, rng, (0.20, 0.50, 0.50), promoters=("TAA", "TAA"))

    genes["color_mutator"] = _diploid_gene("color_mutator", rng, (0.50, 0.50, 0.50))
    genes["pattern_locus"] = _diploid_gene("pattern_locus", rng, (0.12, 0.30, 0.30))

    if kind == "hay":
        genes["hox_posture"] = _diploid_gene("hox_posture", rng, (0.88, 0.12, 0.50), promoters=("ATG", "ATG"))
        genes["hox_limb_gate"] = _diploid_gene("hox_limb_gate", rng, (0.70, 0.70, 0.70), promoters=("ATG", "ATG"))
        genes["size_somatic"] = _diploid_gene(
            "size_somatic", rng, (0.08, 0.12, 0.12), promoters=("TAA", "TAG"), patches=("CCCC", "CCCC")
        )
        genes["build_robust"] = _diploid_gene("build_robust", rng, (0.84, 0.50, 0.50))
        genes["torso_len"] = _diploid_gene("torso_len", rng, (0.12, 0.50, 0.50))
        genes["torso_depth"] = _diploid_gene("torso_depth", rng, (0.72, 0.50, 0.50))
        genes["body_contour"] = _diploid_gene("body_contour", rng, (0.10, 0.50, 0.50))
        genes["neck_morph"] = _diploid_gene("neck_morph", rng, (0.24, 0.72, 0.22), promoters=("ATG", "ATG"))
        genes["limb_fore"] = _diploid_gene("limb_fore", rng, (0.12, 0.55, 0.50), promoters=("ATG", "ATG"))
        genes["limb_hind"] = _diploid_gene("limb_hind", rng, (0.12, 0.55, 0.50), promoters=("ATG", "ATG"))
        genes["limb_extra"] = _diploid_gene(
            "limb_extra", rng, (0.76, 0.85, 0.50), promoters=("ATG", "ATG"), patches=("GGGG", "GGGG")
        )
        genes["arm_dev"] = _diploid_gene(
            "arm_dev", rng, (0.18, 0.45, 0.82), p2=(0.18, 0.45, 0.82), promoters=("ATG", "ATG"), patches=("GGGG", "GGGG")
        )
        genes["pigment_base"] = _diploid_gene("pigment_base", rng, (0.86, 0.88, 0.65))
        genes["pigment_dilute"] = _diploid_gene("pigment_dilute", rng, (0.68, 0.25, 0.55))
        genes["color_mutator"] = _diploid_gene(
            "color_mutator", rng, (0.55, 0.82, 0.50), patches=("GGGGGG", "GGGGGG")
        )
        genes["metabolic_drive"] = _diploid_gene("metabolic_drive", rng, (0.78, 0.65, 0.50), promoters=("ATG", "ATG"))
        return Genome(genes=genes, lineage="Hay", generation=1)

    if kind == "prickly_pear":
        # Succulent pads and spines use the same body, pigment, and outgrowth
        # loci as every other creature; no cactus-specific drawing is needed.
        genes["hox_posture"] = _diploid_gene("hox_posture", rng, (0.94, 0.14, 0.50), promoters=("ATG", "ATG"))
        genes["size_somatic"] = _diploid_gene("size_somatic", rng, (0.62, 0.50, 0.50), promoters=("ATG", "ATG"))
        genes["build_robust"] = _diploid_gene("build_robust", rng, (0.66, 0.50, 0.50))
        genes["torso_len"] = _diploid_gene("torso_len", rng, (0.38, 0.50, 0.50))
        genes["torso_depth"] = _diploid_gene("torso_depth", rng, (0.74, 0.50, 0.50))
        genes["body_contour"] = _diploid_gene("body_contour", rng, (0.48, 0.50, 0.50))
        genes["arm_dev"] = _diploid_gene(
            "arm_dev", rng, (0.82, 0.90, 0.94), p2=(0.82, 0.90, 0.94), promoters=("ATG", "ATG"), utrs=("TTT", "TTT")
        )
        genes["color_mutator"] = _diploid_gene(
            "color_mutator", rng, (0.50, 0.50, 0.50), patches=("ATATAT", "ATATAT")
        )
        genes["osteoderm"] = _diploid_gene(
            "osteoderm", rng, (0.66, 0.82, 0.52), p2=(0.66, 0.82, 0.52), promoters=("ATG", "ATG")
        )
        genes["crest_dev"] = _diploid_gene(
            "crest_dev", rng, (0.92, 0.48, 0.28), p2=(0.92, 0.48, 0.28), promoters=("ATG", "ATG"), utrs=("TTT", "TTT")
        )
        genes["wing_chrom"] = _diploid_gene("wing_chrom", rng, (0.33, 0.68, 0.56))
        genes["pattern_locus"] = _diploid_gene("pattern_locus", rng, (0.18, 0.50, 0.50), promoters=("TAA", "TAA"))
        genes["pattern_chrom"] = _diploid_gene("pattern_chrom", rng, (0.92, 0.88, 0.90))
        return Genome(genes=genes, lineage="PricklyPear", generation=1)

    if kind in ("apple", "apple_crate"):
        genes["hox_posture"] = _diploid_gene("hox_posture", rng, (0.90, 0.14, 0.50), promoters=("ATG", "ATG"))
        genes["size_somatic"] = _diploid_gene("size_somatic", rng, (0.78, 0.65, 0.55), promoters=("ATG", "ATG"))
        genes["build_robust"] = _diploid_gene("build_robust", rng, (0.26, 0.50, 0.50))
        genes["torso_len"] = _diploid_gene("torso_len", rng, (0.92, 0.50, 0.50))
        genes["torso_depth"] = _diploid_gene("torso_depth", rng, (0.26, 0.50, 0.50))
        genes["body_contour"] = _diploid_gene("body_contour", rng, (0.10, 0.50, 0.50))
        genes["neck_morph"] = _diploid_gene("neck_morph", rng, (0.26, 0.88, 0.50), promoters=("ATG", "ATG"))
        genes["head_size"] = _diploid_gene("head_size", rng, (0.45, 0.45, 0.50), promoters=("ATG", "ATG"))
        genes["arm_dev"] = _diploid_gene(
            "arm_dev", rng, (0.44, 0.58, 0.34), p2=(0.44, 0.58, 0.34), promoters=("ATG", "ATG"), patches=("GGGG", "GGGG")
        )
        genes["pigment_base"] = _diploid_gene("pigment_base", rng, (0.24, 0.55, 0.55))
        genes["pigment_dilute"] = _diploid_gene("pigment_dilute", rng, (0.22, 0.20, 0.50))
        genes["crest_dev"] = _diploid_gene(
            "crest_dev", rng, (0.46, 0.82, 0.72), p2=(0.46, 0.82, 0.72), promoters=("ATG", "ATG"), utrs=("TTT", "TTT"), patches=("GGGG", "GGGG")
        )
        genes["wing_chrom"] = _diploid_gene("wing_chrom", rng, (0.33, 0.92, 0.82))
        genes["pattern_chrom"] = _diploid_gene("pattern_chrom", rng, (0.98, 0.88, 0.90))
        genes["sense_reflex"] = _diploid_gene("sense_reflex", rng, (0.68, 0.70, 0.50), promoters=("ATG", "ATG"))
        return Genome(genes=genes, lineage="Apple", generation=1)

    if kind == "beer":
        genes["hox_posture"] = _diploid_gene("hox_posture", rng, (0.82, 0.10, 0.50), promoters=("ATG", "ATG"))
        genes["size_somatic"] = _diploid_gene(
            "size_somatic", rng, (0.05, 0.08, 0.10), promoters=("TAA", "TAG"), patches=("CCCC", "CCCC")
        )
        genes["build_robust"] = _diploid_gene("build_robust", rng, (0.88, 0.80, 0.50))
        genes["torso_len"] = _diploid_gene("torso_len", rng, (0.12, 0.50, 0.50))
        genes["torso_depth"] = _diploid_gene("torso_depth", rng, (0.86, 0.50, 0.50))
        genes["body_contour"] = _diploid_gene(
            "body_contour", rng, (0.90, 0.80, 0.65), promoters=("ATG", "ATG"), patches=("GGGG", "GGGG")
        )
        genes["pigment_base"] = _diploid_gene("pigment_base", rng, (0.82, 0.85, 0.55))
        genes["pigment_dilute"] = _diploid_gene("pigment_dilute", rng, (0.76, 0.25, 0.55))
        genes["color_mutator"] = _diploid_gene(
            "color_mutator", rng, (0.50, 0.78, 0.50), patches=("GGGGGG", "GGGGGG")
        )
        genes["pattern_locus"] = _diploid_gene("pattern_locus", rng, (0.52, 0.82, 0.74), promoters=("ATG", "ATG"))
        genes["pattern_chrom"] = _diploid_gene("pattern_chrom", rng, (0.18, 0.80, 0.50))
        genes["neuro_temperament"] = _diploid_gene("neuro_temperament", rng, (0.12, 0.40, 0.40), promoters=("TAA", "TGA"))
        genes["metabolic_drive"] = _diploid_gene("metabolic_drive", rng, (0.14, 0.50, 0.50))
        return Genome(genes=genes, lineage="Beer", generation=1)

    genes["hox_posture"] = _diploid_gene("hox_posture", rng, (0.85, 0.10, 0.50), promoters=("ATG", "ATG"))
    genes["size_somatic"] = _diploid_gene(
        "size_somatic", rng, (0.10, 0.12, 0.10), promoters=("TAA", "TAG"), patches=("CCCC", "CCCC")
    )
    genes["build_robust"] = _diploid_gene("build_robust", rng, (0.48, 0.50, 0.50))
    genes["torso_len"] = _diploid_gene("torso_len", rng, (0.16, 0.50, 0.50))
    genes["torso_depth"] = _diploid_gene("torso_depth", rng, (0.46, 0.50, 0.50))
    genes["body_contour"] = _diploid_gene("body_contour", rng, (0.64, 0.72, 0.50), promoters=("ATG", "ATG"))
    genes["pigment_base"] = _diploid_gene("pigment_base", rng, (0.78, 0.82, 0.50))
    genes["color_mutator"] = _diploid_gene(
        "color_mutator", rng, (0.72, 0.80, 0.50), patches=("ACACAC", "ACACAC")
    )
    genes["crest_dev"] = _diploid_gene(
        "crest_dev", rng, (0.15, 0.80, 0.82), p2=(0.15, 0.80, 0.82), promoters=("ATG", "ATG"), utrs=("CAG", "CAG"), patches=("GGGG", "GGGG")
    )
    genes["wing_chrom"] = _diploid_gene("wing_chrom", rng, (0.33, 0.92, 0.80))
    genes["metabolic_drive"] = _diploid_gene(
        "metabolic_drive", rng, (0.92, 0.85, 0.65), promoters=("ATG", "ATG"), patches=("GGGG", "GGGG")
    )
    genes["neuro_temperament"] = _diploid_gene("neuro_temperament", rng, (0.32, 0.65, 0.50), promoters=("ATG", "ATG"))
    return Genome(genes=genes, lineage="Chili", generation=1)
