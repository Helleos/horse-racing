"""Phenotype description and coat, skin, and pattern resolution."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable
import colorsys
import hashlib
import math

from allele import (
    DOMINANT_EXOTIC_COLORS,
    GeneExpression,
    _clamp,
    _lerp,
)

# --- PHENOTYPE OUTPUT & REGULATORY GENE NETWORK ---


def _superellipse_outline(power: float, count: int = 32) -> tuple[tuple[float, float], ...]:
    """Normalized outline that varies continuously from round to square."""
    points = []
    for i in range(count):
        angle = i * math.tau / count
        coordinates = []
        for value in (math.cos(angle), math.sin(angle)):
            coordinates.append(0.0 if abs(value) < 1e-12 else math.copysign(abs(value) ** (2.0 / power), value) * 0.5)
        points.append(tuple(coordinates))
    return tuple(points)


@dataclass(frozen=True)
class Phenotype:
    """Resolved phenotype. Spine, face, and forelimbs are continuous axes."""

    label: str
    coat_name: str
    posture: str  # label derived from erectness: "quadruped" or "upright"
    trait_tags: tuple[str, ...]
    disabled_parts: tuple[str, ...]
    color_mutation: str | None

    overall_scale: float
    stocky: float
    mass_scale: float

    # Part dimensions, enables & properties
    torso_size: tuple[float, float]
    torso_mass: float
    torso_color: tuple[int, int, int] | None

    neck_enabled: bool
    neck_size: tuple[float, float]
    neck_mass: float
    neck_anchor_offset: tuple[float, float]
    neck_rest_deg: float
    neck_min_deg: float
    neck_max_deg: float
    neck_color: tuple[int, int, int] | None

    head_enabled: bool
    head_size: tuple[float, float]
    head_mass: float
    head_rest_deg: float
    head_min_deg: float
    head_max_deg: float
    head_color: tuple[int, int, int] | None

    upper_jaw_enabled: bool
    upper_jaw_size: tuple[float, float]
    upper_jaw_mass: float
    upper_jaw_color: tuple[int, int, int] | None

    lower_jaw_enabled: bool
    lower_jaw_size: tuple[float, float]
    lower_jaw_mass: float
    lower_jaw_jointed: bool
    lower_jaw_color: tuple[int, int, int] | None

    ear_enabled: bool
    ear_size: tuple[float, float]
    ear_mass: float
    ear_style: str
    ear_tip_offset: float
    ear_color: tuple[int, int, int] | None

    teeth_enabled: bool
    teeth_size: tuple[float, float]
    teeth_mass: float
    teeth_color: tuple[int, int, int] | None

    nose_enabled: bool
    nose_size: tuple[float, float]
    nose_mass: float
    nose_color: tuple[int, int, int]

    leg_front_enabled: bool
    leg_front_size: tuple[float, float]
    leg_front_mass: float
    leg_front_anchor_offset: tuple[float, float]
    leg_front_knee_deg: float
    leg_front_knee_ratio: float
    leg_front_lower_scale: float
    leg_front_rest_deg: float
    leg_front_stiffness: float
    leg_front_damping: float
    leg_front_color: tuple[int, int, int] | None

    leg_back_enabled: bool
    leg_back_size: tuple[float, float]
    leg_back_mass: float
    leg_back_anchor_offset: tuple[float, float]
    leg_back_knee_deg: float
    leg_back_knee_ratio: float
    leg_back_lower_scale: float
    leg_back_rest_deg: float
    leg_back_stiffness: float
    leg_back_damping: float
    leg_back_color: tuple[int, int, int] | None

    arm_front_enabled: bool
    arm_front_size: tuple[float, float]
    arm_front_mass: float
    arm_front_anchor_offset: tuple[float, float]
    arm_front_knee_deg: float
    arm_front_rest_deg: float
    arm_front_color: tuple[int, int, int] | None

    arm_back_enabled: bool
    arm_back_size: tuple[float, float]
    arm_back_mass: float
    arm_back_anchor_offset: tuple[float, float]
    arm_back_knee_deg: float
    arm_back_rest_deg: float
    arm_back_color: tuple[int, int, int] | None

    hoof_enabled: bool
    hoof_size: tuple[float, float]
    hoof_mass: float
    hoof_friction: float
    hoof_style: str
    hoof_elasticity: float
    hoof_spring_bounce: float
    hoof_front_color: tuple[int, int, int]
    hoof_back_color: tuple[int, int, int]

    hand_enabled: bool
    hand_size: tuple[float, float]
    hand_color: tuple[int, int, int]
    hand_back_color: tuple[int, int, int]

    tail_enabled: bool
    tail_size: tuple[float, float]
    tail_mass: float
    tail_anchor_offset: tuple[float, float]
    tail_style: str
    tail_rest_deg: float
    tail_color: tuple[int, int, int]

    wing_enabled: bool
    wing_style: str
    wing_span: float
    wing_chord: float
    wing_color: tuple[int, int, int]
    wing_secondary_color: tuple[int, int, int]
    wing_lift: float
    wing_flap_freq: float
    wing_drag: float

    horn_enabled: bool
    horn_kind: str
    horn_length: float
    horn_thickness: float
    horn_curve: float
    horn_tines: int
    horn_spread: float
    horn_color: tuple[int, int, int]
    horn_tip_color: tuple[int, int, int]
    horn_seed: int

    eye_enabled: bool
    eye_offset: tuple[float, float]
    eye_radius: float
    eye_pupil_offset: tuple[float, float]
    eye_pupil_radius: float
    eye_sclera_color: tuple[int, int, int]
    eye_pupil_color: tuple[int, int, int]

    coat_color: tuple[int, int, int]
    back_leg_color: tuple[int, int, int]
    tooth_color: tuple[int, int, int]

    pattern_style: str
    pattern_color: tuple[int, int, int]
    pattern_density: float
    pattern_scale: float
    pattern_seed: int

    # Gait parameters
    gait_enabled: bool
    behavior: str
    walk_freq: float
    stride_deg: float
    run_freq: float
    run_stride_deg: float
    run_target_speed: float
    run_phase_offset_deg: float
    tail_sway_deg: float
    balance_stiffness: float
    balance_damping: float
    balance_max_torque: float
    joint_stiffness_scale: float
    joint_damping_scale: float
    torso_style: str = "default"
    limb_roundness: float = 0.0
    limb_inset: tuple[tuple[float, float], ...] = ()
    torso_components: tuple[tuple[tuple[float, float], ...], ...] = ()
    surface_regions: tuple[tuple[tuple[float, float], ...], ...] = ()
    contour_seed: int = 0

    leg_mid_enabled: bool = False
    leg_mid_size: tuple[float, float] = (14.0, 92.0)
    leg_mid_mass: float = 2.4
    leg_mid_anchor_offset: tuple[float, float] = (0.0, 0.0)
    leg_mid_knee_deg: float = 0.0
    leg_mid_knee_ratio: float = 0.5
    leg_mid_lower_scale: float = 0.86
    leg_mid_rest_deg: float = 0.0
    leg_mid_stiffness: float = 1500000.0
    leg_mid_damping: float = 25000.0
    leg_mid_color: tuple[int, int, int] | None = None

    crest_enabled: bool = False
    crest_style: str = "tuft"
    crest_size: float = 22.0
    crest_spread: float = 0.6
    crest_count: int = 3
    crest_color: tuple[int, int, int] = (72, 168, 74)
    crest_tip_color: tuple[int, int, int] = (224, 56, 68)
    crest_has_poms: bool = False
    crest_branches: bool = False
    crest_seed: int = 0

    neuro_trait: str = "steady"
    metabolic_trait: str = "balanced"
    reflex_trait: str = "focused"
    strand_loci: tuple[str, ...] = ()
    pure_strand: bool = False
    incomplete_strand_loci: tuple[str, ...] = ()

    # Continuous body plan. 0 and 1 reproduce the old quadruped and upright bodies.
    erectness: float = 0.0   # horizontal spine → vertical spine
    grasp: float = 0.0       # weight-bearing forelimb → free arm
    humanity: float = 0.0    # equine muzzle and coat → human face and skin
    lagomorph: float = 0.0   # horse build → small, long-eared, saltatory build
    gait_weight: float = 1.0
    head_center: float = 0.0  # muzzle stuck forward → head centered on the neck
    diet: str = "herbivore"
    diet_score: float = 0.0
    osteoderm_amp: float = 0.0
    osteoderm_freq: float = 0.0
    osteoderm_color: tuple[int, int, int] = (120, 92, 64)
    flex_leg: float = 0.5
    flex_neck: float = 0.5
    flex_arm: float = 0.5
    flex_tail: float = 0.5
    joint_looseness: float = 0.0
    lifespan_penalty: int = 0
    spasm: float = 0.0
    lethal_white: bool = False
    sentience: float = 0.0
    eye_lid: str = "open"
    teeth_style: str = "rectangular"
    upper_teeth: bool = True
    lower_teeth: bool = True
    bite: float = 0.0

    head_style: str = "default"
    ear_carriage: float = 0.0
    eye_gaze: float = 0.0
    eye_brow: float = 0.0
    wing_scallop: float = 0.0
    horn_twist: float = 0.0
    crest_pom_scale: float = 1.0
    crest_pom_style: str = "round"
    crest_pendants: int = 0
    ornament_enabled: bool = False
    ornament_style: str = "beads"
    ornament_count: int = 0
    ornament_size: float = 0.0
    rotary_front: float = 0.0
    rotary_back: float = 0.0
    rotary_mid: float = 0.0
    response_strength: float = 1.0
    response_damping: float = 1.0
    head_pitch_deg: float = 0.0
    neck_carriage_deg: float = 0.0


# --- PIGMENTATION & COAT PALETTE ENGINE ---

# Base equine coat anchors (name, coat, back_leg, tail, hoof_f, hoof_b)
CLASSIC_COAT_ANCHORS: tuple[
    tuple[str, tuple[int, int, int], tuple[int, int, int], tuple[int, int, int], tuple[int, int, int], tuple[int, int, int]],
    ...,
] = (
    ("Bay", (178, 98, 44), (138, 72, 32), (38, 28, 24), (38, 32, 30), (30, 25, 24)),
    ("Chestnut", (196, 108, 48), (165, 88, 38), (146, 72, 30), (54, 45, 39), (44, 36, 32)),
    ("Sorrel", (206, 128, 56), (176, 106, 44), (222, 192, 134), (82, 70, 58), (70, 58, 48)),
    ("Palomino", (218, 168, 80), (190, 144, 66), (242, 234, 210), (126, 112, 92), (112, 98, 80)),
    ("Buckskin", (204, 152, 74), (162, 116, 52), (42, 34, 30), (40, 34, 32), (32, 28, 26)),
    ("Dun", (184, 148, 102), (154, 120, 82), (68, 54, 42), (48, 42, 38), (40, 34, 30)),
    ("Black", (46, 44, 50), (34, 32, 38), (26, 24, 28), (28, 26, 28), (22, 20, 22)),
    ("Silver Grey", (176, 178, 184), (148, 150, 156), (118, 120, 128), (74, 72, 76), (62, 60, 64)),
    ("Chocolate", (102, 64, 44), (80, 50, 34), (48, 32, 24), (36, 30, 28), (28, 24, 22)),
    ("Cremello", (232, 222, 200), (206, 194, 172), (218, 206, 182), (148, 134, 112), (134, 120, 100)),
    ("Red Roan", (176, 116, 94), (146, 94, 76), (92, 54, 44), (48, 40, 36), (38, 32, 30)),
)

EYE_PUPIL_ANCHORS: tuple[tuple[int, int, int], ...] = (
    (52, 38, 28),
    (68, 78, 122),
    (92, 62, 34),
    (56, 118, 74),
    (88, 128, 186),
)

HUMAN_SKIN_STOPS: tuple[tuple[int, int, int], ...] = (
    (248, 222, 202),
    (236, 194, 154),
    (214, 162, 116),
    (174, 118, 76),
    (124, 78, 48),
    (76, 48, 34),
)


def _rgb_clamp(rgb: Iterable[float]) -> tuple[int, int, int]:
    r, g, b = rgb
    return (int(_clamp(round(r), 10, 252)), int(_clamp(round(g), 10, 252)), int(_clamp(round(b), 10, 252)))


def _rgb_lerp(c1: tuple[int, int, int], c2: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    return _rgb_clamp((_lerp(c1[0], c2[0], t), _lerp(c1[1], c2[1], t), _lerp(c1[2], c2[2], t)))


def _rgb_shift(c: tuple[int, int, int], dr: float, dg: float, db: float) -> tuple[int, int, int]:
    return _rgb_clamp((c[0] + dr, c[1] + dg, c[2] + db))


def _luminance(rgb: tuple[int, int, int]) -> float:
    return 0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2]


def _chroma_rgb(hue_val: float, sat_val: float, val_val: float) -> tuple[int, int, int]:
    """Maps continuous [0,1] gene values to saturated RGB pigment (green, red, gold, cyan, etc.)."""
    h = hue_val % 1.0
    s = _lerp(0.55, 0.96, _clamp(sat_val, 0.0, 1.0))
    v = _lerp(0.62, 0.96, _clamp(val_val, 0.0, 1.0))
    r, g, b = colorsys.hsv_to_rgb(h, s, v)
    return _rgb_clamp((r * 255.0, g * 255.0, b * 255.0))


def _resolve_human_skin_color(
    g_base: GeneExpression,
    g_dilute: GeneExpression,
) -> tuple[int, int, int]:
    melanin = _clamp(g_base.primary * 0.72 + (1.0 - g_dilute.primary) * 0.28, 0.0, 1.0)
    scaled = melanin * (len(HUMAN_SKIN_STOPS) - 1)
    idx = min(len(HUMAN_SKIN_STOPS) - 2, int(scaled))
    frac = scaled - idx
    base = _rgb_lerp(HUMAN_SKIN_STOPS[idx], HUMAN_SKIN_STOPS[idx + 1], frac)
    warmth = (g_base.secondary - 0.5) * 20.0
    olive = (g_dilute.secondary - 0.5) * 14.0
    return _rgb_shift(base, warmth, warmth * 0.45 + olive, -olive * 0.6)


def _resolve_coat_colors(
    g_base: GeneExpression,
    g_dilute: GeneExpression,
    g_tail_pig: GeneExpression,
    g_mut: GeneExpression,
    g_iris: GeneExpression,
    allow_het_exotic: bool = False,
) -> tuple[
    str,
    str | None,
    tuple[int, int, int],
    tuple[int, int, int],
    tuple[int, int, int],
    tuple[int, int, int],
    tuple[int, int, int],
    tuple[int, int, int],
    tuple[int, int, int] | None,
    tuple[int, int, int] | None,
]:
    """
    Epistatic pigment cascade:
    1. `pigment_base` x `pigment_dilute` -> classic equine base coat
    2. `tail_pigment` modulates mane/tail/hoof divergence
    3. `color_mutator` can trigger rare exotic mutations (dominant or recessive)
    Returns (coat_name, color_mutation, coat, back_leg, tail, hoof_f, hoof_b, nose, ear_override, head_override)
    """
    # Base locus selects eumelanin/pheomelanin continuum
    e_axis = g_base.primary  # 0=black/chocolate, 0.45=bay, 0.72=chestnut, 1.0=sorrel
    depth = g_base.secondary
    dilute = g_dilute.primary
    roan_grey = g_dilute.secondary

    if roan_grey > 0.80 and dilute > 0.30:
        idx = 7  # Silver Grey
    elif dilute > 0.84 and e_axis > 0.35:
        idx = 9  # Cremello
    elif roan_grey > 0.66 and e_axis > 0.38:
        idx = 10  # Red Roan
    elif e_axis < 0.14:
        idx = 6  # Black
    elif e_axis < 0.26:
        idx = 8  # Chocolate
    elif dilute > 0.64:
        idx = 3 if e_axis > 0.56 else 4  # Palomino / Buckskin
    elif dilute > 0.45 and e_axis < 0.55:
        idx = 5  # Dun
    elif e_axis > 0.78:
        idx = 2  # Sorrel
    elif e_axis > 0.52:
        idx = 1  # Chestnut
    else:
        idx = 0  # Bay

    coat_name, coat, back_leg, tail_col, hoof_f, hoof_b = CLASSIC_COAT_ANCHORS[idx]

    # Continuous nucleotide-driven tint variation around the classic anchor
    shift_r = (g_base.tertiary - 0.5) * 22.0 + (depth - 0.5) * 14.0
    shift_g = (g_base.utr_val - 0.5) * 18.0 + (depth - 0.5) * 12.0
    shift_b = (g_dilute.tertiary - 0.5) * 16.0
    coat = _rgb_shift(coat, shift_r, shift_g, shift_b)
    back_leg = _rgb_shift(back_leg, shift_r * 0.8, shift_g * 0.8, shift_b * 0.8)

    # Tail & hoof modulation from tail_pigment interacting with pigment_dilute
    if g_tail_pig.primary > 0.82 and dilute > 0.4:
        tail_col = _rgb_lerp(tail_col, (238, 228, 204), 0.55)
    elif g_tail_pig.primary < 0.16:
        tail_col = _rgb_lerp(tail_col, (26, 22, 22), 0.55)
    else:
        tail_col = _rgb_shift(tail_col, (g_tail_pig.secondary - 0.5) * 18.0, (g_tail_pig.tertiary - 0.5) * 16.0, 0.0)

    hoof_f = _rgb_shift(hoof_f, (g_tail_pig.tertiary - 0.5) * 14.0, (g_tail_pig.tertiary - 0.5) * 12.0, 0.0)
    hoof_b = _rgb_shift(hoof_b, (g_tail_pig.tertiary - 0.5) * 12.0, (g_tail_pig.tertiary - 0.5) * 10.0, 0.0)
    nose_col = _rgb_shift((24, 22, 24), (g_tail_pig.secondary - 0.5) * 12.0, (g_tail_pig.primary - 0.5) * 10.0, 0.0)

    ear_override: tuple[int, int, int] | None = None
    head_override: tuple[int, int, int] | None = None
    color_mutation: str | None = None

    # Check rare color_mutator motifs & epistatic knockouts
    mut_type: str | None = None
    for m in g_mut.homozygous_exotic:
        mut_type = m
        break
    if mut_type is None:
        for m in g_mut.any_exotic:
            if allow_het_exotic or (m in DOMINANT_EXOTIC_COLORS):
                mut_type = m
                break
    # Recessive tyrosinase knockout (color_mutator null + dilute extreme)
    if mut_type is None and (not g_mut.active) and g_dilute.primary > 0.7:
        mut_type = "Albino"
    # Epistatic compound pigment shift (homozygous TTAA + CGCG + high iris chroma)
    if mut_type is None and ("TTAA" in g_mut.shared_motifs and "CGCG" in g_mut.any_motifs):
        mut_type = "Cobalt" if g_iris.primary > 0.5 else "Crimson"

    if mut_type == "Albino":
        coat_name = "Albino"
        color_mutation = "Albino"
        coat = _rgb_shift((246, 242, 236), (g_base.primary - 0.5) * 6, (g_base.secondary - 0.5) * 6, 0)
        back_leg = _rgb_shift((226, 220, 214), 0, 0, 0)
        tail_col = (250, 248, 244)
        hoof_f = (206, 188, 178)
        hoof_b = (192, 174, 166)
        nose_col = (232, 166, 172)
    elif mut_type == "Obsidian":
        coat_name = "Obsidian"
        color_mutation = "Melanistic"
        coat = _rgb_shift((28, 26, 34), 0, 0, (g_mut.tertiary - 0.5) * 10)
        back_leg = (18, 17, 24)
        tail_col = (16, 15, 22)
        hoof_f = (18, 18, 22)
        hoof_b = (14, 14, 18)
        nose_col = (16, 16, 20)
    elif mut_type == "Crimson":
        coat_name = "Crimson"
        color_mutation = "Erythristic"
        coat = _rgb_shift((186, 44, 52), (g_base.primary - 0.5) * 20, (g_base.secondary - 0.5) * 14, 0)
        back_leg = _rgb_shift((138, 28, 36), 0, 0, 0)
        tail_col = (236, 122, 46) if g_tail_pig.primary > 0.55 else (82, 18, 26)
        hoof_f = (52, 24, 26)
        hoof_b = (40, 18, 20)
    elif mut_type == "Cobalt":
        coat_name = "Cobalt"
        color_mutation = "Axanthic Blue"
        coat = _rgb_shift((76, 122, 182), (g_base.primary - 0.5) * 14, (g_base.secondary - 0.5) * 18, (g_mut.tertiary - 0.5) * 18)
        back_leg = (54, 90, 142)
        tail_col = (202, 220, 244) if g_tail_pig.primary > 0.45 else (34, 54, 88)
        hoof_f = (44, 54, 72)
        hoof_b = (34, 42, 58)
    elif mut_type == "Lavender":
        coat_name = "Lavender"
        color_mutation = "Amethyst"
        coat = _rgb_shift((158, 122, 192), (g_base.primary - 0.5) * 14, 0, (g_mut.secondary - 0.5) * 16)
        back_leg = (124, 92, 156)
        tail_col = (228, 208, 244)
        hoof_f = (72, 58, 86)
        hoof_b = (58, 46, 72)
    elif mut_type == "Verdant":
        coat_name = "Verdant"
        color_mutation = "Chlorophyll"
        coat = _rgb_shift((76, 140, 94), (g_base.primary - 0.5) * 14, (g_base.secondary - 0.5) * 18, 0)
        back_leg = (54, 108, 70)
        tail_col = (204, 218, 126) if g_tail_pig.primary > 0.5 else (38, 72, 48)
        hoof_f = (44, 58, 42)
        hoof_b = (34, 46, 32)
    elif mut_type == "Solar":
        coat_name = "Solar"
        color_mutation = "Aureate"
        coat = _rgb_shift((240, 192, 48), 0, (g_base.secondary - 0.5) * 18, 0)
        back_leg = (204, 152, 32)
        tail_col = (252, 242, 180)
        hoof_f = (128, 96, 36)
        hoof_b = (108, 80, 30)
    elif mut_type == "Chimera":
        coat_name = f"Chimera {coat_name}"
        color_mutation = "Chimera"
        alt = _rgb_clamp((248 - coat[0] * 0.65, 215 - coat[1] * 0.45, 240 - coat[2] * 0.55))
        back_leg = alt
        ear_override = alt
        tail_col = _rgb_lerp(alt, (240, 232, 214), 0.35)
        if g_mut.secondary > 0.5:
            head_override = _rgb_lerp(coat, alt, 0.55)

    return coat_name, color_mutation, coat, back_leg, tail_col, hoof_f, hoof_b, nose_col, ear_override, head_override


def _resolve_pattern(
    g_pat: GeneExpression,
    g_pat_col: GeneExpression,
    coat: tuple[int, int, int],
    color_mutation: str | None,
) -> tuple[str, tuple[int, int, int], float, float, int]:
    """Resolves coat pattern style, ink color, density, scale, and deterministic seed."""
    if not g_pat.active:
        return "flat", (242, 236, 224), 0.5, 1.0, 0

    sel = g_pat.primary
    if "ATAC" in g_pat.any_motifs or (sel > 0.88 and "CGCG" in g_pat.any_motifs):
        style = "dappled"
    elif sel < 0.36:
        style = "flat"
    elif sel < 0.61:
        style = "blobs"
    elif sel < 0.85:
        style = "dotted"
    else:
        style = "striped"

    # Also allow rare dappled via utr_code
    if style == "dotted" and g_pat.utr_code % 5 == 0 and g_pat_col.secondary > 0.62:
        style = "dappled"

    lum = _luminance(coat)
    if style == "flat":
        return "flat", (242, 236, 224), 0.5, 1.0, 0

    seed_bytes = hashlib.blake2b(
        (g_pat.readout_a.seq + g_pat.readout_b.seq + g_pat_col.readout_a.seq).encode("ascii"),
        digest_size=4,
    ).digest()
    seed = int.from_bytes(seed_bytes, "big")

    density = _lerp(0.28, 0.92, g_pat.secondary)
    scale = _lerp(0.78, 1.28, g_pat.tertiary)

    # Pattern color interacts with coat luminance & pattern_chrom
    tint = g_pat_col.primary
    if color_mutation == "Albino":
        pcol = _rgb_clamp((228 - tint * 26, 212 - tint * 24, 214 - tint * 20))
    elif color_mutation == "Melanistic":
        pcol = (54, 52, 68) if tint > 0.5 else (14, 14, 18)
    elif style == "blobs":
        if lum < 145:
            pcol = _rgb_shift((240, 236, 226), (tint - 0.5) * 14, (tint - 0.5) * 14, (tint - 0.5) * 14)
        else:
            dark_choices = ((118, 66, 36), (64, 46, 38), (152, 92, 46))
            base_p = dark_choices[int(tint * 2.99)]
            pcol = _rgb_shift(base_p, (g_pat_col.secondary - 0.5) * 20, (g_pat_col.tertiary - 0.5) * 16, 0)
    elif style in ("dotted", "dappled"):
        if lum < 145:
            if tint < 0.7:
                pcol = _rgb_shift((238, 234, 222), (g_pat_col.secondary - 0.5) * 14, 0, 0)
            else:
                pcol = _rgb_clamp((coat[0] * 1.28, coat[1] * 1.28, coat[2] * 1.28))
        else:
            if tint < 0.35:
                pcol = _rgb_shift((88, 60, 44), 0, 0, 0)
            elif tint < 0.70:
                pcol = _rgb_shift((128, 126, 132), 0, 0, 0)
            else:
                pcol = _rgb_clamp((coat[0] * 0.68, coat[1] * 0.68, coat[2] * 0.68))
    else:  # striped
        if lum > 95 and tint < 0.82:
            factor = _lerp(0.52, 0.70, g_pat_col.secondary)
            pcol = _rgb_clamp((coat[0] * factor, coat[1] * factor, coat[2] * factor))
        else:
            pcol = _rgb_shift((226, 218, 202), (g_pat_col.secondary - 0.5) * 16, 0, 0)

    # Rare high-contrast inverted / neon pattern tint if pattern_chrom carries ACGT+TTAA
    if "ACGT" in g_pat_col.shared_motifs and "TTAA" in g_pat_col.any_motifs:
        pcol = _rgb_clamp((255 - coat[0], 230 - coat[1] * 0.5, 240 - coat[2]))

    return style, pcol, density, scale, seed
