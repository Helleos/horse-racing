"""Creature drawing, including nucleotide strand overlays."""
from __future__ import annotations

import math
import random
import pygame
import pymunk

from gene import (
    ALL_LOCI,
    is_strand_complete,
)

from creature_config import (
    PartConfig,
    STRAND_NT_COLORS,
    STRAND_SLOT_BY_LOCUS,
    _draw_rotated_glyph,
)

from creature_parts import draw_poly_shape


def _wing_root(tw: float, th: float, erectness: float, is_back: bool) -> tuple[float, float]:
    """Blend the quadruped and upright wing sockets. The endpoints match the old bodies."""
    e = 0.0 if erectness < 0.0 else (1.0 if erectness > 1.0 else erectness)
    quad = (tw * 0.12 + (-5.0 if is_back else 0.0), -th * 0.22 + (-6.0 if is_back else 0.0))
    upright = (-tw * 0.28 + (-4.0 if is_back else 0.0), -th * 0.22 + (-4.0 if is_back else 0.0))
    return (quad[0] + (upright[0] - quad[0]) * e, quad[1] + (upright[1] - quad[1]) * e)

class CreatureDrawMixin:
    def chew_amount(self) -> float:
        """0 at the start and end of a 1-second bite, 1 at the midpoint (linear open then close)."""
        if self.eat_time <= 0.0:
            return 0.0
        t = 1.0 - max(0.0, min(1.0, self.eat_time))
        if t < 0.5:
            return t * 2.0
        return (1.0 - t) * 2.0

    def mouth_world_pos(self) -> tuple[float, float]:
        head = self.bodies.get("head")
        if head is None:
            torso = self.bodies.get("torso")
            if torso is None:
                return (0.0, 0.0)
            return (torso.position.x, torso.position.y)
        hw, hh = self.config.head.size
        return head.local_to_world((hw * 0.42, hh * 0.18))

    def _color_for(self, part_cfg: PartConfig, default_color: tuple[int, int, int]):
        return part_cfg.color if part_cfg.color is not None else default_color

    def _draw_chewing_jaw(self, screen: pygame.Surface, camera_x: float, color: tuple[int, int, int]):
        """Rotates the lower jaw open and shut linearly around its hinge for the bite."""
        shape = self.shapes.get("lower_jaw")
        if not isinstance(shape, pymunk.Poly):
            return
        body = shape.body
        verts = list(shape.get_vertices())
        if len(verts) < 3:
            return
        hinge_x = min(v.x for v in verts)
        hinge_ys = [v.y for v in verts if v.x <= hinge_x + 3.0]
        hy = sum(hinge_ys) / len(hinge_ys)
        ang = math.radians(34.0 * self.chew_amount())
        ca, sa = math.cos(ang), math.sin(ang)
        pts = []
        for v in verts:
            dx, dy = v.x - hinge_x, v.y - hy
            rx = hinge_x + dx * ca - dy * sa
            ry = hy + dx * sa + dy * ca
            wx, wy = body.local_to_world((rx, ry))
            pts.append((wx - camera_x, wy))
        pygame.draw.polygon(screen, color, pts)

    def _get_torso_surface(self, base_color: tuple[int, int, int]) -> pygame.Surface:
        """Pre-renders the patterned torso onto a cached 2x-supersampled surface."""
        if self._torso_surface is not None:
            return self._torso_surface

        tw, th = self.config.torso.size
        w2 = max(2, int(round(tw * 2.0)))
        h2 = max(2, int(round(th * 2.0)))
        surf = pygame.Surface((w2, h2), pygame.SRCALPHA)
        surf.fill((*base_color, 255))

        pat = self.config.appearance.pattern
        rng = random.Random(pat.seed)
        pcol = pat.color
        density = max(0.05, min(1.0, pat.density))
        pscale = max(0.4, pat.scale)

        if pat.style == "dotted":
            count = int(14 + 32 * density)
            for _ in range(count):
                cx = rng.uniform(w2 * 0.05, w2 * 0.94)
                cy = rng.uniform(h2 * 0.08, h2 * 0.88)
                rx = rng.uniform(3.5, 11.0) * pscale * 2.0
                ry = rx * rng.uniform(0.70, 1.25)
                spot_rect = pygame.Rect(0, 0, max(3, int(rx * 2)), max(3, int(ry * 2)))
                spot_rect.center = (int(cx), int(cy))
                pygame.draw.ellipse(surf, (*pcol, 240), spot_rect)
                if rng.random() < 0.45:
                    fx = cx + rng.uniform(-rx * 1.4, rx * 1.4)
                    fy = cy + rng.uniform(-ry * 1.4, ry * 1.4)
                    fr = max(2, int(rx * 0.45))
                    pygame.draw.circle(surf, (*pcol, 215), (int(fx), int(fy)), fr)

        elif pat.style == "striped":
            count = int(7 + 11 * density)
            step = w2 / max(1, count + 1)
            for i in range(count):
                x_top = step * (i + 1) + rng.uniform(-step * 0.28, step * 0.28)
                stripe_w = rng.uniform(4.5, 10.5) * pscale * 2.0
                depth = h2 * rng.uniform(0.55, 0.96)
                sway = rng.uniform(-12.0, 12.0) * pscale
                pts = [
                    (x_top - stripe_w * 0.55, 0.0),
                    (x_top + stripe_w * 0.55, 0.0),
                    (x_top + sway + stripe_w * 0.40, depth * 0.52),
                    (x_top + sway * 1.35 + stripe_w * 0.08, depth),
                    (x_top + sway * 1.35 - stripe_w * 0.08, depth),
                    (x_top + sway - stripe_w * 0.40, depth * 0.52),
                ]
                pygame.draw.polygon(surf, (*pcol, 225), pts)

        elif pat.style == "dappled":
            count = int(12 + 22 * density)
            for _ in range(count):
                cx = rng.uniform(w2 * 0.06, w2 * 0.94)
                cy = rng.uniform(h2 * 0.10, h2 * 0.88)
                rx = rng.uniform(7.0, 16.0) * pscale * 2.0
                ry = rx * rng.uniform(0.75, 1.15)
                outer = pygame.Rect(0, 0, max(5, int(rx * 2)), max(5, int(ry * 2)))
                outer.center = (int(cx), int(cy))
                pygame.draw.ellipse(surf, (*pcol, 155), outer)
                inner = pygame.Rect(0, 0, max(3, int(rx * 1.15)), max(3, int(ry * 1.15)))
                inner.center = (int(cx), int(cy))
                pygame.draw.ellipse(surf, (*base_color, 185), inner)

        elif pat.style == "blobs":
            count = int(2 + 4 * density)
            for _ in range(count):
                edge_bias = rng.choice(["top", "bottom", "mid"])
                cx = rng.uniform(w2 * 0.10, w2 * 0.90)
                if edge_bias == "top":
                    cy = rng.uniform(h2 * 0.02, h2 * 0.35)
                elif edge_bias == "bottom":
                    cy = rng.uniform(h2 * 0.65, h2 * 0.98)
                else:
                    cy = rng.uniform(h2 * 0.25, h2 * 0.75)

                lobes = rng.randint(5, 9)
                for _ in range(lobes):
                    lx = cx + rng.uniform(-32.0, 32.0) * pscale
                    ly = cy + rng.uniform(-22.0, 22.0) * pscale
                    rx = rng.uniform(14.0, 34.0) * pscale
                    ry = rx * rng.uniform(0.65, 1.30)
                    r = pygame.Rect(0, 0, int(rx * 2), int(ry * 2))
                    r.center = (int(lx), int(ly))
                    pygame.draw.ellipse(surf, (*pcol, 248), r)

        t_style = self.config.torso.shape_style
        if t_style in ("rounded", "tapered", "blob"):
            mask_surf = pygame.Surface((w2, h2), pygame.SRCALPHA)
            if t_style == "rounded":
                pygame.draw.rect(
                    mask_surf,
                    (255, 255, 255, 255),
                    (0, 0, w2, h2),
                    border_radius=max(4, int(min(w2, h2) * 0.36)),
                )
            elif t_style == "tapered":
                cap_r = max(4, int(w2 * 0.42))
                pygame.draw.ellipse(mask_surf, (255, 255, 255, 255), (int(w2 * 0.06), 0, int(w2 * 0.88), cap_r * 2))
                poly_pts = [
                    (w2 * 0.06, cap_r),
                    (w2 * 0.94, cap_r),
                    (w2 * 0.72, h2 - cap_r * 0.45),
                    (w2 * 0.50, h2),
                    (w2 * 0.28, h2 - cap_r * 0.45),
                ]
                pygame.draw.polygon(mask_surf, (255, 255, 255, 255), poly_pts)
            else:  # "blob" (organic yeast-like budding contour)
                rng_b = random.Random(self.config.contour_seed + 17)
                pygame.draw.ellipse(
                    mask_surf,
                    (255, 255, 255, 255),
                    (int(w2 * 0.12), int(h2 * 0.12), max(4, int(w2 * 0.76)), max(4, int(h2 * 0.76))),
                )
                for _ in range(5):
                    ang_b = rng_b.uniform(0.0, 2.0 * math.pi)
                    lx = w2 * 0.5 + math.cos(ang_b) * w2 * rng_b.uniform(0.14, 0.26)
                    ly = h2 * 0.5 + math.sin(ang_b) * h2 * rng_b.uniform(0.14, 0.26)
                    lrx = w2 * rng_b.uniform(0.22, 0.34)
                    lry = h2 * rng_b.uniform(0.22, 0.34)
                    r_b = pygame.Rect(0, 0, max(4, int(lrx * 2)), max(4, int(lry * 2)))
                    r_b.center = (int(lx), int(ly))
                    pygame.draw.ellipse(mask_surf, (255, 255, 255, 255), r_b)
            surf.blit(mask_surf, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)

        target_size = (max(1, int(round(tw))), max(1, int(round(th))))
        self._torso_surface = pygame.transform.smoothscale(surf, target_size)
        return self._torso_surface

    def _draw_wing(
        self,
        screen: pygame.Surface,
        camera_x: float,
        is_back: bool,
    ):
        wing = self.config.wing
        if not wing.enabled or "torso" not in self.bodies:
            return
        tbody = self.bodies["torso"]
        tw, th = self.config.torso.size
        root = _wing_root(tw, th, self.config.erectness, is_back)

        ang = math.radians(self.wing_angle_deg + (12.0 if is_back else 0.0))
        ca, sa = math.cos(ang), math.sin(ang)
        span = wing.span * (0.94 if is_back else 1.0)
        chord = wing.chord * (0.94 if is_back else 1.0)

        def to_screen(lx: float, ly: float) -> tuple[float, float]:
            rx = root[0] + lx * ca - ly * sa
            ry = root[1] + lx * sa + ly * ca
            wx, wy = tbody.local_to_world((rx, ry))
            return (wx - camera_x, wy)

        col = tuple(max(10, int(c * (0.76 if is_back else 1.0))) for c in wing.color)
        sec_col = tuple(max(10, int(c * (0.76 if is_back else 1.0))) for c in wing.secondary_color)

        if wing.style == "leathery":
            pts = [
                to_screen(0.0, 0.0),
                to_screen(-span * 0.48, -chord * 0.42),
                to_screen(-span, -chord * 0.12),
                to_screen(-span * 0.78, chord * 0.62),
                to_screen(-span * 0.46, chord * 0.44),
                to_screen(-span * 0.18, chord * 0.56),
            ]
            pygame.draw.polygon(screen, col, pts)
            pygame.draw.polygon(screen, sec_col, pts, 2)
            elbow = to_screen(-span * 0.48, -chord * 0.42)
            for tip in (pts[2], pts[3], pts[4], pts[5]):
                pygame.draw.line(screen, sec_col, elbow, tip, 2)
        elif wing.style == "swept":
            pts = [
                to_screen(0.0, 0.0),
                to_screen(-span * 0.42, -chord * 0.36),
                to_screen(-span * 1.06, -chord * 0.18),
                to_screen(-span * 0.64, chord * 0.46),
                to_screen(-span * 0.18, chord * 0.38),
            ]
            pygame.draw.polygon(screen, col, pts)
            inner = [
                to_screen(0.0, 0.0),
                to_screen(-span * 0.38, -chord * 0.24),
                to_screen(-span * 0.72, chord * 0.08),
                to_screen(-span * 0.20, chord * 0.26),
            ]
            pygame.draw.polygon(screen, sec_col, inner)
        elif wing.style == "rounded":
            pts = [
                to_screen(0.0, 0.0),
                to_screen(-span * 0.35, -chord * 0.38),
                to_screen(-span * 0.82, -chord * 0.26),
                to_screen(-span * 0.96, chord * 0.18),
                to_screen(-span * 0.72, chord * 0.64),
                to_screen(-span * 0.34, chord * 0.68),
                to_screen(-span * 0.08, chord * 0.42),
            ]
            pygame.draw.polygon(screen, col, pts)
            inner = [
                to_screen(0.0, 0.0),
                to_screen(-span * 0.30, -chord * 0.22),
                to_screen(-span * 0.62, chord * 0.12),
                to_screen(-span * 0.18, chord * 0.34),
            ]
            pygame.draw.polygon(screen, sec_col, inner)
        else:  # "feathery"
            pts = [
                to_screen(0.0, 0.0),
                to_screen(-span * 0.40, -chord * 0.34),
                to_screen(-span, -chord * 0.08),
                to_screen(-span * 0.82, chord * 0.30),
                to_screen(-span * 0.56, chord * 0.54),
                to_screen(-span * 0.26, chord * 0.58),
                to_screen(-span * 0.06, chord * 0.34),
            ]
            pygame.draw.polygon(screen, col, pts)
            for i in range(4):
                t0 = 0.25 + i * 0.19
                p_tip = to_screen(-span * t0, chord * (0.58 - i * 0.08))
                p_root = to_screen(-span * (t0 - 0.14), chord * 0.12)
                pygame.draw.line(screen, sec_col, p_root, p_tip, 2)

    def _draw_horns(self, screen: pygame.Surface, camera_x: float):
        horn = self.config.horn
        if not horn.enabled or "head" not in self.bodies:
            return
        head = self.bodies["head"]
        hw, hh = self.config.head.size
        base = (hw * 0.12, -hh * 0.44)

        def to_screen(lx: float, ly: float) -> tuple[float, float]:
            wx, wy = head.local_to_world((base[0] + lx, base[1] + ly))
            return (wx - camera_x, wy)

        length = horn.length
        thick = horn.thickness

        if horn.kind in ("small_antlers", "branching_antlers"):
            rng_ant = random.Random(horn.seed)
            for is_back in (True, False):
                b_col = (
                    tuple(max(15, int(c * 0.74)) for c in horn.color)
                    if is_back
                    else horn.color
                )
                t_col = (
                    tuple(max(15, int(c * 0.74)) for c in horn.tip_color)
                    if is_back
                    else horn.tip_color
                )
                shift_x = -4.0 if is_back else 0.0
                shift_y = -2.0 if is_back else 0.0
                beam_ang = math.radians(-106.0 + (18.0 if is_back else 6.0) + rng_ant.uniform(-10.0, 10.0))
                bx, by = shift_x, shift_y
                segs = 4 if horn.kind == "branching_antlers" else 3
                seg_len = length / segs
                cur_ang = beam_ang
                for s in range(segs):
                    cur_ang += math.radians(rng_ant.uniform(-14.0, 18.0) * horn.spread)
                    nx = bx + math.cos(cur_ang) * seg_len
                    ny = by + math.sin(cur_ang) * seg_len
                    w_seg = max(2, int(round(thick * (1.0 - 0.55 * (s / segs)))))
                    pygame.draw.line(screen, b_col, to_screen(bx, by), to_screen(nx, ny), w_seg)
                    if s < horn.tines:
                        fork_dir = 1.0 if (s % 2 == 0) else -1.0
                        f_ang = cur_ang + fork_dir * math.radians(rng_ant.uniform(28.0, 52.0) * (0.7 + 0.5 * horn.spread))
                        f_len = seg_len * rng_ant.uniform(0.68, 1.15)
                        fx = nx + math.cos(f_ang) * f_len
                        fy = ny + math.sin(f_ang) * f_len
                        pygame.draw.line(screen, t_col, to_screen(nx, ny), to_screen(fx, fy), max(2, w_seg - 1))
                    bx, by = nx, ny
            return

        if horn.kind == "curved":
            steps = 6
            pts_l: list[tuple[float, float]] = []
            pts_r: list[tuple[float, float]] = []
            for i in range(steps + 1):
                t = i / steps
                cx = t * (length * 0.35 * horn.curve) + (t * t) * (-length * 0.55)
                cy = -t * length + (t * t) * (length * 0.18)
                half_w = max(0.8, thick * 0.5 * (1.0 - 0.85 * t))
                pts_l.append(to_screen(cx - half_w, cy))
                pts_r.append(to_screen(cx + half_w, cy))
            poly = pts_l + list(reversed(pts_r))
            pygame.draw.polygon(screen, horn.color, poly)
            pygame.draw.circle(screen, horn.tip_color, pts_l[-1], max(2.0, thick * 0.22))
        elif horn.kind == "dull":
            pts = [
                to_screen(-thick * 0.55, 0.0),
                to_screen(thick * 0.55, 0.0),
                to_screen(thick * 0.38, -length * 0.85),
                to_screen(0.0, -length),
                to_screen(-thick * 0.38, -length * 0.85),
            ]
            pygame.draw.polygon(screen, horn.color, pts)
            pygame.draw.circle(screen, horn.tip_color, to_screen(0.0, -length * 0.88), max(2.2, thick * 0.36))
        elif horn.kind == "pointed":
            lean = length * 0.42
            pts = [
                to_screen(-thick * 0.50, 0.0),
                to_screen(thick * 0.50, 0.0),
                to_screen(lean, -length),
            ]
            pygame.draw.polygon(screen, horn.color, pts)
            tip_pts = [
                to_screen(lean * 0.55 - thick * 0.20, -length * 0.55),
                to_screen(lean * 0.55 + thick * 0.20, -length * 0.55),
                to_screen(lean, -length),
            ]
            pygame.draw.polygon(screen, horn.tip_color, tip_pts)
        else:  # "straight"
            pts = [
                to_screen(-thick * 0.46, 0.0),
                to_screen(thick * 0.46, 0.0),
                to_screen(thick * 0.14, -length),
                to_screen(-thick * 0.14, -length),
            ]
            pygame.draw.polygon(screen, horn.color, pts)
            tip_pts = [
                to_screen(-thick * 0.25, -length * 0.62),
                to_screen(thick * 0.25, -length * 0.62),
                to_screen(thick * 0.14, -length),
                to_screen(-thick * 0.14, -length),
            ]
            pygame.draw.polygon(screen, horn.tip_color, tip_pts)

    def _draw_crest(self, screen: pygame.Surface, camera_x: float):
        crest = self.config.crest
        if not crest.enabled:
            return
        if "head" in self.bodies:
            body = self.bodies["head"]
            bw, bh = self.config.head.size
            top_y = -bh * 0.44
        elif "neck" in self.bodies:
            body = self.bodies["neck"]
            bw, bh = self.config.neck.size
            top_y = -bh * 0.48
        elif "torso" in self.bodies:
            body = self.bodies["torso"]
            bw, bh = self.config.torso.size
            top_y = -bh * 0.48
        else:
            return

        def to_screen(lx: float, ly: float) -> tuple[float, float]:
            wx, wy = body.local_to_world((lx, ly))
            return (wx - camera_x, wy)

        rng_c = random.Random(crest.seed)
        csize = crest.size
        sway = math.sin(self.gait_phase) * 2.5

        if crest.style == "crown_pom":
            half_w = max(bw * 0.72, csize * 0.95)
            peaks = max(2, min(4, crest.count))
            crown_pts: list[tuple[float, float]] = [to_screen(-half_w, top_y + 5.0)]
            peak_locals: list[tuple[float, float]] = []
            for i in range(peaks):
                px = -half_w + (2.0 * half_w) * ((i + 0.5) / peaks)
                py = top_y - csize * (0.85 + 0.25 * (i % 2))
                peak_locals.append((px, py))
                crown_pts.append(to_screen(px, py))
                if i < peaks - 1:
                    vx = -half_w + (2.0 * half_w) * ((i + 1.0) / peaks)
                    crown_pts.append(to_screen(vx, top_y - csize * 0.16))
            crown_pts.append(to_screen(half_w, top_y + 5.0))
            pygame.draw.polygon(screen, crest.color, crown_pts)

            if crest.branches:
                for side_s in (-1.0, 1.0):
                    bx, by = side_s * half_w * 0.58, top_y - csize * 0.28
                    ang = math.radians(-90.0 + side_s * rng_c.uniform(42.0, 68.0))
                    seg_len = csize * 0.78
                    for seg_i in range(2):
                        ang += math.radians(side_s * rng_c.uniform(-28.0, 32.0))
                        nx = bx + math.cos(ang) * seg_len
                        ny = by + math.sin(ang) * seg_len
                        w_line = max(3, int(round(csize * (0.24 - 0.05 * seg_i))))
                        pygame.draw.line(screen, crest.color, to_screen(bx, by), to_screen(nx, ny), w_line)
                        bx, by = nx, ny
                    for fork_s in (-1.0, 1.0):
                        fang = ang + fork_s * math.radians(rng_c.uniform(28.0, 44.0))
                        flen = seg_len * 0.72
                        fx = bx + math.cos(fang) * flen
                        fy = by + math.sin(fang) * flen
                        pygame.draw.line(screen, crest.color, to_screen(bx, by), to_screen(fx, fy), max(2, int(round(csize * 0.15))))
                        if crest.has_poms:
                            pr = max(3.5, csize * 0.24)
                            p_scr = to_screen(fx, fy)
                            pygame.draw.circle(screen, crest.tip_color, p_scr, pr)
                            pygame.draw.circle(screen, crest.tip_color, (p_scr[0] + fork_s * pr * 0.45, p_scr[1] - pr * 0.25), pr * 0.85)

            if crest.has_poms:
                pr_top = max(3.2, csize * 0.20)
                for px, py in peak_locals:
                    pygame.draw.circle(screen, crest.tip_color, to_screen(px, py), pr_top)

        elif crest.style == "spores":
            cnt = max(3, crest.count + 1)
            for i in range(cnt):
                ox = (-0.42 + 0.84 * (i / max(1, cnt - 1))) * bw
                oy = top_y - csize * rng_c.uniform(0.15, 0.55)
                rad = max(3.0, csize * rng_c.uniform(0.24, 0.42))
                pygame.draw.circle(screen, crest.color, to_screen(ox, oy), rad)
                if crest.has_poms:
                    pygame.draw.circle(screen, crest.tip_color, to_screen(ox, oy - rad * 0.45), rad * 0.48)

        elif crest.style == "mane_plume":
            cnt = max(3, crest.count)
            for i in range(cnt):
                bx = (-0.36 + 0.72 * (i / max(1, cnt - 1))) * bw
                h_p = csize * rng_c.uniform(0.75, 1.25)
                pts = [
                    to_screen(bx - 3.5, top_y + 2.0),
                    to_screen(bx + 3.5, top_y + 2.0),
                    to_screen(bx - h_p * 0.45 + sway, top_y - h_p),
                    to_screen(bx - h_p * 0.75 + sway, top_y - h_p * 0.65),
                ]
                pygame.draw.polygon(screen, crest.color, pts)
                if crest.has_poms:
                    pygame.draw.circle(screen, crest.tip_color, pts[2], max(2.5, csize * 0.14))

        else:  # "tuft"
            cnt = max(3, crest.count + 1)
            for i in range(cnt):
                frac = i / max(1, cnt - 1)
                bx = (-0.38 + 0.76 * frac) * max(bw, 16.0)
                lean = (frac - 0.5) * csize * 0.9 * crest.spread + rng_c.uniform(-4.0, 4.0) + sway
                h_t = csize * rng_c.uniform(0.70, 1.35)
                mid_x = bx + lean * 0.45
                mid_y = top_y - h_t * 0.55
                tip_x = bx + lean
                tip_y = top_y - h_t
                hw_b = max(2.2, csize * 0.18)
                pts = [
                    to_screen(bx - hw_b, top_y + 3.0),
                    to_screen(bx + hw_b, top_y + 3.0),
                    to_screen(mid_x + hw_b * 0.55, mid_y),
                    to_screen(tip_x, tip_y),
                    to_screen(mid_x - hw_b * 0.55, mid_y),
                ]
                pygame.draw.polygon(screen, crest.color, pts)
                if crest.has_poms:
                    pygame.draw.circle(screen, crest.tip_color, to_screen(tip_x, tip_y), max(2.4, csize * 0.14))

    def _draw_leg(
        self,
        screen: pygame.Surface,
        leg_name: str,
        color: tuple[int, int, int],
        camera_x: float,
    ):
        if leg_name not in self.shapes:
            return
        draw_poly_shape(screen, self.shapes[leg_name], color, camera_x)
        lower_name = f"{leg_name}_lower"
        if lower_name in self.shapes:
            draw_poly_shape(screen, self.shapes[lower_name], color, camera_x)
        if leg_name in self.knee_caps and leg_name in self.bodies:
            y_knee, knee_r = self.knee_caps[leg_name]
            kx, ky = self.bodies[leg_name].local_to_world((0.0, y_knee))
            pygame.draw.circle(screen, color, (kx - camera_x, ky), knee_r)

    def _record_strand_hitbox(
        self, locus: str, world_pts: list[tuple[float, float]]
    ):
        if len(world_pts) >= 3:
            self.strand_hitboxes.append((locus, world_pts))

    def _draw_strand_segment(
        self,
        screen: pygame.Surface,
        body: pymunk.Body,
        seq: str,
        p_start: tuple[float, float],
        p_end: tuple[float, float],
        width: float,
        camera_x: float,
        locus: str | None = None,
        functional: bool = True,
    ):
        n = len(seq)
        if n <= 0:
            return
        vx = p_end[0] - p_start[0]
        vy = p_end[1] - p_start[1]
        seg_len = max(1e-4, math.hypot(vx, vy))
        ux, uy = vx / seg_len, vy / seg_len
        px, py = -uy, ux
        hw = width * 0.5
        tile_ang = -math.degrees(body.angle + math.atan2(vy, vx)) - 90.0
        tile_len = seg_len / n

        if locus is not None:
            hb_local = [
                (p_start[0] + px * hw, p_start[1] + py * hw),
                (p_end[0] + px * hw, p_end[1] + py * hw),
                (p_end[0] - px * hw, p_end[1] - py * hw),
                (p_start[0] - px * hw, p_start[1] - py * hw),
            ]
            self._record_strand_hitbox(
                locus, [body.local_to_world(p) for p in hb_local]
            )

        for i, base in enumerate(seq):
            t0 = i / n
            t1 = (i + 1) / n
            ax = p_start[0] + vx * t0
            ay = p_start[1] + vy * t0
            bx = p_start[0] + vx * t1
            by = p_start[1] + vy * t1
            local_pts = [
                (ax + px * hw, ay + py * hw),
                (bx + px * hw, by + py * hw),
                (bx - px * hw, by - py * hw),
                (ax - px * hw, ay - py * hw),
            ]
            world_pts = []
            for lx, ly in local_pts:
                wx, wy = body.local_to_world((lx, ly))
                world_pts.append((wx - camera_x, wy))
            if base in STRAND_NT_COLORS:
                col = STRAND_NT_COLORS[base]
                if not functional:
                    col = (max(20, int(col[0] * 0.58)), max(20, int(col[1] * 0.52)), max(20, int(col[2] * 0.58)))
                border = (22, 18, 28) if functional else (142, 62, 72)
                pygame.draw.polygon(screen, col, world_pts)
                pygame.draw.polygon(screen, border, world_pts, 1)
            else:
                pygame.draw.polygon(screen, (26, 22, 34), world_pts)
                pygame.draw.polygon(screen, (186, 72, 84), world_pts, 1)

            if min(width, tile_len) >= 4.2:
                mx, my = body.local_to_world(((ax + bx) * 0.5, (ay + by) * 0.5))
                _draw_rotated_glyph(
                    screen,
                    base,
                    max(6, int(round(min(width, tile_len * 1.15) * 0.85))),
                    (252, 252, 255) if base in STRAND_NT_COLORS else (210, 118, 128),
                    (mx - camera_x, my),
                    tile_ang,
                )

    def _draw_double_strand_line(
        self,
        screen: pygame.Surface,
        body: pymunk.Body,
        seq_a: str,
        seq_b: str,
        p_start: tuple[float, float],
        p_end: tuple[float, float],
        width: float,
        camera_x: float,
        locus: str,
        functional: bool = True,
        show_badge: bool = False,
    ):
        vx = p_end[0] - p_start[0]
        vy = p_end[1] - p_start[1]
        seg_len = max(1e-4, math.hypot(vx, vy))
        px, py = -vy / seg_len, vx / seg_len
        off = width * 0.27
        sub_w = max(3.6, width * 0.48)
        self._draw_strand_segment(
            screen,
            body,
            seq_a,
            (p_start[0] - px * off, p_start[1] - py * off),
            (p_end[0] - px * off, p_end[1] - py * off),
            sub_w,
            camera_x,
            locus=locus,
            functional=functional,
        )
        self._draw_strand_segment(
            screen,
            body,
            seq_b,
            (p_start[0] + px * off, p_start[1] + py * off),
            (p_end[0] + px * off, p_end[1] + py * off),
            sub_w,
            camera_x,
            locus=locus,
            functional=functional,
        )
        if show_badge:
            mx, my = body.local_to_world(((p_start[0] + p_end[0]) * 0.5, (p_start[1] + p_end[1]) * 0.5))
            num = ALL_LOCI.index(locus) + 1
            pygame.draw.circle(screen, (14, 14, 22), (int(mx - camera_x), int(my)), 8)
            pygame.draw.circle(
                screen,
                (198, 132, 248) if functional else (216, 78, 86),
                (int(mx - camera_x), int(my)),
                8,
                1,
            )
            _draw_rotated_glyph(
                screen,
                str(num),
                10,
                (224, 180, 255) if functional else (238, 128, 134),
                (mx - camera_x, my),
                0.0,
            )

    def _draw_strand_leg(
        self,
        screen: pygame.Surface,
        leg_name: str,
        leg_cfg: PartConfig,
        locus: str,
        camera_x: float,
    ):
        body = self.bodies.get(leg_name)
        if body is None:
            return
        seq_a, seq_b = self._locus_alleles(locus)
        func = self._is_locus_functional(locus)
        lw, lh = leg_cfg.size
        knee_ratio = max(0.25, min(0.75, leg_cfg.knee_ratio))
        upper_h = lh * knee_ratio
        lower_h = lh - upper_h
        y_top = -lh * 0.5
        y_knee = y_top + upper_h
        knee_rad = math.radians(max(-15.0, min(15.0, leg_cfg.knee_deg)))
        foot_tip = (math.sin(knee_rad) * lower_h, y_knee + math.cos(knee_rad) * lower_h)
        mid_a = max(1, len(seq_a) // 2)
        mid_b = max(1, len(seq_b) // 2)
        self._draw_double_strand_line(
            screen, body, seq_a[:mid_a], seq_b[:mid_b], (0.0, y_top), (0.0, y_knee), max(10.0, lw), camera_x, locus, func, show_badge=False
        )
        self._draw_double_strand_line(
            screen, body, seq_a[mid_a:], seq_b[mid_b:], (0.0, y_knee), foot_tip, max(9.0, lw * leg_cfg.lower_width_scale), camera_x, locus, func, show_badge=False
        )
        kx, ky = body.local_to_world((0.0, y_knee))
        num = ALL_LOCI.index(locus) + 1
        pygame.draw.circle(screen, (16, 16, 24), (int(kx - camera_x), int(ky)), 8)
        pygame.draw.circle(screen, (198, 132, 248) if func else (216, 78, 86), (int(kx - camera_x), int(ky)), 8, 1)
        _draw_rotated_glyph(screen, str(num), 10, (224, 180, 255) if func else (238, 128, 134), (kx - camera_x, ky), 0.0)

    def _draw_strand_poly_part(
        self,
        screen: pygame.Surface,
        shape_name: str,
        locus: str,
        camera_x: float,
        show_badge: bool = False,
    ):
        shape = self.shapes.get(shape_name)
        if not isinstance(shape, pymunk.Poly):
            return
        body = shape.body
        verts = list(shape.get_vertices())
        if len(verts) < 3:
            return
        seq_a, seq_b = self._locus_alleles(locus)
        func = self._is_locus_functional(locus)
        world_verts = [body.local_to_world(v) for v in verts]
        screen_pts = [(wx - camera_x, wy) for wx, wy in world_verts]
        pygame.draw.polygon(screen, (18, 18, 26), screen_pts)
        pygame.draw.polygon(screen, (186, 124, 244) if func else (206, 74, 84), screen_pts, 2)
        self._record_strand_hitbox(locus, world_verts)

        xs = [v.x for v in verts]
        ys = [v.y for v in verts]
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        cx, cy = (min_x + max_x) * 0.5, (min_y + max_y) * 0.5
        span_x = max_x - min_x
        span_y = max_y - min_y
        if span_x >= span_y:
            p0, p1 = (min_x + 2.0, cy), (max_x - 2.0, cy)
            w_strip = max(6.0, min(18.0, span_y * 0.65))
        else:
            p0, p1 = (cx, min_y + 2.0), (cx, max_y - 2.0)
            w_strip = max(6.0, min(18.0, span_x * 0.65))
        self._draw_double_strand_line(
            screen, body, seq_a, seq_b, p0, p1, w_strip, camera_x, locus, func, show_badge=show_badge
        )

    def _draw_strand_overlay_part(
        self,
        screen: pygame.Surface,
        shape_name: str,
        base_color: tuple[int, int, int],
        locus: str,
        camera_x: float,
        show_badge: bool = False,
        draw_base: bool = True,
    ):
        shape = self.shapes.get(shape_name)
        if not isinstance(shape, pymunk.Poly):
            return
        if draw_base:
            draw_poly_shape(screen, shape, base_color, camera_x)
        body = shape.body
        verts = list(shape.get_vertices())
        if len(verts) < 3:
            return
        seq_a, seq_b = self._locus_alleles(locus)
        func = self._is_locus_functional(locus)
        world_verts = [body.local_to_world(v) for v in verts]
        self._record_strand_hitbox(locus, world_verts)
        xs = [v.x for v in verts]
        ys = [v.y for v in verts]
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        cx, cy = (min_x + max_x) * 0.5, (min_y + max_y) * 0.5
        span_x = max_x - min_x
        span_y = max_y - min_y
        if span_x >= span_y:
            p0, p1 = (min_x + 2.0, cy), (max_x - 2.0, cy)
            w_strip = max(5.2, min(11.0, span_y * 0.42))
        else:
            p0, p1 = (cx, min_y + 2.0), (cx, max_y - 2.0)
            w_strip = max(5.2, min(11.0, span_x * 0.42))
        self._draw_double_strand_line(
            screen, body, seq_a, seq_b, p0, p1, w_strip, camera_x, locus, func, show_badge=show_badge
        )

    def _draw_strand_torso_band(
        self,
        screen: pygame.Surface,
        camera_x: float,
        locus: str,
        band_idx: int = 0,
        total_bands: int = 1,
    ):
        tbody = self.bodies.get("torso")
        if tbody is None:
            return
        tw, th = self.config.torso.size
        seq_a, seq_b = self._locus_alleles(locus)
        func = self._is_locus_functional(locus)
        if total_bands <= 1:
            y_off = -th * 0.16
        else:
            step = min(14.0, (th * 0.56) / max(1, total_bands - 1))
            y_off = -th * 0.28 + band_idx * step
        p0 = (-tw * 0.44, y_off)
        p1 = (tw * 0.44, y_off)
        self._draw_double_strand_line(
            screen, tbody, seq_a, seq_b, p0, p1, 9.5, camera_x, locus, func, show_badge=True
        )

    def _draw_strand_hoof(
        self,
        screen: pygame.Surface,
        shape_name: str,
        base_color: tuple[int, int, int],
        locus: str,
        camera_x: float,
    ):
        shape = self.shapes.get(shape_name)
        if not isinstance(shape, pymunk.Poly):
            return
        draw_poly_shape(screen, shape, base_color, camera_x)
        body = shape.body
        verts = list(shape.get_vertices())
        if len(verts) < 3:
            return
        seq_a, seq_b = self._locus_alleles(locus)
        func = self._is_locus_functional(locus)
        world_verts = [body.local_to_world(v) for v in verts]
        self._record_strand_hitbox(locus, world_verts)
        xs = [v.x for v in verts]
        ys = [v.y for v in verts]
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        mid_y = (min_y + max_y) * 0.5
        self._draw_double_strand_line(
            screen,
            body,
            seq_a[::2],
            seq_b[::2],
            (min_x + 1.5, mid_y),
            (max_x - 1.5, mid_y),
            max(4.8, (max_y - min_y) * 0.52),
            camera_x,
            locus,
            func,
            show_badge=False,
        )

    def _draw_strand_tail(
        self,
        screen: pygame.Surface,
        locus: str,
        camera_x: float,
    ):
        shape = self.shapes.get("tail")
        if not isinstance(shape, pymunk.Poly):
            return
        body = shape.body
        seq_a, seq_b = self._locus_alleles(locus)
        func = self._is_locus_functional(locus)
        tw, th = self.config.tail.size
        style = self.config.tail.shape_style
        world_verts = [body.local_to_world(v) for v in shape.get_vertices()]
        screen_pts = [(wx - camera_x, wy) for wx, wy in world_verts]
        pygame.draw.polygon(screen, (20, 18, 28), screen_pts)
        pygame.draw.polygon(screen, (186, 124, 244) if func else (206, 74, 84), screen_pts, 2)
        self._record_strand_hitbox(locus, world_verts)

        if style in ("bushy", "flowing"):
            self._draw_strand_segment(
                screen, body, seq_a, (tw * 0.45, -1.5), (-tw * 0.48, -th * 0.48), 5.8, camera_x, locus=locus, functional=func
            )
            self._draw_strand_segment(
                screen, body, seq_b, (tw * 0.45, 1.5), (-tw * 0.48, th * 0.48), 5.8, camera_x, locus=locus, functional=func
            )
        else:
            self._draw_double_strand_line(
                screen, body, seq_a, seq_b, (tw * 0.45, 0.0), (-tw * 0.48, 0.0), max(6.5, th * 0.72), camera_x, locus, func, show_badge=True
            )

    def _draw_strand_wing(
        self,
        screen: pygame.Surface,
        camera_x: float,
        is_back: bool,
        locus: str,
    ):
        wing = self.config.wing
        if not wing.enabled or "torso" not in self.bodies:
            return
        tbody = self.bodies["torso"]
        tw, th = self.config.torso.size
        root = _wing_root(tw, th, self.config.erectness, is_back)

        seq_a, seq_b = self._locus_alleles(locus)
        func = self._is_locus_functional(locus)
        ang = math.radians(self.wing_angle_deg + (12.0 if is_back else 0.0))
        ca, sa = math.cos(ang), math.sin(ang)
        span = wing.span * (0.94 if is_back else 1.0)
        chord = wing.chord * (0.94 if is_back else 1.0)

        def to_local(lx: float, ly: float) -> tuple[float, float]:
            return (root[0] + lx * ca - ly * sa, root[1] + lx * sa + ly * ca)

        if wing.style == "leathery":
            local_poly = [
                to_local(0.0, 0.0),
                to_local(-span * 0.48, -chord * 0.42),
                to_local(-span, -chord * 0.12),
                to_local(-span * 0.78, chord * 0.62),
                to_local(-span * 0.46, chord * 0.44),
                to_local(-span * 0.18, chord * 0.56),
            ]
            elbow = to_local(-span * 0.48, -chord * 0.42)
            rays = [
                (seq_b[:8], elbow, to_local(-span * 0.78, chord * 0.62)),
                (seq_b[8:16], elbow, to_local(-span * 0.46, chord * 0.44)),
                (seq_b[16:24], elbow, to_local(-span * 0.18, chord * 0.56)),
            ]
        elif wing.style == "swept":
            local_poly = [
                to_local(0.0, 0.0),
                to_local(-span * 0.42, -chord * 0.36),
                to_local(-span * 1.06, -chord * 0.18),
                to_local(-span * 0.64, chord * 0.46),
                to_local(-span * 0.18, chord * 0.38),
            ]
            rays = [
                (seq_b[:8], to_local(-span * 0.24, -chord * 0.12), to_local(-span * 0.22, chord * 0.36)),
                (seq_b[8:16], to_local(-span * 0.54, -chord * 0.22), to_local(-span * 0.48, chord * 0.44)),
                (seq_b[16:24], to_local(-span * 0.80, -chord * 0.20), to_local(-span * 0.66, chord * 0.40)),
            ]
        elif wing.style == "rounded":
            local_poly = [
                to_local(0.0, 0.0),
                to_local(-span * 0.35, -chord * 0.38),
                to_local(-span * 0.82, -chord * 0.26),
                to_local(-span * 0.96, chord * 0.18),
                to_local(-span * 0.72, chord * 0.64),
                to_local(-span * 0.34, chord * 0.68),
                to_local(-span * 0.08, chord * 0.42),
            ]
            rays = [
                (seq_b[:8], to_local(-span * 0.20, -chord * 0.08), to_local(-span * 0.32, chord * 0.62)),
                (seq_b[8:16], to_local(-span * 0.48, -chord * 0.16), to_local(-span * 0.66, chord * 0.60)),
                (seq_b[16:24], to_local(-span * 0.74, -chord * 0.14), to_local(-span * 0.90, chord * 0.22)),
            ]
        else:  # "feathery"
            local_poly = [
                to_local(0.0, 0.0),
                to_local(-span * 0.42, -chord * 0.36),
                to_local(-span, -chord * 0.10),
                to_local(-span * 0.72, chord * 0.56),
                to_local(-span * 0.22, chord * 0.52),
            ]
            rays = [
                (seq_b[:8], to_local(-span * 0.22, -chord * 0.08), to_local(-span * 0.24, chord * 0.50)),
                (seq_b[8:16], to_local(-span * 0.52, -chord * 0.14), to_local(-span * 0.58, chord * 0.54)),
                (seq_b[16:24], to_local(-span * 0.78, -chord * 0.12), to_local(-span * 0.84, chord * 0.42)),
            ]

        world_poly = [tbody.local_to_world(p) for p in local_poly]
        self._record_strand_hitbox(locus, world_poly)
        screen_poly = [(wx - camera_x, wy) for wx, wy in world_poly]
        pygame.draw.polygon(screen, (22, 18, 32) if func else (34, 20, 26), screen_poly)
        pygame.draw.polygon(screen, (152, 98, 212) if func else (186, 68, 78), screen_poly, 2)

        spar_tip = to_local(-span * (1.06 if wing.style == "swept" else 0.96), -chord * 0.14)
        self._draw_strand_segment(
            screen, tbody, seq_a, to_local(0.0, 0.0), spar_tip, 7.5, camera_x, locus=locus, functional=func
        )
        for r_seq, rp0, rp1 in rays:
            self._draw_strand_segment(
                screen, tbody, r_seq, rp0, rp1, 6.0, camera_x, locus=locus, functional=func
            )
        if not is_back:
            bx, by = tbody.local_to_world(to_local(-span * 0.45, chord * 0.14))
            num = ALL_LOCI.index(locus) + 1
            pygame.draw.circle(screen, (14, 14, 22), (int(bx - camera_x), int(by)), 8)
            pygame.draw.circle(screen, (198, 132, 248) if func else (216, 78, 86), (int(bx - camera_x), int(by)), 8, 1)
            _draw_rotated_glyph(screen, str(num), 10, (224, 180, 255) if func else (238, 128, 134), (bx - camera_x, by), 0.0)

    def _draw_strand_horn(
        self,
        screen: pygame.Surface,
        camera_x: float,
        locus: str,
    ):
        horn = self.config.horn
        if not horn.enabled:
            return
        if "head" in self.bodies:
            anchor_body = self.bodies["head"]
            hw, hh = self.config.head.size
            base = (hw * 0.12, -hh * 0.44)
        elif "torso" in self.bodies:
            anchor_body = self.bodies["torso"]
            tw, th = self.config.torso.size
            base = (0.0, -th * 0.48)
        else:
            return

        seq_a, seq_b = self._locus_alleles(locus)
        func = self._is_locus_functional(locus)
        length = max(24.0, horn.length)
        thick = max(6.5, horn.thickness)

        if horn.kind == "curved":
            pts = []
            for i in range(4):
                t = i / 3.0
                cx = base[0] + t * (length * 0.35 * horn.curve) + (t * t) * (-length * 0.55)
                cy = base[1] - t * length + (t * t) * (length * 0.18)
                pts.append((cx, cy))
            for i in range(3):
                a_seg = seq_a[i * 8 : (i + 1) * 8]
                b_seg = seq_b[i * 8 : (i + 1) * 8]
                self._draw_double_strand_line(
                    screen, anchor_body, a_seg, b_seg, pts[i], pts[i + 1], max(5.0, thick * (1.0 - 0.18 * i)), camera_x, locus, func, show_badge=(i == 1)
                )
        elif horn.kind in ("small_antlers", "branching_antlers"):
            segs = 3 if horn.kind == "small_antlers" else 4
            beam_pts = [
                (base[0] - length * 0.15 * (i / segs), base[1] - length * (i / segs))
                for i in range(segs + 1)
            ]
            chunk = 24 // segs
            for i in range(segs):
                self._draw_double_strand_line(
                    screen,
                    anchor_body,
                    seq_a[i * chunk : (i + 1) * chunk],
                    seq_b[i * chunk : (i + 1) * chunk],
                    beam_pts[i],
                    beam_pts[i + 1],
                    max(4.8, thick * (1.0 - 0.16 * i)),
                    camera_x,
                    locus,
                    func,
                    show_badge=(i == 0),
                )
                if i < max(1, min(3, horn.tines)):
                    side = 1.0 if i % 2 == 0 else -1.0
                    tine_end = (
                        beam_pts[i + 1][0] + side * length * (0.28 + 0.16 * horn.spread),
                        beam_pts[i + 1][1] - length * 0.22,
                    )
                    self._draw_strand_segment(
                        screen,
                        anchor_body,
                        seq_b[(i * 8) % 16 : ((i * 8) % 16) + 8],
                        beam_pts[i + 1],
                        tine_end,
                        max(4.4, thick * 0.65),
                        camera_x,
                        locus=locus,
                        functional=func,
                    )
        else:
            if horn.kind == "pointed":
                tip = (base[0] + length * 0.36, base[1] - length)
            else:
                tip = (base[0], base[1] - length)
            self._draw_double_strand_line(
                screen, anchor_body, seq_a, seq_b, base, tip, thick, camera_x, locus, func, show_badge=True
            )

    def _draw_eye_lid(
        self,
        screen: pygame.Surface,
        head: pymunk.Body,
        camera_x: float,
        center: tuple[float, float],
        radius: float,
        cover: float,
        line_color: tuple[int, int, int] = (36, 30, 32),
    ):
        """A lid across the crown side of the eye, in the head's own axes."""
        ox, oy = center
        r = max(3.0, radius) + 1.1
        top = oy - r
        edge = top + (2.0 * r) * max(0.05, min(1.0, cover))
        lid_col = self._color_for(self.config.head, self.config.appearance.coat_color)
        poly = []
        for lx, ly in ((ox - r, top), (ox + r, top), (ox + r, edge), (ox - r, edge)):
            wx, wy = head.local_to_world((lx, ly))
            poly.append((wx - camera_x, wy))
        if len(poly) >= 3:
            pygame.draw.polygon(screen, lid_col, poly)
        a = head.local_to_world((ox - r * 0.92, edge))
        b = head.local_to_world((ox + r * 0.92, edge))
        pygame.draw.line(screen, line_color, (a[0] - camera_x, a[1]), (b[0] - camera_x, b[1]), 2)

    def _draw_shut_eye(
        self,
        screen: pygame.Surface,
        head: pymunk.Body,
        camera_x: float,
        center: tuple[float, float],
        radius: float,
    ):
        """Cover the whole eye in coat color, then a lid slit along the head.

        The disk is larger than the sclera, so no white ring survives at the rim.
        """
        ox, oy = center
        lid_col = self._color_for(self.config.head, self.config.appearance.coat_color)
        seal = radius + 3.0
        wx, wy = head.local_to_world((ox, oy))
        pygame.draw.circle(screen, lid_col, (wx - camera_x, wy), seal)
        a = head.local_to_world((ox - seal * 0.72, oy))
        b = head.local_to_world((ox + seal * 0.72, oy))
        pygame.draw.line(
            screen, (36, 30, 32),
            (a[0] - camera_x, a[1]), (b[0] - camera_x, b[1]), 2,
        )

    def _draw_osteoderm(self, screen: pygame.Surface, camera_x: float):
        amp = self.config.spike_amp
        if amp <= 0.02 or "torso" not in self.bodies:
            return
        torso = self.bodies["torso"]
        tw, th = self.config.torso.size
        count = max(2, int(round(2 + 7 * self.config.spike_freq)))
        reach = max(6.0, th * (0.25 + 0.85 * amp))
        color = self.config.spike_color
        for i in range(count):
            t = 0.5 if count == 1 else i / (count - 1)
            x = -tw * 0.38 + tw * 0.76 * t
            base_y = -th * 0.48
            half = max(2.2, tw * 0.035)
            tip = torso.local_to_world((x, base_y - reach))
            left = torso.local_to_world((x - half, base_y))
            right = torso.local_to_world((x + half, base_y))
            pygame.draw.polygon(
                screen,
                color,
                [
                    (left[0] - camera_x, left[1]),
                    (right[0] - camera_x, right[1]),
                    (tip[0] - camera_x, tip[1]),
                ],
            )

    def _draw_strand_eye(
        self,
        screen: pygame.Surface,
        camera_x: float,
        locus: str,
    ):
        eye = self.config.eye
        if not eye.enabled or "head" not in self.bodies:
            return
        head = self.bodies["head"]
        ex, ey = head.local_to_world(eye.offset)
        ecx, ecy = ex - camera_x, ey
        seq_a, seq_b = self._locus_alleles(locus)
        func = self._is_locus_functional(locus)
        ring_r = max(6.5, eye.radius * 1.55)
        pts_hb: list[tuple[float, float]] = []
        for i in range(12):
            a0 = (i / 12.0) * 2.0 * math.pi
            a1 = ((i + 1) / 12.0) * 2.0 * math.pi
            b_ch = seq_a[i * 2] if i % 2 == 0 else seq_b[i * 2]
            col = STRAND_NT_COLORS.get(b_ch, (48, 36, 48))
            if not func and b_ch in STRAND_NT_COLORS:
                col = (max(20, int(col[0] * 0.55)), max(20, int(col[1] * 0.55)), max(20, int(col[2] * 0.55)))
            p0 = (ecx + math.cos(a0) * ring_r, ecy + math.sin(a0) * ring_r)
            p1 = (ecx + math.cos(a1) * ring_r, ecy + math.sin(a1) * ring_r)
            pygame.draw.line(screen, col, p0, p1, 3)
            pts_hb.append((ex + math.cos(a0) * ring_r, ey + math.sin(a0) * ring_r))
        self._record_strand_hitbox(locus, pts_hb)

    def _draw_strand_appendages(
        self,
        screen: pygame.Surface,
        camera_x: float,
        extra_loci: list[tuple[str, str]],
    ):
        tbody = self.bodies.get("torso")
        if tbody is None or not extra_loci:
            return
        tw, th = self.config.torso.size
        crest_idx = 0
        tendril_idx = 0
        for slot_kind, locus in extra_loci:
            seq_a, seq_b = self._locus_alleles(locus)
            func = self._is_locus_functional(locus)
            if slot_kind == "crest":
                lift = 10.0 + (crest_idx % 3) * 7.0
                sway = math.sin(self.gait_phase + crest_idx * 1.1) * 3.0
                x_start = tw * (0.36 - 0.08 * (crest_idx % 2))
                x_end = -tw * (0.34 - 0.06 * (crest_idx % 2))
                pts = [
                    (
                        x_start + (x_end - x_start) * (i / 3.0),
                        -th * 0.48 - lift * math.sin((i / 3.0) * math.pi) + sway * (i / 3.0),
                    )
                    for i in range(4)
                ]
                for i in range(3):
                    self._draw_double_strand_line(
                        screen,
                        tbody,
                        seq_a[i * 8 : (i + 1) * 8],
                        seq_b[i * 8 : (i + 1) * 8],
                        pts[i],
                        pts[i + 1],
                        8.0,
                        camera_x,
                        locus,
                        func,
                        show_badge=(i == 1),
                    )
                crest_idx += 1
            else:
                side = -1.0 if (tendril_idx % 2 == 0) else 1.0
                x0 = -tw * (0.20 + 0.12 * (tendril_idx % 3))
                y0 = -th * (0.14 + 0.10 * (tendril_idx % 2))
                pts = [(x0, y0)]
                for seg_i in range(1, 4):
                    t = seg_i / 3.0
                    wave = math.sin(self.gait_phase + tendril_idx * 1.4 + seg_i * 0.9) * (6.0 * t)
                    pts.append((x0 - 52.0 * t, y0 - th * (0.36 * t) + side * (10.0 * t) + wave))
                for i in range(3):
                    self._draw_double_strand_line(
                        screen,
                        tbody,
                        seq_a[i * 8 : (i + 1) * 8],
                        seq_b[i * 8 : (i + 1) * 8],
                        pts[i],
                        pts[i + 1],
                        8.2 - i * 0.8,
                        camera_x,
                        locus,
                        func,
                        show_badge=(i == 1),
                    )
                tendril_idx += 1

    def _draw_strand_creature(self, screen: pygame.Surface, camera_x: float):
        assert self.config.strand_alleles is not None
        loci = self.config.strand_loci or (ALL_LOCI[max(0, self.config.strand_locus_num - 1)],)
        is_multi = len(loci) > 1
        primary_locus = (
            next(
                (l for l in loci if STRAND_SLOT_BY_LOCUS.get(l, "tendril") not in ("wing", "horn", "tail")),
                loci[0],
            )
            if is_multi
            else loci[0]
        )
        allele_a, allele_b = self._locus_alleles(primary_locus)
        func_a = is_strand_complete(allele_a)
        func_b = is_strand_complete(allele_b)
        func_primary = func_a and func_b

        tail_loc = self._locus_for_slot("tail") if is_multi else None
        if is_multi and "tail" in self.shapes and tail_loc is not None:
            self._draw_strand_tail(screen, tail_loc, camera_x)

        wing_loc = self._locus_for_slot("wing") if is_multi else None
        if is_multi and self.config.wing.enabled and wing_loc is not None:
            self._draw_strand_wing(screen, camera_x, is_back=True, locus=wing_loc)

        for arm_name, seq, arm_cfg, f_side in (
            ("arm_back", allele_a[:8], self.config.arm_back, func_a),
            ("arm_front", allele_b[:8], self.config.arm_front, func_b),
        ):
            body = self.bodies.get(arm_name)
            if body is None:
                continue
            aw, ah = arm_cfg.size
            self._draw_strand_segment(
                screen,
                body,
                seq,
                (0.0, -ah * 0.5),
                (0.0, ah * 0.5),
                aw,
                camera_x,
                locus=primary_locus,
                functional=f_side,
            )

        for leg_name, seq, leg_cfg, f_side in (
            ("leg_back", allele_a[8:], self.config.leg_back, func_a),
            ("leg_front", allele_b[8:], self.config.leg_front, func_b),
        ):
            body = self.bodies.get(leg_name)
            if body is None:
                continue
            lw, lh = leg_cfg.size
            knee_ratio = max(0.25, min(0.75, leg_cfg.knee_ratio))
            upper_h = lh * knee_ratio
            lower_h = lh - upper_h
            y_top = -lh * 0.5
            y_knee = y_top + upper_h
            knee_rad = math.radians(max(-15.0, min(15.0, leg_cfg.knee_deg)))
            foot_tip = (math.sin(knee_rad) * lower_h, y_knee + math.cos(knee_rad) * lower_h)
            mid = max(1, len(seq) // 2)
            self._draw_strand_segment(
                screen, body, seq[:mid], (0.0, y_top), (0.0, y_knee), lw, camera_x, locus=primary_locus, functional=f_side
            )
            self._draw_strand_segment(
                screen, body, seq[mid:], (0.0, y_knee), foot_tip, lw * leg_cfg.lower_width_scale, camera_x, locus=primary_locus, functional=f_side
            )
            if leg_name in self.knee_caps:
                ky_loc, kr = self.knee_caps[leg_name]
                kx, ky = body.local_to_world((0.0, ky_loc))
                mid_base = seq[mid - 1] if seq else "A"
                pygame.draw.circle(
                    screen,
                    STRAND_NT_COLORS.get(mid_base, (40, 34, 46)),
                    (kx - camera_x, ky),
                    kr * 0.9,
                )

        extra_loci: list[tuple[str, str]] = []
        if is_multi:
            used_loci = {primary_locus}
            for used in (tail_loc, wing_loc, self._locus_for_slot("horn")):
                if used is not None:
                    used_loci.add(used)
            for extra_loc in loci:
                if extra_loc in used_loci:
                    continue
                slot = STRAND_SLOT_BY_LOCUS.get(extra_loc, "tendril")
                extra_loci.append(("crest" if slot == "crest" else "tendril", extra_loc))
            if extra_loci:
                self._draw_strand_appendages(screen, camera_x, extra_loci)

        if "torso" in self.shapes and "torso" in self.bodies:
            tbody = self.bodies["torso"]
            tshape = self.shapes["torso"]
            if isinstance(tshape, pymunk.Poly):
                world_pts = [tbody.local_to_world(v) for v in tshape.get_vertices()]
                self._record_strand_hitbox(primary_locus, world_pts)
                pts = [(wx - camera_x, wy) for wx, wy in world_pts]
                pygame.draw.polygon(screen, (16, 16, 22), pts)
                pygame.draw.polygon(
                    screen,
                    (138, 92, 206) if func_primary else (206, 74, 84),
                    pts,
                    2,
                )
            _draw_rotated_glyph(
                screen,
                self.config.label.lstrip("#") if is_multi else str(self.config.strand_locus_num),
                18 if not is_multi else 12,
                (198, 132, 248) if func_primary else (228, 108, 118),
                (tbody.position.x - camera_x, tbody.position.y),
                -math.degrees(tbody.angle),
            )

        horn_loc = self._locus_for_slot("horn") if is_multi else None
        if is_multi and self.config.horn.enabled and horn_loc is not None:
            self._draw_strand_horn(screen, camera_x, horn_loc)
        if is_multi and self.config.wing.enabled and wing_loc is not None:
            self._draw_strand_wing(screen, camera_x, is_back=False, locus=wing_loc)

    def draw(self, screen: pygame.Surface, camera_x: float):
        """Draws all enabled parts using per-part color overrides or AppearanceConfig."""
        self.strand_hitboxes.clear()
        if self.config.pure_strand or (self.config.strand_alleles is not None and len(self.config.strand_loci) <= 1):
            self._draw_strand_creature(screen, camera_x)
            return

        app = self.config.appearance
        arms_loci = self._loci_for_slot("arms")
        leg_b_loci = self._loci_for_slot("leg_back")
        leg_f_loci = self._loci_for_slot("leg_front")
        legs_both_loci = self._loci_for_slot("legs_both")
        hoof_loci = self._loci_for_slot("hooves")
        tail_loci = self._loci_for_slot("tail")
        wing_loci = self._loci_for_slot("wing")
        torso_loci = self._loci_for_slot("torso")
        neck_loci = self._loci_for_slot("neck")
        head_loci = self._loci_for_slot("head")
        ear_loci = self._loci_for_slot("ear")
        jaw_loci = self._loci_for_slot("jaw")
        nose_loci = self._loci_for_slot("nose")
        eye_loci = self._loci_for_slot("eye")
        horn_loci = self._loci_for_slot("horn")

        arms_loc = arms_loci[0] if arms_loci else None
        leg_b_loc = leg_b_loci[0] if leg_b_loci else (legs_both_loci[0] if legs_both_loci else None)
        leg_f_loc = leg_f_loci[0] if leg_f_loci else (legs_both_loci[0] if legs_both_loci else None)
        hoof_loc = hoof_loci[0] if hoof_loci else None
        tail_loc = tail_loci[0] if tail_loci else None
        wing_loc = wing_loci[0] if wing_loci else None
        neck_loc = neck_loci[0] if neck_loci else None
        head_loc = head_loci[0] if head_loci else None
        ear_loc = ear_loci[0] if ear_loci else None
        jaw_loc = jaw_loci[0] if jaw_loci else None
        nose_loc = nose_loci[0] if nose_loci else None
        eye_loc = eye_loci[0] if eye_loci else None
        horn_loc = horn_loci[0] if horn_loci else None

        if arms_loc is not None:
            self._draw_strand_leg(screen, "arm_back", self.config.arm_back, arms_loc, camera_x)
        else:
            self._draw_leg(
                screen, "arm_back", self._color_for(self.config.arm_back, app.back_leg_color), camera_x
            )
        if "hand_back" in self.shapes:
            if arms_loc is not None:
                self._draw_strand_overlay_part(screen, "hand_back", app.hand_back_color, arms_loc, camera_x)
            else:
                draw_poly_shape(screen, self.shapes["hand_back"], app.hand_back_color, camera_x)

        if leg_b_loc is not None:
            self._draw_strand_leg(screen, "leg_back", self.config.leg_back, leg_b_loc, camera_x)
        else:
            self._draw_leg(
                screen, "leg_back", self._color_for(self.config.leg_back, app.back_leg_color), camera_x
            )
        if "hoof_back" in self.shapes:
            h_b_col = self._color_for(self.config.hoof, app.hoof_back_color)
            if hoof_loc is not None:
                self._draw_strand_hoof(screen, "hoof_back", h_b_col, hoof_loc, camera_x)
            else:
                draw_poly_shape(screen, self.shapes["hoof_back"], h_b_col, camera_x)

        if leg_f_loc is not None and "leg_mid" in self.shapes:
            self._draw_strand_leg(screen, "leg_mid", self.config.leg_mid, leg_f_loc, camera_x)
        elif "leg_mid" in self.shapes:
            self._draw_leg(
                screen, "leg_mid", self._color_for(self.config.leg_mid, app.back_leg_color), camera_x
            )
        if "hoof_mid" in self.shapes:
            h_m_col = self._color_for(self.config.hoof, app.hoof_back_color)
            if hoof_loc is not None:
                self._draw_strand_hoof(screen, "hoof_mid", h_m_col, hoof_loc, camera_x)
            else:
                draw_poly_shape(screen, self.shapes["hoof_mid"], h_m_col, camera_x)

        if "tail" in self.shapes:
            if tail_loc is not None:
                self._draw_strand_tail(screen, tail_loc, camera_x)
            else:
                draw_poly_shape(
                    screen,
                    self.shapes["tail"],
                    self._color_for(self.config.tail, app.tail_color),
                    camera_x,
                )

        if wing_loc is not None:
            self._draw_strand_wing(screen, camera_x, is_back=True, locus=wing_loc)
        else:
            self._draw_wing(screen, camera_x, is_back=True)

        if "torso" in self.shapes:
            torso_color = self._color_for(self.config.torso, app.coat_color)
            if app.pattern.style == "flat" and self.config.torso.shape_style == "default":
                draw_poly_shape(screen, self.shapes["torso"], torso_color, camera_x)
            else:
                torso_body = self.bodies["torso"]
                surf = self._get_torso_surface(torso_color)
                rot = pygame.transform.rotozoom(
                    surf, -math.degrees(torso_body.angle), 1.0
                )
                rect = rot.get_rect(
                    center=(torso_body.position.x - camera_x, torso_body.position.y)
                )
                screen.blit(rot, rect)
            for b_idx, t_loc in enumerate(torso_loci[:3]):
                self._draw_strand_torso_band(
                    screen, camera_x, t_loc, band_idx=b_idx, total_bands=min(3, len(torso_loci))
                )

        if leg_f_loc is not None:
            self._draw_strand_leg(screen, "leg_front", self.config.leg_front, leg_f_loc, camera_x)
        else:
            self._draw_leg(
                screen, "leg_front", self._color_for(self.config.leg_front, app.coat_color), camera_x
            )
        if "hoof_front" in self.shapes:
            h_f_col = self._color_for(self.config.hoof, app.hoof_front_color)
            if hoof_loc is not None:
                self._draw_strand_hoof(screen, "hoof_front", h_f_col, hoof_loc, camera_x)
            else:
                draw_poly_shape(screen, self.shapes["hoof_front"], h_f_col, camera_x)

        if self.config.has_apron and "torso" in self.bodies:
            tbody = self.bodies["torso"]
            tw, th = self.config.torso.size
            apron_pts = [
                tbody.local_to_world((-tw * 0.42, -th * 0.12)),
                tbody.local_to_world((tw * 0.42, -th * 0.12)),
                tbody.local_to_world((tw * 0.42, th * 0.58)),
                tbody.local_to_world((-tw * 0.42, th * 0.58)),
            ]
            pygame.draw.polygon(
                screen,
                (54, 118, 72),
                [(wx - camera_x, wy) for wx, wy in apron_pts],
            )

        extra_appendages: list[tuple[str, str]] = []
        drawn_direct: set[str] = {
            l
            for l in (
                arms_loc,
                leg_b_loc,
                leg_f_loc,
                hoof_loc,
                tail_loc,
                wing_loc,
                neck_loc,
                head_loc,
                ear_loc,
                jaw_loc,
                nose_loc,
                eye_loc,
                horn_loc,
            )
            if l is not None
        }
        drawn_direct.update(torso_loci[:3])
        for loc in self.config.strand_loci:
            if loc in drawn_direct:
                continue
            slot = STRAND_SLOT_BY_LOCUS.get(loc, "tendril")
            extra_appendages.append(("crest" if slot == "crest" else "tendril", loc))
        if extra_appendages:
            self._draw_strand_appendages(screen, camera_x, extra_appendages)

        jaw_color = self._color_for(self.config.lower_jaw, app.coat_color)
        jaw_body = self.bodies.get("lower_jaw")
        head_body = self.bodies.get("head")
        fused_jaw_chew = (
            self.eat_time > 0.0
            and jaw_body is not None
            and head_body is not None
            and jaw_body is head_body
        )
        upper_parts = (
            ("neck", self._color_for(self.config.neck, app.coat_color), neck_loc),
            ("head", self._color_for(self.config.head, app.coat_color), head_loc),
            ("ear", self._color_for(self.config.ear, app.coat_color), ear_loc),
            ("upper_jaw", self._color_for(self.config.upper_jaw, app.coat_color), jaw_loc),
            ("lower_jaw", jaw_color, jaw_loc),
            ("tooth", self._color_for(self.config.teeth, app.tooth_color), None),
            ("tooth_lower", self._color_for(self.config.teeth, app.tooth_color), None),
            ("nose", self._color_for(self.config.nose, app.nose_color), nose_loc),
        )
        for name, color, strand_loc in upper_parts:
            if name == "lower_jaw" and fused_jaw_chew:
                self._draw_chewing_jaw(screen, camera_x, jaw_color)
                if strand_loc is not None:
                    self._draw_strand_overlay_part(
                        screen, name, color, strand_loc, camera_x, show_badge=False, draw_base=False
                    )
                continue
            if name in self.shapes:
                if strand_loc is not None:
                    self._draw_strand_overlay_part(
                        screen, name, color, strand_loc, camera_x, show_badge=(name == "head")
                    )
                else:
                    draw_poly_shape(screen, self.shapes[name], color, camera_x)
                    ear_carriage = self.config.ear.carriage
                    if name == "ear" and ear_carriage > 0.08:
                        ear_shape = self.shapes["ear"]
                        if isinstance(ear_shape, pymunk.Poly):
                            v = list(ear_shape.get_vertices())
                            if len(v) == 4:
                                inset = 0.52 * min(1.0, ear_carriage)
                                b_mid = ((v[0][0] + v[1][0]) * 0.5, (v[0][1] + v[1][1]) * 0.5)
                                t_mid = ((v[2][0] + v[3][0]) * 0.5, (v[2][1] + v[3][1]) * 0.5)
                                axis = (t_mid[0] - b_mid[0], t_mid[1] - b_mid[1])
                                inner_local = [
                                    (b_mid[0] + (v[0][0] - b_mid[0]) * inset + axis[0] * 0.10,
                                     b_mid[1] + (v[0][1] - b_mid[1]) * inset + axis[1] * 0.10),
                                    (b_mid[0] + (v[1][0] - b_mid[0]) * inset + axis[0] * 0.10,
                                     b_mid[1] + (v[1][1] - b_mid[1]) * inset + axis[1] * 0.10),
                                    (t_mid[0] + (v[2][0] - t_mid[0]) * inset - axis[0] * 0.13,
                                     t_mid[1] + (v[2][1] - t_mid[1]) * inset - axis[1] * 0.13),
                                    (t_mid[0] + (v[3][0] - t_mid[0]) * inset - axis[0] * 0.13,
                                     t_mid[1] + (v[3][1] - t_mid[1]) * inset - axis[1] * 0.13),
                                ]
                                inner_pts = [
                                    (wx - camera_x, wy)
                                    for wx, wy in (ear_shape.body.local_to_world(p) for p in inner_local)
                                ]
                                pygame.draw.polygon(screen, (244, 168, 174), inner_pts)

        eye = self.config.eye
        show_eye = "head" in self.bodies and (eye.enabled or eye.lid != "open")
        if show_eye:
            head = self.bodies["head"]
            ex, ey = head.local_to_world(eye.offset)
            ecx = ex - camera_x
            ecy = ey
            closed_eye = eye.lid == "closed" or (not eye.enabled) or self.unconscious
            if eye.lid == "cross" or (self.dead and eye.enabled):
                xr = max(3.5, eye.radius * 0.9)
                pygame.draw.circle(screen, (235, 232, 224), (ecx, ecy), max(4.0, eye.radius))
                ox, oy = eye.offset
                for a, b in (
                    ((ox - xr * 0.7, oy - xr * 0.7), (ox + xr * 0.7, oy + xr * 0.7)),
                    ((ox - xr * 0.7, oy + xr * 0.7), (ox + xr * 0.7, oy - xr * 0.7)),
                ):
                    wa, wb = head.local_to_world(a), head.local_to_world(b)
                    pygame.draw.line(
                        screen, (36, 30, 32),
                        (wa[0] - camera_x, wa[1]), (wb[0] - camera_x, wb[1]), 2,
                    )
            elif self.asleep_timer > 0.0 and eye.enabled and eye.lid == "open":
                self._draw_shut_eye(screen, head, camera_x, eye.offset, eye.radius)
                _draw_rotated_glyph(screen, "Z", 11, (186, 212, 252), (ecx + 6, ecy - eye.radius - 8), -12.0)
                _draw_rotated_glyph(screen, "z", 9, (186, 212, 252), (ecx + 14, ecy - eye.radius - 16), 8.0)
            elif closed_eye:
                self._draw_shut_eye(screen, head, camera_x, eye.offset, eye.radius)
            elif self.drunk:
                sr = max(5.8, eye.radius * 1.38)
                pygame.draw.circle(screen, (255, 240, 244), (ecx, ecy), sr)
                pts = []
                steps = 22
                max_theta = 3.2 * math.pi
                for si in range(steps + 1):
                    t_s = si / steps
                    theta = self.swirl_phase + t_s * max_theta
                    rad = t_s * (sr * 0.88)
                    pts.append((ecx + math.cos(theta) * rad, ecy + math.sin(theta) * rad))
                if len(pts) >= 2:
                    pygame.draw.lines(screen, (42, 24, 58), False, pts, 2)
            else:
                sclera_col = (242, 46, 46) if self.frenzied else eye.sclera_color
                pygame.draw.circle(screen, sclera_col, (ecx, ecy), eye.radius)
                # Sit the pupil on the forward rim of the eye, level with its center,
                # so the gaze reads as straight ahead.
                forward = max(0.0, eye.radius - eye.pupil_radius - 0.45)
                pygame.draw.circle(
                    screen,
                    eye.pupil_color,
                    (ex + forward - camera_x, ey),
                    eye.pupil_radius,
                )
                if self.tired:
                    self._draw_eye_lid(screen, head, camera_x, eye.offset, eye.radius, 0.55)
                elif (
                    self.config.gait.metabolic_trait == "front_runner"
                    and self.track_progress > 0.70
                    and self.run_blend > 0.2
                ):
                    self._draw_eye_lid(screen, head, camera_x, eye.offset, eye.radius, 0.48, (42, 34, 32))
            if eye_loc is not None:
                self._draw_strand_eye(screen, camera_x, eye_loc)

        if self.config.hoof.spring_bounce > 0.0:
            for hoof_name in ("hoof_back", "hoof_front"):
                if hoof_name in self.shapes and isinstance(self.shapes[hoof_name], pymunk.Poly):
                    hshape = self.shapes[hoof_name]
                    hbody = hshape.body
                    hverts = [hbody.local_to_world(v) for v in hshape.get_vertices()]
                    bot_pts = sorted(hverts, key=lambda p: p[1], reverse=True)[:2]
                    if len(bot_pts) == 2:
                        pygame.draw.line(
                            screen,
                            (114, 224, 178),
                            (bot_pts[0][0] - camera_x, bot_pts[0][1] - 1.5),
                            (bot_pts[1][0] - camera_x, bot_pts[1][1] - 1.5),
                            3,
                        )

        self._draw_osteoderm(screen, camera_x)
        if horn_loc is not None:
            self._draw_strand_horn(screen, camera_x, horn_loc)
        else:
            self._draw_horns(screen, camera_x)
        self._draw_crest(screen, camera_x)
        if self.config.gait.metabolic_trait == "fiery" and self.run_blend > 0.25 and "torso" in self.bodies:
            tbody = self.bodies["torso"]
            tw, th = self.config.torso.size
            for fi in range(3):
                phase = self.swirl_phase * 2.2 + fi * 2.1
                fx, fy = tbody.local_to_world((-tw * 0.45 - 8.0 - (fi * 9.0), th * 0.25 - abs(math.sin(phase)) * 12.0))
                ecol = (255, 118 + fi * 35, 42)
                pygame.draw.circle(screen, ecol, (int(fx - camera_x), int(fy)), max(2, 4 - fi))

        if wing_loc is not None:
            self._draw_strand_wing(screen, camera_x, is_back=False, locus=wing_loc)
        else:
            self._draw_wing(screen, camera_x, is_back=False)

        if arms_loc is not None:
            self._draw_strand_leg(screen, "arm_front", self.config.arm_front, arms_loc, camera_x)
        else:
            self._draw_leg(
                screen, "arm_front", self._color_for(self.config.arm_front, app.coat_color), camera_x
            )
        if "hand_front" in self.shapes:
            if arms_loc is not None:
                self._draw_strand_overlay_part(screen, "hand_front", app.hand_color, arms_loc, camera_x)
            else:
                draw_poly_shape(screen, self.shapes["hand_front"], app.hand_color, camera_x)
