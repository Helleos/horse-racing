"""Wild Horse Frontier & Derby. Scene loop; world, physics, and UI live in sibling modules."""
from __future__ import annotations

import asyncio
import math
import os
import random
import sys
import traceback
import pygame
import pymunk

from gene import (
    ALLELE_LENGTH,
    ALL_LOCI,
    BASE_TO_INT,
    Gene,
    sample_strands,
)

from racing_models import (
    ActiveBite,
    FossilNode,
    HorseEntry,
    HorseFactory,
    RacecourseData,
    LassoAnim,
    MapGeneNode,
    RanchData,
    SceneHorse,
    SceneProp,
    ShopData,
    SpliceNucleotideNode,
    TreeData,
    WildHorse,
    MeatCut,
    WorldApple,
    diet_accepts,
    entry_strands_functional,
    item_extract_genome,
    get_horse_front_x,
    invalidate_preview_cache,
    prepare_race_lineup,
    refresh_entry_config_for_age,
    simulate_preliminary_trial,
    sync_creature_state,
)

from racing_constants import (
    BOLD_NAME_COLORS,
    FPS,
    HORSE_CANVAS_H,
    HORSE_CANVAS_W,
    HORSE_FLOOR_Y,
    ITEM_PRICES,
    LANE_BOUNDS,
    NUM_LANES,
    OW_COLS,
    OW_HEIGHT,
    OW_ROWS,
    OW_TILE,
    OW_WIDTH,
    PATH_COLOR,
    PATH_SPEED_MULT,
    PHYS_W,
    RANCHER_GREETINGS,
    SCENE_SCALE,
    SCREEN_H,
    SCREEN_W,
    STARTING_BANKROLL,
    START_CAM_X,
    STRONGHORSE_LENGTH,
    STRONGHORSE_SLOPE,
    STD_TRUCK_TRAILER_H,
    STD_TRUCK_TRAILER_W,
    TERRAIN_COLORS,
    TERRAIN_SPEED_MULT,
    TRACK_LENGTH,
    WORLD_SCALE_X,
)

from hires import HiResFont, HiResScreen, enable_dpi_awareness, install_hires_hooks

from open_world import (
    OpenWorld,
    tile_rect_world,
)

from creature import (
    STRAND_NT_COLORS,
    compute_spawn_y,
    config_from_genome,
    get_strand_map_surface,
)

from physics_scene import (
    UnifiedPhysicsScene,
    add_open_pen_walls,
    add_truck_walls,
)

from scene_art import (
    build_carcass_surface,
    build_potion_flask_surface,
    draw_wild_horse_actual,
    draw_world_apple,
    draw_world_convenience_store,
    draw_world_forest_tile,
    draw_world_fossil,
    draw_world_oasis_tile,
    draw_world_racecourse,
    draw_world_tree,
)

from scene_ui import (
    compute_dna_pool_diversity,
    draw_breeding_shed,
    draw_field_background,
    draw_horse_hover_card,
    draw_lane_horse_and_sign,
    draw_lasso_button,
    draw_open_pen_fence,
    draw_scene_status_badges,
    draw_speech_bubble,
    draw_standardized_truck_shell,
    draw_wood_sign,
    synthesize_dna_candidate,
)

def _emscripten_res_scale() -> float:
    """Backing-store scale so the canvas matches device pixels, not a stretched 1200x720."""
    try:
        import platform

        win = platform.window
        dpr = float(win.devicePixelRatio or 1.0)
        css_w = float(win.innerWidth or 0.0)
        css_h = float(win.innerHeight or 0.0)
    except Exception:
        return 2.0
    if css_w < 64 or css_h < 64:
        return 2.0
    dpr = max(1.0, min(dpr, 2.0))
    ar = SCREEN_W / SCREEN_H
    fit_w = css_w
    fit_h = fit_w / ar
    if fit_h > css_h:
        fit_h = css_h
        fit_w = fit_h * ar
    return max(1.0, min((fit_w * dpr) / SCREEN_W, 2.5))


async def main():
    # Logical playfield stays 1200x720. The backing store scales up so it stays sharp.
    RES_SCALE = 1.0
    enable_dpi_awareness()
    pygame.init()
    install_hires_hooks()
    if sys.platform == "emscripten":
        RES_SCALE = _emscripten_res_scale()
    else:
        try:
            desk_w, desk_h = pygame.display.get_desktop_sizes()[0]
            RES_SCALE = min((desk_w - 40) / SCREEN_W, (desk_h - 90) / SCREEN_H, 2.0)
        except Exception:
            RES_SCALE = 1.0
        if os.environ.get("CAPTURE_GALLERY") == "1":
            RES_SCALE = 1.5
    real_screen = pygame.display.set_mode(
        (int(round(SCREEN_W * RES_SCALE)), int(round(SCREEN_H * RES_SCALE))),
        pygame.RESIZABLE,
    )
    if sys.platform == "emscripten":
        try:
            import platform

            platform.window.window_resize()
        except Exception:
            pass
    screen = HiResScreen(real_screen, (SCREEN_W, SCREEN_H), RES_SCALE)
    pygame.display.set_caption("Wild Horse Frontier & Derby")
    screen.fill((20, 23, 33))
    pygame.display.flip()
    pygame.event.pump()
    await asyncio.sleep(0)

    clock = pygame.time.Clock()

    font_med = HiResFont("sans-serif", 17, RES_SCALE, bold=True)
    font_small = HiResFont("sans-serif", 14, RES_SCALE)
    font_odds_small = HiResFont("sans-serif", 13, RES_SCALE, bold=True)
    font_badge = HiResFont("sans-serif", 13, RES_SCALE, bold=True)
    font_hover_name = HiResFont("sans-serif", 22, RES_SCALE, bold=True)
    font_retro = HiResFont("monospace", 24, RES_SCALE, bold=True)
    font_mono_tiny = HiResFont("monospace", 11, RES_SCALE, bold=True)
    font_mono_nt = HiResFont("monospace", 18, RES_SCALE, bold=True)
    name_fonts = [HiResFont("sans-serif", s, RES_SCALE, bold=True) for s in (20, 18, 16, 14)]

    rng = random.Random(20261120 if os.environ.get("CAPTURE_GALLERY") == "1" else None)
    factory = HorseFactory(rng)
    world = OpenWorld(factory, rng)
    print("web: world ready")

    trial_space = pymunk.Space()
    trial_space.gravity = (0, 900)
    trial_floor = pymunk.Segment(
        trial_space.static_body, (-1000.0, HORSE_FLOOR_Y), (TRACK_LENGTH + 1500.0, HORSE_FLOOR_Y), 5.0
    )
    trial_floor.friction = 1.0
    trial_space.add(trial_floor)

    lane_spaces: list[tuple[pymunk.Space, pymunk.Segment]] = []
    for _ in range(NUM_LANES):
        sp = pymunk.Space()
        sp.gravity = (0, 900)
        fl = pymunk.Segment(
            sp.static_body, (-1000.0, HORSE_FLOOR_Y), (TRACK_LENGTH + 2000.0, HORSE_FLOOR_Y), 5.0
        )
        fl.friction = 1.0
        sp.add(fl)
        lane_spaces.append((sp, fl))

    horse_canvas = pygame.Surface((HORSE_CANVAS_W, HORSE_CANVAS_H), pygame.SRCALPHA)

    # Core player state
    bankroll = STARTING_BANKROLL
    day = 1
    truck_horses: list[HorseEntry] = []
    your_ranch_horses: list[HorseEntry] = []
    lasso_count = 0
    lasso_armed = False
    truck_hay = 0
    truck_beer = 0
    truck_apples = 0
    truck_prickly_pears = 0
    truck_chilis = 0
    truck_apple_crates: list[list[int]] = []
    truck_fossils: list[Genome] = []
    truck_meats: list[MeatCut] = []
    has_infinite_lasso = False
    championship_won = False
    active_course: RacecourseData | None = None
    truck_potions: list[Genome] = []
    truck_drives: list[Genome] = []
    active_bites: list[ActiveBite] = []
    first_race_done = False

    # Unified Physics Scene controller (used for Truck, Ranch, Your Ranch, Shop, Racecourse Hub)
    phys_scene = UnifiedPhysicsScene()

    # Scene layout coordinates (in physics units at SCENE_SCALE = 0.56)
    # 1. Truck Interior Scene: centered larger truck on open wild ground
    TRUCK_SCENE_LEFT = 450.0
    TRUCK_SCENE_FLOOR_Y = 930.0

    # 2. Ranch Scene:
    #    - Sample track at top (long dirt stretch across entire width, floor y=355 phys)
    #    - Open wooden Pen middle-left (x=60..1060, floor y=775 phys, NO ceiling)
    #    - Standardized Truck bottom-right (left=940, floor y=1195 phys)
    #    - Rancher bottom-left inside phys_scene (x=185, floor y=1195 phys)
    RANCH_TRACK_FLOOR_Y = 355.0
    RANCH_PEN_X1 = 60.0
    RANCH_PEN_X2 = 1060.0
    RANCH_PEN_FLOOR_Y = 775.0
    RANCH_TRUCK_LEFT = 940.0
    RANCH_TRUCK_FLOOR_Y = 1195.0

    # 3. Your Ranch Scene (Pen + Sample Track + Breeding Shed + Standardized Truck)
    YOUR_PEN_X1 = 60.0
    YOUR_PEN_X2 = 960.0
    YOUR_YARD_FLOOR_Y = 775.0
    SHED_X1 = 1360.0
    SHED_X2 = 1880.0
    SHED_TOP = 465.0
    SHED_FLOOR_Y = 775.0
    YOUR_TRUCK_LEFT = 940.0
    YOUR_TRUCK_FLOOR_Y = 1195.0

    # 4. Racecourse Hub Scene:
    #    - Standardized Truck bottom-left (left=40, floor y=1195 phys)
    #    - Open Racing Pen bottom-right (x=1300..2080, floor y=1195 phys, NO ceiling)
    HUB_TRUCK_LEFT = 40.0
    HUB_TRUCK_FLOOR_Y = 1195.0
    HUB_PEN_X1 = 1300.0
    HUB_PEN_X2 = 2080.0
    HUB_PEN_FLOOR_Y = 1195.0

    # 5. Gene Factory: wide glass box, a gap, the EXTRACT machine, then a separate funnel
    GENE_EXTRACT_COST = 300
    GENE_BENCH_Y = 690.0
    GENE_BOX_X1 = 40.0
    GENE_BOX_X2 = 840.0
    GENE_BOX_TOP = 165.0
    GENE_BOX_FLOOR = GENE_BENCH_Y
    GENE_MACH_X1 = 930.0
    GENE_MACH_X2 = 1480.0
    GENE_MACH_TOP = 310.0
    GENE_MACH_FLOOR = GENE_BENCH_Y
    GENE_FUNNEL_X1 = 1630.0
    GENE_FUNNEL_X2 = 2040.0
    GENE_FUNNEL_TOP = 255.0
    GENE_FUNNEL_FLOOR = GENE_BENCH_Y
    GENE_FLASK_X = 1835.0
    GENE_FLASK_Y = GENE_FUNNEL_FLOOR - 26.0
    GENE_JEAN_X = 180.0
    GENE_TRUCK_LEFT = 940.0
    GENE_TRUCK_FLOOR_Y = 1195.0
    JEAN_LINES = [
        "Welcome neighbour",
        "This is my gene extractor",
        "But running this is very expensive",
        "So you'll need to pay $300 first",
        "You can use the gene extractor by putting a horse into the box and flicking that lever",
        "Try feeding a different horse the potion you get",
    ]
    GENE_MODES = ("EXTRACT", "IMPRINT", "EDIT", "CONVERT")
    GM_WIDTH = 2600.0
    GM_HEIGHT = 1600.0

    # 6. DNA Lab (far from hub): Large Vat -> Central Retro Computer w/ Red Button -> Output Tray
    DNA_BENCH_Y = 690.0
    DNA_VAT_X1 = 150.0
    DNA_VAT_X2 = 440.0
    DNA_VAT_TOP = 165.0
    DNA_VAT_FLOOR = DNA_BENCH_Y
    DNA_COMP_X1 = 620.0
    DNA_COMP_X2 = 1500.0
    DNA_COMP_TOP = 95.0
    DNA_COMP_FLOOR = DNA_BENCH_Y
    DNA_OUT_X = 1760.0
    DNA_OUT_Y = DNA_BENCH_Y - 26.0
    DNA_GUIDE_X = 185.0
    DNA_TRUCK_LEFT = 940.0
    DNA_TRUCK_FLOOR_Y = 1195.0
    DNA_GUIDE_LINES = [
        "Welcome to the DNA Lab",
        "Drop gene potions from your truck into the vat on the left",
        "More potions in the vat means more genetic diversity for better results",
        "Press the big red button on the computer to simulate & breed the fastest horse",
    ]

    # 5. Shop Scene (Counter + 3 Display Shelves + Shopkeeper + Standardized Truck):
    SHOP_SHELF_X1 = 150.0
    SHOP_SHELF_X2 = 860.0
    SHOP_SHELF_YS = {
        "lasso": 340.0,
        "hay": 560.0,
        "beer": 780.0,
    }
    SHOP_TRUCK_LEFT = 940.0
    SHOP_TRUCK_FLOOR_Y = 1195.0

    # Truck open-world state
    truck_x = world.racecourse_pos[0] - 200.0
    truck_y = world.racecourse_pos[1] + 130.0
    truck_facing = 1
    ow_cam_x = truck_x - SCREEN_W * 0.5
    ow_cam_y = truck_y - SCREEN_H * 0.5
    lasso_anim: LassoAnim | None = None

    scene = "racecourse_track"

    # Racecourse track state
    race_num = 1
    race_mode = "bet"
    selected_lane = 0
    bet_amount = 10
    active_bet = 0
    active_bet_lane = -1
    status_banner = ""
    race_time = 0.0
    winner_lane: LaneRuntime | None = None
    lanes: list[LaneRuntime] = []
    track_state = "betting"
    track_cam_x = START_CAM_X

    lanes = prepare_race_lineup(
        world.ranches,
        factory,
        trial_space,
        trial_floor,
        lane_spaces,
        lanes,
        rng,
        extra_pool=world.race_pool_newcomers,
    )

    # Track wooden signs
    sign_bet_minus = pygame.Rect(975, 622, 34, 34)
    sign_bet_plus = pygame.Rect(1105, 622, 34, 34)
    sign_bet_board = pygame.Rect(1013, 620, 88, 38)
    sign_start_race = pygame.Rect(980, 666, 155, 40)
    sign_next_race = pygame.Rect(520, 14, 110, 36)
    sign_leave_track = pygame.Rect(645, 14, 110, 36)

    # Racecourse Hub wooden signs
    hub_sign_bet = pygame.Rect(120, 170, 270, 52)
    hub_sign_race_mine = pygame.Rect(780, 170, 280, 52)
    hub_sign_championship = pygame.Rect(780, 254, 280, 52)
    hub_sign_exit = pygame.Rect(24, 14, 110, 36)
    HUB_PEDESTAL_X = 1050.0
    HUB_PEDESTAL_TOP_Y = 480.0
    hub_sign_arena = pygame.Rect(110, 250, 290, 56)
    arena_guide_target: RacecourseData | None = None
    arena_sign_stronghorse = pygame.Rect(760, 170, 290, 52)
    arena_sign_muddy = pygame.Rect(760, 254, 290, 52)
    hub_sign_bailout = pygame.Rect(440, 170, 200, 48)

    # Truck Interior sign
    truck_sign_exit = pygame.Rect(24, 18, 110, 38)

    # Shop Scene objects
    active_shop: ShopData | None = None
    shop_exit_sign = pygame.Rect(18, 12, 92, 34)
    shop_speech = "Welcome! Drag goods to your truck to buy."

    # Ranch Scene state
    active_ranch: RanchData | None = None
    ranch_exit_sign = pygame.Rect(18, 12, 92, 34)
    ranch_arrow_right = pygame.Rect(SCREEN_W - 58, 292, 44, 64)
    ranch_arrow_left = pygame.Rect(14, 292, 44, 64)
    ranch_pending_horse: SceneHorse | None = None
    ranch_speech = ""
    ranch_view_x = 0.0
    ranch_view_target = 0.0
    ranch_offers: dict[tuple[int, int], int] = {}
    purchased_prices: dict[int, int] = {}

    # Your Ranch & Breeding Shed state
    your_ranch_exit_sign = pygame.Rect(18, 12, 92, 34)
    your_ranch_sleep_sign = pygame.Rect(955, 12, 136, 34)
    breeding_active = False
    breeding_timer = 0.0
    breeding_parents: list[HorseEntry] = []
    shed_notice = ""
    shed_notice_timer = 0.0
    sleep_banner = ""
    sleep_banner_timer = 0.0

    # Gene Factory dialogue. The intro plays once; $300 unlocks the extractor for good.
    gene_exit_sign = pygame.Rect(18, 12, 92, 34)
    jean_line = 0
    jean_intro_index = 0
    jean_intro_done = False
    jean_line_timer = 0.0
    jean_override = ""
    jean_override_timer = 0.0
    gene_lever_anim = 0.0
    gene_paid = False
    gene_fill = 0.0
    gene_pending: Genome | None = None
    gene_pending_kind = "potion"
    gene_mode_idx = 0
    gene_slot_drive: Genome | None = None
    # Gene Map & Splice Editor state
    gm_nodes: list[MapGeneNode] = []
    gm_truck_x = GM_WIDTH * 0.5
    gm_truck_y = GM_HEIGHT * 0.5
    gm_truck_facing = 1
    gm_cam_x = 0.0
    gm_cam_y = 0.0
    gm_exit_sign = pygame.Rect(18, 12, 54, 42)
    gm_lasso_target: MapGeneNode | None = None
    gm_lasso_phase = "shoot"
    gm_lasso_progress = 0.0
    gm_lasso_sx = 0.0
    gm_lasso_sy = 0.0
    truck_return_scene = "world"
    editing_strand_entry: HorseEntry | None = None
    editing_strand_locus = ""
    splice_return_scene = "truck"
    splice_back_sign = pygame.Rect(18, 12, 54, 42)
    splice_dispenser_rects: list[tuple[str, pygame.Rect]] = [
        ("A", pygame.Rect(SCREEN_W - 196, 16, 40, 40)),
        ("C", pygame.Rect(SCREEN_W - 148, 16, 40, 40)),
        ("G", pygame.Rect(SCREEN_W - 100, 16, 40, 40)),
        ("T", pygame.Rect(SCREEN_W - 52, 16, 40, 40)),
    ]
    splice_space: pymunk.Space | None = None
    splice_nodes: list[SpliceNucleotideNode] = []
    splice_slots: dict[tuple[int, int], tuple[float, float, float]] = {}
    splice_mouse_body = pymunk.Body(body_type=pymunk.Body.KINEMATIC)
    splice_mouse_joint: pymunk.PivotJoint | None = None
    splice_drag_node: SpliceNucleotideNode | None = None
    met_npc_ids: set[int] = set()
    shop_welcomed = False

    # DNA Lab state
    dna_vat_pool: list[Genome] = []
    dna_vat_visual_fill = 0.0
    dna_exit_sign = pygame.Rect(18, 12, 92, 34)
    dna_guide_line = 0
    dna_guide_timer = 0.0
    dna_guide_override = ""
    dna_guide_override_timer = 0.0
    dna_guide_done = False
    dna_sim_active = False
    dna_sim_total = 15
    dna_sim_done = 0
    dna_sim_times: list[float] = []
    dna_sim_elites: list[tuple[float, Genome]] = []
    dna_sim_avg_time = 0.0
    dna_sim_diversity = 0.0
    dna_sim_best_genome: Genome | None = None
    dna_sim_best_time = 9999.0
    dna_flash_timer = 0.0
    dna_flash_races = 0
    dna_flash_progress = [0.0] * 5
    dna_flash_speeds = [0.85, 0.95, 1.05, 0.90, 1.00]
    dna_flash_colors = list(BOLD_NAME_COLORS[:5])

    # Hover & inline rename state (for owned horses)
    hover_entry: HorseEntry | None = None
    hover_card_rect: pygame.Rect | None = None
    hover_name_rect: pygame.Rect | None = None
    hover_owned = False
    renaming_entry: HorseEntry | None = None
    rename_text = ""
    rename_anchor: tuple[float, float] = (0.0, 0.0)
    track_player_name_rects: list[tuple[HorseEntry, pygame.Rect]] = []

    shopkeeper_entry = factory.create_rancher("Outfitter")
    shopkeeper_entry.name = "Shopkeep"

    # --- HELPERS ---

    def nearest_arena_from(x: float, y: float) -> RacecourseData | None:
        arenas = [rc for rc in world.racecourses if rc.is_arena]
        if not arenas:
            return None
        return min(arenas, key=lambda rc: math.hypot(rc.x - x, rc.y - y))

    def compass_direction(dx: float, dy: float) -> str:
        ang = math.degrees(math.atan2(dy, dx))
        dirs = (
            "EAST",
            "SOUTHEAST",
            "SOUTH",
            "SOUTHWEST",
            "WEST",
            "NORTHWEST",
            "NORTH",
            "NORTHEAST",
        )
        return dirs[int(((ang + 22.5) % 360.0) // 45.0)]

    def clamp_bet(val: int) -> int:
        if bankroll <= 0:
            return 0
        return max(1, min(bankroll, val))

    def start_track_race():
        nonlocal track_state, active_bet, active_bet_lane, bankroll, race_time, winner_lane, status_banner
        if track_state != "betting":
            return
        if race_mode == "bet":
            active_bet = clamp_bet(bet_amount)
            active_bet_lane = selected_lane
            bankroll -= active_bet
        else:
            active_bet = 0
            active_bet_lane = 2
        race_time = 0.0
        winner_lane = None
        status_banner = ""
        track_state = "racing"

        for lane in lanes:
            lane.place = None
            lane.creature.config.gait.mode = "run"
            lane.creature.config.gait.enabled = True
            lane.creature.gait_phase = rng.uniform(0.0, 2.0 * math.pi)

    def start_new_track_session(mode: str, player_horse: HorseEntry | None = None):
        nonlocal scene, race_mode, lanes, track_state, track_cam_x, bet_amount, active_bet, active_bet_lane
        nonlocal winner_lane, status_banner, race_num, selected_lane
        commit_rename()
        clear_hover_and_rename()
        race_mode = mode
        race_num += 1
        r_kind = mode if mode in ("muddy_tracks", "stronghorse") else ("championship" if mode == "championship" else "standard")
        lanes = prepare_race_lineup(
            world.ranches,
            factory,
            trial_space,
            trial_floor,
            lane_spaces,
            lanes,
            rng,
            player_horse=player_horse,
            extra_pool=world.race_pool_newcomers,
            championship=(mode == "championship"),
            race_kind=r_kind,
        )
        selected_lane = 2 if player_horse is not None else 0
        bet_amount = clamp_bet(min(10, bankroll) if bet_amount == 0 else bet_amount)
        active_bet = 0
        active_bet_lane = -1
        winner_lane = None
        status_banner = ""
        track_cam_x = START_CAM_X
        track_state = "betting"
        scene = "racecourse_track"

    def is_inside_truck(x: float, y: float, truck_left: float, truck_floor_y: float) -> bool:
        return (
            truck_left - 25.0 <= x <= truck_left + STD_TRUCK_TRAILER_W + 25.0
            and truck_floor_y - STD_TRUCK_TRAILER_H - 60.0 <= y <= truck_floor_y + 40.0
        )

    def is_in_ranch_pen(x: float, y: float) -> bool:
        return (
            RANCH_PEN_X1 - 20.0 <= x <= RANCH_PEN_X2 + 20.0
            and RANCH_PEN_FLOOR_Y - 220.0 <= y <= RANCH_PEN_FLOOR_Y + 30.0
        )

    def is_in_rabbit_pen(x: float, y: float) -> bool:
        return (
            PHYS_W + RANCH_PEN_X1 - 20.0 <= x <= PHYS_W + RANCH_PEN_X2 + 20.0
            and RANCH_PEN_FLOOR_Y - 220.0 <= y <= RANCH_PEN_FLOOR_Y + 30.0
        )

    def is_in_sale_pen(x: float, y: float) -> bool:
        if is_in_ranch_pen(x, y):
            return True
        return active_ranch is not None and active_ranch.has_rabbit_pen and is_in_rabbit_pen(x, y)

    def is_in_ranch_pen_interior(x: float, y: float) -> bool:
        return (
            RANCH_PEN_X1 + 8.0 <= x <= RANCH_PEN_X2 - 8.0
            and RANCH_PEN_FLOOR_Y - 175.0 <= y <= RANCH_PEN_FLOOR_Y + 25.0
        )

    def is_in_rabbit_pen_interior(x: float, y: float) -> bool:
        return (
            PHYS_W + RANCH_PEN_X1 + 8.0 <= x <= PHYS_W + RANCH_PEN_X2 - 8.0
            and RANCH_PEN_FLOOR_Y - 175.0 <= y <= RANCH_PEN_FLOOR_Y + 25.0
        )

    def try_confirm_ranch_transfer(sh: SceneHorse, strict_interior: bool = False) -> bool:
        nonlocal bankroll, ranch_pending_horse, ranch_speech
        if active_ranch is None or sh.entry.is_rancher:
            return False
        pos = sh.creature.bodies["torso"].position
        bot_y = max((s.bb.bottom for s in sh.creature.shapes.values()), default=pos.y)
        rancher_ko = (
            active_ranch.rancher_entry is None
            or active_ranch.rancher_entry.is_unconscious
            or active_ranch.rancher_entry in truck_horses
        )

        if strict_interior:
            tr_top = RANCH_TRUCK_FLOOR_Y - STD_TRUCK_TRAILER_H
            in_truck = (
                RANCH_TRUCK_LEFT <= pos.x <= RANCH_TRUCK_LEFT + STD_TRUCK_TRAILER_W
                and (
                    tr_top - 40.0 <= pos.y <= RANCH_TRUCK_FLOOR_Y + 40.0
                    or tr_top + 10.0 <= bot_y <= RANCH_TRUCK_FLOOR_Y + 40.0
                )
            )
            in_main_pen = (
                RANCH_PEN_X1 <= pos.x <= RANCH_PEN_X2
                and (
                    RANCH_PEN_FLOOR_Y - 220.0 <= pos.y <= RANCH_PEN_FLOOR_Y + 30.0
                    or RANCH_PEN_FLOOR_Y - 175.0 <= bot_y <= RANCH_PEN_FLOOR_Y + 30.0
                )
            )
            in_rabbit = (
                active_ranch.has_rabbit_pen
                and PHYS_W + RANCH_PEN_X1 <= pos.x <= PHYS_W + RANCH_PEN_X2
                and (
                    RANCH_PEN_FLOOR_Y - 220.0 <= pos.y <= RANCH_PEN_FLOOR_Y + 30.0
                    or RANCH_PEN_FLOOR_Y - 175.0 <= bot_y <= RANCH_PEN_FLOOR_Y + 30.0
                )
            )
            in_pen = in_main_pen or in_rabbit
        else:
            in_truck = is_inside_truck(pos.x, pos.y, RANCH_TRUCK_LEFT, RANCH_TRUCK_FLOOR_Y)
            in_rabbit = active_ranch.has_rabbit_pen and is_in_rabbit_pen(pos.x, pos.y)
            in_pen = is_in_sale_pen(pos.x, pos.y)

        if not sh.owned_by_player:
            if in_truck:
                if rancher_ko:
                    hx, hy = ranch_return_pos(sh.entry)
                    move_scene_horse_to(sh, hx, hy)
                    sh.creature.config.gait.mode = "walk"
                    sh.creature.config.gait.enabled = False
                elif bankroll >= sh.entry.price:
                    bankroll -= sh.entry.price
                    purchased_prices[sh.entry.entry_id] = sh.entry.price
                    sh.owned_by_player = True
                    sh.creature.config.gait.mode = "walk"
                    sh.creature.config.gait.enabled = False
                    if sh.entry in active_ranch.horses:
                        active_ranch.horses.remove(sh.entry)
                    if sh.entry in active_ranch.rabbits:
                        active_ranch.rabbits.remove(sh.entry)
                    truck_horses.append(sh.entry)
                    if ranch_pending_horse is sh:
                        ranch_pending_horse = None
                    ranch_speech = "Deal"
                else:
                    hx, hy = ranch_return_pos(sh.entry)
                    move_scene_horse_to(sh, hx, hy)
                    sh.creature.config.gait.mode = "walk"
                    sh.creature.config.gait.enabled = False
                    if ranch_pending_horse is sh:
                        ranch_pending_horse = None
                    ranch_speech = f"Not enough cash! Need ${sh.entry.price}"
                return True
        else:
            if in_pen and not rancher_ko:
                offer = get_ranch_buy_offer(active_ranch, sh.entry)
                bankroll += offer
                sh.entry.price = max(sh.entry.price, int(round(offer * 1.45)) + 10)
                sh.owned_by_player = False
                sh.creature.config.gait.mode = "walk"
                sh.creature.config.gait.enabled = False
                if sh.entry in truck_horses:
                    truck_horses.remove(sh.entry)
                if in_rabbit:
                    active_ranch.rabbits.append(sh.entry)
                else:
                    active_ranch.horses.append(sh.entry)
                ranch_speech = "Thank you"
                return True

        return False

    def ranch_return_pos(entry: HorseEntry) -> tuple[float, float]:
        if entry.is_rabbit and active_ranch is not None and active_ranch.has_rabbit_pen:
            return (PHYS_W + RANCH_PEN_X1 + 280.0, RANCH_PEN_FLOOR_Y)
        return (RANCH_PEN_X1 + 420.0, RANCH_PEN_FLOOR_Y)

    def is_inside_shed(x: float, y: float) -> bool:
        return (
            SHED_X1 + 15.0 <= x <= SHED_X2 - 15.0
            and SHED_TOP <= y <= SHED_FLOOR_Y + 25.0
        )

    def move_scene_horse_to(sh_obj: SceneHorse, target_x: float, floor_y: float):
        torso = sh_obj.creature.bodies["torso"]
        dx = target_x - torso.position.x
        dy = compute_spawn_y(sh_obj.entry.config, floor_y) - torso.position.y
        for b in set(sh_obj.creature.bodies.values()):
            b.position = (b.position.x + dx, b.position.y + dy)
            b.velocity = (0.0, 0.0)
            b.angular_velocity = 0.0

    def spawn_truck_props(truck_left: float, truck_floor_y: float):
        hay_vis = min(truck_hay, 10)
        for i in range(hay_vis):
            px = truck_left + 70.0 + (i % 5) * 62.0
            py = truck_floor_y - 22.0 - (i // 5) * 34.0
            phys_scene.spawn_prop("hay", px, py, from_shop=False)
        apple_vis = min(truck_apples, 10)
        for i in range(apple_vis):
            px = truck_left + 320.0 + (i % 4) * 28.0
            py = truck_floor_y - 20.0 - (i // 4) * 26.0
            phys_scene.spawn_prop("apple", px, py, from_shop=False)
        pear_vis = min(truck_prickly_pears, 8)
        for i in range(pear_vis):
            px = truck_left + 390.0 + (i % 3) * 26.0
            py = truck_floor_y - 20.0 - (i // 3) * 26.0
            phys_scene.spawn_prop("prickly_pear", px, py, from_shop=False)
        chili_vis = min(truck_chilis, 8)
        for i in range(chili_vis):
            px = truck_left + 640.0 + (i % 3) * 28.0
            py = truck_floor_y - 18.0 - (i // 3) * 24.0
            phys_scene.spawn_prop("chili", px, py, from_shop=False)
        for idx_c, crate in enumerate(truck_apple_crates[:4]):
            if crate[0] <= 0:
                continue
            pr = phys_scene.spawn_prop(
                "apple_crate",
                truck_left + 210.0 + (idx_c % 2) * 58.0,
                truck_floor_y - 28.0 - (idx_c // 2) * 48.0,
                from_shop=False,
            )
            pr.uses_left = crate[0]
            pr.crate_ref = crate
        beer_vis = min(truck_beer, 12)
        for i in range(beer_vis):
            px = truck_left + 460.0 + (i % 6) * 42.0
            py = truck_floor_y - 24.0 - (i // 6) * 42.0
            phys_scene.spawn_prop("beer", px, py, from_shop=False)
        spawned_genomes = {id(p.genome) for p in phys_scene.props if p.genome is not None}
        shown = 0
        for genome in truck_potions:
            if id(genome) in spawned_genomes or shown >= 8:
                continue
            px = truck_left + 720.0 + (shown % 3) * 38.0
            py = truck_floor_y - 28.0 - (shown // 3) * 42.0
            phys_scene.spawn_prop("potion", px, py, from_shop=False, genome=genome)
            shown += 1
        shown_d = 0
        for genome in truck_drives:
            if id(genome) in spawned_genomes or shown_d >= 8:
                continue
            px = truck_left + 865.0 + (shown_d % 3) * 42.0
            py = truck_floor_y - 20.0 - (shown_d // 3) * 28.0
            phys_scene.spawn_prop("drive", px, py, from_shop=False, genome=genome)
            shown_d += 1
        shown_f = 0
        for idx_m, cut in enumerate(truck_meats[:3]):
            if cut.uses[0] <= 0:
                continue
            pr = phys_scene.spawn_prop(
                "meat",
                truck_left + 470.0 + (idx_m % 2) * 170.0,
                truck_floor_y - 58.0 - (idx_m // 2) * 110.0,
                from_shop=False,
                genome=cut.genome,
            )
            pr.uses_left = cut.uses[0]
            pr.crate_ref = cut.uses
        for genome in truck_fossils:
            if id(genome) in spawned_genomes or shown_f >= 6:
                continue
            px = truck_left + 950.0 + (shown_f % 2) * 44.0
            py = truck_floor_y - 22.0 - (shown_f // 2) * 36.0
            phys_scene.spawn_prop("fossil", px, py, from_shop=False, genome=genome)
            shown_f += 1

    def replenish_truck_prop_if_needed(kind: str, truck_left: float, truck_floor_y: float):
        existing = sum(1 for p in phys_scene.props if not p.from_shop and p.kind == kind)
        if kind == "hay" and truck_hay > existing and existing < 10:
            phys_scene.spawn_prop("hay", truck_left + 120.0, truck_floor_y - 45.0, from_shop=False)
        elif kind == "apple" and truck_apples > existing and existing < 10:
            phys_scene.spawn_prop("apple", truck_left + 340.0, truck_floor_y - 45.0, from_shop=False)
        elif kind == "prickly_pear" and truck_prickly_pears > existing and existing < 8:
            phys_scene.spawn_prop("prickly_pear", truck_left + 390.0, truck_floor_y - 45.0, from_shop=False)
        elif kind == "chili" and truck_chilis > existing and existing < 8:
            phys_scene.spawn_prop("chili", truck_left + 640.0, truck_floor_y - 45.0, from_shop=False)
        elif kind == "beer" and truck_beer > existing and existing < 12:
            phys_scene.spawn_prop("beer", truck_left + 500.0, truck_floor_y - 45.0, from_shop=False)

    def return_prop_to_truck(prop: SceneProp, truck_left: float, truck_floor_y: float):
        if prop.kind == "hay":
            rx = truck_left + 140.0
        elif prop.kind == "apple":
            rx = truck_left + 340.0
        elif prop.kind == "prickly_pear":
            rx = truck_left + 390.0
        elif prop.kind == "apple_crate":
            rx = truck_left + 230.0
        elif prop.kind == "chili":
            rx = truck_left + 640.0
        elif prop.kind == "fossil":
            rx = truck_left + 955.0
        elif prop.kind == "potion":
            rx = truck_left + 760.0
        elif prop.kind == "drive":
            rx = truck_left + 910.0
        else:
            rx = truck_left + 520.0
        phys_scene.move_prop_to(prop, rx, truck_floor_y - 40.0)

    def active_scene_npc() -> SceneHorse | None:
        return next(
            (s for s in phys_scene.horses if s.entry.is_rancher and not s.owned_by_player),
            None,
        )

    def set_active_npc_speech(text: str):
        nonlocal ranch_speech, shop_speech, jean_override, jean_override_timer
        npc_sh = active_scene_npc()
        if text and (npc_sh is None or npc_sh.entry.is_unconscious):
            return
        if scene == "ranch":
            ranch_speech = text
        elif scene == "shop":
            shop_speech = text
        elif scene == "gene_factory":
            jean_override = text
            jean_override_timer = 4.0 if text else 0.0
        elif scene == "dna_lab":
            dna_guide_override = text
            dna_guide_override_timer = 2.6 if text else 0.0

    def sync_truck_horses_from_scene():
        new_truck: list[HorseEntry] = []
        for sh in phys_scene.horses:
            if sh.owned_by_player and sh.entry not in new_truck:
                new_truck.append(sh.entry)
        truck_horses[:] = new_truck

    def handle_npc_capture_release(
        released: SceneHorse,
        scene_npc: HorseEntry | None,
        truck_left: float,
        truck_floor_y: float,
    ) -> bool:
        if scene_npc is None or released.entry is not scene_npc:
            return False
        pos = released.creature.bodies["torso"].position
        if released.entry.is_unconscious and is_inside_truck(pos.x, pos.y, truck_left, truck_floor_y):
            released.owned_by_player = True
            if released.entry not in truck_horses:
                truck_horses.append(released.entry)
        else:
            released.owned_by_player = False
            if released.entry in truck_horses:
                truck_horses.remove(released.entry)
        return True

    def begin_bite(prop: SceneProp, horse: SceneHorse, truck_left: float, truck_floor_y: float):
        if any(b.horse is horse or b.prop is prop for b in active_bites):
            return_prop_to_truck(prop, truck_left, truck_floor_y)
            return
        prop.locked = True
        prop.shape.filter = pymunk.ShapeFilter(categories=0b100, mask=0)
        horse.creature.eat_time = 1.0
        mx, my = horse.creature.mouth_world_pos()
        phys_scene.move_prop_to(prop, mx, my)
        active_bites.append(ActiveBite(prop, horse, 1.0, truck_left, truck_floor_y))

    def respawn_scene_horse(sh: SceneHorse) -> SceneHorse:
        entry = sh.entry
        torso = sh.creature.bodies["torso"]
        x = torso.position.x
        floor_y = max(s.bb.bottom for s in sh.creature.shapes.values())
        owned = sh.owned_by_player
        home = sh.home_x
        phys_scene.remove_horse(sh)
        born = phys_scene.spawn_horse(entry, x, floor_y, owned_by_player=owned)
        born.home_x = home
        return born

    def finish_bite(bite: ActiveBite):
        nonlocal truck_hay, truck_beer, truck_apples, truck_prickly_pears, truck_chilis, ranch_speech
        prop = bite.prop
        horse = bite.horse
        horse.creature.eat_time = 0.0
        entry = horse.entry
        kind = prop.kind
        if kind in ("hay", "apple", "apple_crate"):
            if kind == "hay":
                truck_hay = max(0, truck_hay - 1)
            elif kind == "apple":
                truck_apples = max(0, truck_apples - 1)
            else:
                prop.uses_left = max(0, prop.uses_left - 1)
                if prop.crate_ref is not None:
                    prop.crate_ref[0] = prop.uses_left
            entry.is_hungry = False
            entry.hunger_clock = 0.0
            entry.days_hungry = 0
            horse.creature.hungry = False
            if scene == "ranch" and not horse.owned_by_player and not entry.is_rancher:
                set_active_npc_speech(f"Thanks for feeding {entry.name}!")
            if kind == "apple_crate" and prop.uses_left > 0:
                prop.locked = False
                prop.shape.filter = pymunk.ShapeFilter(categories=0b100, mask=0b01)
                return_prop_to_truck(prop, bite.truck_left, bite.truck_floor)
                return
            if kind == "apple_crate" and prop.crate_ref in truck_apple_crates:
                truck_apple_crates.remove(prop.crate_ref)
        elif kind == "meat":
            prop.uses_left = max(0, prop.uses_left - 1)
            if prop.crate_ref is not None:
                prop.crate_ref[0] = prop.uses_left
            entry.is_hungry = False
            entry.hunger_clock = 0.0
            entry.days_hungry = 0
            horse.creature.hungry = False
            if prop.uses_left > 0:
                prop.locked = False
                prop.shape.filter = pymunk.ShapeFilter(categories=0b100, mask=0b01)
                return_prop_to_truck(prop, bite.truck_left, bite.truck_floor)
                return
            truck_meats[:] = [cut for cut in truck_meats if cut.uses is not prop.crate_ref]
        elif kind == "prickly_pear":
            truck_prickly_pears = max(0, truck_prickly_pears - 1)
            entry.is_hungry = False
            entry.hunger_clock = 0.0
            entry.days_hungry = 0
            horse.creature.hungry = False
            entry.orange_boost = min(1.0, entry.orange_boost + 0.25)
            refresh_entry_config_for_age(entry)
            phys_scene.remove_prop(prop)
            respawn_scene_horse(horse)
            replenish_truck_prop_if_needed("prickly_pear", bite.truck_left, bite.truck_floor)
            return
        elif kind == "chili":
            truck_chilis = max(0, truck_chilis - 1)
            entry.drunk_level = 0
            entry.is_unconscious = False
            entry.is_tired = False
            entry.is_frenzied = True
            sync_creature_state(entry, horse.creature)
            if scene == "ranch" and not horse.owned_by_player and not entry.is_rancher:
                set_active_npc_speech(f"Whoa! {entry.name} is fired up!")
        elif kind == "beer":
            truck_beer = max(0, truck_beer - 1)
            entry.drunk_level += 1
            sync_creature_state(entry, horse.creature)
            if entry.is_unconscious:
                if horse is active_scene_npc():
                    set_active_npc_speech("")
            elif not horse.owned_by_player:
                if entry.is_rancher:
                    set_active_npc_speech(
                        rng.choice(["*hic* Mighty fine brew!", "Whoa... *hic* spinning!"])
                    )
                elif scene == "ranch":
                    set_active_npc_speech(f"Hey! You got {entry.name} drunk!")
        elif kind in ("potion", "drive") and prop.genome is not None and entry.genome is not None:
            entry.genome = entry.genome.nudge_toward(prop.genome, strength=0.22, rng=rng)
            refresh_entry_config_for_age(entry)
            if kind == "potion":
                truck_potions[:] = [g for g in truck_potions if g is not prop.genome]
            else:
                truck_drives[:] = [g for g in truck_drives if g is not prop.genome]
            phys_scene.remove_prop(prop)
            respawn_scene_horse(horse)
            return
        phys_scene.remove_prop(prop)
        if kind in ("hay", "apple", "beer"):
            replenish_truck_prop_if_needed(kind, bite.truck_left, bite.truck_floor)

    def update_bites(dt_bite: float):
        if scene not in ("truck", "ranch", "your_ranch", "racecourse_hub", "arena_hub", "shop", "gene_factory", "dna_lab"):
            active_bites.clear()
            return
        for bite in list(active_bites):
            if bite.prop not in phys_scene.props or bite.horse not in phys_scene.horses:
                if bite.horse in phys_scene.horses:
                    bite.horse.creature.eat_time = 0.0
                active_bites.remove(bite)
                continue
            bite.timer -= dt_bite
            mx, my = bite.horse.creature.mouth_world_pos()
            phys_scene.move_prop_to(bite.prop, mx, my)
            bite.horse.creature.eat_time = max(0.0, min(1.0, bite.timer))
            if bite.timer <= 0.0:
                finish_bite(bite)
                if bite in active_bites:
                    active_bites.remove(bite)

    def handle_owned_prop_release(prop: SceneProp, truck_left: float, truck_floor_y: float):
        nonlocal ranch_speech, has_infinite_lasso, lasso_armed
        if prop.locked:
            return
        px, py = prop.body.position.x, prop.body.position.y
        if prop.kind == "infinite_lasso":
            if is_inside_truck(px, py, truck_left, truck_floor_y):
                has_infinite_lasso = True
                lasso_armed = True
                phys_scene.remove_prop(prop)
            else:
                phys_scene.move_prop_to(prop, HUB_PEDESTAL_X, HUB_PEDESTAL_TOP_Y - 22.0)
            return
        target = phys_scene.find_horse_near_phys_point(px, py, margin=42.0)
        if target is not None and prop.kind in (
            "hay", "apple", "prickly_pear", "apple_crate", "meat", "chili", "beer", "potion", "drive"
        ):
            if target.entry.is_unconscious and prop.kind != "chili":
                return_prop_to_truck(prop, truck_left, truck_floor_y)
                return
            if not diet_accepts(target.entry.diet, prop.kind):
                return_prop_to_truck(prop, truck_left, truck_floor_y)
                if not target.owned_by_player and target.entry.sentience > 0.35:
                    food = prop.kind.replace("_", " ")
                    set_active_npc_speech(f"I don't eat {food}.")
                return
            if prop.kind in ("potion", "drive") and (prop.genome is None or target.entry.genome is None):
                return_prop_to_truck(prop, truck_left, truck_floor_y)
                return
            begin_bite(prop, target, truck_left, truck_floor_y)
            return
        if not is_inside_truck(px, py, truck_left, truck_floor_y):
            return_prop_to_truck(prop, truck_left, truck_floor_y)

    def get_ranch_buy_offer(ranch: RanchData, entry: HorseEntry) -> int:
        key = (ranch.ranch_id, entry.entry_id)
        too_many = len(ranch.horses) > 12
        local_rng = random.Random(ranch.ranch_id * 10007 + entry.entry_id * 37 + (2 if entry.is_champion else (1 if entry.is_winner else 0)))
        if too_many:
            if entry.is_champion:
                offer = local_rng.randint(45, 70)
            else:
                offer = local_rng.randint(20, 35) if entry.is_winner else local_rng.randint(10, 22)
        else:
            if entry.is_champion:
                offer = local_rng.randint(260, 360)
            else:
                offer = local_rng.randint(145, 200) if entry.is_winner else local_rng.randint(40, 110)
        paid = purchased_prices.get(entry.entry_id)
        if paid is not None:
            offer = min(offer, max(5, int(paid * 0.65)))
        ranch_offers[key] = offer
        return offer

    def clear_hover_and_rename():
        nonlocal hover_entry, hover_card_rect, hover_name_rect, hover_owned, renaming_entry, rename_text
        hover_entry = None
        hover_card_rect = None
        hover_name_rect = None
        hover_owned = False
        renaming_entry = None
        rename_text = ""

    def commit_rename():
        nonlocal renaming_entry, rename_text
        if renaming_entry is not None:
            cleaned = rename_text.strip()
            if cleaned:
                renaming_entry.name = cleaned[:24]
            renaming_entry = None
            rename_text = ""

    def sleep_advance_day():
        nonlocal day, sleep_banner, sleep_banner_timer
        day += 1
        seen: set[int] = set()
        grown_entries: list[HorseEntry] = []
        for entry in list(truck_horses) + list(your_ranch_horses):
            if entry.entry_id in seen:
                continue
            seen.add(entry.entry_id)
            entry.is_tired = False
            entry.drunk_level = 0
            entry.is_unconscious = False
            entry.is_frenzied = False
            if not entry.is_rancher:
                if entry.is_strand:
                    if entry.age < 9:
                        entry.age += 1
                elif entry.is_dead or (entry.lifespan_penalty > 0 and entry.age >= entry.death_age):
                    if entry in truck_horses:
                        truck_horses.remove(entry)
                    if entry in your_ranch_horses:
                        your_ranch_horses.remove(entry)
                    factory.release_name(entry.name)
                    continue
                elif entry.age < 10:
                    prev_age = entry.age
                    entry.age = min(10, entry.age + 1)
                    if prev_age == 0 and entry.age >= 1:
                        refresh_entry_config_for_age(entry)
                        grown_entries.append(entry)
                    if entry.lifespan_penalty > 0 and entry.age >= entry.death_age:
                        entry.is_dead = True
                if not entry.is_hungry and rng.random() < 0.10:
                    entry.is_hungry = True
                    entry.hunger_clock = 0.0

        # Rebuild any SceneHorse that just grew from age 0 -> 1 so visuals match immediately
        for entry in grown_entries:
            for sh in list(phys_scene.horses):
                if sh.entry is entry:
                    pos = sh.creature.bodies["torso"].position
                    fl_y = YOUR_TRUCK_FLOOR_Y if is_inside_truck(pos.x, pos.y, YOUR_TRUCK_LEFT, YOUR_TRUCK_FLOOR_Y) else YOUR_YARD_FLOOR_Y
                    owned = sh.owned_by_player
                    phys_scene.remove_horse(sh)
                    phys_scene.spawn_horse(entry, pos.x, fl_y, owned_by_player=owned)

        for sh in phys_scene.horses:
            sh.entry.is_unconscious = False
            sh.entry.drunk_level = 0
            sh.creature.tired = False
            sh.creature.drunk = False
            sh.creature.unconscious = False
            sh.entry.is_frenzied = False
            sh.creature.frenzied = False
            sh.creature.hungry = sh.entry.is_hungry

        world.simulate_day()
        sleep_banner = f"Day {day} - Rested, aged & world updated!"
        sleep_banner_timer = 3.2

    def enter_truck_scene(return_to: str = "world"):
        nonlocal scene, truck_return_scene
        clear_hover_and_rename()
        truck_return_scene = return_to
        phys_scene.reset()
        phys_scene.add_screen_bounds()
        add_truck_walls(phys_scene, TRUCK_SCENE_LEFT, TRUCK_SCENE_FLOOR_Y)
        for idx, entry in enumerate(truck_horses):
            sx = TRUCK_SCENE_LEFT + 140.0 + ((idx * 170) % int(STD_TRUCK_TRAILER_W - 260))
            phys_scene.spawn_horse(entry, sx, TRUCK_SCENE_FLOOR_Y, owned_by_player=True)
        spawn_truck_props(TRUCK_SCENE_LEFT, TRUCK_SCENE_FLOOR_Y)
        scene = "truck"

    def leave_truck_scene():
        nonlocal scene
        commit_rename()
        clear_hover_and_rename()
        phys_scene.reset()
        scene = truck_return_scene

    def enter_racecourse_hub(course: RacecourseData | None = None):
        nonlocal scene, active_course
        clear_hover_and_rename()
        if course is not None:
            active_course = course
        phys_scene.reset()
        phys_scene.add_screen_bounds()
        add_truck_walls(phys_scene, HUB_TRUCK_LEFT, HUB_TRUCK_FLOOR_Y)
        add_open_pen_walls(phys_scene, HUB_PEN_X1, HUB_PEN_X2, HUB_PEN_FLOOR_Y)
        if championship_won:
            phys_scene.add_floor_slab(HUB_PEDESTAL_X - 48.0, HUB_PEDESTAL_X + 48.0, HUB_PEDESTAL_TOP_Y, thickness=72.0, friction=0.95)
            if not has_infinite_lasso:
                phys_scene.spawn_prop("infinite_lasso", HUB_PEDESTAL_X, HUB_PEDESTAL_TOP_Y - 24.0)
        for idx, entry in enumerate(truck_horses):
            sx = HUB_TRUCK_LEFT + 140.0 + ((idx * 170) % int(STD_TRUCK_TRAILER_W - 260))
            phys_scene.spawn_horse(entry, sx, HUB_TRUCK_FLOOR_Y, owned_by_player=True)
        spawn_truck_props(HUB_TRUCK_LEFT, HUB_TRUCK_FLOOR_Y)
        scene = "racecourse_hub"

    def enter_arena_hub(course: RacecourseData):
        nonlocal scene, active_course
        clear_hover_and_rename()
        active_course = course
        phys_scene.reset()
        phys_scene.add_screen_bounds()
        add_truck_walls(phys_scene, HUB_TRUCK_LEFT, HUB_TRUCK_FLOOR_Y)
        add_open_pen_walls(phys_scene, HUB_PEN_X1, HUB_PEN_X2, HUB_PEN_FLOOR_Y)
        for idx, entry in enumerate(truck_horses):
            sx = HUB_TRUCK_LEFT + 140.0 + ((idx * 170) % int(STD_TRUCK_TRAILER_W - 260))
            phys_scene.spawn_horse(entry, sx, HUB_TRUCK_FLOOR_Y, owned_by_player=True)
        spawn_truck_props(HUB_TRUCK_LEFT, HUB_TRUCK_FLOOR_Y)
        scene = "arena_hub"

    def get_hub_pen_horse() -> SceneHorse | None:
        for sh in phys_scene.horses:
            if sh is phys_scene.dragged_horse:
                continue
            tx = sh.creature.bodies["torso"].position.x
            if HUB_PEN_X1 - 20.0 <= tx <= HUB_PEN_X2 + 20.0:
                return sh
        return None

    def leave_racecourse_hub():
        nonlocal scene
        commit_rename()
        clear_hover_and_rename()
        phys_scene.reset()
        scene = "world"

    def say_rancher_greeting(entry: HorseEntry) -> str:
        if entry.entry_id in met_npc_ids:
            return ""
        met_npc_ids.add(entry.entry_id)
        return rng.choice(RANCHER_GREETINGS)

    def enter_shop(shop: ShopData):
        nonlocal scene, active_shop, shop_speech, shop_welcomed
        clear_hover_and_rename()
        active_shop = shop
        if (
            shop.shopkeeper_entry is None
            or shop.shopkeeper_entry in truck_horses
            or shop.shopkeeper_entry in your_ranch_horses
        ):
            shop.shopkeeper_entry = factory.create_shopkeep(shop.name)

        if shop.shopkeeper_entry.is_unconscious:
            shop_speech = ""
        elif shop_welcomed:
            shop_speech = ""
        else:
            shop_speech = "Welcome! Drag goods to your truck to buy."
            shop_welcomed = True

        phys_scene.reset()
        phys_scene.add_screen_bounds()
        # Left counter floor for shopkeeper area + 3 sturdy display shelves
        phys_scene.add_floor_slab(-40.0, 930.0, 1195.0, thickness=80.0, friction=0.95)
        shelf_items = (
            [("chili", 410.0), ("apple_crate", 680.0)]
            if shop.shop_kind == "convenience"
            else [("lasso", SHOP_SHELF_YS["lasso"]), ("hay", SHOP_SHELF_YS["hay"]), ("beer", SHOP_SHELF_YS["beer"])]
        )
        for kind, sy in shelf_items:
            phys_scene.add_floor_slab(SHOP_SHELF_X1, SHOP_SHELF_X2, sy, thickness=22.0, friction=0.95)
            count = shop.stock.get(kind, 0)
            span = (SHOP_SHELF_X2 - SHOP_SHELF_X1) - 90.0
            for i in range(count):
                step = span / max(1, count)
                px = SHOP_SHELF_X1 + 50.0 + i * min(78.0 if kind == "apple_crate" else 54.0, step)
                py = sy - 28.0
                pr = phys_scene.spawn_prop(
                    kind,
                    px,
                    py,
                    from_shop=True,
                    home_pos=(px, py),
                    price=ITEM_PRICES[kind],
                )
                if kind == "apple_crate":
                    pr.uses_left = 25

        add_truck_walls(phys_scene, SHOP_TRUCK_LEFT, SHOP_TRUCK_FLOOR_Y)
        keeper = phys_scene.spawn_horse(shop.shopkeeper_entry, 170.0, SHOP_TRUCK_FLOOR_Y, owned_by_player=False)
        keeper.home_x = 170.0
        for idx, entry in enumerate(truck_horses):
            sx = SHOP_TRUCK_LEFT + 140.0 + ((idx * 170) % int(STD_TRUCK_TRAILER_W - 260))
            phys_scene.spawn_horse(entry, sx, SHOP_TRUCK_FLOOR_Y, owned_by_player=True)
        spawn_truck_props(SHOP_TRUCK_LEFT, SHOP_TRUCK_FLOOR_Y)
        scene = "shop"

    def leave_shop():
        nonlocal scene, active_shop
        commit_rename()
        clear_hover_and_rename()
        sync_truck_horses_from_scene()
        if active_shop is not None and (
            active_shop.shopkeeper_entry is None
            or active_shop.shopkeeper_entry in truck_horses
        ):
            active_shop.shopkeeper_entry = factory.create_shopkeep(active_shop.name)
        phys_scene.reset()
        active_shop = None
        scene = "world"

    def enter_ranch(ranch: RanchData):
        nonlocal scene, active_ranch, ranch_pending_horse, ranch_speech, ranch_view_x, ranch_view_target
        clear_hover_and_rename()
        active_ranch = ranch
        ranch_pending_horse = None
        ranch_view_x = 0.0
        ranch_view_target = 0.0
        ranch_offers.clear()
        if (
            ranch.rancher_entry is None
            or ranch.rancher_entry in truck_horses
            or ranch.rancher_entry in your_ranch_horses
        ):
            ranch.rancher_entry = factory.create_rancher(ranch.name)
        ranch_speech = "" if ranch.rancher_entry.is_unconscious else say_rancher_greeting(ranch.rancher_entry)

        phys_scene.reset()
        world_right = PHYS_W * 2.0 if ranch.has_rabbit_pen else None
        phys_scene.add_screen_bounds(right_limit=world_right)
        # Sample track. Ranches with a rabbit pen keep the dirt going one screen further right.
        track_far = (PHYS_W * 2.0 + 250.0) if ranch.has_rabbit_pen else (PHYS_W + 250.0)
        phys_scene.add_floor_slab(-250.0, track_far, RANCH_TRACK_FLOOR_Y, thickness=44.0, friction=1.0)
        # Open wooden Ranch Pen (no ceiling)
        add_open_pen_walls(phys_scene, RANCH_PEN_X1, RANCH_PEN_X2, RANCH_PEN_FLOOR_Y)
        if ranch.has_rabbit_pen:
            add_open_pen_walls(
                phys_scene,
                PHYS_W + RANCH_PEN_X1,
                PHYS_W + RANCH_PEN_X2,
                RANCH_PEN_FLOOR_Y,
            )
        # Bottom-left Rancher ground slab + Standardized Truck bottom-right
        phys_scene.add_floor_slab(-40.0, 930.0, RANCH_TRUCK_FLOOR_Y, thickness=80.0, friction=0.95)
        add_truck_walls(phys_scene, RANCH_TRUCK_LEFT, RANCH_TRUCK_FLOOR_Y)

        # Spawn live Rancher inside UnifiedPhysicsScene
        phys_scene.spawn_horse(ranch.rancher_entry, 185.0, RANCH_TRUCK_FLOOR_Y, owned_by_player=False)

        # Spawn ranch horses as real physics Creatures in the open pen
        for idx, entry in enumerate(ranch.horses):
            sx = RANCH_PEN_X1 + 135.0 + ((idx * 155) % int(RANCH_PEN_X2 - RANCH_PEN_X1 - 250)) + rng.uniform(-18, 18)
            phys_scene.spawn_horse(entry, sx, RANCH_PEN_FLOOR_Y, owned_by_player=False)
        for idx, entry in enumerate(ranch.rabbits):
            sx = PHYS_W + RANCH_PEN_X1 + 160.0 + ((idx * 180) % int(RANCH_PEN_X2 - RANCH_PEN_X1 - 280))
            phys_scene.spawn_horse(entry, sx, RANCH_PEN_FLOOR_Y, owned_by_player=False)

        # Spawn player's truck horses and supplies inside the standardized truck
        for idx, entry in enumerate(truck_horses):
            sx = RANCH_TRUCK_LEFT + 140.0 + ((idx * 170) % int(STD_TRUCK_TRAILER_W - 260))
            phys_scene.spawn_horse(entry, sx, RANCH_TRUCK_FLOOR_Y, owned_by_player=True)
        spawn_truck_props(RANCH_TRUCK_LEFT, RANCH_TRUCK_FLOOR_Y)

        scene = "ranch"

    def leave_ranch():
        nonlocal scene, active_ranch, ranch_pending_horse, ranch_view_x, ranch_view_target
        commit_rename()
        clear_hover_and_rename()
        if active_ranch is not None:
            sync_truck_horses_from_scene()
            # A new rancher replaces one the player hauled away. A KO'd rancher left behind wakes next day.
            r_ent = active_ranch.rancher_entry
            if r_ent is None or r_ent in truck_horses:
                active_ranch.rancher_entry = factory.create_rancher(active_ranch.name)
        phys_scene.reset()
        ranch_pending_horse = None
        ranch_view_x = 0.0
        ranch_view_target = 0.0
        active_ranch = None
        scene = "world"

    def gene_lever_screen_rect() -> pygame.Rect:
        px = int(GENE_MACH_X2 * SCENE_SCALE) - 2
        py = int((GENE_MACH_TOP + 125.0) * SCENE_SCALE)
        return pygame.Rect(px - 10, py - 58, 76, 116)

    def gene_knob_screen_rect() -> pygame.Rect:
        mx2 = int(GENE_MACH_X2 * SCENE_SCALE)
        my2 = int(GENE_MACH_FLOOR * SCENE_SCALE)
        return pygame.Rect(mx2 - 74, my2 - 66, 46, 46)

    def gene_slot_screen_rect() -> pygame.Rect:
        mx1 = int(GENE_MACH_X1 * SCENE_SCALE)
        my2 = int(GENE_MACH_FLOOR * SCENE_SCALE)
        return pygame.Rect(mx1 + 24, my2 - 58, 92, 34)

    def is_in_drive_slot(px: float, py: float) -> bool:
        r = gene_slot_screen_rect()
        sx, sy = px * SCENE_SCALE, py * SCENE_SCALE
        return r.inflate(26, 26).collidepoint(sx, sy)

    def is_in_convert_zone(px: float, py: float) -> bool:
        in_box = (
            GENE_BOX_X1 + 10.0 <= px <= GENE_BOX_X2 - 10.0
            and GENE_BOX_TOP - 30.0 <= py <= GENE_BOX_FLOOR + 24.0
        )
        in_funnel = (
            GENE_FUNNEL_X1 - 20.0 <= px <= GENE_FUNNEL_X2 + 20.0
            and GENE_FUNNEL_TOP - 30.0 <= py <= GENE_FUNNEL_FLOOR + 24.0
        )
        return in_box or in_funnel

    def advance_jean_intro():
        nonlocal jean_line, jean_intro_index, jean_intro_done, jean_line_timer
        if jean_intro_done:
            return
        if jean_line < len(JEAN_LINES) - 1:
            jean_line += 1
            jean_intro_index = jean_line
            if jean_line >= len(JEAN_LINES) - 1:
                jean_intro_done = True
        jean_line_timer = 0.0

    def commit_pending_potion(spawn_here: bool):
        nonlocal gene_fill, gene_pending, gene_pending_kind
        if gene_pending is None:
            gene_fill = 0.0
            return
        snap = gene_pending
        kind_out = gene_pending_kind
        gene_pending = None
        gene_fill = 0.0
        if kind_out == "drive":
            truck_drives.append(snap)
        else:
            truck_potions.append(snap)
        if spawn_here:
            phys_scene.spawn_prop(kind_out, GENE_FLASK_X, GENE_FLASK_Y, genome=snap)

    def horses_in_gene_box() -> list[SceneHorse]:
        found: list[SceneHorse] = []
        for sh in phys_scene.horses:
            if sh is phys_scene.dragged_horse:
                continue
            if sh.entry.is_rancher and not sh.owned_by_player:
                continue
            pos = sh.creature.bodies["torso"].position
            if (
                GENE_BOX_X1 + 18.0 <= pos.x <= GENE_BOX_X2 - 18.0
                and GENE_BOX_TOP - 30.0 <= pos.y <= GENE_BOX_FLOOR + 24.0
            ):
                found.append(sh)
        return found

    def horse_in_gene_box() -> SceneHorse | None:
        found = horses_in_gene_box()
        return found[0] if found else None

    def fossil_in_gene_box() -> SceneProp | None:
        for pr in phys_scene.props:
            if pr is phys_scene.dragged_prop or pr.locked or pr.kind != "fossil" or pr.genome is None:
                continue
            if (
                GENE_BOX_X1 + 10.0 <= pr.body.position.x <= GENE_BOX_X2 - 10.0
                and GENE_BOX_TOP - 30.0 <= pr.body.position.y <= GENE_BOX_FLOOR + 24.0
            ):
                return pr
        return None

    EXTRACTABLE_PROP_KINDS = ("fossil", "hay", "apple", "prickly_pear", "apple_crate", "beer", "chili", "meat")

    def is_in_gene_box(px: float, py: float) -> bool:
        return (
            GENE_BOX_X1 + 10.0 <= px <= GENE_BOX_X2 - 10.0
            and GENE_BOX_TOP - 30.0 <= py <= GENE_BOX_FLOOR + 24.0
        )

    def props_in_gene_box() -> list[SceneProp]:
        found: list[SceneProp] = []
        for pr in phys_scene.props:
            if pr is phys_scene.dragged_prop or pr.locked:
                continue
            if pr.kind not in EXTRACTABLE_PROP_KINDS:
                continue
            if is_in_gene_box(pr.body.position.x, pr.body.position.y):
                found.append(pr)
        return found

    def prop_in_gene_box() -> SceneProp | None:
        found = props_in_gene_box()
        return found[0] if found else None

    def potion_in_convert_zone() -> SceneProp | None:
        for pr in phys_scene.props:
            if pr is phys_scene.dragged_prop or pr.locked or pr.kind != "potion" or pr.genome is None:
                continue
            if is_in_convert_zone(pr.body.position.x, pr.body.position.y):
                return pr
        return None

    def ensure_jean() -> HorseEntry:
        ent = world.jean_entry
        if ent is None or ent in truck_horses or ent in your_ranch_horses:
            ent = factory.create_rancher("Gene Factory")
            ent.name = "Jean Gene"
            ent.name_color = (198, 146, 255)
            world.jean_entry = ent
        return ent

    def enter_gene_map():
        nonlocal scene, gm_nodes, gm_truck_x, gm_truck_y, gm_truck_facing
        nonlocal gm_lasso_target, gm_lasso_progress
        clear_hover_and_rename()
        gm_lasso_target = None
        gm_lasso_progress = 0.0
        gm_truck_x = GM_WIDTH * 0.5
        gm_truck_y = GM_HEIGHT * 0.5
        gm_truck_facing = 1
        captured_from_drive = {
            h.strand_locus
            for h in truck_horses
            if h.is_strand and h.source_drive is gene_slot_drive
        }
        gm_nodes = []
        cols = 7
        rows = (len(ALL_LOCI) + cols - 1) // cols
        cell_w = (GM_WIDTH - 460.0) / cols
        cell_h = (GM_HEIGHT - 320.0) / rows
        for idx, locus in enumerate(ALL_LOCI):
            if locus in captured_from_drive:
                continue
            c = idx % cols
            r = idx // cols
            gx = 230.0 + (c + 0.5) * cell_w + rng.uniform(-55.0, 55.0)
            gy = 160.0 + (r + 0.5) * cell_h + rng.uniform(-35.0, 35.0)
            if math.hypot(gx - gm_truck_x, gy - gm_truck_y) < 150.0:
                gx += 170.0
            ang = rng.uniform(0.0, 2.0 * math.pi)
            gm_nodes.append(
                MapGeneNode(
                    locus=locus,
                    locus_num=idx + 1,
                    x=gx,
                    y=gy,
                    vx=math.cos(ang) * 18.0,
                    vy=math.sin(ang) * 18.0,
                )
            )
        scene = "gene_map"

    def leave_gene_map():
        nonlocal gm_lasso_target
        gm_lasso_target = None
        enter_gene_factory()

    def build_splice_slots() -> dict[tuple[int, int], tuple[float, float, float]]:
        slots: dict[tuple[int, int], tuple[float, float, float]] = {}
        cx, cy = SCREEN_W * 0.5, 252.0

        def bez_point(
            p0: tuple[float, float],
            p1: tuple[float, float],
            p2: tuple[float, float],
            t: float,
        ) -> tuple[float, float, float]:
            mt = 1.0 - t
            px = mt * mt * p0[0] + 2.0 * mt * t * p1[0] + t * t * p2[0]
            py = mt * mt * p0[1] + 2.0 * mt * t * p1[1] + t * t * p2[1]
            dx = 2.0 * mt * (p1[0] - p0[0]) + 2.0 * t * (p2[0] - p1[0])
            dy = 2.0 * mt * (p1[1] - p0[1]) + 2.0 * t * (p2[1] - p1[1])
            ang = math.atan2(dy, dx) - math.pi * 0.5
            return (px, py, ang)

        # Top-left arm: strand 0, indices 0..7
        p_tl0, p_tl1 = (cx - 38.0, cy - 38.0), (cx - 265.0, 48.0)
        tl_ang = math.atan2(p_tl1[1] - p_tl0[1], p_tl1[0] - p_tl0[0]) - math.pi * 0.5
        for i in range(8):
            t = (i + 0.5) / 8.0
            slots[(0, i)] = (p_tl0[0] + (p_tl1[0] - p_tl0[0]) * t, p_tl0[1] + (p_tl1[1] - p_tl0[1]) * t, tl_ang)

        # Top-right arm: strand 1, indices 0..7
        p_tr0, p_tr1 = (cx + 38.0, cy - 38.0), (cx + 265.0, 48.0)
        tr_ang = math.atan2(p_tr1[1] - p_tr0[1], p_tr1[0] - p_tr0[0]) - math.pi * 0.5
        for i in range(8):
            t = (i + 0.5) / 8.0
            slots[(1, i)] = (p_tr0[0] + (p_tr1[0] - p_tr0[0]) * t, p_tr0[1] + (p_tr1[1] - p_tr0[1]) * t, tr_ang)

        # Bottom-left leg: strand 0, indices 8..23
        for j in range(16):
            t = (j + 0.5) / 16.0
            slots[(0, 8 + j)] = bez_point((cx - 38.0, cy + 38.0), (cx - 175.0, cy + 205.0), (cx - 345.0, 678.0), t)

        # Bottom-right leg: strand 1, indices 8..23
        for j in range(16):
            t = (j + 0.5) / 16.0
            slots[(1, 8 + j)] = bez_point((cx + 38.0, cy + 38.0), (cx + 175.0, cy + 205.0), (cx + 345.0, 678.0), t)

        return slots

    def sync_strand_gene_from_splice():
        if editing_strand_entry is None or editing_strand_entry.genome is None:
            return
        locus = editing_strand_locus or editing_strand_entry.strand_locus
        if not locus:
            return
        a_chars = ["-"] * ALLELE_LENGTH
        b_chars = ["-"] * ALLELE_LENGTH
        for nd in splice_nodes:
            if nd.slot is None:
                continue
            s_idx, n_idx = nd.slot
            if s_idx == 0:
                a_chars[n_idx] = nd.base
            else:
                b_chars[n_idx] = nd.base
        new_gene = Gene(locus, "".join(a_chars), "".join(b_chars))
        editing_strand_entry.genome.genes[locus] = new_gene
        if editing_strand_entry.source_drive is not None:
            editing_strand_entry.source_drive.genes[locus] = new_gene
        refresh_entry_config_for_age(editing_strand_entry)
        for sh in list(phys_scene.horses):
            if sh.entry is editing_strand_entry:
                respawn_scene_horse(sh)

    def spawn_splice_nucleotide_node(
        base: str,
        pos: tuple[float, float],
        angle: float = 0.0,
        slot: tuple[int, int] | None = None,
    ) -> SpliceNucleotideNode:
        assert splice_space is not None
        mass = 1.0
        moment = pymunk.moment_for_box(mass, (25.0, 25.0))
        body = pymunk.Body(mass, moment)
        body.position = pos
        body.angle = angle
        shape = pymunk.Poly.create_box(body, (25.0, 25.0), radius=2.0)
        shape.elasticity = 0.42
        shape.friction = 0.35
        shape.filter = pymunk.ShapeFilter(categories=0b10, mask=0b11)
        splice_space.add(body, shape)
        nd = SpliceNucleotideNode(base=base, slot=slot, body=body, shape=shape)
        splice_nodes.append(nd)
        return nd

    def enter_gene_splice_for_strand(
        strand_entry: HorseEntry,
        return_to: str,
        locus: str | None = None,
    ):
        nonlocal scene, editing_strand_entry, editing_strand_locus, splice_return_scene
        nonlocal splice_space, splice_nodes, splice_slots, splice_mouse_joint, splice_drag_node
        if strand_entry.genome is None:
            return
        target_locus = locus or strand_entry.strand_locus or (
            strand_entry.genome.strand_loci[0] if strand_entry.genome.strand_loci else ""
        )
        if not target_locus or target_locus not in strand_entry.genome.genes:
            return
        editing_strand_entry = strand_entry
        editing_strand_locus = target_locus
        splice_return_scene = return_to
        splice_mouse_joint = None
        splice_drag_node = None

        sp = pymunk.Space()
        sp.gravity = (0.0, 120.0)
        sp.damping = 0.88
        sp.iterations = 18
        wall_segs = [
            ((0.0, 0.0), (SCREEN_W, 0.0)),
            ((0.0, SCREEN_H), (SCREEN_W, SCREEN_H)),
            ((0.0, 0.0), (0.0, SCREEN_H)),
            ((SCREEN_W, 0.0), (SCREEN_W, SCREEN_H)),
        ]
        for wa, wb in wall_segs:
            wseg = pymunk.Segment(sp.static_body, wa, wb, 8.0)
            wseg.elasticity = 0.5
            wseg.friction = 0.3
            wseg.filter = pymunk.ShapeFilter(categories=0b01, mask=0b10)
            sp.add(wseg)

        slots = build_splice_slots()
        gene_obj = strand_entry.genome.genes[target_locus]
        nodes: list[SpliceNucleotideNode] = []
        for s_idx, seq in enumerate((gene_obj.allele_a, gene_obj.allele_b)):
            for n_idx, base in enumerate(seq):
                if base not in BASE_TO_INT:
                    continue
                sx, sy, sang = slots[(s_idx, n_idx)]
                mass = 1.0
                moment = pymunk.moment_for_box(mass, (25.0, 25.0))
                body = pymunk.Body(mass, moment)
                body.position = (sx, sy)
                body.angle = sang
                shape = pymunk.Poly.create_box(body, (25.0, 25.0), radius=2.0)
                shape.elasticity = 0.42
                shape.friction = 0.35
                shape.filter = pymunk.ShapeFilter(categories=0b10, mask=0b11)
                sp.add(body, shape)
                nodes.append(SpliceNucleotideNode(base=base, slot=(s_idx, n_idx), body=body, shape=shape))

        splice_space = sp
        splice_slots = slots
        splice_nodes = nodes
        scene = "gene_splice"

    def leave_gene_splice():
        nonlocal scene, splice_space, splice_nodes, splice_mouse_joint, splice_drag_node
        nonlocal editing_strand_entry, editing_strand_locus
        if splice_space is not None and splice_mouse_joint is not None and splice_mouse_joint in splice_space.constraints:
            splice_space.remove(splice_mouse_joint)
        splice_mouse_joint = None
        splice_drag_node = None
        sync_strand_gene_from_splice()
        splice_space = None
        splice_nodes = []
        editing_strand_entry = None
        editing_strand_locus = ""
        scene = splice_return_scene

    def try_click_strand_in_scene(
        screen_pos: tuple[int, int],
        return_to: str,
        allow_body_fallback: bool = False,
    ) -> bool:
        phys_pos = (screen_pos[0] / SCENE_SCALE + phys_scene.view_x, screen_pos[1] / SCENE_SCALE)
        for sh in reversed(phys_scene.horses):
            if sh.entry.genome is None or (not sh.entry.is_strand and not sh.entry.genome.strand_loci):
                continue
            hit_locus = sh.creature.find_strand_at_point(phys_pos, radius=14.0)
            if hit_locus is not None:
                commit_rename()
                clear_hover_and_rename()
                enter_gene_splice_for_strand(sh.entry, return_to, locus=hit_locus)
                return True
        if allow_body_fallback:
            sh_hit = phys_scene.find_horse_at_screen_pos(screen_pos)
            if sh_hit is not None and sh_hit.entry.genome is not None:
                if sh_hit.entry.is_strand:
                    loc = sh_hit.entry.strand_locus or (
                        sh_hit.entry.genome.strand_loci[0] if sh_hit.entry.genome.strand_loci else ""
                    )
                    if loc:
                        commit_rename()
                        clear_hover_and_rename()
                        enter_gene_splice_for_strand(sh_hit.entry, return_to, locus=loc)
                        return True
                elif sh_hit.entry.genome.strand_loci:
                    commit_rename()
                    clear_hover_and_rename()
                    enter_gene_splice_for_strand(
                        sh_hit.entry, return_to, locus=sh_hit.entry.genome.strand_loci[0]
                    )
                    return True
        return False

    def pull_gene_lever():
        nonlocal bankroll, jean_override, jean_override_timer, gene_lever_anim
        nonlocal gene_paid, gene_fill, gene_pending, gene_pending_kind
        if gene_fill > 0.0:
            return
        gene_lever_anim = 1.0
        mode = GENE_MODES[gene_mode_idx]

        if mode == "EXTRACT":
            donors: list[Genome] = []
            for sh in horses_in_gene_box():
                if sh.entry.genome is not None:
                    donors.append(sh.entry.genome)
            for pr in props_in_gene_box():
                donor = item_extract_genome(pr.kind, pr.genome, rng)
                if donor is not None:
                    donors.append(donor)
            if not donors:
                set_active_npc_speech("Put a horse, fossil, or item in the box and flick that lever!")
                return
            if not gene_paid:
                if bankroll < GENE_EXTRACT_COST:
                    set_active_npc_speech(JEAN_LINES[3])
                    return
                bankroll -= GENE_EXTRACT_COST
                gene_paid = True
            gene_pending = sample_strands(donors, rng)
            jean_override = ""
            jean_override_timer = 0.0
            gene_pending_kind = "potion"
            gene_fill = 1.0

        elif mode == "IMPRINT":
            if gene_slot_drive is None:
                set_active_npc_speech("Insert a Gene Drive into the drive slot first!")
                return
            target_horse = horse_in_gene_box()
            if target_horse is None or target_horse.entry.genome is None:
                set_active_npc_speech("Put a horse in the glass box to imprint the drive onto it!")
                return
            if target_horse.entry.is_strand:
                splice_targets = target_horse.entry.genome.strand_loci or (
                    (target_horse.entry.strand_locus,) if target_horse.entry.strand_locus else ()
                )
                for loc in splice_targets:
                    if loc in target_horse.entry.genome.genes:
                        g_src = target_horse.entry.genome.genes[loc]
                        gene_slot_drive.genes[loc] = Gene(loc, g_src.allele_a, g_src.allele_b)
                set_active_npc_speech(f"Spliced {target_horse.entry.name} onto slotted Gene Drive!")
                return
            target_horse.entry.genome = gene_slot_drive.copy()
            if target_horse.entry.genome.pure_strand:
                target_horse.entry.is_strand = True
            refresh_entry_config_for_age(target_horse.entry)
            respawn_scene_horse(target_horse)
            set_active_npc_speech(f"Imprinted drive onto {target_horse.entry.name} with zero loss!")

        elif mode == "EDIT":
            if gene_slot_drive is None:
                set_active_npc_speech("Insert a Gene Drive into the drive slot before editing!")
                return
            enter_gene_map()

        elif mode == "CONVERT":
            pot = potion_in_convert_zone()
            if pot is None or pot.genome is None:
                set_active_npc_speech("Drop a potion into the glass box, then pull the lever to convert it!")
                return
            snap = pot.genome.copy()
            for idx_p, g_p in enumerate(truck_potions):
                if g_p is pot.genome:
                    truck_potions.pop(idx_p)
                    break
            phys_scene.remove_prop(pot)
            gene_pending = snap
            gene_pending_kind = "drive"
            gene_fill = 1.0
            set_active_npc_speech("Converting potion DNA into a Gene Drive!")

    def enter_gene_factory():
        nonlocal scene, jean_line, jean_line_timer, jean_override, jean_override_timer, gene_lever_anim
        clear_hover_and_rename()
        active_bites.clear()
        jean_line = len(JEAN_LINES) if jean_intro_done else jean_intro_index
        jean_line_timer = 0.0
        jean_override = ""
        jean_override_timer = 0.0
        gene_lever_anim = 0.0
        jean = ensure_jean()
        phys_scene.reset()
        phys_scene.add_screen_bounds()
        phys_scene.add_floor_slab(GENE_BOX_X1, GENE_BOX_X2, GENE_BOX_FLOOR, thickness=18.0, friction=0.95)
        phys_scene.add_box_collider(
            GENE_BOX_X1 - 14.0, GENE_BOX_TOP, GENE_BOX_X1 + 6.0, GENE_BOX_FLOOR + 18.0, friction=0.2, is_floor=False
        )
        phys_scene.add_box_collider(
            GENE_BOX_X2 - 6.0, GENE_BOX_TOP, GENE_BOX_X2 + 14.0, GENE_BOX_FLOOR + 18.0, friction=0.2, is_floor=False
        )
        phys_scene.add_floor_slab(GENE_FLASK_X - 90.0, GENE_FLASK_X + 90.0, GENE_FUNNEL_FLOOR, thickness=16.0, friction=0.9)
        phys_scene.add_floor_slab(-40.0, 900.0, GENE_TRUCK_FLOOR_Y, thickness=80.0, friction=0.95)
        add_truck_walls(phys_scene, GENE_TRUCK_LEFT, GENE_TRUCK_FLOOR_Y)
        jean_sh = phys_scene.spawn_horse(jean, GENE_JEAN_X, GENE_TRUCK_FLOOR_Y, owned_by_player=False)
        jean_sh.home_x = GENE_JEAN_X
        for idx, entry in enumerate(truck_horses):
            sx = GENE_TRUCK_LEFT + 140.0 + ((idx * 170) % int(STD_TRUCK_TRAILER_W - 260))
            phys_scene.spawn_horse(entry, sx, GENE_TRUCK_FLOOR_Y, owned_by_player=True)
        spawn_truck_props(GENE_TRUCK_LEFT, GENE_TRUCK_FLOOR_Y)
        scene = "gene_factory"

    def leave_gene_factory():
        nonlocal scene, gene_slot_drive
        commit_rename()
        clear_hover_and_rename()
        sync_truck_horses_from_scene()
        if world.jean_entry is None or world.jean_entry in truck_horses:
            world.jean_entry = None
        if gene_slot_drive is not None:
            truck_drives.append(gene_slot_drive)
            gene_slot_drive = None
        commit_pending_potion(spawn_here=False)
        active_bites.clear()
        phys_scene.reset()
        scene = "world"

    def dna_red_button_rect() -> pygame.Rect:
        comp_r = int(DNA_COMP_X2 * SCENE_SCALE)
        comp_b = int(DNA_COMP_FLOOR * SCENE_SCALE)
        return pygame.Rect(comp_r - 68, comp_b - 68, 48, 48)

    def is_in_dna_vat(px: float, py: float) -> bool:
        return (
            DNA_VAT_X1 - 24.0 <= px <= DNA_VAT_X2 + 24.0
            and DNA_VAT_TOP - 80.0 <= py <= DNA_VAT_FLOOR + 30.0
        )

    def ensure_dna_guide() -> HorseEntry:
        ent = world.dna_guide_entry
        if ent is None or ent in truck_horses or ent in your_ranch_horses:
            ent = factory.create_rancher("DNA Lab")
            ent.name = "Dr. Helix"
            ent.name_color = (128, 238, 198)
            world.dna_guide_entry = ent
        return ent

    def start_dna_optimization():
        nonlocal dna_sim_active, dna_sim_total, dna_sim_done, dna_sim_times, dna_sim_elites
        nonlocal dna_sim_avg_time, dna_sim_diversity, dna_sim_best_genome, dna_sim_best_time
        nonlocal dna_flash_timer, dna_flash_races, dna_flash_progress, dna_flash_speeds, dna_flash_colors
        if dna_sim_active:
            return
        if not dna_vat_pool:
            set_active_npc_speech("The vat has no DNA yet! Drop potions from your truck into the vat first.")
            return
        dna_sim_diversity = compute_dna_pool_diversity(dna_vat_pool)
        # Small/low-diversity pools only get shallow noisy runs; fuller diverse vats unlock deep evolution
        div_bonus = int(dna_sim_diversity // 18.0)
        dna_sim_total = max(4, min(22, 2 + len(dna_vat_pool) + div_bonus))
        dna_sim_active = True
        dna_sim_done = 0
        dna_sim_times = []
        dna_sim_elites = []
        dna_sim_avg_time = 0.0
        dna_sim_best_genome = None
        dna_sim_best_time = 9999.0
        dna_flash_timer = 0.0
        dna_flash_races = 0
        dna_flash_progress = [0.0] * 5
        dna_flash_speeds = [rng.uniform(0.75, 1.35) for _ in range(5)]
        dna_flash_colors = rng.sample(BOLD_NAME_COLORS, 5)
        if len(dna_vat_pool) < 5 or dna_sim_diversity < 40.0:
            set_active_npc_speech("Low DNA variety! Running a rough pass—add more potions for better results.")
        else:
            set_active_npc_speech("Running deep genetic race simulations! Watch the monitor...")

    def finalize_dna_optimization(spawn_here: bool):
        nonlocal dna_sim_active
        if not dna_sim_active:
            return
        while dna_sim_done < dna_sim_total:
            step_dna_optimization_sim()
        dna_sim_active = False
        if dna_sim_best_genome is not None:
            best_copy = dna_sim_best_genome.copy()
            truck_drives.append(best_copy)
            if spawn_here:
                phys_scene.spawn_prop("drive", DNA_OUT_X, DNA_OUT_Y, genome=best_copy)
            set_active_npc_speech(
                f"Done! Optimal Gene Drive ready ({dna_sim_best_time:.2f}s lap). Drag it to your truck!"
            )

    def step_dna_optimization_sim():
        nonlocal dna_sim_done, dna_sim_avg_time, dna_sim_best_genome, dna_sim_best_time
        if dna_sim_done >= dna_sim_total or not dna_vat_pool:
            return
        pool_strength = min(1.0, (len(dna_vat_pool) / 10.0) * 0.6 + (dna_sim_diversity / 75.0) * 0.4)
        elite_genomes = [g for _t, g in dna_sim_elites[:2]]
        progress_ratio = dna_sim_done / float(max(1, dna_sim_total))
        # High mutation & weak selection when vat lacks DNA; tight elite refinement when vat is rich
        base_mut = 0.048 - 0.026 * pool_strength
        mut_rate = max(0.008, base_mut * (1.0 - 0.45 * progress_ratio))
        elite_bias = 0.25 + 0.55 * pool_strength
        cand = synthesize_dna_candidate(
            dna_vat_pool, elite_genomes, rng, mut_rate=mut_rate, elite_bias=elite_bias
        )
        cfg = config_from_genome(
            cand,
            spawn_x=0.0,
            floor_y=HORSE_FLOOR_Y,
            mode="run",
            collision_group=1,
            age=3,
        )
        t_lap = simulate_preliminary_trial(
            trial_space, trial_floor, cfg, seed=1000 + dna_sim_done + len(dna_vat_pool) * 17
        )
        dna_sim_done += 1
        dna_sim_times.append(t_lap)
        dna_sim_avg_time = sum(dna_sim_times) / float(len(dna_sim_times))
        dna_sim_elites.append((t_lap, cand))
        dna_sim_elites.sort(key=lambda item: item[0])
        if t_lap < dna_sim_best_time:
            dna_sim_best_time = t_lap
            dna_sim_best_genome = cand

    def enter_dna_lab():
        nonlocal scene, dna_guide_line, dna_guide_timer, dna_guide_override, dna_guide_override_timer
        nonlocal dna_sim_diversity, dna_vat_visual_fill
        clear_hover_and_rename()
        active_bites.clear()
        dna_guide_line = len(DNA_GUIDE_LINES) if dna_guide_done else 0
        dna_guide_timer = 0.0
        dna_guide_override = ""
        dna_guide_override_timer = 0.0
        dna_sim_diversity = compute_dna_pool_diversity(dna_vat_pool)
        dna_vat_visual_fill = min(1.0, len(dna_vat_pool) / 20.0)
        guide = ensure_dna_guide()

        phys_scene.reset()
        phys_scene.add_screen_bounds()
        phys_scene.add_floor_slab(DNA_VAT_X1, DNA_VAT_X2, DNA_VAT_FLOOR, thickness=18.0, friction=0.95)
        phys_scene.add_box_collider(
            DNA_VAT_X1 - 14.0, DNA_VAT_TOP, DNA_VAT_X1 + 6.0, DNA_VAT_FLOOR + 18.0, friction=0.2, is_floor=False
        )
        phys_scene.add_box_collider(
            DNA_VAT_X2 - 6.0, DNA_VAT_TOP, DNA_VAT_X2 + 14.0, DNA_VAT_FLOOR + 18.0, friction=0.2, is_floor=False
        )
        phys_scene.add_floor_slab(DNA_OUT_X - 110.0, DNA_OUT_X + 110.0, DNA_BENCH_Y, thickness=16.0, friction=0.9)
        phys_scene.add_floor_slab(-40.0, 900.0, DNA_TRUCK_FLOOR_Y, thickness=80.0, friction=0.95)
        add_truck_walls(phys_scene, DNA_TRUCK_LEFT, DNA_TRUCK_FLOOR_Y)

        guide_sh = phys_scene.spawn_horse(guide, DNA_GUIDE_X, DNA_TRUCK_FLOOR_Y, owned_by_player=False)
        guide_sh.home_x = DNA_GUIDE_X
        for idx, entry in enumerate(truck_horses):
            sx = DNA_TRUCK_LEFT + 140.0 + ((idx * 170) % int(STD_TRUCK_TRAILER_W - 260))
            phys_scene.spawn_horse(entry, sx, DNA_TRUCK_FLOOR_Y, owned_by_player=True)
        spawn_truck_props(DNA_TRUCK_LEFT, DNA_TRUCK_FLOOR_Y)
        scene = "dna_lab"

    def leave_dna_lab():
        nonlocal scene
        commit_rename()
        clear_hover_and_rename()
        finalize_dna_optimization(spawn_here=False)
        sync_truck_horses_from_scene()
        if world.dna_guide_entry is None or world.dna_guide_entry in truck_horses:
            world.dna_guide_entry = None
        active_bites.clear()
        phys_scene.reset()
        scene = "world"

    def finish_breeding_if_active(spawn_in_scene: bool = True):
        nonlocal breeding_active, breeding_timer, breeding_parents
        if not breeding_active:
            return
        if len(breeding_parents) >= 2:
            p1, p2 = breeding_parents[0], breeding_parents[1]
            p1.is_tired = True
            p2.is_tired = True
            foal = factory.create_foal(p1, p2)
            your_ranch_horses.append(foal)
            if spawn_in_scene:
                phys_scene.spawn_horse(p1, SHED_X1 - 220.0, YOUR_YARD_FLOOR_Y, owned_by_player=True)
                phys_scene.spawn_horse(p2, SHED_X1 - 95.0, YOUR_YARD_FLOOR_Y, owned_by_player=True)
                phys_scene.spawn_horse(foal, SHED_X1 - 155.0, YOUR_YARD_FLOOR_Y, owned_by_player=True)
            else:
                if p1 not in your_ranch_horses and p1 not in truck_horses:
                    your_ranch_horses.append(p1)
                if p2 not in your_ranch_horses and p2 not in truck_horses:
                    your_ranch_horses.append(p2)
        breeding_active = False
        breeding_timer = 0.0
        breeding_parents = []

    def enter_your_ranch():
        nonlocal scene, breeding_active, breeding_timer, breeding_parents, shed_notice, shed_notice_timer
        clear_hover_and_rename()
        breeding_active = False
        breeding_timer = 0.0
        breeding_parents = []
        shed_notice = ""
        shed_notice_timer = 0.0

        phys_scene.reset()
        phys_scene.add_screen_bounds()
        # Sample Race Track at top
        phys_scene.add_floor_slab(-250.0, PHYS_W + 250.0, RANCH_TRACK_FLOOR_Y, thickness=44.0, friction=1.0)
        # Middle yard floor covering Open Pen + Shed exit area + Breeding Shed interior
        phys_scene.add_floor_slab(YOUR_PEN_X1, SHED_X2, YOUR_YARD_FLOOR_Y, thickness=18.0, friction=0.95)
        phys_scene.add_box_collider(YOUR_PEN_X1 - 12.0, YOUR_YARD_FLOOR_Y - 190.0, YOUR_PEN_X1 + 4.0, YOUR_YARD_FLOOR_Y + 18.0, friction=0.2, is_floor=False)
        phys_scene.add_box_collider(YOUR_PEN_X2 - 4.0, YOUR_YARD_FLOOR_Y - 120.0, YOUR_PEN_X2 + 8.0, YOUR_YARD_FLOOR_Y + 18.0, friction=0.2, is_floor=False)
        # Breeding shed roof and right wall (left side is open doorway)
        phys_scene.add_box_collider(SHED_X1, SHED_TOP - 16.0, SHED_X2 + 12.0, SHED_TOP + 6.0, friction=0.4, is_floor=False)
        phys_scene.add_box_collider(SHED_X2 - 4.0, SHED_TOP, SHED_X2 + 14.0, SHED_FLOOR_Y + 18.0, friction=0.2, is_floor=False)
        # Standardized Truck bottom-right
        add_truck_walls(phys_scene, YOUR_TRUCK_LEFT, YOUR_TRUCK_FLOOR_Y)

        for idx, entry in enumerate(your_ranch_horses):
            sx = YOUR_PEN_X1 + 135.0 + ((idx * 155) % int(YOUR_PEN_X2 - YOUR_PEN_X1 - 240))
            phys_scene.spawn_horse(entry, sx, YOUR_YARD_FLOOR_Y, owned_by_player=True)

        for idx, entry in enumerate(truck_horses):
            sx = YOUR_TRUCK_LEFT + 140.0 + ((idx * 170) % int(STD_TRUCK_TRAILER_W - 260))
            phys_scene.spawn_horse(entry, sx, YOUR_TRUCK_FLOOR_Y, owned_by_player=True)
        spawn_truck_props(YOUR_TRUCK_LEFT, YOUR_TRUCK_FLOOR_Y)

        scene = "your_ranch"

    def leave_your_ranch():
        nonlocal scene
        commit_rename()
        clear_hover_and_rename()
        finish_breeding_if_active(spawn_in_scene=False)
        new_truck: list[HorseEntry] = []
        new_pen: list[HorseEntry] = []
        for sh in phys_scene.horses:
            pos = sh.creature.bodies["torso"].position
            if is_inside_truck(pos.x, pos.y, YOUR_TRUCK_LEFT, YOUR_TRUCK_FLOOR_Y):
                if sh.entry not in new_truck:
                    new_truck.append(sh.entry)
            else:
                if sh.entry not in new_pen:
                    new_pen.append(sh.entry)
        truck_horses[:] = new_truck
        your_ranch_horses[:] = new_pen
        phys_scene.reset()
        scene = "world"

    gallery = None

    def gallery_export():
        from types import SimpleNamespace
        return SimpleNamespace(
            bankroll=bankroll,
            day=day,
            scene=scene,
            lasso_count=lasso_count,
            lasso_armed=lasso_armed,
            has_infinite_lasso=has_infinite_lasso,
            championship_won=championship_won,
            first_race_done=first_race_done,
            truck_hay=truck_hay,
            truck_beer=truck_beer,
            truck_apples=truck_apples,
            truck_prickly_pears=truck_prickly_pears,
            truck_chilis=truck_chilis,
            truck_horses=truck_horses,
            your_ranch_horses=your_ranch_horses,
            truck_apple_crates=truck_apple_crates,
            truck_fossils=truck_fossils,
            truck_meats=truck_meats,
            truck_potions=truck_potions,
            truck_drives=truck_drives,
            dna_vat_pool=dna_vat_pool,
            truck_x=truck_x,
            truck_y=truck_y,
            truck_facing=truck_facing,
            bet_amount=bet_amount,
            selected_lane=selected_lane,
            track_state=track_state,
            track_cam_x=track_cam_x,
            race_mode=race_mode,
            lanes=lanes,
            breeding_active=breeding_active,
            breeding_timer=breeding_timer,
            gene_paid=gene_paid,
            gene_fill=gene_fill,
            gene_mode_idx=gene_mode_idx,
            gene_slot_drive=gene_slot_drive,
            gene_pending=gene_pending,
            jean_line=jean_line,
            splice_nodes=splice_nodes,
            splice_drag_node=splice_drag_node,
            gm_nodes=gm_nodes,
            gm_lasso_target=gm_lasso_target,
            gm_truck_x=gm_truck_x,
            gm_truck_y=gm_truck_y,
            factory=factory,
            world=world,
            rng=rng,
            phys=phys_scene,
            screen=screen,
            met_npc_ids=met_npc_ids,
            shop_welcomed=shop_welcomed,
            ranch_view_x=ranch_view_x,
        )

    def gallery_apply(**kwargs):
        nonlocal scene, bankroll, day, lasso_count, lasso_armed, has_infinite_lasso, championship_won
        nonlocal first_race_done, truck_hay, truck_beer, truck_apples, truck_prickly_pears, truck_chilis, truck_meats
        nonlocal truck_x, truck_y, truck_facing, bet_amount, selected_lane, track_cam_x
        nonlocal gene_paid, gene_fill, gene_pending, gene_pending_kind, gene_mode_idx, gene_slot_drive
        nonlocal jean_intro_done, jean_line, jean_intro_index
        nonlocal dna_guide_done, dna_guide_line, dna_sim_active, dna_sim_total, dna_sim_done
        nonlocal dna_sim_times, dna_sim_avg_time, dna_sim_diversity, dna_sim_best_time
        nonlocal dna_flash_timer, dna_flash_races, dna_flash_progress, dna_flash_speeds, dna_flash_colors
        nonlocal ranch_view_x, ranch_view_target, lasso_anim
        nonlocal gm_lasso_target, gm_lasso_phase, gm_lasso_progress, gm_truck_x, gm_truck_y, gm_truck_facing
        nonlocal splice_drag_node, shop_welcomed, shop_speech, ranch_speech
        for key, val in kwargs.items():
            if key == "scene":
                scene = val
            elif key == "bankroll":
                bankroll = val
            elif key == "day":
                day = val
            elif key == "lasso_count":
                lasso_count = val
            elif key == "lasso_armed":
                lasso_armed = val
            elif key == "has_infinite_lasso":
                has_infinite_lasso = val
            elif key == "championship_won":
                championship_won = val
            elif key == "first_race_done":
                first_race_done = val
            elif key == "truck_hay":
                truck_hay = val
            elif key == "truck_beer":
                truck_beer = val
            elif key == "truck_apples":
                truck_apples = val
            elif key == "truck_prickly_pears":
                truck_prickly_pears = val
            elif key == "truck_chilis":
                truck_chilis = val
            elif key == "truck_meats":
                truck_meats = val
            elif key == "truck_x":
                truck_x = val
            elif key == "truck_y":
                truck_y = val
            elif key == "truck_facing":
                truck_facing = val
            elif key == "bet_amount":
                bet_amount = val
            elif key == "selected_lane":
                selected_lane = val
            elif key == "track_cam_x":
                track_cam_x = val
            elif key == "gene_paid":
                gene_paid = val
            elif key == "gene_fill":
                gene_fill = val
            elif key == "gene_pending":
                gene_pending = val
            elif key == "gene_pending_kind":
                gene_pending_kind = val
            elif key == "gene_mode_idx":
                gene_mode_idx = val
            elif key == "gene_slot_drive":
                gene_slot_drive = val
            elif key == "jean_intro_done":
                jean_intro_done = val
            elif key == "jean_line":
                jean_line = val
            elif key == "jean_intro_index":
                jean_intro_index = val
            elif key == "dna_guide_done":
                dna_guide_done = val
            elif key == "dna_guide_line":
                dna_guide_line = val
            elif key == "dna_sim_active":
                dna_sim_active = val
            elif key == "dna_sim_total":
                dna_sim_total = val
            elif key == "dna_sim_done":
                dna_sim_done = val
            elif key == "dna_sim_times":
                dna_sim_times = val
            elif key == "dna_sim_avg_time":
                dna_sim_avg_time = val
            elif key == "dna_sim_diversity":
                dna_sim_diversity = val
            elif key == "dna_sim_best_time":
                dna_sim_best_time = val
            elif key == "dna_flash_timer":
                dna_flash_timer = val
            elif key == "dna_flash_races":
                dna_flash_races = val
            elif key == "dna_flash_progress":
                dna_flash_progress = val
            elif key == "dna_flash_speeds":
                dna_flash_speeds = val
            elif key == "dna_flash_colors":
                dna_flash_colors = val
            elif key == "ranch_view_x":
                ranch_view_x = val
            elif key == "ranch_view_target":
                ranch_view_target = val
            elif key == "lasso_anim":
                lasso_anim = val
            elif key == "gm_lasso_target":
                gm_lasso_target = val
            elif key == "gm_lasso_phase":
                gm_lasso_phase = val
            elif key == "gm_lasso_progress":
                gm_lasso_progress = val
            elif key == "gm_truck_x":
                gm_truck_x = val
            elif key == "gm_truck_y":
                gm_truck_y = val
            elif key == "gm_truck_facing":
                gm_truck_facing = val
            elif key == "splice_drag_node":
                splice_drag_node = val
            elif key == "shop_welcomed":
                shop_welcomed = val
            elif key == "shop_speech":
                shop_speech = val
            elif key == "ranch_speech":
                ranch_speech = val
            else:
                raise KeyError(key)

    def gallery_call(name, *args, **kwargs):
        fns = {
            "enter_truck": enter_truck_scene,
            "enter_hub": enter_racecourse_hub,
            "enter_arena": enter_arena_hub,
            "enter_shop": enter_shop,
            "enter_ranch": enter_ranch,
            "enter_gene_factory": enter_gene_factory,
            "enter_gene_map": enter_gene_map,
            "enter_splice": enter_gene_splice_for_strand,
            "enter_dna_lab": enter_dna_lab,
            "enter_your_ranch": enter_your_ranch,
            "start_race": start_track_race,
            "start_session": start_new_track_session,
            "move_horse": move_scene_horse_to,
        }
        return fns[name](*args, **kwargs)

    if os.environ.get("CAPTURE_GALLERY") == "1":
        from capture_gallery import GallerySession
        gallery = GallerySession(os.environ.get("CAPTURE_DIR", "screenshots"))

    dt = 1.0 / FPS
    print("web: entering main loop")

    # --- MAIN LOOP ---
    while True:
        if gallery is not None:
            gallery.before_frame(gallery_export, gallery_apply, gallery_call)
        mx_raw, my_raw = pygame.mouse.get_pos()
        mouse_pos = screen.to_logical((mx_raw, my_raw))

        # Occasional hunger tick on player horses
        for entry in list(truck_horses) + list(your_ranch_horses):
            if not entry.is_rancher and not entry.is_strand and not entry.is_hungry:
                entry.hunger_clock += dt
                thresh = 340.0 + (entry.entry_id % 7) * 40.0
                if entry.hunger_clock >= thresh:
                    entry.is_hungry = True
                    entry.hunger_clock = 0.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return

            if event.type == pygame.VIDEORESIZE:
                if sys.platform == "emscripten":
                    RES_SCALE = _emscripten_res_scale()
                    rw = int(round(SCREEN_W * RES_SCALE))
                    rh = int(round(SCREEN_H * RES_SCALE))
                else:
                    rw, rh = event.w, event.h
                real_screen = pygame.display.set_mode((rw, rh), pygame.RESIZABLE)
                screen._real = real_screen
                screen.set_viewport(rw, rh)
                RES_SCALE = screen.scale
                continue
            if hasattr(event, "pos"):
                event = pygame.event.Event(
                    event.type,
                    {**event.dict, "pos": screen.to_logical(event.pos)},
                )

            if renaming_entry is not None and event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    commit_rename()
                elif event.key == pygame.K_ESCAPE:
                    renaming_entry = None
                    rename_text = ""
                elif event.key == pygame.K_BACKSPACE:
                    rename_text = rename_text[:-1]
                elif event.unicode and event.unicode.isprintable() and len(rename_text) < 24:
                    rename_text += event.unicode
                continue

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if (
                    hover_owned
                    and hover_entry is not None
                    and hover_name_rect is not None
                    and hover_name_rect.collidepoint(event.pos)
                ):
                    renaming_entry = hover_entry
                    rename_text = hover_entry.name
                    continue
                if renaming_entry is not None:
                    commit_rename()

            if (
                event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 3
                and scene in ("truck", "ranch", "your_ranch", "racecourse_hub", "arena_hub", "shop", "gene_factory", "dna_lab")
            ):
                if try_click_strand_in_scene(event.pos, scene, allow_body_fallback=True):
                    continue

            # ---------------- SCENE: RACECOURSE TRACK ----------------
            if scene == "racecourse_track":
                if event.type == pygame.KEYDOWN:
                    if track_state == "betting":
                        if race_mode == "bet":
                            if event.key in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5):
                                selected_lane = event.key - pygame.K_1
                            elif event.key in (pygame.K_UP, pygame.K_RIGHT):
                                bet_amount = clamp_bet(bet_amount + 5)
                            elif event.key in (pygame.K_DOWN, pygame.K_LEFT):
                                bet_amount = clamp_bet(bet_amount - 5)
                        if event.key in (pygame.K_SPACE, pygame.K_RETURN):
                            start_track_race()
                    elif track_state == "results":
                        if event.key in (pygame.K_SPACE, pygame.K_RETURN):
                            if bankroll <= 0 and not truck_horses and not your_ranch_horses:
                                bankroll = STARTING_BANKROLL
                            start_new_track_session("bet")
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    click_pos = event.pos
                    if track_state == "betting":
                        clicked_own_name = False
                        for p_entry, p_rect in track_player_name_rects:
                            if p_rect.collidepoint(click_pos):
                                renaming_entry = p_entry
                                rename_text = p_entry.name
                                clicked_own_name = True
                                break
                        if clicked_own_name:
                            continue
                        if sign_start_race.collidepoint(click_pos):
                            start_track_race()
                        elif first_race_done and sign_leave_track.collidepoint(click_pos):
                            if active_course is not None and active_course.is_arena:
                                enter_arena_hub(active_course)
                            else:
                                enter_racecourse_hub(active_course)
                        elif race_mode == "bet":
                            if sign_bet_minus.collidepoint(click_pos):
                                bet_amount = clamp_bet(bet_amount - 5)
                            elif sign_bet_plus.collidepoint(click_pos):
                                bet_amount = clamp_bet(bet_amount + 5)
                            elif sign_bet_board.collidepoint(click_pos):
                                bet_amount = clamp_bet(bankroll if bet_amount < bankroll else 10)
                            else:
                                for idx, (top, bot) in enumerate(LANE_BOUNDS):
                                    if top <= click_pos[1] < bot:
                                        selected_lane = idx
                                        break
                    elif track_state == "results":
                        if sign_next_race.collidepoint(click_pos):
                            if bankroll <= 0 and not truck_horses and not your_ranch_horses:
                                bankroll = STARTING_BANKROLL
                            start_new_track_session("bet")
                        elif first_race_done and sign_leave_track.collidepoint(click_pos):
                            if active_course is not None and active_course.is_arena:
                                enter_arena_hub(active_course)
                            else:
                                enter_racecourse_hub(active_course)

            # ---------------- SCENE: RACECOURSE HUB ----------------
            elif scene == "racecourse_hub":
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    leave_racecourse_hub()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    click_pos = event.pos
                    pen_horse = get_hub_pen_horse()
                    can_race_pen = (
                        pen_horse is not None
                        and 1 <= pen_horse.entry.age <= 9
                        and not pen_horse.entry.is_tired
                        and not pen_horse.entry.is_hungry
                        and not pen_horse.entry.is_unconscious
                        and not pen_horse.entry.is_champion
                        and entry_strands_functional(pen_horse.entry)
                        and bankroll >= 25
                    )
                    can_champ_pen = (
                        pen_horse is not None
                        and pen_horse.entry.is_winner
                        and not pen_horse.entry.is_champion
                        and 1 <= pen_horse.entry.age <= 9
                        and not pen_horse.entry.is_tired
                        and not pen_horse.entry.is_hungry
                        and not pen_horse.entry.is_unconscious
                        and bankroll >= 500
                    )
                    if hub_sign_bet.collidepoint(click_pos) and bankroll > 0:
                        phys_scene.reset()
                        start_new_track_session("bet")
                    elif hub_sign_race_mine.collidepoint(click_pos) and can_race_pen and pen_horse is not None:
                        bankroll -= 25
                        chosen = pen_horse.entry
                        if chosen not in truck_horses:
                            truck_horses.append(chosen)
                        phys_scene.reset()
                        start_new_track_session("own_horse", player_horse=chosen)
                    elif hub_sign_championship.collidepoint(click_pos) and can_champ_pen and pen_horse is not None:
                        bankroll -= 500
                        chosen = pen_horse.entry
                        if chosen not in truck_horses:
                            truck_horses.append(chosen)
                        phys_scene.reset()
                        start_new_track_session("championship", player_horse=chosen)
                    elif hub_sign_arena.collidepoint(click_pos):
                        ref_x, ref_y = (
                            (active_course.x, active_course.y)
                            if active_course is not None
                            else world.racecourse_pos
                        )
                        target_arena = nearest_arena_from(ref_x, ref_y)
                        leave_racecourse_hub()
                        arena_guide_target = target_arena
                    elif hub_sign_exit.collidepoint(click_pos):
                        leave_racecourse_hub()
                    elif bankroll <= 0 and not truck_horses and not your_ranch_horses and hub_sign_bailout.collidepoint(click_pos):
                        bankroll = STARTING_BANKROLL
                    else:
                        phys_scene.start_drag(click_pos)
                elif event.type == pygame.MOUSEMOTION:
                    if phys_scene.dragged_horse is not None or phys_scene.dragged_prop is not None:
                        phys_scene.update_drag(event.pos)
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    drag_dist = math.hypot(
                        event.pos[0] - phys_scene.drag_start_pos[0],
                        event.pos[1] - phys_scene.drag_start_pos[1],
                    )
                    rel_kind, rel_obj = phys_scene.release_drag()
                    if drag_dist < 10.0 and try_click_strand_in_scene(
                        event.pos,
                        "racecourse_hub",
                        allow_body_fallback=(isinstance(rel_obj, SceneHorse) and rel_obj.entry.is_strand),
                    ):
                        continue
                    if rel_kind == "prop" and isinstance(rel_obj, SceneProp):
                        handle_owned_prop_release(rel_obj, HUB_TRUCK_LEFT, HUB_TRUCK_FLOOR_Y)

            elif scene == "arena_hub":
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    leave_racecourse_hub()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    click_pos = event.pos
                    pen_horse = get_hub_pen_horse()
                    can_race_pen = (
                        pen_horse is not None
                        and 1 <= pen_horse.entry.age <= 9
                        and not pen_horse.entry.is_tired
                        and not pen_horse.entry.is_hungry
                        and not pen_horse.entry.is_unconscious
                        and not pen_horse.entry.is_champion
                        and entry_strands_functional(pen_horse.entry)
                        and bankroll >= 25
                    )
                    if arena_sign_stronghorse.collidepoint(click_pos) and can_race_pen and pen_horse is not None:
                        bankroll -= 25
                        chosen = pen_horse.entry
                        if chosen not in truck_horses:
                            truck_horses.append(chosen)
                        phys_scene.reset()
                        start_new_track_session("stronghorse", player_horse=chosen)
                    elif arena_sign_muddy.collidepoint(click_pos) and can_race_pen and pen_horse is not None:
                        bankroll -= 25
                        chosen = pen_horse.entry
                        if chosen not in truck_horses:
                            truck_horses.append(chosen)
                        phys_scene.reset()
                        start_new_track_session("muddy_tracks", player_horse=chosen)
                    elif hub_sign_exit.collidepoint(click_pos):
                        leave_racecourse_hub()
                    else:
                        phys_scene.start_drag(click_pos)
                elif event.type == pygame.MOUSEMOTION:
                    if phys_scene.dragged_horse is not None or phys_scene.dragged_prop is not None:
                        phys_scene.update_drag(event.pos)
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    rel_kind, rel_obj = phys_scene.release_drag()
                    if rel_kind == "prop" and isinstance(rel_obj, SceneProp):
                        handle_owned_prop_release(rel_obj, HUB_TRUCK_LEFT, HUB_TRUCK_FLOOR_Y)

            # ---------------- SCENE: OPEN WORLD ----------------
            elif scene == "world":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    lasso_btn_rect = pygame.Rect(SCREEN_W - 76, 16, 58, 58)
                    if (lasso_count > 0 or has_infinite_lasso) and lasso_btn_rect.collidepoint(mouse_pos):
                        lasso_armed = not lasso_armed
                        continue

                    wx = mouse_pos[0] + ow_cam_x
                    wy = mouse_pos[1] + ow_cam_y

                    if pygame.Rect(int(truck_x - 52), int(truck_y - 28), 104, 56).collidepoint(wx, wy):
                        enter_truck_scene()
                        continue

                    clicked_course = None
                    for rc in world.racecourses:
                        if tile_rect_world(rc.x, rc.y).collidepoint(wx, wy):
                            clicked_course = rc
                            break
                    if clicked_course is not None:
                        if clicked_course.is_arena:
                            enter_arena_hub(clicked_course)
                        else:
                            enter_racecourse_hub(clicked_course)
                        continue

                    if tile_rect_world(*world.your_ranch_pos).collidepoint(wx, wy):
                        enter_your_ranch()
                        continue

                    if tile_rect_world(*world.gene_factory_pos).collidepoint(wx, wy):
                        enter_gene_factory()
                        continue

                    if tile_rect_world(*world.dna_lab_pos).collidepoint(wx, wy):
                        enter_dna_lab()
                        continue

                    clicked_shop = None
                    for sh in world.shops:
                        if tile_rect_world(sh.x, sh.y).collidepoint(wx, wy):
                            clicked_shop = sh
                            break
                    if clicked_shop is not None:
                        enter_shop(clicked_shop)
                        continue

                    clicked_ranch = None
                    for r in world.ranches:
                        if tile_rect_world(r.x, r.y).collidepoint(wx, wy):
                            clicked_ranch = r
                            break
                    if clicked_ranch is not None:
                        enter_ranch(clicked_ranch)
                        continue

                    # Pick up fallen apples on click
                    picked_apple = None
                    for ap in world.world_apples:
                        if math.hypot(ap.x - wx, ap.y - wy) < 28.0:
                            picked_apple = ap
                            break
                    if picked_apple is not None:
                        world.world_apples.remove(picked_apple)
                        if picked_apple.kind == "prickly_pear":
                            truck_prickly_pears += 1
                        else:
                            truck_apples += 1
                        continue

                    clicked_fossil = None
                    for fos in world.fossils:
                        if math.hypot(fos.x - wx, fos.y - wy) < 36.0:
                            clicked_fossil = fos
                            break
                    if clicked_fossil is not None:
                        truck_fossils.append(clicked_fossil.genome)
                        world.fossils.remove(clicked_fossil)
                        continue

                    clicked_meat = None
                    for cut in world.meats:
                        if math.hypot(cut.x - wx, cut.y - wy) < 70.0:
                            clicked_meat = cut
                            break
                    if clicked_meat is not None:
                        stored = (
                            clicked_meat.genome.copy()
                            if clicked_meat.genome is not None
                            else None
                        )
                        truck_meats.append(MeatCut(genome=stored, uses=[clicked_meat.uses]))
                        world.meats.remove(clicked_meat)
                        continue

                    # Shake apple tree to drop an apple when clicked
                    clicked_tree = None
                    for tr in world.trees:
                        sc = tr.scale
                        if abs(wx - tr.x) < 34.0 * sc and (tr.y - 76.0 * sc) <= wy <= (tr.y + 12.0 * sc):
                            clicked_tree = tr
                            break
                    if clicked_tree is not None:
                        if clicked_tree.has_apples and clicked_tree.apples:
                            dx_ap, dy_ap = clicked_tree.apples.pop(rng.randrange(len(clicked_tree.apples)))
                            world.world_apples.append(
                                WorldApple(
                                    x=clicked_tree.x + dx_ap,
                                    y=clicked_tree.y + dy_ap,
                                    vy=20.0,
                                    target_y=clicked_tree.y + rng.uniform(14.0, 28.0) * clicked_tree.scale,
                                    falling=True,
                                    kind="prickly_pear" if clicked_tree.kind == "cactus" else "apple",
                                )
                            )
                        continue

                    if (lasso_count > 0 or has_infinite_lasso) and lasso_armed and lasso_anim is None:
                        best_wh = None
                        best_d = 52.0
                        for wh in world.wild_horses:
                            if wh.being_lassoed or wh.entry.is_dead:
                                continue
                            d = math.hypot(wh.x - wx, wh.y - wy)
                            if d < best_d:
                                best_d = d
                                best_wh = wh
                        if best_wh is not None:
                            best_wh.being_lassoed = True
                            lasso_anim = LassoAnim(
                                target=best_wh,
                                phase="shoot",
                                progress=0.0,
                                start_x=truck_x,
                                start_y=truck_y,
                            )

            # ---------------- SCENE: TRUCK INTERIOR ----------------
            elif scene == "truck":
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    leave_truck_scene()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if truck_sign_exit.collidepoint(mouse_pos):
                        leave_truck_scene()
                    else:
                        phys_scene.start_drag(mouse_pos)
                elif event.type == pygame.MOUSEMOTION:
                    if phys_scene.dragged_horse is not None or phys_scene.dragged_prop is not None:
                        phys_scene.update_drag(mouse_pos)
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    drag_dist = math.hypot(
                        event.pos[0] - phys_scene.drag_start_pos[0],
                        event.pos[1] - phys_scene.drag_start_pos[1],
                    )
                    rel_kind, rel_obj = phys_scene.release_drag()
                    if drag_dist < 10.0 and not truck_sign_exit.collidepoint(event.pos) and try_click_strand_in_scene(
                        event.pos,
                        "truck",
                        allow_body_fallback=(isinstance(rel_obj, SceneHorse) and rel_obj.entry.is_strand),
                    ):
                        continue
                    if rel_kind == "prop" and isinstance(rel_obj, SceneProp):
                        handle_owned_prop_release(rel_obj, TRUCK_SCENE_LEFT, TRUCK_SCENE_FLOOR_Y)
                    elif rel_kind == "horse" and isinstance(rel_obj, SceneHorse):
                        pos = rel_obj.creature.bodies["torso"].position
                        if not is_inside_truck(pos.x, pos.y, TRUCK_SCENE_LEFT, TRUCK_SCENE_FLOOR_Y):
                            if rel_obj.entry in truck_horses:
                                truck_horses.remove(rel_obj.entry)
                            phys_scene.remove_horse(rel_obj)
                            if truck_return_scene == "gene_map" and rel_obj.entry.is_strand:
                                ang_ret = rng.uniform(0.0, 2.0 * math.pi)
                                gm_nodes.append(
                                    MapGeneNode(
                                        locus=rel_obj.entry.strand_locus,
                                        locus_num=rel_obj.entry.strand_num,
                                        x=max(140.0, min(GM_WIDTH - 140.0, gm_truck_x + math.cos(ang_ret) * 140.0)),
                                        y=max(130.0, min(GM_HEIGHT - 130.0, gm_truck_y + math.sin(ang_ret) * 120.0)),
                                        vx=math.cos(ang_ret) * 18.0,
                                        vy=math.sin(ang_ret) * 18.0,
                                    )
                                )
                            elif not rel_obj.entry.is_rancher:
                                world.release_horse(rel_obj.entry, truck_x, truck_y)

            # ---------------- SCENE: SHOP ----------------
            elif scene == "shop" and active_shop is not None:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    leave_shop()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if shop_exit_sign.collidepoint(mouse_pos):
                        leave_shop()
                    else:
                        kind_drag = phys_scene.start_drag(mouse_pos)
                        if kind_drag == "conscious_npc":
                            set_active_npc_speech("Hands off, partner!")
                        elif kind_drag == "prop" and phys_scene.dragged_prop is not None and phys_scene.dragged_prop.from_shop:
                            p = phys_scene.dragged_prop
                            if p.kind == "lasso":
                                set_active_npc_speech(f"Lasso: ${p.price} (1 capture). Drop in truck!")
                            elif p.kind == "hay":
                                set_active_npc_speech(f"Hay Bale: ${p.price}. Drop in truck!")
                            elif p.kind == "chili":
                                set_active_npc_speech(f"Chili Pepper: ${p.price}. Drop in truck!")
                            elif p.kind == "apple_crate":
                                set_active_npc_speech(f"Apple Crate (x25): ${p.price}. Drop in truck!")
                            elif p.kind == "beer":
                                set_active_npc_speech(f"Cold Beer: ${p.price}. Drop in truck!")
                elif event.type == pygame.MOUSEMOTION:
                    if phys_scene.dragged_horse is not None or phys_scene.dragged_prop is not None:
                        phys_scene.update_drag(mouse_pos)
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    drag_dist = math.hypot(
                        event.pos[0] - phys_scene.drag_start_pos[0],
                        event.pos[1] - phys_scene.drag_start_pos[1],
                    )
                    rel_kind, rel_obj = phys_scene.release_drag()
                    if drag_dist < 10.0 and not shop_exit_sign.collidepoint(event.pos) and try_click_strand_in_scene(
                        event.pos,
                        "shop",
                        allow_body_fallback=(isinstance(rel_obj, SceneHorse) and rel_obj.entry.is_strand),
                    ):
                        continue
                    if rel_kind == "prop" and isinstance(rel_obj, SceneProp):
                        if rel_obj.from_shop:
                            pos = rel_obj.body.position
                            if is_inside_truck(pos.x, pos.y, SHOP_TRUCK_LEFT, SHOP_TRUCK_FLOOR_Y):
                                if bankroll >= rel_obj.price and active_shop.stock.get(rel_obj.kind, 0) > 0:
                                    bankroll -= rel_obj.price
                                    active_shop.stock[rel_obj.kind] -= 1
                                    if rel_obj.kind == "lasso":
                                        lasso_count += 1
                                        lasso_armed = True
                                        phys_scene.remove_prop(rel_obj)
                                    elif rel_obj.kind == "hay":
                                        truck_hay += 1
                                        rel_obj.from_shop = False
                                    elif rel_obj.kind == "chili":
                                        truck_chilis += 1
                                        rel_obj.from_shop = False
                                    elif rel_obj.kind == "apple_crate":
                                        crate = [25]
                                        truck_apple_crates.append(crate)
                                        rel_obj.uses_left = 25
                                        rel_obj.crate_ref = crate
                                        rel_obj.from_shop = False
                                    else:
                                        truck_beer += 1
                                        rel_obj.from_shop = False
                                    set_active_npc_speech(f"Sold {rel_obj.kind.replace('_', ' ')} for ${rel_obj.price}!")
                                else:
                                    phys_scene.move_prop_to(rel_obj, rel_obj.home_pos[0], rel_obj.home_pos[1])
                                    set_active_npc_speech(f"Not enough cash! Need ${rel_obj.price}.")
                            else:
                                phys_scene.move_prop_to(rel_obj, rel_obj.home_pos[0], rel_obj.home_pos[1])
                        else:
                            handle_owned_prop_release(rel_obj, SHOP_TRUCK_LEFT, SHOP_TRUCK_FLOOR_Y)
                    elif rel_kind == "horse" and isinstance(rel_obj, SceneHorse):
                        rel_obj.creature.config.gait.mode = "walk"
                        rel_obj.creature.config.gait.enabled = False
                        handle_npc_capture_release(
                            rel_obj, active_shop.shopkeeper_entry, SHOP_TRUCK_LEFT, SHOP_TRUCK_FLOOR_Y
                        )

            # ---------------- SCENE: RANCH ----------------
            elif scene == "ranch" and active_ranch is not None:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    leave_ranch()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if ranch_exit_sign.collidepoint(mouse_pos):
                        leave_ranch()
                    elif (
                        active_ranch.has_rabbit_pen
                        and ranch_view_target < PHYS_W * 0.5
                        and ranch_arrow_right.collidepoint(mouse_pos)
                    ):
                        ranch_view_target = PHYS_W
                    elif (
                        active_ranch.has_rabbit_pen
                        and ranch_view_target >= PHYS_W * 0.5
                        and ranch_arrow_left.collidepoint(mouse_pos)
                    ):
                        ranch_view_target = 0.0
                    else:
                        drag_res = phys_scene.start_drag(mouse_pos)
                        if drag_res == "conscious_npc":
                            set_active_npc_speech("Hands off, partner!")
                elif event.type == pygame.MOUSEMOTION:
                    if phys_scene.dragged_prop is not None:
                        phys_scene.update_drag(mouse_pos)
                    elif phys_scene.dragged_horse is not None:
                        phys_scene.update_drag(mouse_pos)
                        dragged = phys_scene.dragged_horse
                        if dragged.entry.is_rabbit and active_ranch.has_rabbit_pen:
                            if mouse_pos[0] < 48:
                                ranch_view_target = 0.0
                            elif mouse_pos[0] > SCREEN_W - 48:
                                ranch_view_target = PHYS_W
                        rancher_ko = (
                            active_ranch.rancher_entry is None
                            or active_ranch.rancher_entry.is_unconscious
                            or active_ranch.rancher_entry in truck_horses
                        )
                        if not rancher_ko:
                            pos = dragged.creature.bodies["torso"].position
                            if not dragged.owned_by_player and not dragged.entry.is_rancher:
                                if not is_in_sale_pen(pos.x, pos.y):
                                    ranch_pending_horse = dragged
                                    ranch_speech = (
                                        f"I will sell {dragged.entry.name} to you "
                                        f"for ${dragged.entry.price}"
                                    )
                                elif dragged is ranch_pending_horse:
                                    ranch_pending_horse = None
                                    ranch_speech = ""
                            elif dragged.owned_by_player and not dragged.entry.is_rancher:
                                if is_in_sale_pen(pos.x, pos.y):
                                    offer = get_ranch_buy_offer(active_ranch, dragged.entry)
                                    if len(active_ranch.horses) > 12:
                                        ranch_speech = (
                                            f"I have too many horses! Best I can offer "
                                            f"for {dragged.entry.name} is ${offer}."
                                        )
                                    else:
                                        ranch_speech = (
                                            f"I'll buy {dragged.entry.name} from you "
                                            f"for ${offer}."
                                        )
                                else:
                                    ranch_speech = ""
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    drag_dist = math.hypot(
                        event.pos[0] - phys_scene.drag_start_pos[0],
                        event.pos[1] - phys_scene.drag_start_pos[1],
                    )
                    rel_kind, rel_obj = phys_scene.release_drag()
                    if drag_dist < 10.0 and not ranch_exit_sign.collidepoint(event.pos) and try_click_strand_in_scene(
                        event.pos,
                        "ranch",
                        allow_body_fallback=(isinstance(rel_obj, SceneHorse) and rel_obj.entry.is_strand),
                    ):
                        continue
                    if rel_kind == "prop" and isinstance(rel_obj, SceneProp):
                        handle_owned_prop_release(rel_obj, RANCH_TRUCK_LEFT, RANCH_TRUCK_FLOOR_Y)
                    elif rel_kind == "horse" and isinstance(rel_obj, SceneHorse):
                        released = rel_obj
                        pos = released.creature.bodies["torso"].position
                        can_run = (
                            not released.entry.is_tired
                            and not released.entry.is_hungry
                            and not released.entry.is_unconscious
                        )
                        # If dropped on the top Sample Track, enable running gait if fit to run
                        if pos.y < RANCH_TRACK_FLOOR_Y + 35.0 and can_run:
                            released.creature.config.gait.mode = "run"
                            released.creature.config.gait.enabled = True
                            released.creature.run_blend = 1.0
                            released.creature.gait_blend = 1.0
                        else:
                            released.creature.config.gait.mode = "walk"
                            released.creature.config.gait.enabled = False

                        rancher_ko = (
                            active_ranch.rancher_entry is None
                            or active_ranch.rancher_entry.is_unconscious
                            or active_ranch.rancher_entry in truck_horses
                        )

                        if handle_npc_capture_release(
                            released, active_ranch.rancher_entry, RANCH_TRUCK_LEFT, RANCH_TRUCK_FLOOR_Y
                        ):
                            pass
                        elif not try_confirm_ranch_transfer(released, strict_interior=False):
                            if not released.owned_by_player:
                                if is_in_sale_pen(pos.x, pos.y):
                                    ranch_pending_horse = None
                                    if not rancher_ko:
                                        ranch_speech = ""
                                else:
                                    ranch_pending_horse = released
                                    if not rancher_ko:
                                        ranch_speech = (
                                            f"I will sell {released.entry.name} to you "
                                            f"for ${released.entry.price}"
                                        )
                        elif released.owned_by_player and not released.entry.is_rancher:
                            if is_in_sale_pen(pos.x, pos.y) and not rancher_ko:
                                offer = get_ranch_buy_offer(active_ranch, released.entry)
                                bankroll += offer
                                released.owned_by_player = False
                                if released.entry in truck_horses:
                                    truck_horses.remove(released.entry)
                                if is_in_rabbit_pen(pos.x, pos.y) and active_ranch.has_rabbit_pen:
                                    active_ranch.rabbits.append(released.entry)
                                else:
                                    active_ranch.horses.append(released.entry)
                                ranch_speech = "Thank you"

            # ---------------- SCENE: GENE FACTORY ----------------
            elif scene == "gene_factory":
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    leave_gene_factory()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if gene_exit_sign.collidepoint(mouse_pos):
                        leave_gene_factory()
                    elif gene_lever_screen_rect().collidepoint(mouse_pos):
                        pull_gene_lever()
                    elif gene_knob_screen_rect().collidepoint(mouse_pos) and gene_fill <= 0.0:
                        gene_mode_idx = (gene_mode_idx + 1) % len(GENE_MODES)
                        mode_hints = {
                            "EXTRACT": "EXTRACT mode: Put a horse in the glass box to extract a potion.",
                            "IMPRINT": "IMPRINT mode: Slot a Gene Drive + horse in box to overwrite genes exactly!",
                            "EDIT": "EDIT mode: Slot a Gene Drive and pull the switch to enter its gene map.",
                            "CONVERT": "CONVERT mode: Drop a potion in the glass box to turn it into a Gene Drive.",
                        }
                        set_active_npc_speech(mode_hints[GENE_MODES[gene_mode_idx]])
                    elif gene_slot_screen_rect().collidepoint(mouse_pos) and gene_slot_drive is not None and gene_fill <= 0.0:
                        ejected = gene_slot_drive
                        gene_slot_drive = None
                        phys_scene.spawn_prop("drive", GENE_MACH_X1 - 60.0, GENE_MACH_FLOOR - 24.0, genome=ejected)
                    else:
                        drag_res = phys_scene.start_drag(mouse_pos)
                        if drag_res == "conscious_npc" and jean_line < len(JEAN_LINES) - 1:
                            jean_line += 1
                            jean_line_timer = 0.0
                elif event.type == pygame.MOUSEMOTION:
                    if phys_scene.dragged_horse is not None or phys_scene.dragged_prop is not None:
                        phys_scene.update_drag(mouse_pos)
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    drag_dist = math.hypot(
                        event.pos[0] - phys_scene.drag_start_pos[0],
                        event.pos[1] - phys_scene.drag_start_pos[1],
                    )
                    rel_kind, rel_obj = phys_scene.release_drag()
                    if drag_dist < 10.0 and not gene_exit_sign.collidepoint(event.pos) and try_click_strand_in_scene(
                        event.pos,
                        "gene_factory",
                        allow_body_fallback=(isinstance(rel_obj, SceneHorse) and rel_obj.entry.is_strand),
                    ):
                        continue
                    if rel_kind == "prop" and isinstance(rel_obj, SceneProp):
                        px, py = rel_obj.body.position.x, rel_obj.body.position.y
                        if rel_obj.kind == "drive" and rel_obj.genome is not None and is_in_drive_slot(px, py):
                            if gene_slot_drive is None:
                                gene_slot_drive = rel_obj.genome
                                for idx_d, g_d in enumerate(truck_drives):
                                    if g_d is rel_obj.genome:
                                        truck_drives.pop(idx_d)
                                        break
                                phys_scene.remove_prop(rel_obj)
                                set_active_npc_speech("Drive inserted! Turn the knob or pull the switch.")
                            else:
                                set_active_npc_speech("Drive slot is full! Click the slot to eject it first.")
                                return_prop_to_truck(rel_obj, GENE_TRUCK_LEFT, GENE_TRUCK_FLOOR_Y)
                        elif rel_obj.kind == "potion" and GENE_MODES[gene_mode_idx] == "CONVERT" and is_in_convert_zone(px, py):
                            pass
                        elif rel_obj.kind in EXTRACTABLE_PROP_KINDS and is_in_gene_box(px, py):
                            pass
                        else:
                            handle_owned_prop_release(rel_obj, GENE_TRUCK_LEFT, GENE_TRUCK_FLOOR_Y)
                    elif rel_kind == "horse" and isinstance(rel_obj, SceneHorse):
                        released = rel_obj
                        released.creature.config.gait.mode = "walk"
                        released.creature.config.gait.enabled = False
                        handle_npc_capture_release(
                            released, world.jean_entry, GENE_TRUCK_LEFT, GENE_TRUCK_FLOOR_Y
                        )

            # ---------------- SCENE: GENE MAP (CONSTRAINED DRIVE EDITOR) ----------------
            elif scene == "gene_map":
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    leave_gene_map()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    lasso_btn_rect = pygame.Rect(SCREEN_W - 76, 16, 58, 58)
                    wx_gm = mouse_pos[0] + gm_cam_x
                    wy_gm = mouse_pos[1] + gm_cam_y
                    if gm_exit_sign.collidepoint(mouse_pos):
                        leave_gene_map()
                    elif (lasso_count > 0 or has_infinite_lasso) and lasso_btn_rect.collidepoint(mouse_pos):
                        lasso_armed = not lasso_armed
                    elif gm_lasso_target is None and pygame.Rect(int(gm_truck_x - 55), int(gm_truck_y - 32), 110, 60).collidepoint(wx_gm, wy_gm):
                        enter_truck_scene(return_to="gene_map")
                    elif (lasso_count > 0 or has_infinite_lasso) and lasso_armed and gm_lasso_target is None:
                        best_node = None
                        best_d = 64.0
                        for nd in gm_nodes:
                            d = math.hypot(nd.x - wx_gm, nd.y - wy_gm)
                            if d < best_d:
                                best_d = d
                                best_node = nd
                        if best_node is not None:
                            best_node.being_lassoed = True
                            gm_lasso_target = best_node
                            gm_lasso_phase = "shoot"
                            gm_lasso_progress = 0.0
                            gm_lasso_sx = gm_truck_x
                            gm_lasso_sy = gm_truck_y

            # ---------------- SCENE: GENE SPLICE (LOW-GRAVITY PHYSICS SWAPPER) ----------------
            elif scene == "gene_splice" and splice_space is not None:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    leave_gene_splice()
                elif (
                    event.type == pygame.KEYDOWN
                    and event.key in (pygame.K_LEFT, pygame.K_RIGHT)
                    and editing_strand_entry is not None
                    and editing_strand_entry.genome is not None
                    and len(editing_strand_entry.genome.strand_loci) > 1
                ):
                    sloci = editing_strand_entry.genome.strand_loci
                    cur_i = sloci.index(editing_strand_locus) if editing_strand_locus in sloci else 0
                    step = -1 if event.key == pygame.K_LEFT else 1
                    next_loc = sloci[(cur_i + step) % len(sloci)]
                    sync_strand_gene_from_splice()
                    enter_gene_splice_for_strand(editing_strand_entry, splice_return_scene, locus=next_loc)
                    continue
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:
                    hits = splice_space.point_query(mouse_pos, 18.0, pymunk.ShapeFilter(mask=0b10))
                    if hits:
                        hit_shape = min(hits, key=lambda h: h.distance).shape
                        hit_node = next((nd for nd in splice_nodes if nd.shape is hit_shape), None)
                        if hit_node is not None:
                            if splice_drag_node is hit_node:
                                if splice_mouse_joint is not None and splice_mouse_joint in splice_space.constraints:
                                    splice_space.remove(splice_mouse_joint)
                                splice_mouse_joint = None
                                splice_drag_node = None
                            if hit_node.shape in splice_space.shapes:
                                splice_space.remove(hit_node.shape)
                            if hit_node.body in splice_space.bodies:
                                splice_space.remove(hit_node.body)
                            splice_nodes.remove(hit_node)
                            sync_strand_gene_from_splice()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if splice_back_sign.collidepoint(mouse_pos):
                        leave_gene_splice()
                    elif (
                        editing_strand_entry is not None
                        and editing_strand_entry.genome is not None
                        and len(editing_strand_entry.genome.strand_loci) > 1
                        and (
                            pygame.Rect(SCREEN_W // 2 - 74, 234, 32, 36).collidepoint(mouse_pos)
                            or pygame.Rect(SCREEN_W // 2 + 42, 234, 32, 36).collidepoint(mouse_pos)
                        )
                    ):
                        sloci = editing_strand_entry.genome.strand_loci
                        cur_i = sloci.index(editing_strand_locus) if editing_strand_locus in sloci else 0
                        step = -1 if mouse_pos[0] < SCREEN_W // 2 else 1
                        next_loc = sloci[(cur_i + step) % len(sloci)]
                        sync_strand_gene_from_splice()
                        enter_gene_splice_for_strand(editing_strand_entry, splice_return_scene, locus=next_loc)
                    elif splice_mouse_joint is None:
                        disp_base = next((b for b, r in splice_dispenser_rects if r.collidepoint(mouse_pos)), None)
                        if disp_base is not None:
                            new_nd = spawn_splice_nucleotide_node(disp_base, (float(mouse_pos[0]), float(mouse_pos[1])), slot=None)
                            splice_drag_node = new_nd
                            splice_mouse_body.position = mouse_pos
                            splice_mouse_joint = pymunk.PivotJoint(
                                splice_mouse_body, new_nd.body, mouse_pos
                            )
                            splice_mouse_joint.max_force = 75000.0
                            splice_mouse_joint.error_bias = (1.0 - 0.18) ** 60.0
                            splice_space.add(splice_mouse_joint)
                        else:
                            hits = splice_space.point_query(mouse_pos, 18.0, pymunk.ShapeFilter(mask=0b10))
                            if hits:
                                hit_shape = min(hits, key=lambda h: h.distance).shape
                                hit_node = next((nd for nd in splice_nodes if nd.shape is hit_shape), None)
                                if hit_node is not None:
                                    splice_drag_node = hit_node
                                    hit_node.free_timer = 0.0
                                    splice_mouse_body.position = mouse_pos
                                    splice_mouse_joint = pymunk.PivotJoint(
                                        splice_mouse_body, hit_node.body, mouse_pos
                                    )
                                    splice_mouse_joint.max_force = 75000.0
                                    splice_mouse_joint.error_bias = (1.0 - 0.18) ** 60.0
                                    splice_space.add(splice_mouse_joint)
                elif event.type == pygame.MOUSEMOTION:
                    if splice_drag_node is not None:
                        splice_mouse_body.position = (
                            max(16.0, min(SCREEN_W - 16.0, float(mouse_pos[0]))),
                            max(16.0, min(SCREEN_H - 16.0, float(mouse_pos[1]))),
                        )
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    if splice_mouse_joint is not None and splice_mouse_joint in splice_space.constraints:
                        splice_space.remove(splice_mouse_joint)
                    splice_mouse_joint = None
                    if splice_drag_node is not None:
                        nd = splice_drag_node
                        splice_drag_node = None
                        px, py = nd.body.position.x, nd.body.position.y
                        best_slot = None
                        best_dist = 42.0
                        for sl_key, (sx, sy, _sang) in splice_slots.items():
                            if sl_key == nd.slot:
                                continue
                            d = math.hypot(sx - px, sy - py)
                            if d < best_dist:
                                best_dist = d
                                best_slot = sl_key
                        if best_slot is not None:
                            other_nd = next((o for o in splice_nodes if o.slot == best_slot), None)
                            old_slot = nd.slot
                            nd.slot = best_slot
                            if other_nd is not None:
                                other_nd.slot = old_slot
                                other_nd.free_timer = 0.0
                                if old_slot is not None:
                                    ox, oy, _oang = splice_slots[old_slot]
                                    other_nd.body.apply_impulse_at_world_point(
                                        ((ox - other_nd.body.position.x) * 1.4, (oy - other_nd.body.position.y) * 1.4 - 45.0),
                                        other_nd.body.position,
                                    )
                            nd.free_timer = 0.0
                            sync_strand_gene_from_splice()
                        else:
                            nd.slot = None
                            nd.free_timer = 0.0
                            sync_strand_gene_from_splice()

            # ---------------- SCENE: DNA LAB ----------------
            elif scene == "dna_lab":
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    leave_dna_lab()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if dna_exit_sign.collidepoint(mouse_pos):
                        leave_dna_lab()
                    elif dna_red_button_rect().collidepoint(mouse_pos):
                        start_dna_optimization()
                    else:
                        drag_res = phys_scene.start_drag(mouse_pos)
                        if drag_res == "conscious_npc":
                            if dna_guide_line < len(DNA_GUIDE_LINES) - 1:
                                dna_guide_line += 1
                                dna_guide_timer = 0.0
                            else:
                                set_active_npc_speech("Drop potions into the vat, then hit the red button!")
                elif event.type == pygame.MOUSEMOTION:
                    if phys_scene.dragged_horse is not None or phys_scene.dragged_prop is not None:
                        phys_scene.update_drag(mouse_pos)
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    drag_dist = math.hypot(
                        event.pos[0] - phys_scene.drag_start_pos[0],
                        event.pos[1] - phys_scene.drag_start_pos[1],
                    )
                    rel_kind, rel_obj = phys_scene.release_drag()
                    if drag_dist < 10.0 and not dna_exit_sign.collidepoint(event.pos) and try_click_strand_in_scene(
                        event.pos,
                        "dna_lab",
                        allow_body_fallback=(isinstance(rel_obj, SceneHorse) and rel_obj.entry.is_strand),
                    ):
                        continue
                    if rel_kind == "prop" and isinstance(rel_obj, SceneProp):
                        px, py = rel_obj.body.position.x, rel_obj.body.position.y
                        if rel_obj.kind == "potion" and rel_obj.genome is not None and is_in_dna_vat(px, py):
                            dna_vat_pool.append(rel_obj.genome)
                            for idx_p, g_p in enumerate(truck_potions):
                                if g_p is rel_obj.genome:
                                    truck_potions.pop(idx_p)
                                    break
                            phys_scene.remove_prop(rel_obj)
                            dna_sim_diversity = compute_dna_pool_diversity(dna_vat_pool)
                            set_active_npc_speech(
                                f"DNA added ({len(dna_vat_pool)} in vat, {dna_sim_diversity:.0f}% diversity)! Press the red button!"
                            )
                        else:
                            handle_owned_prop_release(rel_obj, DNA_TRUCK_LEFT, DNA_TRUCK_FLOOR_Y)
                    elif rel_kind == "horse" and isinstance(rel_obj, SceneHorse):
                        released = rel_obj
                        released.creature.config.gait.mode = "walk"
                        released.creature.config.gait.enabled = False
                        handle_npc_capture_release(
                            released, world.dna_guide_entry, DNA_TRUCK_LEFT, DNA_TRUCK_FLOOR_Y
                        )

            # ---------------- SCENE: YOUR RANCH ----------------
            elif scene == "your_ranch":
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    leave_your_ranch()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if your_ranch_exit_sign.collidepoint(mouse_pos):
                        leave_your_ranch()
                    elif your_ranch_sleep_sign.collidepoint(mouse_pos) and not breeding_active:
                        sleep_advance_day()
                    else:
                        phys_scene.start_drag(mouse_pos)
                elif event.type == pygame.MOUSEMOTION:
                    if phys_scene.dragged_horse is not None or phys_scene.dragged_prop is not None:
                        phys_scene.update_drag(mouse_pos)
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    drag_dist = math.hypot(
                        event.pos[0] - phys_scene.drag_start_pos[0],
                        event.pos[1] - phys_scene.drag_start_pos[1],
                    )
                    rel_kind, rel_obj = phys_scene.release_drag()
                    if (
                        drag_dist < 10.0
                        and not your_ranch_exit_sign.collidepoint(event.pos)
                        and not your_ranch_sleep_sign.collidepoint(event.pos)
                        and try_click_strand_in_scene(
                            event.pos,
                            "your_ranch",
                            allow_body_fallback=(isinstance(rel_obj, SceneHorse) and rel_obj.entry.is_strand),
                        )
                    ):
                        continue
                    if rel_kind == "prop" and isinstance(rel_obj, SceneProp):
                        handle_owned_prop_release(rel_obj, YOUR_TRUCK_LEFT, YOUR_TRUCK_FLOOR_Y)
                    elif rel_kind == "horse" and isinstance(rel_obj, SceneHorse):
                        released = rel_obj
                        pos = released.creature.bodies["torso"].position
                        can_run = (
                            not released.entry.is_tired
                            and not released.entry.is_hungry
                            and not released.entry.is_unconscious
                        )
                        if pos.y < RANCH_TRACK_FLOOR_Y + 35.0 and can_run:
                            released.creature.config.gait.mode = "run"
                            released.creature.config.gait.enabled = True
                            released.creature.run_blend = 1.0
                            released.creature.gait_blend = 1.0
                        else:
                            released.creature.config.gait.mode = "walk"
                            released.creature.config.gait.enabled = False

                        if is_inside_shed(pos.x, pos.y):
                            if breeding_active:
                                move_scene_horse_to(released, SHED_X1 - 110.0, YOUR_YARD_FLOOR_Y)
                            elif not entry_strands_functional(released.entry):
                                shed_notice = "Incomplete strand! Missing nucleotides."
                                shed_notice_timer = 2.0
                                move_scene_horse_to(released, SHED_X1 - 110.0, YOUR_YARD_FLOOR_Y)
                            elif released.entry.is_unconscious:
                                shed_notice = "Unconscious! Let them sleep."
                                shed_notice_timer = 2.0
                                move_scene_horse_to(released, SHED_X1 - 110.0, YOUR_YARD_FLOOR_Y)
                            elif released.entry.age == 0:
                                shed_notice = "Too young to breed! (Age 0)"
                                shed_notice_timer = 2.0
                                move_scene_horse_to(released, SHED_X1 - 110.0, YOUR_YARD_FLOOR_Y)
                            elif released.entry.age >= 10:
                                shed_notice = "Too old to breed! (Elder)"
                                shed_notice_timer = 2.0
                                move_scene_horse_to(released, SHED_X1 - 110.0, YOUR_YARD_FLOOR_Y)
                            elif released.entry.is_tired:
                                shed_notice = "Too tired to breed! Sleep first."
                                shed_notice_timer = 2.0
                                move_scene_horse_to(released, SHED_X1 - 110.0, YOUR_YARD_FLOOR_Y)
                            elif released.entry.is_hungry:
                                shed_notice = "Too hungry to breed! Feed hay."
                                shed_notice_timer = 2.0
                                move_scene_horse_to(released, SHED_X1 - 110.0, YOUR_YARD_FLOOR_Y)

        # ==============================================================
        # UPDATE & RENDER BY SCENE
        # ==============================================================

        if scene != "world":
            arena_guide_target = None

        if scene == "racecourse_track":
            if track_state == "betting":
                for lane in lanes:
                    torso = lane.creature.bodies["torso"]
                    lane.creature.update(dt, lane.floor)
                    tilt = math.atan2(math.sin(torso.angle), math.cos(torso.angle))
                    torso.torque += -320000.0 * tilt - 38000.0 * torso.angular_velocity
                    torso.velocity = (-torso.position.x * 4.0, torso.velocity.y)
                    lane.space.step(dt)
            elif track_state == "racing":
                race_time += dt
                cur_track_len = STRONGHORSE_LENGTH if race_mode == "stronghorse" else TRACK_LENGTH
                lane_front_xs = [get_horse_front_x(l.creature) for l in lanes]
                touching: list[tuple[float, LaneRuntime]] = []
                for idx_l, lane in enumerate(lanes):
                    fx = lane_front_xs[idx_l]
                    lane.creature.track_progress = max(0.0, min(1.0, fx / cur_track_len))
                    ahead = [ox - fx for j_l, ox in enumerate(lane_front_xs) if j_l != idx_l and ox > fx]
                    lane.creature.nearest_ahead_dist = min(ahead) if ahead else 9999.0
                    lane.creature.update(dt, lane.floor)
                    lane.space.step(dt)
                    fx_after = get_horse_front_x(lane.creature)
                    if fx_after >= cur_track_len:
                        touching.append((fx_after, lane))

                if touching or race_time >= 45.0:
                    ranked = sorted(lanes, key=lambda l: get_horse_front_x(l.creature), reverse=True)
                    for idx, lane in enumerate(ranked):
                        lane.place = idx + 1

                    winner_lane = ranked[0]
                    had_titles = (
                        winner_lane.entry.is_winner,
                        winner_lane.entry.is_gladiator,
                        winner_lane.entry.is_champion,
                    )
                    if race_mode in ("muddy_tracks", "stronghorse"):
                        winner_lane.entry.is_gladiator = True
                    else:
                        winner_lane.entry.is_winner = True
                    first_race_done = True

                    if race_mode == "bet":
                        if winner_lane.lane_index == active_bet_lane:
                            payout = max(active_bet + 5, int(round(active_bet * winner_lane.odds)))
                            bankroll += payout
                            status_banner = f"{winner_lane.entry.name} WINS! +${payout}"
                        else:
                            status_banner = f"{winner_lane.entry.name} wins!"
                    elif race_mode == "championship":
                        player_lane = next((l for l in ranked if l.is_player_horse), None)
                        if player_lane is not None:
                            player_lane.entry.is_tired = True
                        if player_lane and player_lane.place == 1:
                            player_lane.entry.is_champion = True
                            championship_won = True
                            invalidate_preview_cache(player_lane.entry.entry_id)
                            bankroll += 2500
                            status_banner = f"CHAMPION! {player_lane.entry.name} WINS! +$2500"
                        elif player_lane and player_lane.place == 2:
                            bankroll += 350
                            status_banner = f"{player_lane.entry.name} 2nd in Championship! +$350"
                        else:
                            status_banner = f"{winner_lane.entry.name} wins Championship!"
                    elif race_mode in ("muddy_tracks", "stronghorse"):
                        prizes = (500, 175, 75, 25) if race_mode == "stronghorse" else (450, 150, 60, 25)
                        player_lane = next((l for l in ranked if l.is_player_horse), None)
                        if player_lane is not None:
                            player_lane.entry.is_tired = True
                        if player_lane and player_lane.place is not None and 1 <= player_lane.place <= 4:
                            payout = prizes[player_lane.place - 1]
                            bankroll += payout
                            status_banner = f"{player_lane.entry.name} place {player_lane.place}! +${payout}"
                        else:
                            status_banner = f"{winner_lane.entry.name} wins!"
                    else:
                        player_lane = next((l for l in ranked if l.is_player_horse), None)
                        if player_lane is not None:
                            player_lane.entry.is_tired = True
                        if player_lane and player_lane.place == 1:
                            bankroll += 350
                            status_banner = f"{player_lane.entry.name} WINS! +$350"
                        elif player_lane and player_lane.place == 2:
                            bankroll += 120
                            status_banner = f"{player_lane.entry.name} 2nd! +$120"
                        elif player_lane and player_lane.place == 3:
                            bankroll += 50
                            status_banner = f"{player_lane.entry.name} 3rd! +$50"
                        elif player_lane and player_lane.place == 4:
                            bankroll += 20
                            status_banner = f"{player_lane.entry.name} 4th! +$20"
                        else:
                            status_banner = f"{winner_lane.entry.name} wins!"

                    track_state = "results"

                    new_titles = (
                        winner_lane.entry.is_winner,
                        winner_lane.entry.is_gladiator,
                        winner_lane.entry.is_champion,
                    )
                    if winner_lane.is_player_horse and new_titles != had_titles:
                        purchased_prices.pop(winner_lane.entry.entry_id, None)

            visible_world_w = SCREEN_W / WORLD_SCALE_X
            cur_track_len = STRONGHORSE_LENGTH if race_mode == "stronghorse" else TRACK_LENGTH
            max_cam_x = cur_track_len - visible_world_w * 0.85
            if track_state == "betting":
                target_cam_x = START_CAM_X
            else:
                lead_x = max(get_horse_front_x(l.creature) for l in lanes)
                target_cam_x = max(START_CAM_X, min(max_cam_x, lead_x - visible_world_w * 0.78))
            track_cam_x += (target_cam_x - track_cam_x) * 0.12

            draw_field_background(
                screen, track_cam_x, selected_lane, track_state, font_small,
                race_mode=race_mode, track_len=cur_track_len,
            )
            lane_hover_candidates: list[tuple[LaneRuntime, pygame.Rect]] = []
            track_player_name_rects = []
            for lane in lanes:
                is_sel = (
                    lane.lane_index == selected_lane
                    if track_state == "betting"
                    else lane.lane_index == active_bet_lane
                )
                h_rect, p_name_rect = draw_lane_horse_and_sign(
                    screen,
                    horse_canvas,
                    lane,
                    track_cam_x,
                    track_state,
                    is_sel,
                    race_mode,
                    name_fonts,
                    font_odds_small,
                    font_badge,
                )
                lane_hover_candidates.append((lane, h_rect))
                if p_name_rect is not None:
                    track_player_name_rects.append((lane.entry, p_name_rect))
                if lane.creature.quip_timer > 0.0 and lane.creature.quip and "torso" in lane.creature.bodies:
                    tx = get_horse_front_x(lane.creature) - track_cam_x
                    ty = lane.creature.bodies["torso"].position.y - 78.0
                    draw_speech_bubble(
                        screen,
                        pygame.Rect(int(tx - 90), int(ty - 28), 190, 52),
                        lane.creature.quip,
                        font_small,
                        max_lines=2,
                    )

            screen.blit(font_med.render(f"${bankroll}", True, (242, 234, 180)), (16, 12))
            
            if race_mode == "championship" and track_state != "results":
                champ_hdr = font_med.render("GRAND CHAMPIONSHIP  ($2,500 PRIZE)", True, (255, 206, 86))
                screen.blit(champ_hdr, champ_hdr.get_rect(center=(SCREEN_W * 0.5, 22)))

            if track_state == "betting":
                if race_mode == "bet":
                    draw_wood_sign(screen, sign_bet_minus, "-", font_med, sign_bet_minus.collidepoint(mouse_pos), with_post=False)
                    draw_wood_sign(screen, sign_bet_board, f"BET ${bet_amount}", font_badge, sign_bet_board.collidepoint(mouse_pos), with_post=False)
                    draw_wood_sign(screen, sign_bet_plus, "+", font_med, sign_bet_plus.collidepoint(mouse_pos), with_post=False)
                draw_wood_sign(
                    screen,
                    sign_start_race,
                    "RACE!",
                    font_med,
                    sign_start_race.collidepoint(mouse_pos),
                    with_post=False,
                    board_color=(72, 114, 58),
                )
            elif track_state == "results" and winner_lane is not None:
                res_s = font_med.render(status_banner, True, (255, 232, 148))
                screen.blit(res_s, (110, 18))
                draw_wood_sign(screen, sign_next_race, "NEXT", font_badge, sign_next_race.collidepoint(mouse_pos), with_post=False)
                if first_race_done:
                    draw_wood_sign(
                        screen,
                        sign_leave_track,
                        "LEAVE",
                        font_badge,
                        sign_leave_track.collidepoint(mouse_pos),
                        with_post=False,
                        board_color=(138, 72, 52),
                    )

            # Hover card on track (or active rename on owned horse)
            hovered_lane = None
            if hover_entry is not None and hover_card_rect is not None and hover_card_rect.collidepoint(mouse_pos):
                hovered_lane = next((l for l, _ in lane_hover_candidates if l.entry is hover_entry), None)
            if hovered_lane is None:
                for l, r in lane_hover_candidates:
                    if r.collidepoint(mouse_pos):
                        hovered_lane = l
                        break
            if hovered_lane is not None:
                l_rect = next(r for l, r in lane_hover_candidates if l is hovered_lane)
                r_txt = rename_text if renaming_entry is hovered_lane.entry else None
                c_rect, n_rect = draw_horse_hover_card(
                    screen,
                    hovered_lane.entry,
                    l_rect.centerx,
                    l_rect.top,
                    font_hover_name,
                    font_small,
                    owned_by_player=hovered_lane.is_player_horse,
                    mouse_pos=mouse_pos,
                    renaming_text=r_txt,
                )
                hover_entry = hovered_lane.entry
                hover_card_rect = c_rect
                hover_name_rect = n_rect
                hover_owned = hovered_lane.is_player_horse
            elif renaming_entry is not None:
                c_rect, n_rect = draw_horse_hover_card(
                    screen,
                    renaming_entry,
                    SCREEN_W * 0.5,
                    150,
                    font_hover_name,
                    font_small,
                    owned_by_player=True,
                    mouse_pos=mouse_pos,
                    renaming_text=rename_text,
                )
                hover_entry = renaming_entry
                hover_card_rect = c_rect
                hover_name_rect = n_rect
                hover_owned = True
            else:
                hover_entry = None
                hover_card_rect = None
                hover_name_rect = None
                hover_owned = False

        # ---------------- SCENE: RACECOURSE HUB ----------------
        elif scene == "racecourse_hub":
            phys_scene.step(dt)
            update_bites(dt)

            screen.fill((58, 92, 54))
            pygame.draw.rect(screen, (42, 62, 86), (0, 0, SCREEN_W, 130))
            pygame.draw.polygon(screen, (124, 48, 44), [(420, 130), (500, 72), (820, 72), (880, 130)])
            pygame.draw.rect(screen, (112, 88, 62), (0, 320, SCREEN_W, 400))

            screen.blit(font_med.render(f"${bankroll}", True, (242, 234, 180)), (150, 20))
            sup_txt = f"Day {day}  |  Hay: {truck_hay}  Beer: {truck_beer}"
            screen.blit(font_small.render(sup_txt, True, (216, 212, 198)), (250, 22))

            pen_horse = get_hub_pen_horse()
            can_race_own = (
                pen_horse is not None
                and 1 <= pen_horse.entry.age <= 9
                and not pen_horse.entry.is_tired
                and not pen_horse.entry.is_hungry
                and not pen_horse.entry.is_unconscious
                and not pen_horse.entry.is_champion
                and entry_strands_functional(pen_horse.entry)
                and bankroll >= 25
            )
            can_champ = (
                pen_horse is not None
                and pen_horse.entry.is_winner
                and not pen_horse.entry.is_champion
                and 1 <= pen_horse.entry.age <= 9
                and not pen_horse.entry.is_tired
                and not pen_horse.entry.is_hungry
                and not pen_horse.entry.is_unconscious
                and bankroll >= 500
            )
            if pen_horse is not None and not entry_strands_functional(pen_horse.entry):
                race_btn_lbl = "BROKEN STRAND"
            elif pen_horse is not None and pen_horse.entry.is_champion:
                race_btn_lbl = "CHAMPION (RETIRED)"
            elif pen_horse is not None and pen_horse.entry.is_unconscious:
                race_btn_lbl = "UNCONSCIOUS"
            elif pen_horse is not None and pen_horse.entry.age == 0:
                race_btn_lbl = "TOO YOUNG (AGE 0)"
            elif pen_horse is not None and pen_horse.entry.age >= 10:
                race_btn_lbl = "TOO OLD (ELDER)"
            elif pen_horse is not None and pen_horse.entry.is_tired:
                race_btn_lbl = "TIRED (SLEEP)"
            elif pen_horse is not None and pen_horse.entry.is_hungry:
                race_btn_lbl = "HUNGRY (FEED HAY)"
            else:
                race_btn_lbl = "RACE HORSE ($25)"

            if pen_horse is None:
                champ_btn_lbl = "CHAMPIONSHIP ($500)"
            elif pen_horse.entry.is_champion:
                champ_btn_lbl = "ALREADY CHAMPION"
            elif not pen_horse.entry.is_winner:
                champ_btn_lbl = "WIN A RACE FIRST"
            elif pen_horse.entry.is_unconscious:
                champ_btn_lbl = "UNCONSCIOUS"
            elif pen_horse.entry.age == 0:
                champ_btn_lbl = "TOO YOUNG (AGE 0)"
            elif pen_horse.entry.age >= 10:
                champ_btn_lbl = "TOO OLD (ELDER)"
            elif pen_horse.entry.is_tired:
                champ_btn_lbl = "TIRED (SLEEP)"
            elif pen_horse.entry.is_hungry:
                champ_btn_lbl = "HUNGRY (FEED HAY)"
            elif bankroll < 500:
                champ_btn_lbl = "NEED $500"
            else:
                champ_btn_lbl = "CHAMPIONSHIP ($500)"

            draw_wood_sign(screen, hub_sign_bet, "BET ON RANCH HORSES", font_med, hub_sign_bet.collidepoint(mouse_pos) and bankroll > 0)
            ref_x, ref_y = (
                (active_course.x, active_course.y)
                if active_course is not None
                else world.racecourse_pos
            )
            target_arena = nearest_arena_from(ref_x, ref_y)
            arena_dir = (
                compass_direction(target_arena.x - ref_x, target_arena.y - ref_y)
                if target_arena is not None
                else "NORTH"
            )
            draw_wood_sign(
                screen,
                hub_sign_arena,
                "Arena now welcoming ranchers!",
                font_badge,
                hub_sign_arena.collidepoint(mouse_pos),
                board_color=(138, 76, 52),
                subtext=f"GO {arena_dir}",
                subtext_font=font_med,
                subtext_color=(255, 224, 128),
            )
            draw_wood_sign(
                screen,
                hub_sign_race_mine,
                race_btn_lbl,
                font_med,
                hub_sign_race_mine.collidepoint(mouse_pos) and can_race_own,
                board_color=(82, 118, 58) if can_race_own else (84, 68, 54),
                text_color=(248, 240, 208) if can_race_own else (168, 156, 142),
            )
            draw_wood_sign(
                screen,
                hub_sign_championship,
                champ_btn_lbl,
                font_med,
                hub_sign_championship.collidepoint(mouse_pos) and can_champ,
                board_color=(158, 112, 36) if can_champ else (84, 68, 54),
                text_color=(255, 240, 184) if can_champ else (168, 156, 142),
            )
            draw_wood_sign(screen, hub_sign_exit, "EXIT", font_badge, hub_sign_exit.collidepoint(mouse_pos), with_post=False)
            if bankroll <= 0 and not truck_horses and not your_ranch_horses:
                draw_wood_sign(screen, hub_sign_bailout, "BAILOUT +$50", font_badge, hub_sign_bailout.collidepoint(mouse_pos))

            draw_standardized_truck_shell(screen, HUB_TRUCK_LEFT, HUB_TRUCK_FLOOR_Y)
            draw_open_pen_fence(screen, HUB_PEN_X1, HUB_PEN_X2, HUB_PEN_FLOOR_Y)
            if championship_won:
                px = HUB_PEDESTAL_X * SCENE_SCALE
                py = HUB_PEDESTAL_TOP_Y * SCENE_SCALE
                pygame.draw.rect(screen, (92, 86, 78), (px - 28, py, 56, 40), border_radius=4)
                pygame.draw.rect(screen, (214, 176, 72), (px - 22, py - 8, 44, 12), border_radius=3)
            phys_scene.draw_horses(screen)
            draw_scene_status_badges(screen, phys_scene, font_badge)

        elif scene == "arena_hub":
            phys_scene.step(dt)
            update_bites(dt)
            screen.fill((78, 64, 56))
            # Stone colosseum wall & arched colonnade along upper backdrop
            pygame.draw.rect(screen, (52, 48, 56), (0, 0, SCREEN_W, 130))
            pygame.draw.rect(screen, (118, 108, 96), (0, 118, SCREEN_W, 24))
            pygame.draw.line(screen, (162, 150, 134), (0, 118), (SCREEN_W, 118), 3)
            for ax in range(32, SCREEN_W, 110):
                pygame.draw.rect(screen, (94, 86, 78), (ax, 38, 64, 80), border_top_left_radius=32, border_top_right_radius=32)
                pygame.draw.rect(screen, (42, 38, 44), (ax + 10, 48, 44, 70), border_top_left_radius=22, border_top_right_radius=22)
            for bx in (420, 680, 1090):
                pygame.draw.polygon(screen, (176, 52, 46), [(bx, 12), (bx + 42, 12), (bx + 42, 84), (bx + 21, 68), (bx, 84)])
                pygame.draw.polygon(screen, (238, 192, 72), [(bx + 5, 16), (bx + 37, 16), (bx + 37, 74), (bx + 21, 61), (bx + 5, 74)], 2)
            screen.blit(font_med.render(f"${bankroll}", True, (242, 234, 180)), (150, 20))
            pen_horse = get_hub_pen_horse()
            can_arena = (
                pen_horse is not None
                and 1 <= pen_horse.entry.age <= 9
                and not pen_horse.entry.is_tired
                and not pen_horse.entry.is_hungry
                and not pen_horse.entry.is_unconscious
                and not pen_horse.entry.is_champion
                and entry_strands_functional(pen_horse.entry)
                and bankroll >= 25
            )
            draw_wood_sign(
                screen, arena_sign_stronghorse, "STRONGHORSE ($25)", font_med,
                arena_sign_stronghorse.collidepoint(mouse_pos) and can_arena,
                board_color=(92, 88, 82) if can_arena else (84, 68, 54),
            )
            draw_wood_sign(
                screen, arena_sign_muddy, "MUDDY TRACKS ($25)", font_med,
                arena_sign_muddy.collidepoint(mouse_pos) and can_arena,
                board_color=(78, 58, 40) if can_arena else (84, 68, 54),
            )
            draw_wood_sign(screen, hub_sign_exit, "EXIT", font_badge, hub_sign_exit.collidepoint(mouse_pos), with_post=False)
            draw_standardized_truck_shell(screen, HUB_TRUCK_LEFT, HUB_TRUCK_FLOOR_Y)
            draw_open_pen_fence(screen, HUB_PEN_X1, HUB_PEN_X2, HUB_PEN_FLOOR_Y)
            phys_scene.draw_horses(screen)
            draw_scene_status_badges(screen, phys_scene, font_badge)

        # ---------------- SCENE: OPEN WORLD ----------------
        elif scene == "world":
            keys = pygame.key.get_pressed()
            ax = (1 if (keys[pygame.K_d] or keys[pygame.K_RIGHT]) else 0) - (
                1 if (keys[pygame.K_a] or keys[pygame.K_LEFT]) else 0
            )
            ay = (1 if (keys[pygame.K_s] or keys[pygame.K_DOWN]) else 0) - (
                1 if (keys[pygame.K_w] or keys[pygame.K_UP]) else 0
            )

            curr_terr = world.get_terrain(truck_x, truck_y)
            spd = 860.0 * TERRAIN_SPEED_MULT[curr_terr]
            if world.is_path_at_world(truck_x, truck_y):
                spd *= PATH_SPEED_MULT

            if ax != 0 or ay != 0:
                mag = math.hypot(ax, ay)
                vx = (ax / mag) * spd
                vy = (ay / mag) * spd
                if ax != 0:
                    truck_facing = 1 if ax > 0 else -1
                truck_x = max(80.0, min(OW_WIDTH - 80.0, truck_x + vx * dt))
                truck_y = max(80.0, min(OW_HEIGHT - 80.0, truck_y + vy * dt))

            ow_cam_x = max(0.0, min(OW_WIDTH - SCREEN_W, truck_x - SCREEN_W * 0.5))
            ow_cam_y = max(0.0, min(OW_HEIGHT - SCREEN_H, truck_y - SCREEN_H * 0.5))
            if arena_guide_target is not None:
                ax_t, ay_t = arena_guide_target.x, arena_guide_target.y
                if (
                    ow_cam_x + 24.0 <= ax_t <= ow_cam_x + SCREEN_W - 24.0
                    and ow_cam_y + 24.0 <= ay_t <= ow_cam_y + SCREEN_H - 24.0
                ):
                    arena_guide_target = None

            world.update_wild_horses(dt, ow_cam_x + SCREEN_W * 0.5, ow_cam_y + SCREEN_H * 0.5)

            # Update falling apples & pick up ground apples driven over by the truck
            for ap in list(world.world_apples):
                if ap.falling:
                    ap.vy += 420.0 * dt
                    ap.y += ap.vy * dt
                    if ap.y >= ap.target_y:
                        ap.y = ap.target_y
                        ap.vy = 0.0
                        ap.falling = False
                if (not ap.falling) and math.hypot(ap.x - truck_x, ap.y - truck_y) < 56.0:
                    world.world_apples.remove(ap)
                    if ap.kind == "prickly_pear":
                        truck_prickly_pears += 1
                    else:
                        truck_apples += 1

            if lasso_anim is not None:
                if lasso_anim.phase == "shoot":
                    lasso_anim.progress += dt / 0.22
                    if lasso_anim.progress >= 1.0:
                        lasso_anim.progress = 0.0
                        lasso_anim.phase = "reel"
                        lasso_anim.target.flipped = True
                        lasso_anim.start_x = lasso_anim.target.x
                        lasso_anim.start_y = lasso_anim.target.y
                else:
                    lasso_anim.progress += dt / 0.40
                    t_reel = min(1.0, lasso_anim.progress)
                    lasso_anim.target.x = lasso_anim.start_x + (truck_x - lasso_anim.start_x) * t_reel
                    lasso_anim.target.y = lasso_anim.start_y + (truck_y - lasso_anim.start_y) * t_reel
                    if t_reel >= 1.0:
                        captured = lasso_anim.target
                        if captured in world.wild_horses:
                            world.wild_horses.remove(captured)
                        truck_horses.append(captured.entry)
                        if not has_infinite_lasso:
                            lasso_count = max(0, lasso_count - 1)
                            if lasso_count <= 0:
                                lasso_armed = False
                        lasso_anim = None

            c0 = max(0, int(ow_cam_x // OW_TILE))
            c1 = min(OW_COLS - 1, int((ow_cam_x + SCREEN_W) // OW_TILE))
            r0 = max(0, int(ow_cam_y // OW_TILE))
            r1 = min(OW_ROWS - 1, int((ow_cam_y + SCREEN_H) // OW_TILE))

            for r in range(r0, r1 + 1):
                for c in range(c0, c1 + 1):
                    t_type = world.get_tile_terrain(c, r)
                    sx = c * OW_TILE - ow_cam_x
                    sy = r * OW_TILE - ow_cam_y
                    is_path = (c, r) in world.path_tiles
                    if is_path:
                        pygame.draw.rect(screen, PATH_COLOR, (sx, sy, OW_TILE + 1, OW_TILE + 1))
                        pygame.draw.rect(screen, (166, 138, 98), (sx + 10, sy + 14, OW_TILE - 20, OW_TILE - 28), border_radius=8)
                    else:
                        pygame.draw.rect(screen, TERRAIN_COLORS[t_type], (sx, sy, OW_TILE + 1, OW_TILE + 1))

                        h_val = (c * 73856093 ^ r * 19349663) & 0xFFFF
                        if t_type == "grass" and h_val % 5 == 0:
                            gx, gy = sx + 16 + (h_val % 30), sy + 20 + ((h_val >> 4) % 28)
                            pygame.draw.line(screen, (92, 148, 78), (gx, gy), (gx - 3, gy - 6), 2)
                            pygame.draw.line(screen, (92, 148, 78), (gx + 2, gy), (gx + 5, gy - 5), 2)
                        elif t_type == "desert" and h_val % 4 == 0:
                            dx, dy = sx + 10 + (h_val % 24), sy + 24 + ((h_val >> 5) % 24)
                            pygame.draw.arc(screen, (172, 138, 82), (dx, dy, 28, 10), 0.2, 2.9, 2)
                        elif t_type == "rock" and h_val % 3 == 0:
                            rx, ry = sx + 12 + (h_val % 28), sy + 20 + ((h_val >> 4) % 28)
                            pygame.draw.polygon(
                                screen, (88, 84, 80), [(rx, ry), (rx + 12, ry - 5), (rx + 18, ry + 4), (rx + 4, ry + 7)]
                            )
                        elif t_type == "mountain" and h_val % 2 == 0:
                            mx, my = sx + OW_TILE * 0.5, sy + OW_TILE * 0.6
                            pygame.draw.polygon(screen, (64, 66, 78), [(mx - 24, my + 16), (mx, my - 22), (mx + 24, my + 16)])
                            pygame.draw.polygon(screen, (212, 220, 232), [(mx - 8, my - 10), (mx, my - 22), (mx + 8, my - 10)])
                        elif t_type == "snowy_peaks" and h_val % 2 == 0:
                            mx, my = sx + OW_TILE * 0.5, sy + OW_TILE * 0.62
                            pygame.draw.polygon(screen, (168, 178, 196), [(mx - 26, my + 16), (mx, my - 24), (mx + 26, my + 16)])
                            pygame.draw.polygon(screen, (244, 248, 252), [(mx - 10, my - 8), (mx, my - 24), (mx + 10, my - 8)])
                        elif t_type == "oasis":
                            draw_world_oasis_tile(
                                screen,
                                sx,
                                sy,
                                h_val,
                                world.get_tile_terrain(c, r - 1) == "oasis",
                                world.get_tile_terrain(c, r + 1) == "oasis",
                                world.get_tile_terrain(c - 1, r) == "oasis",
                                world.get_tile_terrain(c + 1, r) == "oasis",
                                world.get_tile_terrain(c - 1, r - 1) == "oasis",
                                world.get_tile_terrain(c + 1, r - 1) == "oasis",
                                world.get_tile_terrain(c - 1, r + 1) == "oasis",
                                world.get_tile_terrain(c + 1, r + 1) == "oasis",
                            )
                        elif t_type == "deep_forest":
                            draw_world_forest_tile(screen, sx, sy, h_val)
                        elif t_type == "savanna" and h_val % 4 == 0:
                            gx, gy = sx + 14 + (h_val % 24), sy + 22 + ((h_val >> 4) % 22)
                            pygame.draw.line(screen, (186, 168, 72), (gx, gy), (gx - 2, gy - 8), 2)
                            pygame.draw.line(screen, (196, 176, 78), (gx + 4, gy), (gx + 6, gy - 7), 2)

            hovered_tile_label: tuple[str, float, float] | None = None
            wx_mouse = mouse_pos[0] + ow_cam_x
            wy_mouse = mouse_pos[1] + ow_cam_y

            for rc in world.racecourses:
                rc_rect_w = tile_rect_world(rc.x, rc.y)
                if -OW_TILE <= rc_rect_w.x - ow_cam_x <= SCREEN_W + OW_TILE and -OW_TILE <= rc_rect_w.y - ow_cam_y <= SCREEN_H + OW_TILE:
                    rsx, rsy = rc_rect_w.x - ow_cam_x, rc_rect_w.y - ow_cam_y
                    draw_world_racecourse(screen, rsx, rsy, rc.is_arena)
                    if rc_rect_w.collidepoint(wx_mouse, wy_mouse):
                        hovered_tile_label = (rc.name, rsx + 32, rsy - 6)

            # Exact 1-tile Your Ranch (64x64)
            yr_rect_w = tile_rect_world(*world.your_ranch_pos)
            if -OW_TILE <= yr_rect_w.x - ow_cam_x <= SCREEN_W + OW_TILE and -OW_TILE <= yr_rect_w.y - ow_cam_y <= SCREEN_H + OW_TILE:
                ysx, ysy = yr_rect_w.x - ow_cam_x, yr_rect_w.y - ow_cam_y
                pygame.draw.rect(screen, (112, 86, 62), (ysx + 4, ysy + 26, 30, 30))
                pygame.draw.rect(screen, (214, 188, 128), (ysx + 4, ysy + 26, 30, 30), 2)
                pygame.draw.rect(screen, (68, 118, 178), (ysx + 32, ysy + 18, 28, 36), border_radius=3)
                pygame.draw.polygon(screen, (226, 178, 66), [(ysx + 29, ysy + 18), (ysx + 46, ysy + 4), (ysx + 63, ysy + 18)])
                if yr_rect_w.collidepoint(wx_mouse, wy_mouse):
                    hovered_tile_label = ("Your Ranch", ysx + 32, ysy - 6)

            # Exact 1-tile Gene Factory
            gf_rect_w = tile_rect_world(*world.gene_factory_pos)
            if -OW_TILE <= gf_rect_w.x - ow_cam_x <= SCREEN_W + OW_TILE and -OW_TILE <= gf_rect_w.y - ow_cam_y <= SCREEN_H + OW_TILE:
                gsx, gsy = gf_rect_w.x - ow_cam_x, gf_rect_w.y - ow_cam_y
                pygame.draw.rect(screen, (198, 224, 236), (gsx + 4, gsy + 16, 26, 38), border_radius=2)
                pygame.draw.rect(screen, (120, 168, 196), (gsx + 4, gsy + 16, 26, 38), 2, border_radius=2)
                pygame.draw.rect(screen, (98, 62, 148), (gsx + 32, gsy + 20, 26, 34), border_radius=3)
                pygame.draw.rect(screen, (214, 150, 245), (gsx + 36, gsy + 28, 18, 8), border_radius=2)
                pygame.draw.line(screen, (170, 190, 206), (gsx + 30, gsy + 34), (gsx + 32, gsy + 34), 2)
                if gf_rect_w.collidepoint(wx_mouse, wy_mouse):
                    hovered_tile_label = ("Gene Factory", gsx + 32, gsy - 6)

            # Exact 1-tile DNA Lab
            dl_rect_w = tile_rect_world(*world.dna_lab_pos)
            if -OW_TILE <= dl_rect_w.x - ow_cam_x <= SCREEN_W + OW_TILE and -OW_TILE <= dl_rect_w.y - ow_cam_y <= SCREEN_H + OW_TILE:
                dsx, dsy = dl_rect_w.x - ow_cam_x, dl_rect_w.y - ow_cam_y
                pygame.draw.rect(screen, (62, 74, 96), (dsx + 4, dsy + 14, 56, 42), border_radius=4)
                pygame.draw.rect(screen, (112, 132, 162), (dsx + 4, dsy + 14, 56, 42), 2, border_radius=4)
                pygame.draw.rect(screen, (16, 28, 22), (dsx + 24, dsy + 20, 30, 20), border_radius=2)
                pygame.draw.rect(screen, (92, 232, 146), (dsx + 27, dsy + 24, 24, 3))
                pygame.draw.rect(screen, (182, 74, 224), (dsx + 8, dsy + 20, 12, 28), border_radius=3)
                pygame.draw.circle(screen, (226, 56, 62), (int(dsx + 48), int(dsy + 47)), 4)
                if dl_rect_w.collidepoint(wx_mouse, wy_mouse):
                    hovered_tile_label = ("DNA Lab", dsx + 32, dsy - 6)

            # Exact 1-tile Outfitter Shops (64x64)
            for sh in world.shops:
                sh_rect_w = tile_rect_world(sh.x, sh.y)
                if -OW_TILE <= sh_rect_w.x - ow_cam_x <= SCREEN_W + OW_TILE and -OW_TILE <= sh_rect_w.y - ow_cam_y <= SCREEN_H + OW_TILE:
                    ssx, ssy = sh_rect_w.x - ow_cam_x, sh_rect_w.y - ow_cam_y
                    if sh.shop_kind == "convenience":
                        draw_world_convenience_store(screen, ssx, ssy, font_badge)
                    else:
                        pygame.draw.rect(screen, (148, 102, 58), (ssx + 8, ssy + 20, 48, 36), border_radius=4)
                        pygame.draw.polygon(screen, (194, 78, 52), [(ssx + 4, ssy + 21), (ssx + 32, ssy + 6), (ssx + 60, ssy + 21)])
                        pygame.draw.rect(screen, (62, 42, 26), (ssx + 25, ssy + 38, 14, 18))
                        pygame.draw.circle(screen, (236, 206, 132), (int(ssx + 32), int(ssy + 30)), 5, 2)
                    if sh_rect_w.collidepoint(wx_mouse, wy_mouse):
                        hovered_tile_label = (sh.name, ssx + 32, ssy - 6)

            # Exact 1-tile Ranches (64x64)
            for r in world.ranches:
                r_rect_w = tile_rect_world(r.x, r.y)
                if -OW_TILE <= r_rect_w.x - ow_cam_x <= SCREEN_W + OW_TILE and -OW_TILE <= r_rect_w.y - ow_cam_y <= SCREEN_H + OW_TILE:
                    rsx, rsy = r_rect_w.x - ow_cam_x, r_rect_w.y - ow_cam_y
                    pygame.draw.rect(screen, (112, 86, 62), (rsx + 4, rsy + 26, 30, 30))
                    pygame.draw.rect(screen, (192, 168, 134), (rsx + 4, rsy + 26, 30, 30), 2)
                    pygame.draw.rect(screen, (166, 56, 48), (rsx + 32, rsy + 20, 28, 34), border_radius=3)
                    pygame.draw.polygon(screen, (118, 38, 34), [(rsx + 29, rsy + 20), (rsx + 46, rsy + 6), (rsx + 63, rsy + 20)])
                    if r_rect_w.collidepoint(wx_mouse, wy_mouse):
                        hovered_tile_label = (r.name, rsx + 32, rsy - 6)

            for cut in world.meats:
                if ow_cam_x - 120 <= cut.x <= ow_cam_x + SCREEN_W + 120 and ow_cam_y - 80 <= cut.y <= ow_cam_y + SCREEN_H + 80:
                    msx, msy = cut.x - ow_cam_x, cut.y - ow_cam_y
                    carcass = build_carcass_surface((108, 72))
                    screen.blit(carcass, (msx - 54, msy - 36))
                    num = font_small.render(str(cut.uses), True, (255, 246, 224))
                    badge_r = num.get_rect(center=(int(msx), int(msy + 4))).inflate(10, 4)
                    pygame.draw.rect(screen, (48, 16, 20), badge_r, border_radius=5)
                    screen.blit(num, num.get_rect(center=badge_r.center))
                    if math.hypot(cut.x - wx_mouse, cut.y - wy_mouse) < 70.0:
                        hovered_tile_label = ("Meat", msx, msy - 40)

            for fos in world.fossils:
                if ow_cam_x - 40 <= fos.x <= ow_cam_x + SCREEN_W + 40 and ow_cam_y - 40 <= fos.y <= ow_cam_y + SCREEN_H + 40:
                    fsx, fsy = fos.x - ow_cam_x, fos.y - ow_cam_y
                    draw_world_fossil(screen, fos, fsx, fsy)
                    if math.hypot(fos.x - wx_mouse, fos.y - wy_mouse) < 36.0:
                        hovered_tile_label = ("Fossil", fsx, fsy - 20)

            visible_trees = [
                tr
                for tr in world.trees
                if ow_cam_x - 100 <= tr.x <= ow_cam_x + SCREEN_W + 100
                and ow_cam_y - 100 <= tr.y <= ow_cam_y + SCREEN_H + 120
            ]
            visible_apples = [
                ap
                for ap in world.world_apples
                if ow_cam_x - 40 <= ap.x <= ow_cam_x + SCREEN_W + 40
                and ow_cam_y - 40 <= ap.y <= ow_cam_y + SCREEN_H + 40
            ]
            visible_horses = [
                wh
                for wh in world.wild_horses
                if ow_cam_x - 80 <= wh.x <= ow_cam_x + SCREEN_W + 80
                and ow_cam_y - 80 <= wh.y <= ow_cam_y + SCREEN_H + 80
            ]

            draw_queue: list[tuple[float, str, object]] = []
            for tr in visible_trees:
                draw_queue.append((tr.y, "tree", tr))
            for ap in visible_apples:
                draw_queue.append((ap.y, "apple", ap))
            for wh in visible_horses:
                draw_queue.append((wh.y, "horse", wh))
            draw_queue.append((truck_y, "truck", None))
            draw_queue.sort(key=lambda item: item[0])

            hovered_wh: WildHorse | None = None
            tsx, tsy = truck_x - ow_cam_x, truck_y - ow_cam_y
            for _y, kind_item, obj in draw_queue:
                if kind_item == "tree":
                    tr_obj = obj
                    assert isinstance(tr_obj, TreeData)
                    draw_world_tree(screen, tr_obj, tr_obj.x - ow_cam_x, tr_obj.y - ow_cam_y)
                elif kind_item == "apple":
                    ap_obj = obj
                    assert isinstance(ap_obj, WorldApple)
                    draw_world_apple(screen, ap_obj.x - ow_cam_x, ap_obj.y - ow_cam_y, kind=ap_obj.kind)
                elif kind_item == "horse":
                    wh = obj
                    assert isinstance(wh, WildHorse)
                    wh_sx = wh.x - ow_cam_x
                    wh_sy = wh.y - ow_cam_y
                    draw_wild_horse_actual(screen, wh, wh_sx, wh_sy)
                    if pygame.Rect(int(wh_sx - 36), int(wh_sy - 36), 72, 54).collidepoint(mouse_pos):
                        hovered_wh = wh
                else:
                    truck_surf = pygame.Surface((110, 60), pygame.SRCALPHA)
                    pygame.draw.ellipse(truck_surf, (0, 0, 0, 70), (6, 42, 98, 14))
                    pygame.draw.rect(truck_surf, (218, 222, 232), (6, 12, 58, 32), border_radius=4)
                    pygame.draw.rect(truck_surf, (92, 102, 124), (6, 12, 58, 32), 2, border_radius=4)
                    pygame.draw.rect(truck_surf, (206, 62, 54), (64, 20, 38, 24), border_radius=4)
                    pygame.draw.rect(truck_surf, (206, 62, 54), (66, 10, 22, 14), border_radius=3)
                    pygame.draw.rect(truck_surf, (152, 212, 244), (72, 12, 13, 9))
                    pygame.draw.circle(truck_surf, (28, 28, 34), (22, 44), 7)
                    pygame.draw.circle(truck_surf, (28, 28, 34), (50, 44), 7)
                    pygame.draw.circle(truck_surf, (28, 28, 34), (88, 44), 7)
                    if truck_facing < 0:
                        truck_surf = pygame.transform.flip(truck_surf, True, False)
                    screen.blit(truck_surf, (tsx - 55, tsy - 32))

            if lasso_anim is not None:
                if lasso_anim.phase == "shoot":
                    t_s = min(1.0, lasso_anim.progress)
                    rx = truck_x + (lasso_anim.target.x - truck_x) * t_s - ow_cam_x
                    ry = truck_y + (lasso_anim.target.y - truck_y) * t_s - ow_cam_y
                else:
                    rx = lasso_anim.target.x - ow_cam_x
                    ry = lasso_anim.target.y - ow_cam_y
                rope = (108, 224, 255) if has_infinite_lasso else (226, 198, 124)
                pygame.draw.line(screen, rope, (tsx, tsy - 6), (rx, ry), 3)
                pygame.draw.circle(screen, rope, (int(rx), int(ry)), 8, 2)

            if arena_guide_target is not None:
                asx = arena_guide_target.x - ow_cam_x
                asy = arena_guide_target.y - ow_cam_y
                adx = asx - tsx
                ady = asy - tsy
                ang = math.atan2(ady, adx)
                margin = 48.0
                hit_t = []
                if abs(adx) > 1e-4:
                    hit_t.append(((SCREEN_W - margin - tsx) if adx > 0 else (margin - tsx)) / adx)
                if abs(ady) > 1e-4:
                    hit_t.append(((SCREEN_H - margin - tsy) if ady > 0 else (margin - tsy)) / ady)
                edge_t = min((t for t in hit_t if t > 0.0), default=1.0)
                edge_t = min(edge_t, 1.0)
                pulse = 1.0 + 0.06 * math.sin(pygame.time.get_ticks() * 0.008)
                acx = max(margin, min(SCREEN_W - margin, tsx + adx * edge_t * pulse))
                acy = max(margin, min(SCREEN_H - margin, tsy + ady * edge_t * pulse))
                ux, uy = math.cos(ang), math.sin(ang)
                px, py = -uy, ux
                arrow_pts = [
                    (acx + ux * 24.0, acy + uy * 24.0),
                    (acx + ux * 2.0 + px * 15.0, acy + uy * 2.0 + py * 15.0),
                    (acx + ux * 5.0 + px * 6.0, acy + uy * 5.0 + py * 6.0),
                    (acx - ux * 16.0 + px * 6.0, acy - uy * 16.0 + py * 6.0),
                    (acx - ux * 16.0 - px * 6.0, acy - uy * 16.0 - py * 6.0),
                    (acx + ux * 5.0 - px * 6.0, acy + uy * 5.0 - py * 6.0),
                    (acx + ux * 2.0 - px * 15.0, acy + uy * 2.0 - py * 15.0),
                ]
                shadow_pts = [(x + 2, y + 3) for x, y in arrow_pts]
                pygame.draw.polygon(screen, (28, 20, 16), shadow_pts)
                pygame.draw.polygon(screen, (255, 206, 72), arrow_pts)
                pygame.draw.polygon(screen, (118, 52, 28), arrow_pts, 2)

            if hovered_wh is not None:
                draw_horse_hover_card(
                    screen,
                    hovered_wh.entry,
                    hovered_wh.x - ow_cam_x,
                    hovered_wh.y - ow_cam_y - 34,
                    font_hover_name,
                    font_small,
                    owned_by_player=False,
                    mouse_pos=mouse_pos,
                )
            elif hovered_tile_label is not None:
                lbl_txt, lx, ly = hovered_tile_label
                lbl_s = font_badge.render(lbl_txt, True, (248, 236, 206))
                sign_r = pygame.Rect(0, 0, lbl_s.get_width() + 16, 24)
                sign_r.midbottom = (int(max(60, min(SCREEN_W - 60, lx))), int(max(30, ly)))
                draw_wood_sign(screen, sign_r, lbl_txt, font_badge, hover=False, with_post=False)

            hud_txt = f"${bankroll}   Day {day}   Lassos: {lasso_count}   Hay: {truck_hay}   Apples: {truck_apples}   Beer: {truck_beer}"
            hud_s = font_med.render(hud_txt, True, (245, 236, 184))
            hud_bg = pygame.Surface((hud_s.get_width() + 20, 32), pygame.SRCALPHA)
            hud_bg.fill((18, 22, 30, 175))
            screen.blit(hud_bg, (10, 8))
            screen.blit(hud_s, (18, 14))
            if lasso_count > 0 or has_infinite_lasso:
                lasso_btn_rect = pygame.Rect(SCREEN_W - 76, 16, 58, 58)
                draw_lasso_button(
                    screen,
                    lasso_btn_rect,
                    lasso_armed,
                    lasso_btn_rect.collidepoint(mouse_pos),
                    count=lasso_count,
                    font_badge=font_badge,
                    infinite=has_infinite_lasso,
                )

        # ---------------- SCENE: TRUCK INTERIOR (STANDARDIZED & PHYSICAL) ----------------
        elif scene == "truck":
            phys_scene.step(dt)
            update_bites(dt)
            terr = world.get_terrain(truck_x, truck_y)
            screen.fill(TERRAIN_COLORS[terr])

            draw_standardized_truck_shell(screen, TRUCK_SCENE_LEFT, TRUCK_SCENE_FLOOR_Y)
            phys_scene.draw_horses(screen)
            draw_scene_status_badges(screen, phys_scene, font_badge)
            draw_wood_sign(screen, truck_sign_exit, "EXIT", font_badge, truck_sign_exit.collidepoint(mouse_pos), with_post=False)
            sup_txt = f"${bankroll}   Day {day}   Lassos: {lasso_count}   Hay: {truck_hay}   Apples: {truck_apples}   Beer: {truck_beer}"
            screen.blit(font_med.render(sup_txt, True, (245, 236, 184)), (155, 24))

        # ---------------- SCENE: SHOP (SHELVES, SHOPKEEPER, STANDARDIZED TRUCK) ----------------
        elif scene == "shop" and active_shop is not None:
            phys_scene.step(dt)
            update_bites(dt)

            is_conv = active_shop.shop_kind == "convenience"
            if is_conv:
                # Bright modern 24H convenience store interior
                screen.fill((204, 218, 222))
                pygame.draw.rect(screen, (36, 52, 62), (0, 0, SCREEN_W, 48))
                pygame.draw.rect(screen, (236, 114, 38), (0, 48, SCREEN_W, 5))
                pygame.draw.rect(screen, (42, 168, 88), (0, 53, SCREEN_W, 5))
                pygame.draw.rect(screen, (214, 54, 52), (0, 58, SCREEN_W, 5))
                pygame.draw.rect(screen, (230, 236, 240), (24, 72, 490, 422), border_radius=8)
                pygame.draw.rect(screen, (62, 152, 164), (24, 72, 490, 422), 3, border_radius=8)
                pygame.draw.rect(screen, (176, 186, 192), (0, 669, 1200, 51))
                for tx in range(0, 1200, 60):
                    pygame.draw.rect(screen, (198, 206, 212), (tx, 669, 30, 26))
                    pygame.draw.rect(screen, (198, 206, 212), (tx + 30, 695, 30, 25))
            else:
                # Warm wooden outfitter shop interior
                screen.fill((72, 52, 36))
                pygame.draw.rect(screen, (94, 68, 46), (24, 54, 490, 440), border_radius=8)
                pygame.draw.rect(screen, (58, 40, 28), (24, 54, 490, 440), 3, border_radius=8)
                pygame.draw.rect(screen, (88, 70, 52), (0, 669, 1200, 51))

            # Display shelves (matching physics slabs)
            if is_conv:
                shelf_labels = [
                    (410.0, f"CHILI PEPPER  $15  ({active_shop.stock.get('chili', 0)}/8 left)"),
                    (680.0, f"APPLE CRATE (x25)  $50  ({active_shop.stock.get('apple_crate', 0)}/3 left)"),
                ]
            else:
                shelf_labels = [
                    (SHOP_SHELF_YS["lasso"], f"LASSO  $50   ({active_shop.stock.get('lasso', 0)}/4 left)"),
                    (SHOP_SHELF_YS["hay"], f"HAY  $5   ({active_shop.stock.get('hay', 0)}/8 left)"),
                    (SHOP_SHELF_YS["beer"], f"BEER  $10   ({active_shop.stock.get('beer', 0)}/12 left)"),
                ]
            sx1_s = SHOP_SHELF_X1 * SCENE_SCALE
            sx2_s = SHOP_SHELF_X2 * SCENE_SCALE
            for sy_phys, lbl_txt in shelf_labels:
                sy_s = sy_phys * SCENE_SCALE
                shelf_fill = (214, 224, 232) if is_conv else (138, 98, 60)
                shelf_edge = (42, 168, 176) if is_conv else (84, 56, 34)
                lbl_col = (34, 52, 62) if is_conv else (246, 232, 198)
                pygame.draw.rect(screen, shelf_fill, (sx1_s - 6, sy_s, sx2_s - sx1_s + 12, 14), border_radius=3)
                pygame.draw.rect(screen, shelf_edge, (sx1_s - 6, sy_s, sx2_s - sx1_s + 12, 14), 2, border_radius=3)
                lbl_surf = font_badge.render(lbl_txt, True, lbl_col)
                screen.blit(lbl_surf, (sx1_s, sy_s - 62))

            draw_wood_sign(screen, shop_exit_sign, "EXIT", font_badge, shop_exit_sign.collidepoint(mouse_pos), with_post=False)
            screen.blit(font_med.render(f"${bankroll}", True, (245, 236, 184)), (1110, 14))
            sup_txt = f"Day {day}  |  Lassos: {lasso_count}   Hay: {truck_hay}   Beer: {truck_beer}"
            screen.blit(font_small.render(sup_txt, True, (226, 218, 196)), (140, 20))

            keeper_sh = active_scene_npc()
            if keeper_sh is not None and not keeper_sh.entry.is_unconscious and shop_speech:
                draw_speech_bubble(screen, pygame.Rect(156, 526, 355, 110), shop_speech, font_med, max_lines=3)

            draw_standardized_truck_shell(screen, SHOP_TRUCK_LEFT, SHOP_TRUCK_FLOOR_Y)
            phys_scene.draw_horses(screen)
            draw_scene_status_badges(screen, phys_scene, font_badge)

        # ---------------- SCENE: RANCH (UNIFIED PHYSICS, OPEN PEN, PHYSICAL DRAG, REAL TRACK) ----------------
        elif scene == "ranch" and active_ranch is not None:
            # A horse that runs off the right of the sample track reveals the rabbit pen.
            # Past the far end of an extended track, it laps back to the left.
            track_far = (PHYS_W * 2.0 - 90.0) if active_ranch.has_rabbit_pen else (PHYS_W - 40.0)
            for sh in phys_scene.horses:
                if sh is phys_scene.dragged_horse:
                    continue
                torso = sh.creature.bodies["torso"]
                if sh.creature.config.gait.enabled and torso.position.y < RANCH_TRACK_FLOOR_Y + 40.0:
                    if (
                        active_ranch.has_rabbit_pen
                        and ranch_view_target < PHYS_W * 0.5
                        and torso.position.x > PHYS_W - 20.0
                    ):
                        ranch_view_target = PHYS_W
                    if torso.position.x > track_far:
                        dx = -160.0 - torso.position.x
                        for b in set(sh.creature.bodies.values()):
                            b.position = (b.position.x + dx, b.position.y)

            ranch_view_x += (ranch_view_target - ranch_view_x) * min(1.0, dt * 5.0)
            phys_scene.view_x = ranch_view_x
            if phys_scene.dragged_horse is not None or phys_scene.dragged_prop is not None:
                phys_scene.update_drag(mouse_pos)

            phys_scene.step(dt)
            for sh in list(phys_scene.horses):
                if sh is not phys_scene.dragged_horse:
                    try_confirm_ranch_transfer(sh, strict_interior=True)
            update_bites(dt)

            # Ranch scenery
            screen.fill((66, 98, 56))
            pygame.draw.rect(screen, (48, 72, 98), (0, 0, SCREEN_W, 92))

            # Sample Race Track dirt stretch (real physics floor at RANCH_TRACK_FLOOR_Y)
            track_y_screen = int(RANCH_TRACK_FLOOR_Y * SCENE_SCALE)
            pygame.draw.rect(screen, (112, 86, 62), (0, track_y_screen - 54, SCREEN_W, 66))
            pygame.draw.line(screen, (148, 120, 88), (0, track_y_screen - 54), (SCREEN_W, track_y_screen - 54), 3)
            pygame.draw.line(screen, (148, 120, 88), (0, track_y_screen + 12), (SCREEN_W, track_y_screen + 12), 3)
            post_far = int((PHYS_W * 2.0 if active_ranch.has_rabbit_pen else PHYS_W) * SCENE_SCALE)
            for fx in range(40, post_far, 120):
                sx = fx - ranch_view_x * SCENE_SCALE
                if -20 <= sx <= SCREEN_W + 20:
                    pygame.draw.rect(screen, (124, 94, 62), (sx, track_y_screen - 82, 6, 28))
            pygame.draw.line(screen, (182, 156, 122), (0, track_y_screen - 72), (SCREEN_W, track_y_screen - 72), 3)

            draw_wood_sign(screen, ranch_exit_sign, "EXIT", font_badge, ranch_exit_sign.collidepoint(mouse_pos), with_post=False)
            screen.blit(font_med.render(f"${bankroll}", True, (245, 236, 184)), (1120, 14))
            if ranch_view_x > PHYS_W * 0.45:
                sup_txt = f"Rabbit Pen ({len(active_ranch.rabbits)})  |  Hay: {truck_hay}  Beer: {truck_beer}"
            else:
                sup_txt = f"{active_ranch.name} ({len(active_ranch.horses)} horses)  |  Hay: {truck_hay}  Beer: {truck_beer}"
            screen.blit(font_small.render(sup_txt, True, (226, 224, 208)), (135, 20))

            cam = ranch_view_x
            draw_open_pen_fence(screen, RANCH_PEN_X1 - cam, RANCH_PEN_X2 - cam, RANCH_PEN_FLOOR_Y)
            if active_ranch.has_rabbit_pen:
                draw_open_pen_fence(
                    screen,
                    PHYS_W + RANCH_PEN_X1 - cam,
                    PHYS_W + RANCH_PEN_X2 - cam,
                    RANCH_PEN_FLOOR_Y,
                )
                showing_pen = ranch_view_target >= PHYS_W * 0.5
                arrow = ranch_arrow_left if showing_pen else ranch_arrow_right
                hov_arrow = arrow.collidepoint(mouse_pos)
                pygame.draw.rect(screen, (98, 72, 46) if hov_arrow else (78, 56, 36), arrow, border_radius=8)
                pygame.draw.rect(screen, (186, 150, 96), arrow, 2, border_radius=8)
                tip_x = arrow.left + 10 if showing_pen else arrow.right - 10
                base_x = arrow.right - 12 if showing_pen else arrow.left + 12
                pygame.draw.polygon(
                    screen,
                    (246, 232, 198),
                    [(tip_x, arrow.centery), (base_x, arrow.centery - 12), (base_x, arrow.centery + 12)],
                )

            # Standardized Truck (bottom-right, identical physics interior, no text)
            draw_standardized_truck_shell(screen, RANCH_TRUCK_LEFT - cam, RANCH_TRUCK_FLOOR_Y)

            # Bottom-left ground + Rancher speech bubble (when rancher is present)
            pygame.draw.rect(screen, (88, 70, 52), (0, 669, 1200, 51))
            rancher_sh = active_scene_npc()
            if rancher_sh is not None and not rancher_sh.entry.is_unconscious and ranch_speech:
                draw_speech_bubble(screen, pygame.Rect(156, 530, 355, 118), ranch_speech, font_med, max_lines=4)

            # Draw ALL live physics horses & props in the unified scene
            phys_scene.draw_horses(screen)
            draw_scene_status_badges(screen, phys_scene, font_badge)

        # ---------------- SCENE: GENE FACTORY ----------------
        elif scene == "gene_factory":
            jean_sh = active_scene_npc()
            jean_conscious = jean_sh is not None and not jean_sh.entry.is_unconscious
            if jean_override_timer > 0.0:
                jean_override_timer = max(0.0, jean_override_timer - dt)
            if jean_conscious:
                jean_line_timer += dt
                if jean_override_timer <= 0.0 and not jean_intro_done and jean_line_timer > 3.6:
                    advance_jean_intro()
            gene_lever_anim = max(0.0, gene_lever_anim - dt / 0.42)
            if gene_fill > 0.0:
                gene_fill = max(0.0, gene_fill - dt / 0.85)
                if gene_fill <= 0.0:
                    commit_pending_potion(spawn_here=True)

            phys_scene.step(dt)
            update_bites(dt)

            screen.fill((54, 62, 78))
            pygame.draw.rect(screen, (36, 42, 56), (0, 0, SCREEN_W, 78))
            pygame.draw.rect(screen, (72, 64, 58), (0, int(GENE_TRUCK_FLOOR_Y * SCENE_SCALE), SCREEN_W, SCREEN_H))

            box = pygame.Rect(
                int(GENE_BOX_X1 * SCENE_SCALE),
                int(GENE_BOX_TOP * SCENE_SCALE),
                int((GENE_BOX_X2 - GENE_BOX_X1) * SCENE_SCALE),
                int((GENE_BOX_FLOOR - GENE_BOX_TOP) * SCENE_SCALE),
            )
            mach = pygame.Rect(
                int(GENE_MACH_X1 * SCENE_SCALE),
                int(GENE_MACH_TOP * SCENE_SCALE),
                int((GENE_MACH_X2 - GENE_MACH_X1) * SCENE_SCALE),
                int((GENE_MACH_FLOOR - GENE_MACH_TOP) * SCENE_SCALE),
            )
            funnel = pygame.Rect(
                int(GENE_FUNNEL_X1 * SCENE_SCALE),
                int(GENE_FUNNEL_TOP * SCENE_SCALE),
                int((GENE_FUNNEL_X2 - GENE_FUNNEL_X1) * SCENE_SCALE),
                int((GENE_FUNNEL_FLOOR - GENE_FUNNEL_TOP) * SCENE_SCALE),
            )

            # Wires connecting Box -> Machine -> Funnel
            wire_y = mach.bottom - 26
            wire_col = (196, 118, 240) if gene_fill > 0.0 else (150, 176, 194)
            pygame.draw.rect(screen, (42, 46, 56), (box.right - 2, wire_y - 2, mach.left - box.right + 4, 14), border_radius=2)
            pygame.draw.rect(screen, wire_col, (box.right - 2, wire_y, mach.left - box.right + 4, 10), border_radius=2)
            pygame.draw.rect(screen, (42, 46, 56), (mach.right - 2, wire_y - 2, funnel.left - mach.right + 4, 14), border_radius=2)
            pygame.draw.rect(screen, wire_col, (mach.right - 2, wire_y, funnel.left - mach.right + 4, 10), border_radius=2)
            for cx_plug in (box.right - 2, mach.left - 4, mach.right - 2, funnel.left - 4):
                pygame.draw.rect(screen, (96, 104, 118), (cx_plug, wire_y - 4, 8, 18), border_radius=2)

            # Machine chassis + retro display
            pygame.draw.rect(screen, (78, 84, 98), mach, border_radius=8)
            pygame.draw.rect(screen, (48, 52, 64), mach, 4, border_radius=8)
            disp_rect = pygame.Rect(mach.left + 20, mach.top + 20, mach.width - 40, 56)
            pygame.draw.rect(screen, (38, 42, 52), disp_rect.inflate(6, 6), border_radius=6)
            pygame.draw.rect(screen, (12, 16, 14), disp_rect, border_radius=4)
            for sy_scan in range(disp_rect.top + 4, disp_rect.bottom - 2, 5):
                pygame.draw.line(screen, (20, 28, 22), (disp_rect.left + 3, sy_scan), (disp_rect.right - 3, sy_scan), 1)

            cur_mode = GENE_MODES[gene_mode_idx]
            mode_colors = {
                "EXTRACT": (108, 248, 146) if gene_paid else (246, 168, 88),
                "IMPRINT": (106, 224, 255),
                "EDIT": (224, 152, 255),
                "CONVERT": (255, 214, 102),
            }
            extract_lbl = font_retro.render(cur_mode, True, mode_colors[cur_mode])
            screen.blit(extract_lbl, extract_lbl.get_rect(center=disp_rect.center))

            # Lower instrument panel + progress bar + Drive Slot + Mode Knob
            panel_rect = pygame.Rect(mach.left + 20, disp_rect.bottom + 14, mach.width - 40, mach.bottom - disp_rect.bottom - 34)
            pygame.draw.rect(screen, (62, 68, 82), panel_rect, border_radius=5)
            pygame.draw.rect(screen, (44, 48, 58), panel_rect, 2, border_radius=5)
            led_col = (210, 108, 255) if gene_fill > 0.0 else ((98, 232, 134) if gene_paid else (228, 82, 74))
            pygame.draw.circle(screen, led_col, (panel_rect.left + 20, panel_rect.top + 20), 6)
            pygame.draw.rect(screen, (26, 30, 38), (panel_rect.left + 38, panel_rect.top + 12, panel_rect.width - 54, 16), border_radius=3)
            if gene_fill > 0.0:
                prog_w = int((panel_rect.width - 58) * (1.0 - gene_fill))
                pygame.draw.rect(screen, (186, 72, 232), (panel_rect.left + 40, panel_rect.top + 14, prog_w, 12), border_radius=2)
            for vy in range(panel_rect.top + 42, panel_rect.bottom - 10, 10):
                pygame.draw.line(screen, (42, 46, 56), (panel_rect.left + 16, vy), (panel_rect.right - 16, vy), 3)

            slot_r = gene_slot_screen_rect()
            pygame.draw.rect(screen, (22, 26, 34), slot_r, border_radius=4)
            pygame.draw.rect(screen, (118, 144, 182), slot_r, 2, border_radius=4)
            if gene_slot_drive is not None:
                pygame.draw.rect(screen, (62, 78, 108), slot_r.inflate(-8, -8), border_radius=3)
                pygame.draw.rect(screen, (92, 236, 224), (slot_r.left + 8, slot_r.centery - 3, slot_r.width - 28, 6), border_radius=2)
                pygame.draw.circle(screen, (206, 112, 255), (slot_r.right - 12, slot_r.centery), 4)
            else:
                sl_lbl = font_mono_tiny.render("DRIVE SLOT", True, (132, 148, 170))
                screen.blit(sl_lbl, sl_lbl.get_rect(center=slot_r.center))

            knob_r = gene_knob_screen_rect()
            k_hover = knob_r.collidepoint(mouse_pos)
            pygame.draw.circle(screen, (42, 46, 56), knob_r.center, 20)
            pygame.draw.circle(screen, (148, 154, 172) if k_hover else (96, 102, 118), knob_r.center, 16)
            pygame.draw.circle(screen, (52, 56, 66), knob_r.center, 12)
            notch_angles = (-135.0, -45.0, 45.0, 135.0)
            for ni, nang in enumerate(notch_angles):
                nr = math.radians(nang)
                nx = knob_r.centerx + math.cos(nr) * 21
                ny = knob_r.centery + math.sin(nr) * 21
                ncol = (118, 246, 176) if ni == gene_mode_idx else (120, 126, 140)
                pygame.draw.circle(screen, ncol, (int(nx), int(ny)), 3)
            k_ang = math.radians(notch_angles[gene_mode_idx])
            pygame.draw.line(
                screen,
                (250, 242, 214),
                knob_r.center,
                (knob_r.centerx + math.cos(k_ang) * 12, knob_r.centery + math.sin(k_ang) * 12),
                3,
            )

            # Funnel chamber
            pygame.draw.rect(screen, (92, 78, 118), funnel, border_radius=8)
            pygame.draw.rect(screen, (58, 48, 78), funnel, 3, border_radius=8)
            spout_x = funnel.centerx
            pygame.draw.polygon(
                screen,
                (176, 186, 198),
                [
                    (funnel.left + 28, funnel.top + 28),
                    (funnel.right - 28, funnel.top + 28),
                    (spout_x + 12, funnel.top + 92),
                    (spout_x - 12, funnel.top + 92),
                ],
            )
            pygame.draw.rect(screen, (176, 186, 198), (spout_x - 6, funnel.top + 90, 12, 22))

            # Pouring & filling animation (potion flask in EXTRACT, drive in CONVERT)
            if gene_fill > 0.0:
                flask_cx = int(round(GENE_FLASK_X * SCENE_SCALE))
                flask_cy = int(round(GENE_FLASK_Y * SCENE_SCALE))
                if gene_pending_kind == "drive":
                    pygame.draw.line(screen, (92, 236, 224), (spout_x, funnel.top + 112), (flask_cx, flask_cy - 6), 3)
                    prog = 1.0 - gene_fill
                    dw, dh = int(26 * SCENE_SCALE + 10), int(18 * SCENE_SCALE + 6)
                    d_rect = pygame.Rect(0, 0, dw, dh)
                    d_rect.center = (flask_cx, flask_cy)
                    pygame.draw.rect(screen, (54, 68, 92), d_rect, border_radius=3)
                    fill_w = max(2, int((dw - 6) * prog))
                    pygame.draw.rect(screen, (92, 236, 224), (d_rect.left + 3, d_rect.centery - 2, fill_w, 4))
                else:
                    flask_surf = build_potion_flask_surface(1.0 - gene_fill)
                    target_flask_size = (
                        max(1, int(round(52 * SCENE_SCALE))),
                        max(1, int(round(62 * SCENE_SCALE))),
                    )
                    scaled_flask = pygame.transform.smoothscale(flask_surf, target_flask_size)
                    flask_rect = scaled_flask.get_rect(center=(flask_cx, flask_cy))
                    pygame.draw.line(
                        screen,
                        (196, 72, 236),
                        (spout_x, funnel.top + 112),
                        (flask_cx, flask_rect.top + 6),
                        3,
                    )
                    screen.blit(scaled_flask, flask_rect)

            pygame.draw.rect(screen, (176, 206, 220), box, 6, border_radius=4)
            glass = pygame.Surface((box.width, box.height), pygame.SRCALPHA)
            glass.fill((186, 220, 236, 36))
            screen.blit(glass, box.topleft)

            draw_wood_sign(screen, gene_exit_sign, "EXIT", font_badge, gene_exit_sign.collidepoint(mouse_pos), with_post=False)
            screen.blit(font_med.render(f"${bankroll}", True, (245, 236, 184)), (1040, 16))
            fee_txt = "Extractor unlocked" if gene_paid else f"Unlock extractor ${GENE_EXTRACT_COST} once"
            screen.blit(
                font_small.render(
                    f"Gene Factory  |  {fee_txt}  |  Potions: {len(truck_potions)}  |  Drives: {len(truck_drives)}",
                    True,
                    (226, 220, 236),
                ),
                (130, 18),
            )

            if jean_conscious:
                spoken = ""
                if jean_override_timer > 0.0:
                    spoken = jean_override
                elif jean_line < len(JEAN_LINES):
                    spoken = JEAN_LINES[jean_line]
                if spoken:
                    draw_speech_bubble(screen, pygame.Rect(156, 530, 356, 118), spoken, font_med, max_lines=6)

            draw_standardized_truck_shell(screen, GENE_TRUCK_LEFT, GENE_TRUCK_FLOOR_Y)
            phys_scene.draw_horses(screen)
            glass_front = pygame.Surface((max(1, box.width - 12), max(1, box.height - 12)), pygame.SRCALPHA)
            glass_front.fill((210, 236, 246, 28))
            screen.blit(glass_front, (box.left + 6, box.top + 6))
            pygame.draw.rect(screen, (214, 236, 246), box, 3, border_radius=4)

            if gene_lever_anim <= 0.0:
                lever_pull = 0.0
            else:
                elapsed = 1.0 - gene_lever_anim
                if elapsed < 0.28:
                    lever_pull = elapsed / 0.28
                else:
                    lever_pull = max(0.0, 1.0 - (elapsed - 0.28) / 0.72)
            lever_ang = math.radians(-48.0 + 96.0 * lever_pull)
            piv_x = int(GENE_MACH_X2 * SCENE_SCALE) - 2
            piv_y = int((GENE_MACH_TOP + 125.0) * SCENE_SCALE)
            knob_x = piv_x + math.cos(lever_ang) * 48.0
            knob_y = piv_y + math.sin(lever_ang) * 48.0
            pygame.draw.rect(screen, (52, 56, 66), (piv_x - 4, piv_y - 12, 12, 24), border_radius=3)
            pygame.draw.line(screen, (192, 198, 210), (piv_x + 2, piv_y), (knob_x, knob_y), 6)
            pygame.draw.circle(screen, (206, 68, 72), (int(round(knob_x)), int(round(knob_y))), 9)
            pygame.draw.circle(screen, (246, 134, 138), (int(round(knob_x - 2)), int(round(knob_y - 2))), 3)
            draw_scene_status_badges(screen, phys_scene, font_badge)

        # ---------------- SCENE: GENE MAP (CONSTRAINED DRIVE EDITOR) ----------------
        elif scene == "gene_map" and gene_slot_drive is not None:
            keys = pygame.key.get_pressed()
            ax = (1 if (keys[pygame.K_d] or keys[pygame.K_RIGHT]) else 0) - (
                1 if (keys[pygame.K_a] or keys[pygame.K_LEFT]) else 0
            )
            ay = (1 if (keys[pygame.K_s] or keys[pygame.K_DOWN]) else 0) - (
                1 if (keys[pygame.K_w] or keys[pygame.K_UP]) else 0
            )
            if ax != 0 or ay != 0:
                mag = math.hypot(ax, ay)
                if ax != 0:
                    gm_truck_facing = 1 if ax > 0 else -1
                gm_truck_x = max(70.0, min(GM_WIDTH - 70.0, gm_truck_x + (ax / mag) * 680.0 * dt))
                gm_truck_y = max(70.0, min(GM_HEIGHT - 70.0, gm_truck_y + (ay / mag) * 680.0 * dt))

            gm_cam_x = max(0.0, min(GM_WIDTH - SCREEN_W, gm_truck_x - SCREEN_W * 0.5))
            gm_cam_y = max(0.0, min(GM_HEIGHT - SCREEN_H, gm_truck_y - SCREEN_H * 0.5))

            for nd in gm_nodes:
                if nd.being_lassoed:
                    continue
                nd.x += nd.vx * dt
                nd.y += nd.vy * dt
                if nd.x < 120.0 or nd.x > GM_WIDTH - 120.0:
                    nd.vx *= -1.0
                    nd.x = max(120.0, min(GM_WIDTH - 120.0, nd.x))
                if nd.y < 110.0 or nd.y > GM_HEIGHT - 110.0:
                    nd.vy *= -1.0
                    nd.y = max(110.0, min(GM_HEIGHT - 110.0, nd.y))

            if gm_lasso_target is not None:
                if gm_lasso_phase == "shoot":
                    gm_lasso_progress += dt / 0.22
                    if gm_lasso_progress >= 1.0:
                        gm_lasso_progress = 0.0
                        gm_lasso_phase = "reel"
                        gm_lasso_sx = gm_lasso_target.x
                        gm_lasso_sy = gm_lasso_target.y
                else:
                    gm_lasso_progress += dt / 0.35
                    t_r = min(1.0, gm_lasso_progress)
                    gm_lasso_target.x = gm_lasso_sx + (gm_truck_x - gm_lasso_sx) * t_r
                    gm_lasso_target.y = gm_lasso_sy + (gm_truck_y - gm_lasso_sy) * t_r
                    if t_r >= 1.0:
                        captured_node = gm_lasso_target
                        gm_lasso_target = None
                        captured_node.being_lassoed = False
                        if captured_node in gm_nodes:
                            gm_nodes.remove(captured_node)
                        strand_entry = factory.create_strand(
                            captured_node.locus,
                            gene_slot_drive.genes[captured_node.locus],
                            source_drive=gene_slot_drive,
                        )
                        truck_horses.append(strand_entry)
                        if not has_infinite_lasso:
                            lasso_count = max(0, lasso_count - 1)
                            if lasso_count <= 0:
                                lasso_armed = False

            screen.fill((58, 28, 78))
            grid_step = 80
            gx0 = int(math.floor(gm_cam_x / grid_step) * grid_step)
            gy0 = int(math.floor(gm_cam_y / grid_step) * grid_step)
            for gx in range(gx0, int(gm_cam_x + SCREEN_W + grid_step), grid_step):
                pygame.draw.line(screen, (74, 38, 98), (gx - gm_cam_x, 0), (gx - gm_cam_x, SCREEN_H), 1)
            for gy in range(gy0, int(gm_cam_y + SCREEN_H + grid_step), grid_step):
                pygame.draw.line(screen, (74, 38, 98), (0, gy - gm_cam_y), (SCREEN_W, gy - gm_cam_y), 1)

            border_r = pygame.Rect(
                int(24 - gm_cam_x), int(24 - gm_cam_y), int(GM_WIDTH - 48), int(GM_HEIGHT - 48)
            )
            pygame.draw.rect(screen, (176, 118, 224), border_r, 4, border_radius=12)

            # Draw each locus graphically as its numbered X-chromosome strands & nucleotides (no text/motifs)
            for nd in gm_nodes:
                sx = nd.x - gm_cam_x
                sy = nd.y - gm_cam_y
                if sx < -140 or sx > SCREEN_W + 140 or sy < -140 or sy > SCREEN_H + 140:
                    continue
                g_obj = gene_slot_drive.genes[nd.locus]
                strand_surf = get_strand_map_surface(nd.locus_num, g_obj.allele_a, g_obj.allele_b, size=132)
                strand_surf = get_strand_map_surface(
                    nd.locus_num, g_obj.allele_a, g_obj.allele_b, size=int(round(132 * screen.scale))
                )
                screen._real.blit(
                    strand_surf,
                    (screen._ox + int(round((sx - 66) * screen.scale)), screen._oy + int(round((sy - 50) * screen.scale))),
                )

            # Draw Truck in Gene Map
            tsx, tsy = gm_truck_x - gm_cam_x, gm_truck_y - gm_cam_y
            truck_surf = pygame.Surface((110, 60), pygame.SRCALPHA)
            pygame.draw.rect(truck_surf, (218, 222, 232), (6, 12, 58, 32), border_radius=4)
            pygame.draw.rect(truck_surf, (92, 102, 124), (6, 12, 58, 32), 2, border_radius=4)
            pygame.draw.rect(truck_surf, (206, 62, 54), (64, 20, 38, 24), border_radius=4)
            pygame.draw.rect(truck_surf, (206, 62, 54), (66, 10, 22, 14), border_radius=3)
            pygame.draw.rect(truck_surf, (152, 212, 244), (72, 12, 13, 9))
            pygame.draw.circle(truck_surf, (28, 28, 34), (22, 44), 7)
            pygame.draw.circle(truck_surf, (28, 28, 34), (50, 44), 7)
            pygame.draw.circle(truck_surf, (28, 28, 34), (88, 44), 7)
            if gm_truck_facing < 0:
                truck_surf = pygame.transform.flip(truck_surf, True, False)
            screen.blit(truck_surf, (tsx - 55, tsy - 32))

            if gm_lasso_target is not None:
                if gm_lasso_phase == "shoot":
                    t_s = min(1.0, gm_lasso_progress)
                    rx = gm_truck_x + (gm_lasso_target.x - gm_truck_x) * t_s - gm_cam_x
                    ry = gm_truck_y + (gm_lasso_target.y - gm_truck_y) * t_s - gm_cam_y
                else:
                    rx = gm_lasso_target.x - gm_cam_x
                    ry = gm_lasso_target.y - gm_cam_y
                rope = (108, 224, 255) if has_infinite_lasso else (226, 198, 124)
                pygame.draw.line(screen, rope, (tsx, tsy - 6), (rx, ry), 3)
                pygame.draw.circle(screen, rope, (int(rx), int(ry)), 8, 2)

            # Graphical back-arrow button (no text)
            ex_hov = gm_exit_sign.collidepoint(mouse_pos)
            pygame.draw.rect(screen, (138, 98, 60) if ex_hov else (112, 78, 46), gm_exit_sign, border_radius=6)
            pygame.draw.rect(screen, (72, 48, 26), gm_exit_sign, 2, border_radius=6)
            ex_cy = gm_exit_sign.centery
            pygame.draw.polygon(
                screen,
                (248, 236, 206),
                [(gm_exit_sign.left + 12, ex_cy), (gm_exit_sign.left + 26, ex_cy - 9), (gm_exit_sign.left + 26, ex_cy + 9)],
            )
            pygame.draw.line(screen, (248, 236, 206), (gm_exit_sign.left + 24, ex_cy), (gm_exit_sign.right - 12, ex_cy), 4)

            if lasso_count > 0 or has_infinite_lasso:
                lasso_btn_rect = pygame.Rect(SCREEN_W - 76, 16, 58, 58)
                draw_lasso_button(
                    screen, lasso_btn_rect, lasso_armed, lasso_btn_rect.collidepoint(mouse_pos),
                    count=0, font_badge=font_badge, infinite=has_infinite_lasso,
                )
                for di in range(min(lasso_count, 5)):
                    pygame.draw.circle(screen, (255, 232, 150), (lasso_btn_rect.left + 11 + di * 9, lasso_btn_rect.bottom - 8), 3)

        # ---------------- SCENE: GENE SPLICE (LOW-GRAVITY PHYSICS SWAPPER) ----------------
        elif scene == "gene_splice" and splice_space is not None and editing_strand_entry is not None:
            substeps = 2
            sub_dt = dt / substeps
            for _ in range(substeps):
                for nd in splice_nodes:
                    if nd is splice_drag_node or nd.slot is None:
                        nd.body.angular_velocity *= 0.90
                        continue
                    if nd.free_timer > 0.0:
                        nd.free_timer = max(0.0, nd.free_timer - sub_dt)
                        continue
                    tx, ty, tang = splice_slots[nd.slot]
                    bx, by = nd.body.position.x, nd.body.position.y
                    vx, vy = nd.body.velocity.x, nd.body.velocity.y
                    fx = (tx - bx) * 44.0 - vx * 6.5
                    fy = (ty - by) * 44.0 - vy * 6.5
                    nd.body.apply_force_at_world_point((fx, fy), nd.body.position)
                    ang_err = math.atan2(math.sin(tang - nd.body.angle), math.cos(tang - nd.body.angle))
                    nd.body.torque += ang_err * 340.0 - nd.body.angular_velocity * 26.0
                splice_space.step(sub_dt)

            screen.fill((68, 26, 92))

            # Subtle backbone lines linking slots into the two strands
            for s_idx in (0, 1):
                arm_pts = [splice_slots[(s_idx, i)][:2] for i in range(7, -1, -1)]
                leg_pts = [splice_slots[(s_idx, i)][:2] for i in range(8, 24)]
                pygame.draw.lines(screen, (108, 52, 142), False, arm_pts + leg_pts, 4)

            occupied_slots = {nd.slot for nd in splice_nodes if nd.slot is not None}
            for sl_key, (sx, sy, _sang) in splice_slots.items():
                if sl_key not in occupied_slots:
                    pygame.draw.circle(screen, (28, 16, 40), (int(sx), int(sy)), 11)
                    pygame.draw.circle(screen, (206, 76, 92), (int(sx), int(sy)), 11, 2)
                    dash_s = font_mono_nt.render("-", True, (216, 96, 112))
                    screen.blit(dash_s, dash_s.get_rect(center=(int(sx), int(sy))))

            # Tether lines from open/stretched sockets & target hover ring
            hover_target_slot = None
            if splice_drag_node is not None:
                px, py = splice_drag_node.body.position.x, splice_drag_node.body.position.y
                best_d = 42.0
                for sl_key, (sx, sy, _sang) in splice_slots.items():
                    if sl_key == splice_drag_node.slot:
                        continue
                    d = math.hypot(sx - px, sy - py)
                    if d < best_d:
                        best_d = d
                        hover_target_slot = sl_key

            for nd in splice_nodes:
                if nd.slot is None:
                    continue
                sx, sy, _sang = splice_slots[nd.slot]
                bx, by = nd.body.position.x, nd.body.position.y
                if math.hypot(bx - sx, by - sy) > 5.0:
                    pygame.draw.line(screen, (176, 132, 212), (sx, sy), (bx, by), 2)
                if nd is splice_drag_node or nd.free_timer > 0.0:
                    pygame.draw.circle(screen, (148, 86, 186), (int(sx), int(sy)), 11, 2)

            if hover_target_slot is not None:
                hsx, hsy, _ = splice_slots[hover_target_slot]
                pygame.draw.circle(screen, (255, 244, 146), (int(hsx), int(hsy)), 19, 3)

            # Central numbered locus square
            locus_idx_num = (
                ALL_LOCI.index(editing_strand_locus) + 1
                if editing_strand_locus in ALL_LOCI
                else editing_strand_entry.strand_num
            )
            hub_rect = pygame.Rect(0, 0, 58, 58)
            hub_rect.center = (SCREEN_W // 2, 252)
            pygame.draw.rect(screen, (12, 12, 16), hub_rect, border_radius=5)
            pygame.draw.rect(screen, (72, 64, 88), hub_rect, 3, border_radius=5)
            num_s = font_retro.render(str(locus_idx_num), True, (198, 132, 248))
            screen.blit(num_s, num_s.get_rect(center=hub_rect.center))

            # Prev/Next arrows beside hub when inspecting a multi-locus creature
            if editing_strand_entry.genome is not None and len(editing_strand_entry.genome.strand_loci) > 1:
                prev_r = pygame.Rect(SCREEN_W // 2 - 74, 234, 32, 36)
                next_r = pygame.Rect(SCREEN_W // 2 + 42, 234, 32, 36)
                for ar, is_left in ((prev_r, True), (next_r, False)):
                    hov_a = ar.collidepoint(mouse_pos)
                    pygame.draw.rect(screen, (98, 54, 128) if hov_a else (52, 24, 72), ar, border_radius=6)
                    pygame.draw.rect(screen, (186, 128, 224), ar, 2, border_radius=6)
                    tip_x = ar.left + 8 if is_left else ar.right - 8
                    base_x = ar.right - 9 if is_left else ar.left + 9
                    pygame.draw.polygon(
                        screen,
                        (246, 228, 255),
                        [(tip_x, ar.centery), (base_x, ar.centery - 7), (base_x, ar.centery + 7)],
                    )

            # Draw nucleotide bodies (dragged node drawn last on top)
            ordered_nodes = [n for n in splice_nodes if n is not splice_drag_node]
            if splice_drag_node is not None:
                ordered_nodes.append(splice_drag_node)
            for nd in ordered_nodes:
                pts = [nd.body.local_to_world(v) for v in nd.shape.get_vertices()]
                col = STRAND_NT_COLORS.get(nd.base, (180, 180, 180))
                pygame.draw.polygon(screen, col, pts)
                border_col = (255, 244, 146) if nd is splice_drag_node else (28, 22, 36)
                pygame.draw.polygon(screen, border_col, pts, 3 if nd is splice_drag_node else 2)
                ang_deg = -math.degrees(nd.body.angle)
                lbl = pygame.transform.rotozoom(font_mono_nt.render(nd.base, True, (252, 252, 255)), ang_deg, 1.0)
                screen.blit(lbl, lbl.get_rect(center=(int(nd.body.position.x), int(nd.body.position.y))))

            # A/C/G/T dispenser tiles (click & drag to fill empty slots)
            for disp_base, disp_rect in splice_dispenser_rects:
                d_col = STRAND_NT_COLORS[disp_base]
                if disp_rect.collidepoint(mouse_pos):
                    d_col = tuple(min(255, c + 22) for c in d_col)
                pygame.draw.rect(screen, d_col, disp_rect, border_radius=6)
                pygame.draw.rect(screen, (26, 20, 34), disp_rect, 2, border_radius=6)
                dlbl = font_mono_nt.render(disp_base, True, (252, 252, 255))
                screen.blit(dlbl, dlbl.get_rect(center=disp_rect.center))

            # Graphical back-arrow button (no text)
            sb_hov = splice_back_sign.collidepoint(mouse_pos)
            pygame.draw.rect(screen, (138, 98, 60) if sb_hov else (112, 78, 46), splice_back_sign, border_radius=6)
            pygame.draw.rect(screen, (72, 48, 26), splice_back_sign, 2, border_radius=6)
            sb_cy = splice_back_sign.centery
            pygame.draw.polygon(
                screen,
                (248, 236, 206),
                [(splice_back_sign.left + 12, sb_cy), (splice_back_sign.left + 26, sb_cy - 9), (splice_back_sign.left + 26, sb_cy + 9)],
            )
            pygame.draw.line(screen, (248, 236, 206), (splice_back_sign.left + 24, sb_cy), (splice_back_sign.right - 12, sb_cy), 4)

        # ---------------- SCENE: DNA LAB ----------------
        elif scene == "dna_lab":
            guide_sh = active_scene_npc()
            guide_conscious = guide_sh is not None and not guide_sh.entry.is_unconscious
            if dna_guide_override_timer > 0.0:
                dna_guide_override_timer = max(0.0, dna_guide_override_timer - dt)
            if guide_conscious:
                dna_guide_timer += dt
                if dna_guide_override_timer <= 0.0 and not dna_guide_done and dna_guide_timer > 3.0:
                    if dna_guide_line < len(DNA_GUIDE_LINES) - 1:
                        dna_guide_line += 1
                    else:
                        dna_guide_done = True
                    dna_guide_timer = 0.0

            if dna_sim_active:
                if dna_sim_done < dna_sim_total:
                    step_dna_optimization_sim()
                dna_flash_timer += dt
                for fi in range(5):
                    dna_flash_progress[fi] += dna_flash_speeds[fi] * dt * 3.8
                if dna_flash_timer >= 0.24 or any(p >= 1.0 for p in dna_flash_progress):
                    dna_flash_timer = 0.0
                    dna_flash_races += 1
                    dna_flash_progress = [0.0] * 5
                    dna_flash_speeds = [rng.uniform(0.75, 1.38) for _ in range(5)]
                    dna_flash_colors = rng.sample(BOLD_NAME_COLORS, 5)
                if dna_sim_done >= dna_sim_total and dna_flash_races >= 7:
                    finalize_dna_optimization(spawn_here=True)

            phys_scene.step(dt)
            update_bites(dt)

            screen.fill((46, 54, 68))
            pygame.draw.rect(screen, (32, 38, 50), (0, 0, SCREEN_W, 56))
            pygame.draw.rect(screen, (66, 62, 58), (0, int(DNA_BENCH_Y * SCENE_SCALE), SCREEN_W, SCREEN_H))
            pygame.draw.rect(screen, (88, 82, 76), (0, int(DNA_BENCH_Y * SCENE_SCALE), SCREEN_W, 12))
            pygame.draw.rect(screen, (72, 64, 58), (0, int(DNA_TRUCK_FLOOR_Y * SCENE_SCALE), SCREEN_W, SCREEN_H))

            vat_rect = pygame.Rect(
                int(DNA_VAT_X1 * SCENE_SCALE),
                int(DNA_VAT_TOP * SCENE_SCALE),
                int((DNA_VAT_X2 - DNA_VAT_X1) * SCENE_SCALE),
                int((DNA_VAT_FLOOR - DNA_VAT_TOP) * SCENE_SCALE),
            )
            comp_rect = pygame.Rect(
                int(DNA_COMP_X1 * SCENE_SCALE),
                int(DNA_COMP_TOP * SCENE_SCALE),
                int((DNA_COMP_X2 - DNA_COMP_X1) * SCENE_SCALE),
                int((DNA_COMP_FLOOR - DNA_COMP_TOP) * SCENE_SCALE),
            )
            out_cx = int(DNA_OUT_X * SCENE_SCALE)
            out_y = int(DNA_BENCH_Y * SCENE_SCALE)

            # Pipe connecting Vat -> Computer
            pipe_y = vat_rect.bottom - 38
            pipe_col = (196, 84, 242) if dna_vat_pool else (92, 102, 120)
            pygame.draw.rect(screen, (42, 46, 56), (vat_rect.right - 2, pipe_y - 3, comp_rect.left - vat_rect.right + 4, 18), border_radius=3)
            pygame.draw.rect(screen, pipe_col, (vat_rect.right - 2, pipe_y, comp_rect.left - vat_rect.right + 4, 12), border_radius=2)

            # Output pipe & dispenser nozzle Computer -> Output Tray
            pygame.draw.rect(screen, (72, 78, 92), (comp_rect.right - 2, pipe_y - 44, out_cx - comp_rect.right + 10, 16), border_radius=3)
            pygame.draw.rect(screen, (98, 106, 122), (out_cx - 10, pipe_y - 44, 20, 32), border_radius=3)
            pygame.draw.rect(screen, (96, 104, 118), (out_cx - 46, out_y - 6, 92, 8), border_radius=2)

            # Vat back & glowing DNA liquid fill
            vat_glass = pygame.Surface((vat_rect.width, vat_rect.height), pygame.SRCALPHA)
            vat_glass.fill((170, 212, 232, 32))
            screen.blit(vat_glass, vat_rect.topleft)

            fill_frac = min(1.0, len(dna_vat_pool) / 8.0) if dna_vat_pool else 0.0
            if fill_frac > 0.0:
                liq_h = max(14, int((vat_rect.height - 16) * fill_frac))
                liq_rect = pygame.Rect(
                    vat_rect.left + 6,
                    vat_rect.bottom - 6 - liq_h,
                    vat_rect.width - 12,
                    liq_h,
                )
                pygame.draw.rect(screen, (176, 54, 224), liq_rect, border_radius=4)
                pygame.draw.line(screen, (232, 146, 255), (liq_rect.left + 2, liq_rect.top), (liq_rect.right - 2, liq_rect.top), 3)
                # Animated DNA bubbles inside vat
                t_bub = pygame.time.get_ticks() * 0.003
                for bi in range(min(10, 2 + len(dna_vat_pool))):
                    bx = liq_rect.left + 16 + ((bi * 37) % max(20, liq_rect.width - 32))
                    by = liq_rect.bottom - 8 - int(((t_bub * 28 + bi * 23) % max(10, liq_h - 10)))
                    pygame.draw.circle(screen, (238, 186, 255), (bx, by), 3)

            vat_lbl = font_badge.render(f"DNA VAT ({len(dna_vat_pool)})", True, (226, 236, 246))
            screen.blit(vat_lbl, vat_lbl.get_rect(center=(vat_rect.centerx, vat_rect.top - 14)))

            # Large Central Retro Computer
            pygame.draw.rect(screen, (164, 160, 148), comp_rect, border_radius=12)
            pygame.draw.rect(screen, (98, 94, 86), comp_rect, 4, border_radius=12)

            crt_rect = pygame.Rect(comp_rect.left + 24, comp_rect.top + 22, comp_rect.width - 48, comp_rect.height - 116)
            pygame.draw.rect(screen, (42, 46, 52), crt_rect.inflate(10, 10), border_radius=8)
            pygame.draw.rect(screen, (10, 22, 16), crt_rect, border_radius=6)

            # Retro CRT Scanlines
            for sy_scan in range(crt_rect.top + 4, crt_rect.bottom - 2, 5):
                pygame.draw.line(screen, (16, 32, 24), (crt_rect.left + 4, sy_scan), (crt_rect.right - 4, sy_scan), 1)

            # Telemetry readouts at top of retro screen
            stat_avg = f"{dna_sim_avg_time:.2f}s" if dna_sim_times else "--"
            stat_div = f"{dna_sim_diversity:.0f}%" if dna_vat_pool else "0%"
            stat_sims = f"{dna_sim_done}/{dna_sim_total}" if (dna_sim_active or dna_sim_done > 0) else "0"
            t_col = (112, 248, 152)
            screen.blit(font_badge.render(f"AVG LAP: {stat_avg}", True, t_col), (crt_rect.left + 14, crt_rect.top + 10))
            screen.blit(font_badge.render(f"DIVERSITY: {stat_div}", True, t_col), (crt_rect.centerx - 55, crt_rect.top + 10))
            screen.blit(font_badge.render(f"SIMS: {stat_sims}", True, t_col), (crt_rect.right - 108, crt_rect.top + 10))
            pygame.draw.line(screen, (44, 96, 66), (crt_rect.left + 10, crt_rect.top + 34), (crt_rect.right - 10, crt_rect.top + 34), 2)

            # Mini Race Area inside CRT
            track_box = pygame.Rect(crt_rect.left + 14, crt_rect.top + 42, crt_rect.width - 28, crt_rect.height - 54)
            if dna_sim_active:
                lane_h = track_box.height / 5.0
                for li in range(5):
                    ly = int(track_box.top + li * lane_h)
                    pygame.draw.line(screen, (28, 62, 44), (track_box.left, ly), (track_box.right, ly), 1)
                    hx = track_box.left + 14 + min(1.0, dna_flash_progress[li]) * (track_box.width - 32)
                    hy = int(ly + lane_h * 0.5)
                    pygame.draw.rect(screen, dna_flash_colors[li], (int(hx) - 10, hy - 5, 18, 10), border_radius=2)
                    pygame.draw.rect(screen, dna_flash_colors[li], (int(hx) + 6, hy - 9, 7, 7), border_radius=2)
                pygame.draw.line(screen, (220, 240, 220), (track_box.right - 12, track_box.top), (track_box.right - 12, track_box.bottom), 2)
                flash_lbl = font_badge.render(f"SIMULATING RACE #{dna_flash_races + 1}", True, (246, 232, 128))
                screen.blit(flash_lbl, (track_box.left + 6, track_box.bottom - 18))
            elif dna_sim_best_genome is not None:
                res1 = font_retro.render("OPTIMAL GENOME FOUND", True, (118, 252, 156))
                res2 = font_med.render(f"Best Simulated Lap: {dna_sim_best_time:.2f}s", True, (220, 250, 226))
                screen.blit(res1, res1.get_rect(center=(track_box.centerx, track_box.centery - 16)))
                screen.blit(res2, res2.get_rect(center=(track_box.centerx, track_box.centery + 18)))
            else:
                idle1 = font_retro.render("DNA RACE OPTIMIZER", True, (96, 226, 138))
                idle_msg = "Pour DNA potions in Vat" if not dna_vat_pool else "Press RED BUTTON to simulate!"
                idle2 = font_small.render(idle_msg, True, (158, 218, 178))
                screen.blit(idle1, idle1.get_rect(center=(track_box.centerx, track_box.centery - 16)))
                screen.blit(idle2, idle2.get_rect(center=(track_box.centerx, track_box.centery + 18)))

            # Lower computer console + Red Button
            console_rect = pygame.Rect(comp_rect.left + 20, crt_rect.bottom + 18, comp_rect.width - 110, 56)
            pygame.draw.rect(screen, (118, 114, 104), console_rect, border_radius=6)
            for vx in range(console_rect.left + 16, console_rect.right - 16, 14):
                pygame.draw.line(screen, (72, 70, 64), (vx, console_rect.top + 10), (vx, console_rect.bottom - 10), 3)

            rbtn = dna_red_button_rect()
            pygame.draw.rect(screen, (62, 64, 72), rbtn.inflate(10, 10), border_radius=8)
            btn_col = (245, 72, 72) if rbtn.collidepoint(mouse_pos) and not dna_sim_active else (204, 42, 44)
            pygame.draw.circle(screen, btn_col, rbtn.center, rbtn.width // 2)
            pygame.draw.circle(screen, (255, 136, 136), (rbtn.centerx - 5, rbtn.centery - 5), 6)
            pygame.draw.circle(screen, (112, 22, 24), rbtn.center, rbtn.width // 2, 3)

            draw_wood_sign(screen, dna_exit_sign, "EXIT", font_badge, dna_exit_sign.collidepoint(mouse_pos), with_post=False)
            screen.blit(font_med.render(f"${bankroll}", True, (245, 236, 184)), (1110, 16))
            screen.blit(
                font_small.render(
                    f"DNA Lab  |  Vat DNA: {len(dna_vat_pool)}  |  Potions in Truck: {len(truck_potions)}",
                    True,
                    (220, 230, 242),
                ),
                (130, 18),
            )

            if guide_conscious:
                spoken = ""
                if dna_guide_override_timer > 0.0:
                    spoken = dna_guide_override
                elif dna_guide_line < len(DNA_GUIDE_LINES):
                    spoken = DNA_GUIDE_LINES[dna_guide_line]
                if spoken:
                    draw_speech_bubble(screen, pygame.Rect(160, 540, 355, 118), spoken, font_med, max_lines=4)

            draw_standardized_truck_shell(screen, DNA_TRUCK_LEFT, DNA_TRUCK_FLOOR_Y)
            phys_scene.draw_horses(screen)

            # Front glass highlight over vat
            pygame.draw.rect(screen, (196, 226, 240), vat_rect, 4, border_radius=4)
            draw_scene_status_badges(screen, phys_scene, font_badge)

        # ---------------- SCENE: YOUR RANCH (PEN + SAMPLE TRACK + BREEDING SHED + TRUCK) ----------------
        elif scene == "your_ranch":
            if shed_notice_timer > 0.0:
                shed_notice_timer = max(0.0, shed_notice_timer - dt)
                if shed_notice_timer <= 0.0:
                    shed_notice = ""
            if sleep_banner_timer > 0.0:
                sleep_banner_timer = max(0.0, sleep_banner_timer - dt)
                if sleep_banner_timer <= 0.0:
                    sleep_banner = ""

            # Wrap horses running along top Sample Track
            for sh in phys_scene.horses:
                if sh is phys_scene.dragged_horse:
                    continue
                torso = sh.creature.bodies["torso"]
                if sh.creature.config.gait.enabled and torso.position.y < RANCH_TRACK_FLOOR_Y + 40.0:
                    if torso.position.x > PHYS_W + 140.0:
                        dx = -160.0 - torso.position.x
                        for b in set(sh.creature.bodies.values()):
                            b.position = (b.position.x + dx, b.position.y)

            phys_scene.step(dt)
            update_bites(dt)

            # Breeding Shed logic
            if breeding_active:
                breeding_timer -= dt
                if breeding_timer <= 0.0:
                    finish_breeding_if_active(spawn_in_scene=True)
            else:
                in_shed = [
                    sh
                    for sh in phys_scene.horses
                    if sh is not phys_scene.dragged_horse
                    and 1 <= sh.entry.age <= 9
                    and not sh.entry.is_tired
                    and not sh.entry.is_hungry
                    and not sh.entry.is_unconscious
                    and entry_strands_functional(sh.entry)
                    and is_inside_shed(
                        sh.creature.bodies["torso"].position.x,
                        sh.creature.bodies["torso"].position.y,
                    )
                ]
                if len(in_shed) >= 2:
                    p1, p2 = in_shed[0], in_shed[1]
                    breeding_parents = [p1.entry, p2.entry]
                    phys_scene.remove_horse(p1)
                    phys_scene.remove_horse(p2)
                    breeding_active = True
                    breeding_timer = 1.0

            screen.fill((66, 98, 56))
            pygame.draw.rect(screen, (48, 72, 98), (0, 0, SCREEN_W, 92))

            # Sample Race Track dirt stretch
            track_y_screen = int(RANCH_TRACK_FLOOR_Y * SCENE_SCALE)
            pygame.draw.rect(screen, (112, 86, 62), (0, track_y_screen - 54, SCREEN_W, 66))
            pygame.draw.line(screen, (148, 120, 88), (0, track_y_screen - 54), (SCREEN_W, track_y_screen - 54), 3)
            pygame.draw.line(screen, (148, 120, 88), (0, track_y_screen + 12), (SCREEN_W, track_y_screen + 12), 3)
            for fx in range(40, SCREEN_W, 120):
                pygame.draw.rect(screen, (124, 94, 62), (fx, track_y_screen - 82, 6, 28))
            pygame.draw.line(screen, (182, 156, 122), (0, track_y_screen - 72), (SCREEN_W, track_y_screen - 72), 3)

            draw_wood_sign(screen, your_ranch_exit_sign, "EXIT", font_badge, your_ranch_exit_sign.collidepoint(mouse_pos), with_post=False)
            draw_wood_sign(
                screen,
                your_ranch_sleep_sign,
                f"SLEEP (DAY {day})",
                font_badge,
                your_ranch_sleep_sign.collidepoint(mouse_pos) and not breeding_active,
                with_post=False,
                board_color=(64, 92, 138),
            )
            screen.blit(font_med.render(f"${bankroll}", True, (245, 236, 184)), (1115, 16))
            sup_txt = f"Your Ranch  |  Day {day}  |  Hay: {truck_hay}  Beer: {truck_beer}"
            screen.blit(font_small.render(sup_txt, True, (226, 224, 208)), (135, 20))
            if sleep_banner:
                sb_s = font_med.render(sleep_banner, True, (255, 238, 156))
                screen.blit(sb_s, sb_s.get_rect(center=(SCREEN_W * 0.5, 58)))

            # Yard floor + Open Pen + Breeding Shed + Standardized Truck
            draw_open_pen_fence(screen, YOUR_PEN_X1, YOUR_PEN_X2, YOUR_YARD_FLOOR_Y)
            yx_left = YOUR_PEN_X2 * SCENE_SCALE
            yx_right = SHED_X1 * SCENE_SCALE
            yy_floor = YOUR_YARD_FLOOR_Y * SCENE_SCALE
            pygame.draw.rect(screen, (112, 86, 60), (yx_left, yy_floor - 10, yx_right - yx_left + 8, 22), border_radius=3)
            draw_breeding_shed(
                screen,
                SHED_X1,
                SHED_X2,
                SHED_TOP,
                SHED_FLOOR_Y,
                doors_closed=breeding_active,
                progress=(1.0 - breeding_timer) if breeding_active else 0.0,
                font_small=font_badge,
                notice=shed_notice,
            )
            draw_standardized_truck_shell(screen, YOUR_TRUCK_LEFT, YOUR_TRUCK_FLOOR_Y)
            phys_scene.draw_horses(screen)
            draw_scene_status_badges(screen, phys_scene, font_badge)

        # Hover card & inline rename across all UnifiedPhysicsScene screens
        if scene in ("truck", "ranch", "your_ranch", "racecourse_hub", "arena_hub", "shop", "gene_factory", "dna_lab"):
            hovered_sh: SceneHorse | None = None
            if phys_scene.dragged_horse is None:
                if hover_entry is not None and hover_card_rect is not None and hover_card_rect.collidepoint(mouse_pos):
                    hovered_sh = next((s for s in phys_scene.horses if s.entry is hover_entry), None)
                if hovered_sh is None:
                    hovered_sh = phys_scene.find_horse_at_screen_pos(mouse_pos)
            if hovered_sh is not None:
                top_y_phys = min(s.bb.top for s in hovered_sh.creature.shapes.values())
                tx_phys = hovered_sh.creature.bodies["torso"].position.x
                r_txt = rename_text if renaming_entry is hovered_sh.entry else None
                c_rect, n_rect = draw_horse_hover_card(
                    screen,
                    hovered_sh.entry,
                    (tx_phys - phys_scene.view_x) * SCENE_SCALE,
                    top_y_phys * SCENE_SCALE,
                    font_hover_name,
                    font_small,
                    owned_by_player=hovered_sh.owned_by_player,
                    mouse_pos=mouse_pos,
                    renaming_text=r_txt,
                )
                hover_entry = hovered_sh.entry
                hover_card_rect = c_rect
                hover_name_rect = n_rect
                hover_owned = hovered_sh.owned_by_player
            elif renaming_entry is not None:
                c_rect, n_rect = draw_horse_hover_card(
                    screen,
                    renaming_entry,
                    SCREEN_W * 0.5,
                    150,
                    font_hover_name,
                    font_small,
                    owned_by_player=True,
                    mouse_pos=mouse_pos,
                    renaming_text=rename_text,
                )
                hover_entry = renaming_entry
                hover_card_rect = c_rect
                hover_name_rect = n_rect
                hover_owned = True
            else:
                hover_entry = None
                hover_card_rect = None
                hover_name_rect = None
                hover_owned = False

        pygame.display.flip()
        if gallery is not None:
            if gallery.after_frame(gallery_export, gallery_apply, gallery_call):
                pygame.quit()
                return
        else:
            clock.tick(FPS)
        await asyncio.sleep(0)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except SystemExit:
        raise
    except Exception:
        traceback.print_exc()
        pygame.quit()
        sys.exit(1)
