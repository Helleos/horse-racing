"""Screen, track, world, and name-table constants."""
# --- CONSTANTS & CONFIGURATION ---

SCREEN_W = 1200
SCREEN_H = 720
FPS = 60

NUM_LANES = 5
TRACK_LENGTH = 5000.0
STRONGHORSE_LENGTH = 1800.0
STRONGHORSE_SLOPE = 0.052
STARTING_BANKROLL = 1000

HORSE_FLOOR_Y = 385.0
HORSE_CANVAS_W = 520
HORSE_CANVAS_H = 410
HORSE_CENTER_X = 250.0

WORLD_SCALE_X = 0.34
START_CAM_X = -860.0

FIELD_TOP_Y = 105
LANE_BOUNDS = [
    (105, 210),
    (210, 324),
    (324, 447),
    (447, 579),
    (579, 720),
]
LANE_GROUND_Y = [198, 311, 433, 564, 702]
LANE_SCALES = [0.36, 0.385, 0.41, 0.435, 0.46]

# Unified physics-to-screen scale across Truck, Ranch, and Racecourse Hub
SCENE_SCALE = 0.56
PHYS_W = SCREEN_W / SCENE_SCALE  # ~2142.8
PHYS_H = SCREEN_H / SCENE_SCALE  # ~1285.7

# Standardized Truck dimensions in physics units (larger interior, identical everywhere)
STD_TRUCK_TRAILER_W = 1040.0
STD_TRUCK_TRAILER_H = 400.0
STD_TRUCK_CAB_W = 165.0

# Open World: 100,000 px wide x 50,000 px tall with smaller 64 px tiles
OW_WIDTH = 100000
OW_HEIGHT = 50000
OW_TILE = 64
OW_COLS = OW_WIDTH // OW_TILE
OW_ROWS = OW_HEIGHT // OW_TILE

TERRAIN_COLORS = {
    "grass": (74, 124, 64),
    "savanna": (162, 158, 76),
    "deep_forest": (42, 86, 46),
    "desert": (196, 162, 102),
    "oasis": (74, 156, 98),
    "rock": (108, 102, 98),
    "mountain": (82, 84, 96),
    "snowy_peaks": (224, 232, 242),
}
PATH_COLOR = (146, 118, 82)
PATH_SPEED_MULT = 1.15
TERRAIN_SPEED_MULT = {
    "grass": 1.0,
    "savanna": 0.98,
    "deep_forest": 0.78,
    "desert": 0.94,
    "oasis": 0.86,
    "rock": 0.76,
    "mountain": 0.52,
    "snowy_peaks": 0.42,
}

HORSE_FIRST_NAMES = [
    "Amber", "Apache", "Autumn", "Bandit", "Bayou", "Blaze", "Bramble", "Brandy",
    "Briar", "Buck", "Canyon", "Cedar", "Cheyenne", "Cinder", "Clover", "Cobalt",
    "Copper", "Crest", "Crimson", "Dakota", "Dapple", "Desert", "Dusty", "Echo",
    "Ember", "Fable", "Flash", "Flint", "Frontier", "Ginger", "Golden", "Granite",
    "Harbor", "Hazel", "Highland", "Honey", "Indigo", "Iron", "Jasper", "Juniper",
    "Kestrel", "Lucky", "Maple", "Meadow", "Mesa", "Midnight", "Misty", "Noble",
    "Nutmeg", "Onyx", "Outlaw", "Pebble", "Phantom", "Prairie", "Quartz", "Rapid",
    "Red", "River", "Rogue", "Rowan", "Rusty", "Sable", "Saddle", "Sage",
    "Scarlet", "Shadow", "Sierra", "Silver", "Sky", "Solar", "Sorrel", "Starlight",
    "Sterling", "Storm", "Summer", "Sunny", "Sunset", "Thunder", "Timber", "Topaz",
    "Velvet", "Whiskey", "Wild", "Willow", "Winter", "Zephyr",
]

HORSE_LAST_NAMES = [
    "Arrow", "Banner", "Blossom", "Bolt", "Bound", "Breeze", "Brook", "Chaser",
    "Cinder", "Cloud", "Comet", "Creek", "Crest", "Crown", "Dancer", "Dash",
    "Dawn", "Drift", "Dusk", "Echo", "Falcon", "Feather", "Flame", "Flash",
    "Flight", "Frost", "Fury", "Gale", "Gallop", "Ghost", "Glade", "Gleam",
    "Hawk", "Heart", "Hoof", "Horizon", "Hunter", "Jet", "Jumper", "Lark",
    "Legend", "Lightning", "Mane", "Mirage", "Mist", "Moon", "Peak", "Plume",
    "Pride", "Pulse", "Ranger", "Rebel", "Ridge", "Rider", "River", "Rocket",
    "Runner", "Scout", "Shadow", "Shire", "Song", "Spark", "Spirit", "Sprint",
    "Spur", "Star", "Step", "Stone", "Stride", "Strike", "Sun", "Swift",
    "Tempest", "Thorn", "Trail", "Vale", "Valor", "Whisper", "Wind", "Wing",
]

RANCH_PREFIXES = [
    "Redwood", "Sun Valley", "Whispering", "Lone Pine", "Silver Creek", "Mesa",
    "Copper Ridge", "Twin Oaks", "Dusty Trail", "Prairie Wind", "Canyon",
    "Rolling Hills", "Highland", "Broken Spur", "Golden Meadow", "Wildflower",
    "Blue Sky", "Sagebrush", "Cedar", "Coyote", "Mustang", "Arrowhead",
    "Clearwater", "Ironwood", "Timberline", "Dry Creek", "Big Sky", "Starlight",
]

BOLD_NAME_COLORS = [
    (255, 114, 102),
    (255, 212, 82),
    (86, 214, 255),
    (102, 232, 152),
    (204, 146, 255),
    (255, 164, 72),
    (255, 134, 194),
    (182, 242, 92),
    (116, 174, 255),
    (255, 196, 148),
]

RANCHER_GREETINGS = [
    "Howdy partner",
    "Hello",
    "Welcome to my ranch",
    "Hola amigo",
    "Hello there",
]

ITEM_PRICES = {
    "lasso": 50,
    "hay": 5,
    "beer": 10,
    "chili": 15,
    "apple_crate": 50,
}
