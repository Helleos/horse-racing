"""Procedural open world: terrain, paths, ranches, shops, and wild herds."""
from __future__ import annotations

import math
import random
import pygame

from racing_models import (
    FossilNode,
    HorseEntry,
    HorseFactory,
    RacecourseData,
    RanchData,
    ShopData,
    TreeData,
    WildHorse,
    WorldApple,
    WorldMeat,
    meat_from_kill,
    refresh_entry_config_for_age,
)

from racing_constants import (
    OW_COLS,
    OW_HEIGHT,
    OW_ROWS,
    OW_TILE,
    OW_WIDTH,
    RANCH_PREFIXES,
)

from gene import (
    TERRAIN_PACK_SPECIES,
    random_fossil_genome,
    random_herd_animal_genome,
)

from scene_art import fossil_visual_params

# --- OPEN WORLD GENERATION (PROCEDURAL 100,000 x 50,000) ---


def tile_center(c: int, r: int) -> tuple[float, float]:
    return (c * OW_TILE + OW_TILE * 0.5, r * OW_TILE + OW_TILE * 0.5)


def tile_rect_world(wx: float, wy: float) -> pygame.Rect:
    c = int(wx // OW_TILE)
    r = int(wy // OW_TILE)
    return pygame.Rect(c * OW_TILE, r * OW_TILE, OW_TILE, OW_TILE)


class OpenWorld:
    def __init__(self, factory: HorseFactory, rng: random.Random):
        self.rng = rng
        self.factory = factory
        self.seed_x = rng.uniform(0.0, 100.0)
        self.seed_y = rng.uniform(0.0, 100.0)
        self.overrides: dict[tuple[int, int], str] = {}
        self.path_tiles: set[tuple[int, int]] = set()
        used_tiles: set[tuple[int, int]] = set()

        def claim_tile(c: int, r: int, terrain: str = "grass") -> tuple[int, int]:
            c = max(4, min(OW_COLS - 5, c))
            r = max(4, min(OW_ROWS - 5, r))
            while (c, r) in used_tiles:
                c = max(4, min(OW_COLS - 5, c + 1))
            used_tiles.add((c, r))
            self.overrides[(c, r)] = terrain
            return (c, r)

        # 1. Central Racecourse (exact 1 tile) & Your Ranch (exact 1 tile nearby)
        rc_tile = claim_tile(OW_COLS // 2, OW_ROWS // 2, "grass")
        self.racecourse_pos = tile_center(*rc_tile)
        self.racecourses: list[RacecourseData] = [
            RacecourseData(1, "Central Racecourse", *self.racecourse_pos, is_arena=False)
        ]

        outer_course_tiles = [
            ("Northwind Downs", 420, 140),
            ("Suncrest Track", 1180, 160),
            ("Dustbowl Downs", 220, 390),
            ("Timberline Track", 1340, 410),
            ("Mesa Downs", 360, 640),
            ("Highland Track", 1120, 650),
        ]
        course_tiles: list[tuple[int, int]] = [rc_tile]
        for cname, cc, cr in outer_course_tiles:
            terr = self.get_tile_terrain(cc, cr)
            ct = claim_tile(cc, cr, "grass" if terr in ("mountain", "snowy_peaks", "oasis") else terr)
            course_tiles.append(ct)
            self.racecourses.append(
                RacecourseData(len(self.racecourses) + 1, cname, *tile_center(*ct), is_arena=False)
            )

        rcx, rcy = rc_tile
        arena_coords = [
            ("Ironwood Arena", rcx - 52, rcy - 36),
            ("Crimson Arena", rcx + 52, rcy - 36),
            ("Obsidian Arena", rcx - 52, rcy + 36),
            ("Colosseum Arena", rcx + 52, rcy + 36),
        ]
        for aname, ac, ar in arena_coords:
            terr = self.get_tile_terrain(ac, ar)
            at = claim_tile(ac, ar, "rock" if terr in ("mountain", "snowy_peaks", "oasis") else terr)
            course_tiles.append(at)
            self.racecourses.append(
                RacecourseData(len(self.racecourses) + 1, aname, *tile_center(*at), is_arena=True)
            )

        yr_tile = claim_tile(rc_tile[0] + 6, rc_tile[1], "grass")
        self.your_ranch_pos = tile_center(*yr_tile)

        gf_tile = claim_tile(yr_tile[0] + 3, yr_tile[1] - 4, "grass")
        self.gene_factory_pos = tile_center(*gf_tile)
        self.jean_entry = factory.create_rancher("Gene Factory")
        self.jean_entry.name = "Jean Gene"
        self.jean_entry.name_color = (198, 146, 255)

        dl_tile = claim_tile(rc_tile[0] + 64, rc_tile[1] + 40, "grass")
        self.dna_lab_pos = tile_center(*dl_tile)
        self.dna_guide_entry = factory.create_rancher("DNA Lab")
        self.dna_guide_entry.name = "Dr. Helix"
        self.dna_guide_entry.name_color = (128, 238, 198)

        # 2. Shops (exact 1 tile each)
        shop_tiles_raw = [
            (rc_tile[0] - 6, rc_tile[1] - 3),
            (rc_tile[0] + 18, rc_tile[1] + 10),
            (180, 180),
            (390, 590),
            (590, 220),
            (970, 560),
            (1180, 230),
            (1390, 500),
            (280, 405),
            (1280, 650),
            (500, 120),
            (1050, 140),
            (150, 640),
            (850, 660),
            (700, 450),
            (900, 320),
            (460, 460),
            (1100, 400),
        ]
        self.shops: list[ShopData] = []
        shop_tiles: list[tuple[int, int]] = []
        for idx, (sc, sr) in enumerate(shop_tiles_raw):
            tc, tr = claim_tile(sc, sr, "grass" if idx < 2 else "desert")
            shop_tiles.append((tc, tr))
            sx, sy = tile_center(tc, tr)
            self.shops.append(
                ShopData(
                    idx + 1,
                    "Outfitter Shop",
                    sx,
                    sy,
                    shopkeeper_entry=factory.create_shopkeep("Outfitter"),
                )
            )

        conv_tiles: list[tuple[int, int]] = []
        for cx_idx in range(8):
            for cy_idx in range(5):
                base_c = int(110 + (cx_idx + 0.5) * ((OW_COLS - 220) / 8))
                base_r = int(80 + (cy_idx + 0.5) * ((OW_ROWS - 160) / 5))
                sc = base_c + rng.randint(-50, 50)
                sr = base_r + rng.randint(-35, 35)
                terr = self.get_tile_terrain(sc, sr)
                tc, tr = claim_tile(sc, sr, "grass" if terr in ("mountain", "snowy_peaks", "oasis") else terr)
                conv_tiles.append((tc, tr))
                sx, sy = tile_center(tc, tr)
                self.shops.append(
                    ShopData(
                        len(self.shops) + 1,
                        "Convenience Store",
                        sx,
                        sy,
                        stock={"chili": 8, "apple_crate": 3},
                        shopkeeper_entry=factory.create_shopkeep("Convenience Store"),
                        shop_kind="convenience",
                    )
                )

        # 3. Many more Ranches across the entire frontier + near hub (exact 1 tile each)
        ranch_tiles: list[tuple[int, int]] = [
            claim_tile(rc_tile[0] + 10, rc_tile[1] - 7, "grass"),
            claim_tile(rc_tile[0] - 9, rc_tile[1] + 8, "grass"),
            claim_tile(rc_tile[0] + 3, rc_tile[1] + 12, "grass"),
            claim_tile(rc_tile[0] - 14, rc_tile[1] - 9, "grass"),
            claim_tile(rc_tile[0] + 22, rc_tile[1] - 4, "grass"),
        ]
        cols_sectors = 12
        rows_sectors = 8
        for sx_idx in range(cols_sectors):
            for sy_idx in range(rows_sectors):
                base_c = int(60 + (sx_idx + 0.5) * ((OW_COLS - 120) / cols_sectors))
                base_r = int(40 + (sy_idx + 0.5) * ((OW_ROWS - 80) / rows_sectors))
                rc = base_c + rng.randint(-42, 42)
                rr = base_r + rng.randint(-30, 30)
                terr = self.get_tile_terrain(rc, rr)
                tile = claim_tile(rc, rr, "grass" if terr == "mountain" else terr)
                ranch_tiles.append(tile)

        self.ranches: list[RanchData] = []
        for idx, (tc, tr) in enumerate(ranch_tiles):
            rx, ry = tile_center(tc, tr)
            prefix = RANCH_PREFIXES[idx % len(RANCH_PREFIXES)]
            suffix = "" if idx < len(RANCH_PREFIXES) else f" #{idx // len(RANCH_PREFIXES) + 1}"
            rname = f"{prefix} Ranch{suffix}"
            count = rng.randint(6, 9)
            horses = [factory.create_horse(origin=rname) for _ in range(count)]
            has_rabbit_pen = rng.random() < 0.9
            rabbits = (
                [factory.create_rabbit(origin=rname) for _ in range(rng.randint(2, 4))]
                if has_rabbit_pen
                else []
            )
            self.ranches.append(
                RanchData(
                    idx + 1,
                    rname,
                    rx,
                    ry,
                    horses,
                    rancher_entry=factory.create_rancher(rname),
                    has_rabbit_pen=has_rabbit_pen,
                    rabbits=rabbits,
                )
            )

        self.race_pool_newcomers: list[HorseEntry] = [
            factory.create_horse(origin="Frontier Circuit", age=rng.randint(1, 5))
            for _ in range(8)
        ]

        # 4. Build connected path network linking Racecourse, Your Ranch, Shops, Gene Factory, and DNA Lab and all Ranches
        all_nodes: list[tuple[int, int]] = (
            [yr_tile, gf_tile, dl_tile] + course_tiles + shop_tiles + conv_tiles + ranch_tiles
        )
        self._build_path_network(all_nodes, rng)
        self._carve_path(gf_tile, dl_tile)

        self.wild_horses: list[WildHorse] = []
        for _ in range(28):
            wx = self.racecourse_pos[0] + rng.uniform(-2200.0, 2200.0)
            wy = self.racecourse_pos[1] + rng.uniform(-1600.0, 1600.0)
            if math.hypot(wx - self.racecourse_pos[0], wy - self.racecourse_pos[1]) > 420.0:
                if rng.random() < 0.035:
                    self._spawn_curated_pack(wx, wy, self.get_terrain(wx, wy))
                elif rng.random() < 0.05:
                    self.wild_horses.append(self._make_wild_horse(wx, wy, entry=self.factory.create_carnivore()))
                else:
                    self.wild_horses.append(self._make_wild_horse(wx, wy))

        attempts = 0
        while len(self.wild_horses) < 540 and attempts < 8000:
            attempts += 1
            wx = rng.uniform(500.0, OW_WIDTH - 500.0)
            wy = rng.uniform(500.0, OW_HEIGHT - 500.0)
            terr = self.get_terrain(wx, wy)
            accept_prob = {
                "grass": 0.95,
                "savanna": 0.85,
                "deep_forest": 0.35,
                "desert": 0.38,
                "oasis": 0.70,
                "rock": 0.22,
                "mountain": 0.08,
                "snowy_peaks": 0.04,
            }[terr]
            if rng.random() > accept_prob:
                continue
            herd_count = 2 if (len(self.wild_horses) < 539 and rng.random() < 0.55) else 1
            for hi in range(herd_count):
                hx = wx if hi == 0 else max(120.0, min(OW_WIDTH - 120.0, wx + rng.uniform(-140.0, 140.0)))
                hy = wy if hi == 0 else max(120.0, min(OW_HEIGHT - 120.0, wy + rng.uniform(-140.0, 140.0)))
                if rng.random() < 0.045:
                    self.wild_horses.append(
                        self._make_wild_horse(hx, hy, entry=self.factory.create_carnivore())
                    )
                else:
                    self.wild_horses.append(self._make_wild_horse(hx, hy))

        # Sparse trees on grass and desert (some are apple trees)
        self.trees: list[TreeData] = []
        self.world_apples: list[WorldApple] = []
        self.fossils: list[FossilNode] = []
        self.meats: list[WorldMeat] = []
        landmarks = [self.your_ranch_pos, self.gene_factory_pos, self.dna_lab_pos]
        landmarks.extend((rc.x, rc.y) for rc in self.racecourses)
        landmarks.extend((sh.x, sh.y) for sh in self.shops)
        landmarks.extend((r.x, r.y) for r in self.ranches)

        for _ in range(8):
            tx = self.racecourse_pos[0] + rng.uniform(-1800.0, 1800.0)
            ty = self.racecourse_pos[1] + rng.uniform(-1400.0, 1400.0)
            terr = self.get_terrain(tx, ty)
            if terr in ("grass", "savanna", "deep_forest", "desert", "oasis") and not self.is_path_at_world(tx, ty):
                if all(math.hypot(tx - lx, ty - ly) > 220.0 for lx, ly in landmarks):
                    is_apple = (rng.random() < 0.10) if terr == "grass" else False
                    self.trees.append(self._make_tree(len(self.trees) + 1, tx, ty, terr, is_apple))

        tree_attempts = 0
        while len(self.trees) < 2800 and tree_attempts < 18000:
            tree_attempts += 1
            tx = rng.uniform(350.0, OW_WIDTH - 350.0)
            ty = rng.uniform(350.0, OW_HEIGHT - 350.0)
            terr = self.get_terrain(tx, ty)
            if terr not in ("grass", "savanna", "deep_forest", "desert", "oasis") or self.is_path_at_world(tx, ty):
                continue
            if terr == "desert" and rng.random() > 0.45:
                continue
            if terr == "savanna" and rng.random() > 0.50:
                continue
            if any(math.hypot(tx - lx, ty - ly) < 200.0 for lx, ly in landmarks):
                continue
            if terr == "deep_forest":
                is_apple = False
            elif terr == "grass":
                is_apple = rng.random() < 0.055
            elif terr == "savanna":
                is_apple = rng.random() < 0.025
            elif terr == "desert":
                is_apple = rng.random() < 0.12
            else:
                is_apple = False
            self.trees.append(self._make_tree(len(self.trees) + 1, tx, ty, terr, is_apple))

        fossil_attempts = 0
        while len(self.fossils) < 48 and fossil_attempts < 24000:
            fossil_attempts += 1
            fx = rng.uniform(400.0, OW_WIDTH - 400.0)
            fy = rng.uniform(400.0, OW_HEIGHT - 400.0)
            terr = self.get_terrain(fx, fy)
            if terr not in ("mountain", "snowy_peaks") or self.is_path_at_world(fx, fy):
                continue
            if any(math.hypot(fx - f.x, fy - f.y) < 1200.0 for f in self.fossils):
                continue
            fos_genome = random_fossil_genome(rng)
            fos_var, _ = fossil_visual_params(fos_genome)
            self.fossils.append(
                FossilNode(
                    fossil_id=len(self.fossils) + 1,
                    x=fx,
                    y=fy,
                    genome=fos_genome,
                    variant=fos_var,
                )
            )


    def _spawn_curated_pack(self, wx: float, wy: float, terrain: str):
        species = self.rng.choice(TERRAIN_PACK_SPECIES.get(terrain, ("zebra",)))
        pack_size = self.rng.randint(3, 6)
        pack_angle = self.rng.uniform(0.0, 2.0 * math.pi)
        pack_wander = self.rng.random() < 0.5

        for _ in range(pack_size):
            ang = self.rng.uniform(0.0, 2.0 * math.pi)
            dist = self.rng.uniform(28.0, 155.0)
            px = max(120.0, min(OW_WIDTH - 120.0, wx + math.cos(ang) * dist))
            py = max(120.0, min(OW_HEIGHT - 120.0, wy + math.sin(ang) * dist))
            age = self.rng.choices([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], weights=[14, 12, 12, 12, 11, 10, 9, 8, 7, 5], k=1)[0]
            g = random_herd_animal_genome(species, rng=self.rng)
            entry = self.factory.create_horse("Wild", age=age, genome=g)
            wh = self._make_wild_horse(px, py, entry=entry)
            if pack_wander:
                spd = self.rng.uniform(26.0, 42.0)
                ang_j = pack_angle + self.rng.uniform(-0.35, 0.35)
                wh.state = "wander"
                wh.vx = math.cos(ang_j) * spd
                wh.vy = math.sin(ang_j) * spd
                wh.facing = 1 if wh.vx >= 0 else -1
            else:
                wh.state = "graze"
                wh.vx = 0.0
                wh.vy = 0.0
                wh.facing = 1 if math.cos(pack_angle) >= 0 else -1
            self.wild_horses.append(wh)

    def _carve_path(self, a: tuple[int, int], b: tuple[int, int]):
        c, r = a
        tc, tr = b
        while c != tc or r != tr:
            self.path_tiles.add((c, r))
            dc = tc - c
            dr = tr - r
            # Prefer stepping along the larger delta, creating natural gentle diagonal/stepped trails
            if abs(dc) >= abs(dr) and dc != 0:
                c += 1 if dc > 0 else -1
            elif dr != 0:
                r += 1 if dr > 0 else -1
        self.path_tiles.add((tc, tr))

    def _build_path_network(self, nodes: list[tuple[int, int]], rng: random.Random):
        if len(nodes) < 2:
            return
        # Prim's Minimum Spanning Tree so every ranch, shop, Your Ranch & racecourse is connected
        n = len(nodes)
        in_tree = [False] * n
        in_tree[0] = True
        dist = [math.hypot(nodes[i][0] - nodes[0][0], nodes[i][1] - nodes[0][1]) for i in range(n)]
        parent = [0] * n
        edges: list[tuple[int, int]] = []

        for _ in range(n - 1):
            best_i = -1
            best_d = 1e18
            for i in range(n):
                if not in_tree[i] and dist[i] < best_d:
                    best_d = dist[i]
                    best_i = i
            if best_i == -1:
                break
            in_tree[best_i] = True
            edges.append((parent[best_i], best_i))
            nx, ny = nodes[best_i]
            for j in range(n):
                if not in_tree[j]:
                    d = math.hypot(nodes[j][0] - nx, nodes[j][1] - ny)
                    if d < dist[j]:
                        dist[j] = d
                        parent[j] = best_i

        # Add a few extra shortcut loops between close neighbors for crossroads
        edge_set = {tuple(sorted(e)) for e in edges}
        for i in range(0, n, 4):
            ix, iy = nodes[i]
            nearest = sorted(
                ((math.hypot(nodes[j][0] - ix, nodes[j][1] - iy), j) for j in range(n) if j != i),
                key=lambda x: x[0],
            )[:3]
            for _, j in nearest:
                pair = tuple(sorted((i, j)))
                if pair not in edge_set and rng.random() < 0.45:
                    edge_set.add(pair)
                    edges.append(pair)

        for i, j in edges:
            self._carve_path(nodes[i], nodes[j])

    def is_path_at_world(self, wx: float, wy: float) -> bool:
        return (int(wx // OW_TILE), int(wy // OW_TILE)) in self.path_tiles

    def get_tile_terrain(self, c: int, r: int) -> str:
        c = max(0, min(OW_COLS - 1, c))
        r = max(0, min(OW_ROWS - 1, r))
        ov = self.overrides.get((c, r))
        if ov is not None:
            return ov
        nx = c * 0.022 + self.seed_x
        ny = r * 0.022 + self.seed_y
        elev = (
            0.50 * math.sin(nx * 0.8 + math.cos(ny * 0.7))
            + 0.30 * math.cos(nx * 1.9 - ny * 1.3)
            + 0.20 * math.sin(nx * 3.7 + ny * 3.1)
        )
        moist = (
            0.55 * math.cos(nx * 0.6 + 1.4)
            + 0.45 * math.sin(ny * 1.1 - nx * 0.5)
        )
        if elev > 0.68:
            return "snowy_peaks"
        if elev > 0.52:
            return "mountain"
        if elev > 0.26:
            return "rock"
        if moist < -0.10:
            oasis_val = math.sin(c * 0.14 + self.seed_x * 2.1) * math.cos(r * 0.14 - self.seed_y * 1.7)
            if oasis_val > 0.80:
                return "oasis"
            return "desert"
        if moist < 0.08:
            return "savanna"
        if moist > 0.34:
            return "deep_forest"
        return "grass"

    def _flatten_area(self, wx: float, wy: float, radius_tiles: int, terrain: str):
        cc = int(wx // OW_TILE)
        rr = int(wy // OW_TILE)
        for dr in range(-radius_tiles, radius_tiles + 1):
            for dc in range(-radius_tiles, radius_tiles + 1):
                c2 = max(0, min(OW_COLS - 1, cc + dc))
                r2 = max(0, min(OW_ROWS - 1, rr + dr))
                self.overrides[(c2, r2)] = terrain

    def _make_tree(self, tree_id: int, tx: float, ty: float, terr: str, has_apples: bool) -> TreeData:
        scale = self.rng.uniform(0.86, 1.18)
        if terr == "deep_forest":
            kind = "pine"
            has_apples = False
        elif terr == "oasis":
            kind = "palm"
            has_apples = False
        elif terr == "savanna":
            kind = "acacia"
        elif terr == "desert":
            kind = "cactus" if (has_apples or self.rng.random() < 0.78) else "tree"
            if kind != "cactus":
                has_apples = False
        else:
            kind = "tree"

        apples: list[tuple[float, float]] = []
        if has_apples:
            cnt = self.rng.randint(1, 2) if kind == "cactus" else self.rng.randint(2, 4)
            for _ in range(cnt):
                if kind == "cactus":
                    apples.append((
                        self.rng.uniform(-14.0, 14.0) * scale,
                        self.rng.uniform(-52.0, -34.0) * scale,
                    ))
                else:
                    apples.append((
                        self.rng.uniform(-22.0, 22.0) * scale,
                        self.rng.uniform(-64.0, -34.0) * scale,
                    ))
        return TreeData(
            tree_id=tree_id,
            x=tx,
            y=ty,
            terrain=terr,
            has_apples=has_apples,
            apples=apples,
            scale=scale,
            kind=kind,
        )

    def get_terrain(self, wx: float, wy: float) -> str:
        return self.get_tile_terrain(int(wx // OW_TILE), int(wy // OW_TILE))

    def _make_wild_horse(self, wx: float, wy: float, entry: HorseEntry | None = None) -> WildHorse:
        if entry is None:
            entry = self.factory.create_horse("Wild")
        st = self.rng.choice(["graze", "graze", "wander"])
        ang = self.rng.uniform(0.0, 2.0 * math.pi)
        spd = 30.0 if st == "wander" else 0.0
        vx = math.cos(ang) * spd
        vy = math.sin(ang) * spd
        return WildHorse(
            entry=entry,
            x=wx,
            y=wy,
            vx=vx,
            vy=vy,
            facing=1 if vx >= 0 else -1,
            state=st,
            state_timer=self.rng.uniform(1.5, 5.0),
        )

    def release_horse(self, entry: HorseEntry, wx: float, wy: float):
        ang = self.rng.uniform(0.0, 2.0 * math.pi)
        rx = max(120.0, min(OW_WIDTH - 120.0, wx + math.cos(ang) * 110.0))
        ry = max(120.0, min(OW_HEIGHT - 120.0, wy + math.sin(ang) * 90.0))
        wh = self._make_wild_horse(rx, ry, entry=entry)
        wh.state = "wander"
        wh.vx = math.cos(ang) * 42.0
        wh.vy = math.sin(ang) * 42.0
        wh.facing = 1 if wh.vx >= 0 else -1
        wh.state_timer = 3.0
        self.wild_horses.append(wh)

    def simulate_day(self):
        """Advances 1 day: senescents die off, remaining horses age, and breeding stays controlled."""
        # 1. Ranches: senescent elders (age >= 10) die off; breeding & surplus spillover
        ranch_pairs: list[tuple[HorseEntry, HorseEntry]] = []
        for ranch in self.ranches:
            kept: list[HorseEntry] = []
            for h in ranch.horses:
                if h.is_dead or (not h.is_rancher and h.age >= h.death_age):
                    self.factory.release_name(h.name)
                    continue
                prev_age = h.age
                h.age = min(10, h.age + 1)
                if prev_age == 0 and h.age >= 1:
                    refresh_entry_config_for_age(h)
                h.is_tired = False
                h.drunk_level = 0
                h.is_frenzied = False
                if not h.is_rancher and self.rng.random() < 0.05:
                    h.is_hungry = True
                kept.append(h)
            ranch.horses = kept

            # Ranch breeding excludes juveniles (0) & elders (10)
            adults = [h for h in ranch.horses if 1 <= h.age <= 9 and not h.is_rancher and not h.is_unconscious]
            if len(adults) >= 2:
                p1, p2 = self.rng.sample(adults, 2)
                ranch_pairs.append((p1, p2))
                if len(ranch.horses) < 12:
                    max_pairs = min(2, len(adults) // 2)
                    for _ in range(max_pairs):
                        if len(ranch.horses) >= 12:
                            break
                        if self.rng.random() < 0.55:
                            bp1, bp2 = self.rng.sample(adults, 2)
                            foal = self.factory.create_foal(bp1, bp2, origin=ranch.name)
                            ranch.horses.append(foal)

            # Only bring in fresh stock if a ranch lacks a breeding pair
            if len(adults) < 2 and self.rng.random() < 0.35:
                ranch.horses.append(
                    self.factory.create_horse(origin=ranch.name, age=self.rng.randint(1, 3))
                )

            if ranch.rancher_entry is None:
                ranch.rancher_entry = self.factory.create_rancher(ranch.name)
            else:
                ranch.rancher_entry.drunk_level = 0
                ranch.rancher_entry.is_frenzied = False

        # 2. Wild horses: dead bodies clear after 1 day; living roam, forage/hunt, starve after 1-2 days, and breed
        survivors: list[WildHorse] = []
        slain_in_sim: set[int] = set()
        for wh in self.wild_horses:
            if id(wh) in slain_in_sim:
                continue
            if wh.entry.is_dead:
                wh.entry.dead_days += 1
                if wh.entry.dead_days >= 1:
                    self.factory.release_name(wh.entry.name)
                    continue
                wh.vx = 0.0
                wh.vy = 0.0
                wh.flipped = True
                wh.state = "dead"
                survivors.append(wh)
                continue
            if wh.entry.is_strand:
                wh.entry.is_tired = False
                wh.entry.drunk_level = 0
                wh.entry.is_frenzied = False
                survivors.append(wh)
                continue
            if wh.entry.age >= wh.entry.death_age:
                self.factory.release_name(wh.entry.name)
                continue
            prev_age = wh.entry.age
            wh.entry.age = min(10, wh.entry.age + 1)
            if prev_age == 0 and wh.entry.age >= 1:
                refresh_entry_config_for_age(wh.entry)
            wh.entry.is_tired = False
            wh.entry.drunk_level = 0
            wh.entry.is_frenzied = False

            was_hungry = wh.entry.is_hungry
            if not wh.entry.is_hungry and self.rng.random() < 0.42:
                wh.entry.is_hungry = True
                wh.entry.hunger_clock = 0.0
                wh.entry.days_hungry = 0

            best_nx, best_ny = wh.x, wh.y
            best_score = -999.0
            for _ in range(2):
                ang = self.rng.uniform(0.0, 2.0 * math.pi)
                step = self.rng.uniform(110.0, 320.0)
                nx = max(120.0, min(OW_WIDTH - 120.0, wh.x + math.cos(ang) * step))
                ny = max(120.0, min(OW_HEIGHT - 120.0, wh.y + math.sin(ang) * step))
                t_cand = self.get_terrain(nx, ny)
                score = {
                    "grass": 3.0,
                    "savanna": 2.4,
                    "oasis": 2.2,
                    "deep_forest": 1.0,
                    "desert": 0.6,
                    "rock": -0.5,
                    "mountain": -2.0,
                    "snowy_peaks": -3.0,
                }[t_cand] + self.rng.uniform(-0.5, 0.5)
                if score > best_score:
                    best_score = score
                    best_nx, best_ny = nx, ny
            wh.x, wh.y = best_nx, best_ny

            if wh.entry.is_hungry:
                ate = False
                if wh.entry.diet == "carnivore":
                    meat_cand = None
                    meat_d = 760.0
                    for cut in self.meats:
                        if cut.uses <= 0:
                            continue
                        d = math.hypot(cut.x - wh.x, cut.y - wh.y)
                        if d < meat_d:
                            meat_cand = cut
                            meat_d = d
                    if meat_cand is not None:
                        wh.x, wh.y = meat_cand.x, meat_cand.y
                        meat_cand.uses -= 1
                        if meat_cand.uses <= 0:
                            self.meats.remove(meat_cand)
                        ate = True
                    else:
                        corpse_cand = None
                        corpse_d = 760.0
                        for other in self.wild_horses:
                            if other is wh or not other.entry.is_dead or id(other) in slain_in_sim:
                                continue
                            d = math.hypot(other.x - wh.x, other.y - wh.y)
                            if d < corpse_d:
                                corpse_cand = other
                                corpse_d = d
                        if corpse_cand is not None:
                            wh.x, wh.y = corpse_cand.x, corpse_cand.y
                            new_cut = meat_from_kill(corpse_cand)
                            new_cut.uses -= 1
                            if new_cut.uses > 0:
                                self.meats.append(new_cut)
                            slain_in_sim.add(id(corpse_cand))
                            ate = True
                        elif was_hungry or self.rng.random() < 0.35:
                            prey_cand = None
                            prey_d = 520.0
                            for other in self.wild_horses:
                                if (
                                    other is wh
                                    or other.entry.is_dead
                                    or other.entry.diet == "carnivore"
                                    or id(other) in slain_in_sim
                                ):
                                    continue
                                d = math.hypot(other.x - wh.x, other.y - wh.y)
                                if d < prey_d:
                                    prey_cand = other
                                    prey_d = d
                            if prey_cand is not None:
                                wh.x, wh.y = prey_cand.x, prey_cand.y
                                new_cut = meat_from_kill(prey_cand)
                                new_cut.uses -= 1
                                if new_cut.uses > 0:
                                    self.meats.append(new_cut)
                                prey_cand.entry.is_dead = True
                                slain_in_sim.add(id(prey_cand))
                                ate = True
                else:
                    ap_cand = None
                    ap_d = 460.0
                    for ap in self.world_apples:
                        if ap.falling:
                            continue
                        d = math.hypot(ap.x - wh.x, ap.y - wh.y)
                        if d < ap_d:
                            ap_cand = ap
                            ap_d = d
                    if ap_cand is not None:
                        wh.x, wh.y = ap_cand.x, ap_cand.y
                        self.world_apples.remove(ap_cand)
                        if ap_cand.kind == "prickly_pear":
                            wh.entry.orange_boost = min(1.0, wh.entry.orange_boost + 0.25)
                            refresh_entry_config_for_age(wh.entry)
                        ate = True
                    elif wh.entry.diet == "omnivore":
                        meat_cand = None
                        meat_d = 460.0
                        for cut in self.meats:
                            if cut.uses <= 0:
                                continue
                            d = math.hypot(cut.x - wh.x, cut.y - wh.y)
                            if d < meat_d:
                                meat_cand = cut
                                meat_d = d
                        if meat_cand is not None:
                            wh.x, wh.y = meat_cand.x, meat_cand.y
                            meat_cand.uses -= 1
                            if meat_cand.uses <= 0:
                                self.meats.remove(meat_cand)
                            ate = True
                    if not ate:
                        terr_now = self.get_terrain(wh.x, wh.y)
                        if terr_now == "grass" or (terr_now in ("savanna", "oasis") and self.rng.random() < 0.85):
                            ate = True

                if ate:
                    wh.entry.is_hungry = False
                    wh.entry.days_hungry = 0
                    wh.entry.hunger_clock = 0.0
                elif was_hungry:
                    wh.entry.days_hungry += 1
                    starve_limit = 1 if (wh.entry.entry_id % 2 == 0) else 2
                    if wh.entry.days_hungry >= starve_limit:
                        wh.entry.is_dead = True
                        wh.entry.dead_days = 0
                        wh.flipped = True
                        wh.vx = 0.0
                        wh.vy = 0.0
                        wh.state = "dead"

            survivors.append(wh)
        if slain_in_sim:
            for w in survivors:
                if id(w) in slain_in_sim:
                    self.factory.release_name(w.entry.name)
            survivors = [w for w in survivors if id(w) not in slain_in_sim]
        self.wild_horses = survivors

        max_wild_cap = 1400
        cells: dict[tuple[int, int], list[WildHorse]] = {}
        for wh in self.wild_horses:
            if (
                1 <= wh.entry.age <= 9
                and not wh.entry.is_dead
                and not wh.entry.is_rancher
                and not wh.entry.is_strand
            ):
                key = (int(wh.x // 900.0), int(wh.y // 900.0))
                cells.setdefault(key, []).append(wh)

        wild_pairs: list[tuple[HorseEntry, HorseEntry]] = []
        for herd in cells.values():
            if len(herd) >= 2:
                wp1, wp2 = self.rng.sample(herd, 2)
                wild_pairs.append((wp1.entry, wp2.entry))

        if len(self.wild_horses) < max_wild_cap:
            new_foals: list[WildHorse] = []
            cell_keys = list(cells.keys())
            self.rng.shuffle(cell_keys)
            for key in cell_keys:
                if len(self.wild_horses) + len(new_foals) >= max_wild_cap:
                    break
                herd = cells[key]
                cx, cy = key
                if len(herd) >= 2:
                    max_pairs = min(3, len(herd) // 2)
                    shuffled_herd = list(herd)
                    self.rng.shuffle(shuffled_herd)
                    for p_idx in range(max_pairs):
                        if len(self.wild_horses) + len(new_foals) >= max_wild_cap:
                            break
                        if self.rng.random() < 0.55:
                            p1 = shuffled_herd[p_idx * 2]
                            p2 = shuffled_herd[p_idx * 2 + 1]
                            foal_entry = self.factory.create_foal(p1.entry, p2.entry, origin="Wild")
                            disp_ang = self.rng.uniform(0.0, 2.0 * math.pi)
                            disp_dist = (
                                self.rng.uniform(420.0, 1050.0)
                                if len(herd) >= 4
                                else self.rng.uniform(120.0, 480.0)
                            )
                            fx = max(120.0, min(OW_WIDTH - 120.0, (p1.x + p2.x) * 0.5 + math.cos(disp_ang) * disp_dist))
                            fy = max(120.0, min(OW_HEIGHT - 120.0, (p1.y + p2.y) * 0.5 + math.sin(disp_ang) * disp_dist))
                            new_foals.append(self._make_wild_horse(fx, fy, entry=foal_entry))
                elif len(herd) == 1:
                    neighbor_mates: list[WildHorse] = []
                    for dx in (-1, 0, 1):
                        for dy in (-1, 0, 1):
                            if dx == 0 and dy == 0:
                                continue
                            neighbor_mates.extend(cells.get((cx + dx, cy + dy), ()))
                    if neighbor_mates and self.rng.random() < 0.45:
                        p1 = herd[0]
                        p2 = self.rng.choice(neighbor_mates)
                        foal_entry = self.factory.create_foal(p1.entry, p2.entry, origin="Wild")
                        disp_ang = self.rng.uniform(0.0, 2.0 * math.pi)
                        disp_dist = self.rng.uniform(120.0, 480.0)
                        fx = max(120.0, min(OW_WIDTH - 120.0, (p1.x + p2.x) * 0.5 + math.cos(disp_ang) * disp_dist))
                        fy = max(120.0, min(OW_HEIGHT - 120.0, (p1.y + p2.y) * 0.5 + math.sin(disp_ang) * disp_dist))
                        new_foals.append(self._make_wild_horse(fx, fy, entry=foal_entry))

            self.wild_horses.extend(new_foals)

        # Excess stock on large ranches spills into the surrounding wild
        for ranch in self.ranches:
            if len(self.wild_horses) >= max_wild_cap:
                break
            if len(ranch.horses) > 10 and self.rng.random() < 0.50:
                surplus = [h for h in ranch.horses if 1 <= h.age <= 8 and not h.is_rancher and not h.is_unconscious]
                if surplus:
                    chosen_out = self.rng.choice(surplus)
                    ranch.horses.remove(chosen_out)
                    self.release_horse(chosen_out, ranch.x, ranch.y)

        # 3. Fresh horses entering the race pool circuit (drawn from living frontier ecology)
        kept_newcomers: list[HorseEntry] = []
        for h in self.race_pool_newcomers:
            if h.age >= 10:
                self.factory.release_name(h.name)
                continue
            prev_age = h.age
            h.age = min(10, h.age + 1)
            if prev_age == 0 and h.age >= 1:
                refresh_entry_config_for_age(h)
            h.is_tired = False
            h.drunk_level = 0
            h.is_frenzied = False
            kept_newcomers.append(h)
        self.race_pool_newcomers = kept_newcomers
        ecology_pairs = wild_pairs + ranch_pairs
        for _ in range(3):
            if len(self.race_pool_newcomers) >= 14:
                removed = self.race_pool_newcomers.pop(0)
                self.factory.release_name(removed.name)
            if ecology_pairs:
                p1, p2 = self.rng.choice(ecology_pairs)
                newcomer = self.factory.create_foal(p1, p2, origin="Frontier Circuit")
                newcomer.age = self.rng.randint(1, 4)
                refresh_entry_config_for_age(newcomer)
            else:
                newcomer = self.factory.create_horse(origin="Frontier Circuit", age=self.rng.randint(1, 4))
            self.race_pool_newcomers.append(newcomer)

        # 4. KO'd Jean Gene wakes with the new day
        if self.jean_entry is not None:
            self.jean_entry.is_unconscious = False
            self.jean_entry.drunk_level = 0
            self.jean_entry.is_tired = False
            self.jean_entry.is_frenzied = False

        if self.dna_guide_entry is not None:
            self.dna_guide_entry.is_unconscious = False
            self.dna_guide_entry.drunk_level = 0
            self.dna_guide_entry.is_tired = False
            self.dna_guide_entry.is_frenzied = False

        # 5. Restock all shops & wake/replace shopkeepers
        for sh in self.shops:
            if sh.shop_kind == "convenience":
                sh.stock = {"chili": 8, "apple_crate": 3}
            else:
                sh.stock = {"lasso": 4, "hay": 8, "beer": 12}
            if sh.shopkeeper_entry is None:
                sh.shopkeeper_entry = self.factory.create_shopkeep(sh.name)
            else:
                sh.shopkeeper_entry.drunk_level = 0
                sh.shopkeeper_entry.is_tired = False

        # 6. Regrow apples on apple trees and occasionally drop a ripe apple
        for tr in self.trees:
            if not tr.has_apples:
                continue
            target_cnt = self.rng.randint(1, 2) if tr.kind == "cactus" else self.rng.randint(2, 4)
            while len(tr.apples) < target_cnt:
                if tr.kind == "cactus":
                    tr.apples.append((
                        self.rng.uniform(-14.0, 14.0) * tr.scale,
                        self.rng.uniform(-52.0, -34.0) * tr.scale,
                    ))
                else:
                    tr.apples.append((
                        self.rng.uniform(-22.0, 22.0) * tr.scale,
                        self.rng.uniform(-64.0, -34.0) * tr.scale,
                    ))
            if len(self.world_apples) < 250 and self.rng.random() < (0.04 if tr.kind == "cactus" else 0.08):
                ax = tr.x + self.rng.uniform(-28.0, 28.0)
                ay = tr.y + self.rng.uniform(12.0, 26.0)
                self.world_apples.append(
                    WorldApple(
                        x=ax,
                        y=ay,
                        target_y=ay,
                        falling=False,
                        kind="prickly_pear" if tr.kind == "cactus" else "apple",
                    )
                )

    def update_wild_horses(self, dt: float, cam_cx: float, cam_cy: float):
        slain: list[WildHorse] = []
        slain_ids: set[int] = set()
        eaten_apples: set[int] = set()
        for wh in self.wild_horses:
            if id(wh) in slain_ids:
                continue
            if wh.entry.is_dead:
                wh.vx = 0.0
                wh.vy = 0.0
                wh.flipped = True
                wh.state = "dead"
                continue
            if wh.being_lassoed:
                continue
            near_cam = abs(wh.x - cam_cx) < 1300.0 and abs(wh.y - cam_cy) < 950.0
            if not near_cam and self.rng.random() > 0.06:
                continue
            step_dt = dt if near_cam else dt * 16.0

            wh.hunt_cooldown = max(0.0, wh.hunt_cooldown - step_dt)
            if not wh.entry.is_strand and not wh.entry.is_rancher and not wh.entry.is_hungry:
                wh.entry.hunger_clock += step_dt
                hunger_thresh = 95.0 + (wh.entry.entry_id % 7) * 14.0
                if wh.entry.hunger_clock >= hunger_thresh:
                    wh.entry.is_hungry = True
                    wh.entry.hunger_clock = 0.0

            terr = self.get_terrain(wh.x, wh.y)
            seeking_food = False

            if wh.entry.is_hungry:
                if wh.entry.diet == "carnivore":
                    meat_target = None
                    meat_dist = 820.0
                    for cut in self.meats:
                        if cut.uses <= 0:
                            continue
                        dist = math.hypot(cut.x - wh.x, cut.y - wh.y)
                        if dist < meat_dist:
                            meat_target = cut
                            meat_dist = dist

                    if meat_target is not None:
                        seeking_food = True
                        ang = math.atan2(meat_target.y - wh.y, meat_target.x - wh.x)
                        wh.vx = math.cos(ang) * 72.0
                        wh.vy = math.sin(ang) * 72.0
                        wh.facing = 1 if wh.vx >= 0 else -1
                        wh.state = "wander"
                        if meat_dist < 42.0:
                            meat_target.uses -= 1
                            if meat_target.uses <= 0 and meat_target in self.meats:
                                self.meats.remove(meat_target)
                            wh.entry.is_hungry = False
                            wh.entry.days_hungry = 0
                            wh.entry.hunger_clock = 0.0
                            wh.vx = 0.0
                            wh.vy = 0.0
                            wh.state = "graze"
                            wh.state_timer = 2.0
                    else:
                        corpse_target = None
                        corpse_dist = 820.0
                        for other in self.wild_horses:
                            if other is wh or not other.entry.is_dead or id(other) in slain_ids:
                                continue
                            dist = math.hypot(other.x - wh.x, other.y - wh.y)
                            if dist < corpse_dist:
                                corpse_target = other
                                corpse_dist = dist

                        if corpse_target is not None:
                            seeking_food = True
                            ang = math.atan2(corpse_target.y - wh.y, corpse_target.x - wh.x)
                            wh.vx = math.cos(ang) * 68.0
                            wh.vy = math.sin(ang) * 68.0
                            wh.facing = 1 if wh.vx >= 0 else -1
                            wh.state = "wander"
                            if corpse_dist < 40.0:
                                new_cut = meat_from_kill(corpse_target)
                                new_cut.uses -= 1
                                if new_cut.uses > 0:
                                    self.meats.append(new_cut)
                                slain_ids.add(id(corpse_target))
                                slain.append(corpse_target)
                                wh.entry.is_hungry = False
                                wh.entry.days_hungry = 0
                                wh.entry.hunger_clock = 0.0
                                wh.vx = 0.0
                                wh.vy = 0.0
                                wh.state = "graze"
                                wh.state_timer = 2.0
                        elif near_cam and wh.hunt_cooldown <= 0.0:
                            prey = None
                            prey_dist = 520.0
                            for other in self.wild_horses:
                                if (
                                    other is wh
                                    or other.entry.is_dead
                                    or other.being_lassoed
                                    or other.entry.diet == "carnivore"
                                    or id(other) in slain_ids
                                ):
                                    continue
                                dist = math.hypot(other.x - wh.x, other.y - wh.y)
                                if dist < prey_dist:
                                    prey = other
                                    prey_dist = dist
                            if prey is not None:
                                seeking_food = True
                                ang = math.atan2(prey.y - wh.y, prey.x - wh.x)
                                wh.vx = math.cos(ang) * 78.0
                                wh.vy = math.sin(ang) * 78.0
                                wh.facing = 1 if wh.vx >= 0 else -1
                                wh.state = "wander"
                                if prey_dist < 36.0 and not prey.entry.is_dead:
                                    new_cut = meat_from_kill(prey)
                                    new_cut.uses -= 1
                                    if new_cut.uses > 0:
                                        self.meats.append(new_cut)
                                    prey.entry.is_dead = True
                                    slain_ids.add(id(prey))
                                    slain.append(prey)
                                    wh.entry.is_hungry = False
                                    wh.entry.days_hungry = 0
                                    wh.entry.hunger_clock = 0.0
                                    wh.hunt_cooldown = 18.0
                                    wh.vx = 0.0
                                    wh.vy = 0.0
                                    wh.state = "graze"
                                    wh.state_timer = 2.5
                else:
                    ap_target = None
                    ap_dist = 480.0
                    for ap in self.world_apples:
                        if ap.falling or id(ap) in eaten_apples:
                            continue
                        dist = math.hypot(ap.x - wh.x, ap.y - wh.y)
                        if dist < ap_dist:
                            ap_target = ap
                            ap_dist = dist

                    if ap_target is not None:
                        seeking_food = True
                        ang = math.atan2(ap_target.y - wh.y, ap_target.x - wh.x)
                        wh.vx = math.cos(ang) * 54.0
                        wh.vy = math.sin(ang) * 54.0
                        wh.facing = 1 if wh.vx >= 0 else -1
                        wh.state = "wander"
                        if ap_dist < 32.0:
                            eaten_apples.add(id(ap_target))
                            if ap_target.kind == "prickly_pear":
                                wh.entry.orange_boost = min(1.0, wh.entry.orange_boost + 0.25)
                                refresh_entry_config_for_age(wh.entry)
                            wh.entry.is_hungry = False
                            wh.entry.days_hungry = 0
                            wh.entry.hunger_clock = 0.0
                            wh.vx = 0.0
                            wh.vy = 0.0
                            wh.state = "graze"
                            wh.state_timer = 2.0
                    elif wh.entry.diet == "omnivore":
                        meat_target = None
                        meat_dist = 480.0
                        for cut in self.meats:
                            if cut.uses <= 0:
                                continue
                            dist = math.hypot(cut.x - wh.x, cut.y - wh.y)
                            if dist < meat_dist:
                                meat_target = cut
                                meat_dist = dist
                        if meat_target is not None:
                            seeking_food = True
                            ang = math.atan2(meat_target.y - wh.y, meat_target.x - wh.x)
                            wh.vx = math.cos(ang) * 54.0
                            wh.vy = math.sin(ang) * 54.0
                            wh.facing = 1 if wh.vx >= 0 else -1
                            wh.state = "wander"
                            if meat_dist < 40.0:
                                meat_target.uses -= 1
                                if meat_target.uses <= 0 and meat_target in self.meats:
                                    self.meats.remove(meat_target)
                                wh.entry.is_hungry = False
                                wh.entry.days_hungry = 0
                                wh.entry.hunger_clock = 0.0
                                wh.vx = 0.0
                                wh.vy = 0.0
                                wh.state = "graze"
                                wh.state_timer = 2.0

            if not seeking_food:
                if wh.entry.is_hungry and wh.entry.diet != "carnivore" and terr in ("grass", "savanna", "oasis"):
                    if wh.state != "graze":
                        wh.state = "graze"
                        wh.vx = 0.0
                        wh.vy = 0.0
                        wh.state_timer = self.rng.uniform(1.6, 2.8)
                elif wh.entry.is_hungry and wh.state == "graze":
                    wh.state = "wander"
                    wh.state_timer = 0.0

                wh.state_timer -= step_dt
                if wh.state_timer <= 0.0:
                    if (
                        wh.state == "graze"
                        and wh.entry.is_hungry
                        and wh.entry.diet != "carnivore"
                        and terr in ("grass", "savanna", "oasis")
                    ):
                        wh.entry.is_hungry = False
                        wh.entry.days_hungry = 0
                        wh.entry.hunger_clock = 0.0

                    if wh.entry.is_hungry:
                        if wh.entry.diet != "carnivore" and terr in ("grass", "savanna", "oasis"):
                            wh.state = "graze"
                        else:
                            wh.state = "wander"
                    elif terr == "grass":
                        wh.state = "graze" if self.rng.random() < 0.65 else "wander"
                    else:
                        wh.state = "wander" if self.rng.random() < 0.80 else "graze"
                    wh.state_timer = self.rng.uniform(2.0, 5.5)

                    if wh.state == "wander":
                        best_ang = self.rng.uniform(0.0, 2.0 * math.pi)
                        best_score = -999.0
                        for _ in range(6):
                            cand = self.rng.uniform(0.0, 2.0 * math.pi)
                            tx = wh.x + math.cos(cand) * 320.0
                            ty = wh.y + math.sin(cand) * 320.0
                            t_cand = self.get_terrain(tx, ty)
                            score = {
                                "grass": 3.0,
                                "savanna": 2.4,
                                "oasis": 2.2,
                                "deep_forest": 1.0,
                                "desert": 0.6,
                                "rock": -0.5,
                                "mountain": -2.0,
                                "snowy_peaks": -3.0,
                            }[t_cand]
                            if wh.entry.is_hungry and wh.entry.diet != "carnivore":
                                if t_cand in ("grass", "savanna", "oasis"):
                                    score += 2.5
                            score += self.rng.uniform(-0.4, 0.4)
                            if score > best_score:
                                best_score = score
                                best_ang = cand
                        spd = self.rng.uniform(38.0, 54.0) if wh.entry.is_hungry else self.rng.uniform(24.0, 44.0)
                        wh.vx = math.cos(best_ang) * spd
                        wh.vy = math.sin(best_ang) * spd
                        wh.facing = 1 if wh.vx >= 0 else -1
                    else:
                        wh.vx = 0.0
                        wh.vy = 0.0

            if wh.state == "wander":
                wh.x = max(80.0, min(OW_WIDTH - 80.0, wh.x + wh.vx * step_dt))
                wh.y = max(80.0, min(OW_HEIGHT - 80.0, wh.y + wh.vy * step_dt))
        if eaten_apples:
            self.world_apples = [ap for ap in self.world_apples if id(ap) not in eaten_apples]
        if slain:
            self.wild_horses = [w for w in self.wild_horses if id(w) not in slain_ids]
            for victim in slain:
                self.factory.release_name(victim.entry.name)


# --- CREATURE STATIC SNAPSHOT FOR OPEN WORLD WILD HORSES ---
