# Universal genome

Every creature has 64 diploid loci, each containing two 24-nucleotide alleles.
The original 50 loci retain their strand numbers. The added loci are numbers
51–64, and missing loci in imported genomes receive neutral alleles.

Quantitative shape channels use 0.5 as their neutral value. Promoters, dosage,
stop codons, crossover and mutation still determine expression. Shapes follow
the alleles rather than a creature's lineage or item name.

Head scaling carries both jaw parts, teeth and nose with it across animal,
intermediate and upright body plans. The extra skull and muzzle channels make
smaller proportion adjustments; new wild creatures inherit values close to
neutral so these adjustments do not compound into oversized or needle-thin
faces. Gene editing and mutation still allow a wider range than ordinary
wild variation.

| Strand | Locus | Primary | Secondary | Tertiary |
| --- | --- | --- | --- | --- |
| 51 | `cranial_shape` | Head width | Head height | Rounded / tapered outline |
| 52 | `muzzle_shape` | Muzzle length | Muzzle depth | Nose size |
| 53 | `eye_expression` | Eye size | Eye height | Gaze and brow slope |
| 54 | `ear_shape` | Ear length | Ear width | Upright carriage |
| 55 | `limb_shape` | Limb width | Lower-limb taper | Bend |
| 56 | `tail_shape` | Tail length | Plume width | Ribbon / forked tips |
| 57 | `wing_shape` | Span | Chord | Fan / scalloped outline |
| 58 | `horn_shape` | Spiral curl | Spread | Branch count |
| 59 | `crest_shape` | Fan / antennae / rosette | Size | Spread |
| 60 | `crest_ornament` | Pom size | Hanging ornaments | Round / diamond tips |
| 61 | `skin_ornament` | Density | Size | Beads / rosettes / plates |
| 62 | `joint_response` | Spring strength | Damping | Compliance |
| 63 | `joint_pose` | Neck carriage | Head pitch | Arm repose |
| 64 | `rotary_drive` | Front-leg rotation | Hind-leg rotation | Middle-leg rotation |

Existing appendage development loci govern whether limbs, tails, wings and
horns exist; the new shape loci refine their geometry. Extreme `crest_shape`
expression can also produce a crest. Decorations remain small geometric
marks built by the shared renderer.

`rotary_drive` channels above 0.84 rotate forward and below 0.16 rotate backward.
Intermediate channels keep the usual gait. The UTR sets rotation speed, scaled
by running cadence. Each leg can rotate independently. During an active run,
a Pymunk motor drives the leg while its rotary spring and angular limit exert
zero force. When running stops, those constraints resume; rebasing by complete
turns preserves the visible orientation. Sleeping, unconscious, dead and
disabled creatures stop their motors.

New wild creatures inherit moderate proportion variation, with less frequent
ornamental extremes and rotary legs. All 64 loci participate in breeding,
mutation, extraction, drives and strand editing. The gene map uses an 8×8
layout in a 3000×2000 scene with less initial position jitter.

Run the regression checks from the repository root:

```sh
python3 -B -m unittest discover -s sim/tests -v
```
