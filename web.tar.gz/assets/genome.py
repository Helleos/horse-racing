"""Diploid genome: breeding, mutation, and phenotype evaluation."""
from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import math
import random

from allele import (
    ALLELE_LENGTH,
    ALL_LOCI,
    BASE_TO_INT,
    Gene,
    GeneExpression,
    _clamp,
    _lerp,
    _rise,
    encode_allele,
)

from phenotype import (
    EYE_PUPIL_ANCHORS,
    Phenotype,
    _chroma_rgb,
    _resolve_coat_colors,
    _resolve_human_skin_color,
    _resolve_pattern,
    _rgb_clamp,
    _rgb_lerp,
    _rgb_shift,
)


def _channel_bias(expr: GeneExpression, value: float) -> float:
    """Signed pull around a wild-type 0.5 allele. Inactive genes contribute nothing.

    Values within 0.01 of 0.5 count as neutral. Encoding 0.5 does not land on
    exactly 0.5 after stop-codon avoidance, and that residue must not nudge a body.
    """
    if not expr.active:
        return 0.0
    delta = value - 0.5
    if abs(delta) < 0.01:
        return 0.0
    return delta * min(1.0, expr.dosage)


def _mix2(
    a: tuple[float, float],
    b: tuple[float, float],
    t: float,
) -> tuple[float, float]:
    return (_lerp(a[0], b[0], t), _lerp(a[1], b[1], t))


# --- GENOME CLASS ---


@dataclass
class Genome:
    """Universal 32-gene diploid genome shared by all creatures."""

    genes: dict[str, Gene] = field(default_factory=dict)
    lineage: str = "Wild"
    generation: int = 1
    strand_loci: tuple[str, ...] = ()
    pure_strand: bool = False

    def __post_init__(self):
        # Ensure all 32 loci exist so every creature shares the exact same gene set
        for locus in ALL_LOCI:
            if locus not in self.genes:
                wt = encode_allele(0.5, 0.5, 0.5)
                self.genes[locus] = Gene(locus, wt, wt)
        if self.strand_loci:
            allowed = set(self.strand_loci)
            self.strand_loci = tuple(l for l in ALL_LOCI if l in allowed)

    def express_all(self) -> dict[str, GeneExpression]:
        return {locus: self.genes[locus].express() for locus in ALL_LOCI}

    def mutate(self, point_rate: float = 0.015, rng: random.Random | None = None) -> "Genome":
        rng = rng or random.Random()
        new_genes = {
            locus: self.genes[locus].mutate(point_rate=point_rate, rng=rng)
            for locus in ALL_LOCI
        }
        return Genome(
            genes=new_genes,
            lineage=f"{self.lineage}*",
            generation=self.generation,
            strand_loci=self.strand_loci,
            pure_strand=self.pure_strand,
        )

    def breed(
        self,
        other: "Genome",
        point_mutation_rate: float = 0.012,
        rng: random.Random | None = None,
    ) -> "Genome":
        rng = rng or random.Random()
        self_strand = set(self.strand_loci)
        other_strand = set(other.strand_loci)
        child_genes: dict[str, Gene] = {}
        child_strands: list[str] = []

        if self.pure_strand and other.pure_strand:
            child_pure = True
            for locus in ALL_LOCI:
                in_a = locus in self_strand
                in_b = locus in other_strand
                if in_a and in_b:
                    child_genes[locus] = self.genes[locus].crossover(other.genes[locus], rng=rng).mutate(
                        point_rate=point_mutation_rate, rng=rng
                    )
                    child_strands.append(locus)
                elif in_a:
                    child_genes[locus] = self.genes[locus].mutate(point_rate=point_mutation_rate, rng=rng)
                    child_strands.append(locus)
                elif in_b:
                    child_genes[locus] = other.genes[locus].mutate(point_rate=point_mutation_rate, rng=rng)
                    child_strands.append(locus)
                else:
                    wt = encode_allele(0.5, 0.5, 0.5)
                    child_genes[locus] = Gene(locus, wt, wt)
        elif self.pure_strand != other.pure_strand:
            strand_p, body_p = (self, other) if self.pure_strand else (other, self)
            sp_set = set(strand_p.strand_loci)
            bp_set = set(body_p.strand_loci)
            child_pure = False
            for locus in ALL_LOCI:
                if locus in sp_set:
                    sg = strand_p.genes[locus]
                    bg = body_p.genes[locus]
                    if sg.is_complete() and rng.random() < 0.75:
                        gamete_s = sg.allele_a if rng.random() < 0.5 else sg.allele_b
                    else:
                        gamete_s = sg.recombine_gamete(rng)
                    gamete_b = bg.recombine_gamete(rng)
                    pair = (gamete_s, gamete_b) if strand_p is self else (gamete_b, gamete_s)
                    child_genes[locus] = Gene(locus, pair[0], pair[1]).mutate(
                        point_rate=point_mutation_rate * 0.25, rng=rng
                    )
                    child_strands.append(locus)
                else:
                    child_genes[locus] = body_p.genes[locus].mutate(point_rate=point_mutation_rate, rng=rng)
                    if locus in bp_set and rng.random() < 0.85:
                        child_strands.append(locus)
        else:
            child_pure = False
            for locus in ALL_LOCI:
                child_genes[locus] = self.genes[locus].crossover(other.genes[locus], rng=rng).mutate(
                    point_rate=point_mutation_rate, rng=rng
                )
                in_a = locus in self_strand
                in_b = locus in other_strand
                if in_a and in_b:
                    child_strands.append(locus)
                elif (in_a or in_b) and rng.random() < 0.70:
                    child_strands.append(locus)

        return Genome(
            genes=child_genes,
            lineage=f"{self.lineage}x{other.lineage}",
            generation=max(self.generation, other.generation) + 1,
            strand_loci=tuple(child_strands),
            pure_strand=child_pure,
        )

    def nudge_toward(
        self,
        donor: "Genome",
        strength: float = 0.24,
        rng: random.Random | None = None,
    ) -> "Genome":
        """Rewrite a fraction of nucleotides so this genome shifts slightly toward donor."""
        rng = rng or random.Random()
        strength = _clamp(strength, 0.05, 0.6)
        swaps = max(2, int(round(ALLELE_LENGTH * strength)))
        new_genes: dict[str, Gene] = {}
        for locus in ALL_LOCI:
            mine = self.genes[locus]
            theirs = donor.genes[locus]
            strands = []
            for seq, src in (
                (mine.allele_a, theirs.allele_a),
                (mine.allele_b, theirs.allele_b),
            ):
                chars = list(seq)
                for idx in rng.sample(range(ALLELE_LENGTH), swaps):
                    if src[idx] in BASE_TO_INT:
                        chars[idx] = src[idx]
                strands.append("".join(chars))
            new_genes[locus] = Gene(locus, strands[0], strands[1])
        return Genome(
            genes=new_genes,
            lineage=self.lineage,
            generation=self.generation,
            strand_loci=self.strand_loci,
            pure_strand=self.pure_strand,
        )

    def copy(self) -> "Genome":
        return Genome(
            genes={
                locus: Gene(locus, gene.allele_a, gene.allele_b)
                for locus, gene in self.genes.items()
            },
            lineage=self.lineage,
            generation=self.generation,
            strand_loci=self.strand_loci,
            pure_strand=self.pure_strand,
        )

    def nucleotide_fingerprint(self, length: int = 16) -> str:
        """Compact representative nucleotide motif string across key loci."""
        parts = [
            self.genes["hox_posture"].allele_a[:4],
            self.genes["hox_limb_gate"].allele_a[:4],
            self.genes["pigment_base"].allele_a[3:7],
            self.genes["color_mutator"].allele_a[9:13],
        ]
        return "".join(parts)[:length]

    def evaluate(self, age: int = 1) -> Phenotype:
        """Evaluates the 32-gene regulatory network into a unified Phenotype."""
        ex = self.express_all()

        g_post = ex["hox_posture"]
        g_axial = ex["axial_plan"]
        g_diet = ex["diet_guild"]
        g_osteo = ex["osteoderm"]
        g_flex = ex["joint_flex"]
        g_vital = ex["vital_span"]
        g_lws = ex["lethal_white"]
        g_sent = ex["sentience"]
        g_dent = ex["dentition"]
        g_limb_gate = ex["hox_limb_gate"]
        g_cran = ex["hox_cranial"]
        g_caud = ex["hox_caudal"]
        g_size = ex["size_somatic"]
        g_build = ex["build_robust"]

        g_tlen = ex["torso_len"]
        g_tdep = ex["torso_depth"]
        g_neck = ex["neck_morph"]
        g_head = ex["head_size"]
        g_jaw = ex["jaw_morph"]
        g_teeth = ex["teeth_dev"]
        g_nose = ex["nose_dev"]
        g_ear = ex["ear_form"]

        g_fore = ex["limb_fore"]
        g_hind = ex["limb_hind"]
        g_arm = ex["arm_dev"]
        g_hoof = ex["hoof_dev"]
        g_tail = ex["tail_form"]
        g_sym = ex["symmetry_mod"]

        g_eye = ex["eye_dev"]
        g_iris = ex["iris_chrom"]

        g_pbase = ex["pigment_base"]
        g_pdil = ex["pigment_dilute"]
        g_pat = ex["pattern_locus"]
        g_pcol = ex["pattern_chrom"]
        g_cmut = ex["color_mutator"]
        g_tpig = ex["tail_pigment"]

        g_cad = ex["gait_cadence"]
        g_pow = ex["gait_power"]
        g_bal = ex["balance_core"]
        g_bone = ex["bone_density"]
        g_wing = ex["wing_dev"]
        g_wchrom = ex["wing_chrom"]
        g_horn = ex["horn_dev"]
        g_beh = ex["behavior_locus"]
        g_contour = ex["body_contour"]
        g_lextra = ex["limb_extra"]
        g_sense = ex["sense_reflex"]
        g_neuro = ex["neuro_temperament"]
        g_meta = ex["metabolic_drive"]
        g_crest = ex["crest_dev"]

        trait_tags: list[str] = []
        disabled_parts: list[str] = []

        strand_set = set(self.strand_loci)
        incomplete_strands = tuple(
            loc for loc in self.strand_loci
            if loc in self.genes and not self.genes[loc].is_complete()
        )
        if self.strand_loci and not self.pure_strand:
            trait_tags.append("Strand-Hybrid")
        if incomplete_strands:
            trait_tags.append("Broken-Strand")

        def _active_strand(loc: str, expr: GeneExpression) -> bool:
            return (loc in strand_set) and expr.active

        def _knocked_out_strand(loc: str, expr: GeneExpression) -> bool:
            return (loc in strand_set) and (not expr.active)

        # 1. Continuous body plan.
        # Horse posture alleles sit at or below 0.30 / 0.20. Rancher alleles sit
        # at or above 0.70. The ramps are linear across the gap, so a
        # heterozygote is partway along the same axes. No species pair is special.
        # humanity is the muzzle-to-face axis. grasp turns a living arm_dev
        # allele into a free forelimb; stop-codon arms stay at 0.
        # axial_plan: primary biases erectness, secondary biases grasp.
        # tertiary is the saltatory axis. 0.5 is the horse baseline.
        # The ramp fills the gap between the horse band and the upright band.
        # It reaches 1 at the lowest rancher and item postures, so a heterozygote
        # sitting near the middle of that gap is about half erect.
        erect_core = (
            _clamp((g_post.primary - 0.30) / 0.46, 0.0, 1.0) if g_post.active else 0.0
        )
        erectness = _clamp(erect_core + _channel_bias(g_axial, g_axial.primary) * 0.55, 0.0, 1.0)
        humanity = _clamp((g_post.secondary - 0.20) / 0.56, 0.0, 1.0)
        if abs(g_axial.tertiary - 0.5) < 0.03:
            lagomorph = 0.0
        else:
            lagomorph = _clamp((g_axial.tertiary - 0.50) / 0.46, 0.0, 1.0)
        if _knocked_out_strand("arm_dev", g_arm) or not g_arm.active:
            grasp_core = 0.0
        else:
            grasp_core = _rise(g_arm.dosage, 0.40, 0.85)
        grasp = _clamp(grasp_core + _channel_bias(g_axial, g_axial.secondary) * 1.40, 0.0, 1.0)
        # Arms on a still-horizontal spine: a centaur, not a second body plan.
        centaur = grasp * (1.0 - erectness)
        pose = _clamp(erectness + 0.70 * centaur, 0.0, 1.0)
        head_center = erectness

        diet_score = g_diet.primary if g_diet.active else 0.12
        if diet_score < 0.34:
            diet = "herbivore"
        elif diet_score < 0.67:
            diet = "omnivore"
        else:
            diet = "carnivore"
        if g_osteo.active and g_osteo.primary > 0.62:
            osteo_amp = _clamp((g_osteo.primary - 0.62) / 0.34, 0.0, 1.0)
            osteo_freq = _clamp(g_osteo.secondary, 0.0, 1.0)
            osteo_color = (
                int(_lerp(92, 214, g_osteo.tertiary)),
                int(_lerp(64, 168, 1.0 - abs(g_osteo.tertiary - 0.45))),
                int(_lerp(48, 96, g_osteo.utr_val)),
            )
        else:
            osteo_amp = 0.0
            osteo_freq = 0.0
            osteo_color = (120, 92, 64)
        flex_leg = g_flex.primary
        flex_neck = g_flex.secondary
        flex_arm = g_flex.tertiary
        flex_tail = g_flex.utr_val
        joint_looseness = (
            abs(flex_leg - 0.5) + abs(flex_neck - 0.5) + abs(flex_arm - 0.5) + abs(flex_tail - 0.5)
        ) / 2.0
        if g_vital.active and g_vital.primary > 0.62:
            lifespan_penalty = int(round(_rise(g_vital.primary, 0.62, 0.98) * 5.0))
        else:
            lifespan_penalty = 0
        spasm = _rise(g_vital.secondary, 0.60, 0.96) if g_vital.active else 0.0
        lethal_white = bool(
            g_lws.active and g_lws.primary > 0.78 and g_lws.secondary > 0.55
        )
        sentience = (
            _clamp((g_sent.primary - 0.40) / 0.42, 0.0, 1.0) if g_sent.active else 0.0
        )
        teeth_style = "triangular" if g_dent.primary >= 0.58 else "rectangular"
        upper_teeth = g_dent.active and g_dent.secondary > 0.38
        lower_teeth = g_dent.active and g_dent.tertiary > 0.38
        bite = 0.0 if abs(g_dent.utr_val - 0.5) < 0.06 else (g_dent.utr_val - 0.5) * 2.0

        posture = "upright" if erectness >= 0.5 else "quadruped"
        if humanity >= 0.75:
            trait_tags.append("Humanoid")
        elif humanity >= 0.22:
            trait_tags.append("Hybrid")
        if erectness >= 0.5 and humanity < 0.75:
            trait_tags.append("Upright")

        # 2. Unified Somatic Scale & Build (preserves upright pace while widening variation)
        horse_scale = _lerp(0.84, 1.15, g_size.primary)
        human_scale = _lerp(0.78, 1.22, g_size.primary) * 1.72
        raw_scale = _lerp(horse_scale, human_scale, humanity)
        if not g_size.active:
            raw_scale *= 0.56 if ("CCCC" in g_size.any_motifs and g_size.primary < 0.16) else 0.76
            trait_tags.append("Pygmy")
        elif g_size.primary > 0.90 and g_bone.primary > 0.78:
            raw_scale *= 1.09
            trait_tags.append("Draft")

        overall = _clamp(raw_scale, 0.34, 2.24)
        app_scale = overall / (1.0 + 0.55 * humanity)
        # Saltatory builds are smaller. 0 leaves every horse-sized creature alone.
        compact = _lerp(1.0, 0.50, lagomorph)
        overall *= compact
        app_scale *= compact
        stocky = _lerp(
            _lerp(0.86, 1.16, g_build.primary),
            _lerp(0.72, 1.36, g_build.primary),
            humanity,
        ) * (0.94 + 0.12 * g_bone.primary)

        is_juvenile = age == 0
        if is_juvenile:
            overall *= 0.72
            app_scale *= 0.72
        mass_scale = (overall**2) * stocky * (0.90 + 0.20 * g_bone.primary)
        rot_scale = mass_scale * _clamp(overall**1.5, 0.08, 1.8)

        # 3. Unified Hox Switches for Appendages & Organs
        limb_master_on = (
            False
            if _knocked_out_strand("hox_limb_gate", g_limb_gate)
            else (g_limb_gate.active or _active_strand("hox_limb_gate", g_limb_gate))
        )
        if not limb_master_on:
            disabled_parts.extend(["leg_front", "leg_back"])

        leg_front_enabled = (
            False
            if _knocked_out_strand("limb_fore", g_fore)
            else (
                _active_strand("limb_fore", g_fore)
                or (
                    limb_master_on
                    and g_fore.active
                    and not (g_limb_gate.secondary < 0.08 and g_sym.primary > 0.85)
                )
            )
        )
        leg_back_enabled = (
            False
            if _knocked_out_strand("limb_hind", g_hind)
            else (
                _active_strand("limb_hind", g_hind)
                or (
                    limb_master_on
                    and g_hind.active
                    and not (g_limb_gate.tertiary < 0.08 and g_sym.primary < 0.15)
                )
            )
        )
        leg_mid_enabled = (
            False
            if _knocked_out_strand("limb_extra", g_lextra)
            else (
                limb_master_on
                and (
                    _active_strand("limb_extra", g_lextra)
                    or (
                        g_lextra.active
                        and (
                            (
                                "ATG" in (g_lextra.readout_a.seq[:3], g_lextra.readout_b.seq[:3])
                                and "GGGG" in g_lextra.any_motifs
                            )
                            or (
                                g_lextra.readout_a.seq[:3] == "ATG"
                                and g_lextra.readout_b.seq[:3] == "ATG"
                            )
                            or g_lextra.primary > 0.94
                        )
                    )
                )
            )
        )
        if leg_mid_enabled:
            trait_tags.append("3-Legged")

        if not leg_front_enabled and "leg_front" not in disabled_parts:
            disabled_parts.append("leg_front")
        if not leg_back_enabled and "leg_back" not in disabled_parts:
            disabled_parts.append("leg_back")

        if not leg_front_enabled and not leg_back_enabled:
            trait_tags.append("Limbless")
        elif not leg_front_enabled:
            trait_tags.append("No-Front-Legs")
        elif not leg_back_enabled:
            trait_tags.append("No-Back-Legs")

        if _knocked_out_strand("arm_dev", g_arm):
            front_w = 0.0
            back_w = 0.0
        elif _active_strand("arm_dev", g_arm):
            front_w = _rise(g_arm.secondary, 0.02, 0.10)
            back_w = _rise(g_arm.tertiary, 0.02, 0.10)
            if front_w < 0.2 and back_w < 0.2:
                front_w = back_w = 1.0
        else:
            front_w = grasp * _rise(g_arm.secondary, 0.04, 0.13)
            back_w = grasp * _rise(g_arm.tertiary, 0.04, 0.13)
        arm_front_enabled = front_w > 0.45
        arm_back_enabled = back_w > 0.45
        if not (humanity >= 0.75 and erectness >= 0.5) and (arm_front_enabled or arm_back_enabled):
            trait_tags.append("Armed")

        hoof_enabled = (
            False
            if _knocked_out_strand("hoof_dev", g_hoof)
            else (
                (_active_strand("hoof_dev", g_hoof) and (leg_front_enabled or leg_back_enabled))
                or (
                    (leg_front_enabled or leg_back_enabled)
                    and g_hoof.active
                    and (
                        humanity < 0.90
                        or "ATG" in (g_hoof.readout_a.seq[:3], g_hoof.readout_b.seq[:3])
                    )
                )
            )
        )
        if not hoof_enabled and humanity < 0.50 and (leg_front_enabled or leg_back_enabled):
            disabled_parts.append("hoof")
            trait_tags.append("Hoofless")

        head_enabled = (
            False
            if (_knocked_out_strand("head_size", g_head) or _knocked_out_strand("hox_cranial", g_cran))
            else (
                g_head.active
                or (humanity > 0.72)
                or _active_strand("head_size", g_head)
                or _active_strand("hox_cranial", g_cran)
            )
        )
        if not head_enabled:
            disabled_parts.append("head")
            trait_tags.append("Headless")

        neck_enabled = (
            False
            if _knocked_out_strand("neck_morph", g_neck)
            else (_active_strand("neck_morph", g_neck) or (g_neck.active and not (not g_cran.active and g_neck.primary < 0.35)))
        )
        if not neck_enabled:
            disabled_parts.append("neck")
            trait_tags.append("Neckless")

        ear_enabled = (
            False
            if _knocked_out_strand("ear_form", g_ear)
            else (
                (_active_strand("ear_form", g_ear) and head_enabled)
                or (
                    head_enabled
                    and g_cran.active
                    and g_ear.active
                    and not (g_cran.primary < 0.10 and g_ear.primary < 0.25)
                )
            )
        )
        if not ear_enabled and humanity < 0.55:
            disabled_parts.append("ear")
            trait_tags.append("Earless")

        eye_enabled = (
            False
            if _knocked_out_strand("eye_dev", g_eye)
            else (
                (head_enabled and (_active_strand("eye_dev", g_eye) or _active_strand("iris_chrom", g_iris)))
                or (
                    head_enabled
                    and g_eye.active
                    and not (not g_cran.active and g_eye.primary < 0.50)
                    and not (g_cran.tertiary < 0.08 and g_eye.primary < 0.22)
                )
            )
        )
        if not eye_enabled:
            disabled_parts.append("eye")
            trait_tags.append("Eyeless")
        eye_lid = "closed" if not eye_enabled else "open"

        upper_jaw_enabled = head_enabled and (
            False
            if _knocked_out_strand("jaw_morph", g_jaw)
            else (_active_strand("jaw_morph", g_jaw) or _active_strand("teeth_dev", g_teeth) or g_jaw.active or g_jaw.primary > 0.28)
        )
        lower_jaw_enabled = head_enabled and (
            False
            if _knocked_out_strand("jaw_morph", g_jaw)
            else (_active_strand("jaw_morph", g_jaw) or _active_strand("teeth_dev", g_teeth) or g_jaw.active or g_jaw.secondary > 0.28)
        )
        if not upper_jaw_enabled:
            disabled_parts.append("upper_jaw")
        if not lower_jaw_enabled:
            disabled_parts.append("lower_jaw")
        if not upper_jaw_enabled and not lower_jaw_enabled and head_enabled:
            trait_tags.append("Jawless")

        lower_jaw_jointed = (
            lower_jaw_enabled
            and (
                ("GTAC" in g_jaw.shared_motifs and g_cran.secondary > 0.78)
                or (_active_strand("jaw_morph", g_jaw) and "GTAC" in g_jaw.any_motifs)
            )
        )
        if lower_jaw_jointed:
            trait_tags.append("Hinged-Jaw")

        teeth_enabled = (
            False
            if _knocked_out_strand("teeth_dev", g_teeth)
            else (
                (_active_strand("teeth_dev", g_teeth) and head_enabled and (upper_jaw_enabled or lower_jaw_enabled))
                or (
                    head_enabled
                    and g_cran.active
                    and g_teeth.active
                    and (upper_jaw_enabled or lower_jaw_enabled)
                )
            )
        )
        if teeth_enabled and not upper_teeth and not lower_teeth:
            teeth_enabled = False
        if not teeth_enabled and humanity < 0.55:
            disabled_parts.append("teeth")
            trait_tags.append("Toothless")

        nose_enabled = (
            False
            if _knocked_out_strand("nose_dev", g_nose)
            else ((_active_strand("nose_dev", g_nose) and head_enabled) or (head_enabled and g_nose.active and g_cran.active))
        )
        if not nose_enabled:
            disabled_parts.append("nose")
            trait_tags.append("Noseless")

        tail_enabled = (
            False
            if (_knocked_out_strand("tail_form", g_tail) or _knocked_out_strand("hox_caudal", g_caud))
            else (
                _active_strand("tail_form", g_tail)
                or _active_strand("hox_caudal", g_caud)
                or _active_strand("tail_pigment", g_tpig)
                or (
                    g_caud.active
                    and g_tail.active
                    and not (g_caud.primary < 0.10 and g_tail.primary < 0.25)
                )
            )
        )
        if not tail_enabled and humanity < 0.55:
            disabled_parts.append("tail")
            trait_tags.append("Tailless")
        elif tail_enabled and humanity >= 0.70:
            trait_tags.append("Tailed")

        # 4. Unified Pigmentation, Human Skin, Clothing & Patterns
        (
            coat_name,
            color_mutation,
            coat_col,
            back_leg_col,
            tail_col,
            hoof_f_col,
            hoof_b_col,
            nose_col,
            ear_override,
            head_override,
        ) = _resolve_coat_colors(
            g_pbase,
            g_pdil,
            g_tpig,
            g_cmut,
            g_iris,
            allow_het_exotic=_active_strand("color_mutator", g_cmut),
        )

        if color_mutation:
            trait_tags.append(color_mutation)

        skin_col = _resolve_human_skin_color(g_pbase, g_pdil)
        if color_mutation is not None:
            skin_col = _rgb_lerp(skin_col, coat_col, 0.76)
        skin_shadow = _rgb_shift(skin_col, -14, -18, -18)

        flesh_col = _rgb_lerp(coat_col, skin_col, humanity)
        flesh_back = _rgb_lerp(back_leg_col, skin_shadow, humanity)

        pat_style, pat_col, pat_density, pat_scale, pat_seed = _resolve_pattern(
            g_pat, g_pcol, coat_col, color_mutation
        )

        # Eye colors (work uniformly across horses, humans, hybrids, and exotic mutations)
        if color_mutation == "Albino":
            eye_sclera = (255, 240, 242)
            eye_pupil = (212, 68, 84) if g_iris.primary < 0.7 else (126, 178, 232)
        elif color_mutation == "Melanistic":
            eye_sclera = (232, 224, 206)
            eye_pupil = (224, 158, 38) if g_iris.primary > 0.5 else (32, 24, 28)
        elif color_mutation == "Erythristic":
            eye_sclera = (255, 246, 238)
            eye_pupil = (214, 118, 28) if g_iris.primary > 0.5 else (142, 32, 28)
        elif color_mutation == "Chlorophyll":
            eye_sclera = (248, 255, 246)
            eye_pupil = (64, 156, 86) if g_iris.primary > 0.45 else (210, 176, 48)
        elif color_mutation == "Aureate":
            eye_sclera = (255, 254, 242)
            eye_pupil = (128, 88, 208) if g_iris.primary > 0.5 else (54, 148, 212)
        elif color_mutation in ("Amethyst", "Axanthic Blue"):
            eye_sclera = (252, 252, 255)
            eye_pupil = (142, 94, 212) if color_mutation == "Amethyst" else (96, 186, 240)
        else:
            ip = g_iris.primary
            if ip < 0.42:
                eye_pupil = EYE_PUPIL_ANCHORS[0]
            elif ip < 0.65:
                eye_pupil = EYE_PUPIL_ANCHORS[1]
            elif ip < 0.80:
                eye_pupil = EYE_PUPIL_ANCHORS[2]
            elif ip < 0.92:
                eye_pupil = EYE_PUPIL_ANCHORS[3]
            else:
                eye_pupil = EYE_PUPIL_ANCHORS[4]
            eye_pupil = _rgb_shift(
                eye_pupil,
                (g_iris.secondary - 0.5) * 18,
                (g_iris.tertiary - 0.5) * 18,
                (g_iris.utr_val - 0.5) * 14,
            )
            eye_sclera = (255, 255, 255)

        cloth_weight = _clamp((humanity - 0.34) / 0.36, 0.0, 1.0)
        if cloth_weight > 0.02:
            shirt = _rgb_clamp(
                (40 + 200 * g_pcol.primary, 40 + 190 * g_pcol.secondary, 40 + 190 * g_pcol.tertiary)
            )
            bare_arms = humanity > 0.65 and g_tpig.utr_val > 0.64
            if bare_arms:
                sleeve = flesh_col
                sleeve_back = flesh_back
            else:
                sleeve = _rgb_clamp(
                    (34 + 196 * g_tpig.primary, 34 + 186 * g_tpig.secondary, 34 + 186 * g_tpig.tertiary)
                )
                sleeve_back = _rgb_shift(sleeve, -26, -22, -18)
            pants_f = _rgb_clamp(
                (36 + 98 * g_pbase.tertiary, 32 + 86 * g_pdil.secondary, 28 + 80 * g_pdil.tertiary)
            )
            pants_b = _rgb_shift(pants_f, -16, -14, -12)

            if color_mutation == "Chimera" and g_cmut.secondary > 0.5:
                shirt = _rgb_lerp(shirt, back_leg_col, 0.45)

            torso_color = _rgb_lerp(coat_col, shirt, cloth_weight)
            leg_front_color = _rgb_lerp(coat_col, pants_f, cloth_weight)
            leg_back_color = _rgb_lerp(back_leg_col, pants_b, cloth_weight)
            arm_front_color = _rgb_lerp(flesh_col, sleeve, cloth_weight)
            arm_back_color = _rgb_lerp(flesh_back, sleeve_back, cloth_weight)
            coat_col_out = torso_color
            back_leg_out = leg_back_color
        else:
            torso_color = None
            leg_front_color = None
            leg_back_color = None
            arm_front_color = coat_col if (arm_front_enabled or arm_back_enabled) else None
            arm_back_color = back_leg_col if (arm_front_enabled or arm_back_enabled) else None
            coat_col_out = coat_col
            back_leg_out = back_leg_col

        neck_color = _rgb_shift(flesh_col, -8, -10, -10) if humanity > 0.15 else None
        head_color = head_override if head_override is not None else (flesh_col if humanity > 0.15 else None)
        upper_jaw_color = flesh_col if humanity > 0.15 else None
        lower_jaw_color = _rgb_shift(flesh_col, -10, -12, -12) if humanity > 0.15 else None
        ear_color = ear_override if ear_override is not None else (flesh_col if humanity > 0.15 else None)
        if lagomorph > 0.0:
            src = ear_color if ear_color is not None else coat_col
            target = (
                src[0] * 0.22 + 216 * 0.78,
                src[1] * 0.22 + 210 * 0.78,
                src[2] * 0.22 + 204 * 0.78,
            )
            ear_color = tuple(int(src[i] + (target[i] - src[i]) * lagomorph) for i in range(3))
        nose_col = _rgb_lerp(nose_col, _rgb_shift(flesh_col, -16, -24, -22), humanity)
        hand_color = flesh_col
        hand_back_color = flesh_back

        if humanity >= 0.78:
            coat_name = f"{color_mutation} Human" if color_mutation else "Human"
        elif humanity >= 0.22:
            coat_name = f"Hybrid {coat_name}"

        # Keep coat/shirt patterns when inherited or non-flat
        if humanity > 0.76 and pat_style != "flat" and color_mutation is None and g_pat.primary < 0.60:
            pat_style = "flat"

        # 5. One torso equation. erectness 0 is the horse body, 1 is the rancher body.
        quad_tw = _lerp(180.0, 134.0, humanity) * overall * _lerp(0.90, 1.12, g_tlen.primary)
        quad_th = _lerp(80.0, 72.0, humanity) * overall * stocky * _lerp(0.88, 1.12, g_tdep.primary)
        up_tw = _lerp(74.0, 34.0, humanity) * overall * stocky * _lerp(0.84, 1.18, g_tdep.primary)
        up_th = _lerp(162.0, 66.0, humanity) * overall * _lerp(0.86, 1.16, g_tlen.primary)
        tw = _lerp(quad_tw, up_tw, erectness)
        th = _lerp(quad_th, up_th, erectness)
        tw *= _lerp(1.0, 1.06, lagomorph)
        th *= _lerp(1.0, 0.82, lagomorph)

        contour_seed_bytes = hashlib.blake2b(
            (g_contour.readout_a.seq + g_contour.readout_b.seq).encode("ascii"),
            digest_size=4,
        ).digest()
        contour_seed = int.from_bytes(contour_seed_bytes, "big")
        if not g_contour.active or g_contour.primary < 0.38:
            torso_style = "default"
        elif g_contour.primary < 0.58:
            torso_style = "rounded"
        elif g_contour.primary < 0.78:
            torso_style = "tapered"
            trait_tags.append("Tapered")
        else:
            torso_style = "blob"
            trait_tags.append("Blob")

        # Neck morphology
        neck_len_mult = _lerp(0.82, 1.22, g_neck.primary) * (1.0 + 0.08 * (g_sym.secondary - 0.5))
        if "GGGG" in g_neck.shared_motifs and g_neck.primary > 0.78:
            neck_len_mult *= 1.24
            trait_tags.append("Long-Neck")
        nw = _lerp(20.0, 11.0, humanity) * overall * stocky * _lerp(0.84, 1.20, g_neck.secondary)
        base_nh = _lerp(_lerp(80.0, 40.0, humanity), _lerp(64.0, 20.0, humanity), erectness)
        nh = base_nh * overall * neck_len_mult
        neck_anchor = _mix2(
            (-2.0 * overall, 5.0 * overall),
            (
                _lerp(-6.0 * overall, -(tw - nw) * 0.5, humanity),
                _lerp(6.0, 1.0, humanity) * overall,
            ),
            erectness,
        )
        neck_rest_deg = _lerp(
            _lerp(7.0, 24.0, g_neck.tertiary),
            _lerp(_lerp(-2.0, 12.0, g_neck.tertiary), _lerp(-6.0, 6.0, g_neck.tertiary), humanity),
            erectness,
        )
        neck_rest_deg += _lerp(0.0, 14.0, lagomorph)
        nh *= _lerp(1.0, 0.50, lagomorph)
        neck_min_deg = _lerp(-15.0, _lerp(-15.0, -16.0, humanity), erectness)
        neck_max_deg = _lerp(32.0, _lerp(32.0, 16.0, humanity), erectness)
        neck_max_deg += _lerp(0.0, 16.0, lagomorph)

        # Head & cranial morphology
        juv_head_mult = 1.16 if is_juvenile else 1.0
        hw = _lerp(60.0, 26.0, humanity) * overall * _lerp(0.86, 1.16, g_head.primary) * juv_head_mult
        hh = _lerp(35.0, 28.0, humanity) * overall * _lerp(0.86, 1.16, g_head.secondary) * juv_head_mult
        if abs(g_sent.secondary - 0.5) >= 0.04:
            head_bulk = _lerp(0.72, 1.35, g_sent.secondary) / _lerp(0.72, 1.35, 0.5)
            hw *= head_bulk
            hh *= head_bulk
        if abs(g_sent.tertiary - 0.5) >= 0.04:
            hw *= _lerp(0.78, 1.26, g_sent.tertiary) / _lerp(0.78, 1.26, 0.5)
            hh *= _lerp(1.26, 0.78, g_sent.tertiary) / _lerp(1.26, 0.78, 0.5)
        head_ratio_w = hw / _lerp(60.0, 26.0, humanity)
        head_ratio_h = hh / _lerp(35.0, 28.0, humanity)
        head_rest_deg = _lerp(
            _lerp(-34.0, -14.0, g_head.tertiary),
            _lerp(-18.0, 4.0, g_head.tertiary),
            erectness,
        )
        head_min_deg = _lerp(-40.0, -26.0, erectness)
        head_max_deg = _lerp(25.0, 20.0, erectness)

        jaw_w_mod = _lerp(0.84, 1.20, g_jaw.primary)
        jaw_h_mod = _lerp(0.84, 1.18, g_jaw.secondary)
        ujw = _lerp(27.0 * head_ratio_w, 6.2 * overall, humanity) * jaw_w_mod
        ujh = _lerp(12.0 * head_ratio_h, 7.0 * overall, humanity) * jaw_h_mod
        ljw = _lerp(25.0 * head_ratio_w, 5.2 * overall, humanity) * jaw_w_mod
        ljh = _lerp(11.0 * head_ratio_h, 7.0 * overall, humanity) * jaw_h_mod

        teeth_shrink = _lerp(1.0, 0.25, lagomorph)
        teeth_size = (
            _lerp(11.0 * head_ratio_w, 8.0 * overall, humanity) * _lerp(0.75, 1.32, g_teeth.primary) * teeth_shrink,
            _lerp(2.2 * head_ratio_h, 3.0 * overall, humanity) * _lerp(0.75, 1.45, g_teeth.secondary) * teeth_shrink,
        )
        nose_size = (
            _lerp(5.0 * head_ratio_w, 4.2 * overall, humanity) * _lerp(0.75, 1.40, g_nose.primary),
            _lerp(5.5 * head_ratio_h, 4.0 * overall, humanity) * _lerp(0.75, 1.40, g_nose.secondary),
        )

        # Ears (continuous scale, nuanced for humans & hybrids)
        ear_human_scale = _lerp(1.0, 0.56, _clamp((humanity - 0.55) / 0.45, 0.0, 1.0))
        ear_w = 14.0 * app_scale * ear_human_scale * _lerp(0.80, 1.28, g_ear.secondary)
        ear_h = 22.0 * app_scale * ear_human_scale * _lerp(0.72, 1.36, g_ear.primary)
        if "GGGG" in g_ear.shared_motifs and g_ear.primary > 0.75:
            ear_h *= 1.38
            trait_tags.append("Long-Ears")
        ear_w *= _lerp(1.0, 1.55, lagomorph)
        ear_h *= _lerp(1.0, 3.6, lagomorph)
        ear_size = (ear_w, ear_h)
        ear_styles = ("pointed", "curved", "rounded")
        ear_style = ear_styles[(int(g_ear.tertiary * 3.0) + g_cran.utr_code) % 3]
        ear_tip = _lerp(0.18, 0.58, g_ear.utr_val)

        # Legs (continuous lengths, thickness, knee flexion, and anchor spacing)
        sym_bias = (g_sym.primary - 0.5) * 0.14 * (1.0 - 0.7 * humanity)
        if _active_strand("symmetry_mod", g_sym) and ("ACGT" in g_sym.any_motifs or g_sym.dosage > 1.05):
            sym_bias *= 1.65
        base_leg_raw = _lerp(92.0, 60.0, humanity)
        leg_avg_gene = _lerp(0.88, 1.14, 0.5 * (g_fore.primary + g_hind.primary))
        base_leg_len = base_leg_raw * overall * leg_avg_gene
        fore_strand_mod = (
            (_clamp(0.94 + 0.12 * g_fore.dosage, 0.90, 1.12) * (0.94 if "CCCC" in g_fore.any_motifs else 1.0))
            if _active_strand("limb_fore", g_fore)
            else 1.0
        )
        hind_strand_mod = (
            (_clamp(0.94 + 0.12 * g_hind.dosage, 0.90, 1.12) * (0.94 if "CCCC" in g_hind.any_motifs else 1.0))
            if _active_strand("limb_hind", g_hind)
            else 1.0
        )
        flh = base_leg_len * _lerp(0.96, 1.04, g_fore.primary) * (1.0 + sym_bias) * fore_strand_mod
        blh = base_leg_len * _lerp(0.96, 1.04, g_hind.primary) * (1.0 - sym_bias) * hind_strand_mod
        flw = _lerp(13.0, 12.0, humanity) * overall * stocky * _lerp(0.86, 1.18, g_fore.secondary)
        blw = _lerp(15.0, 12.0, humanity) * overall * stocky * _lerp(0.86, 1.18, g_hind.secondary)
        flh *= _lerp(1.0, 0.90, lagomorph)
        blh *= _lerp(1.0, 0.68, lagomorph)
        flw *= _lerp(1.0, 1.28, lagomorph)
        blw *= _lerp(1.0, 1.42, lagomorph)

        front_anchor = _mix2(
            (4.0 * overall, 0.0),
            (_lerp(-6.0 * overall, 0.0, humanity), 0.0),
            erectness,
        )
        back_anchor = _mix2(
            (0.0, 0.0),
            (_lerp(6.0 * overall, 0.0, humanity), 0.0),
            erectness,
        )
        # A centaur keeps the horizontal body and slides the forelegs back
        # so the new arms own the shoulder.
        shoulder_clear = centaur * (1.0 + _channel_bias(g_axial, g_axial.tertiary))
        front_anchor = (front_anchor[0] - shoulder_clear * 9.0 * overall, front_anchor[1])
        leg_front_rest = _lerp(0.0, _lerp(0.0, -2.0, humanity), erectness)
        leg_front_rest += _lerp(0.0, -38.0, lagomorph)
        leg_back_rest = _lerp(4.0, _lerp(4.0, 2.0, humanity), erectness)

        knee_damp_hum = 1.0 - 0.72 * humanity
        knee_damp_hop = _lerp(1.0, 0.0, lagomorph)
        front_knee_deg = _lerp(-15.0, 15.0, g_fore.tertiary) * knee_damp_hum * knee_damp_hop
        back_knee_deg = _lerp(-15.0, 15.0, g_hind.tertiary) * knee_damp_hum * knee_damp_hop
        front_knee_ratio = _lerp(0.45, 0.57, g_fore.utr_val)
        back_knee_ratio = _lerp(0.43, 0.56, g_hind.utr_val)
        front_lower_scale = _lerp(
            _lerp(0.76, 0.94, (g_fore.secondary + g_bone.primary) * 0.5),
            _lerp(0.82, 0.96, g_fore.secondary),
            humanity,
        )
        back_lower_scale = _lerp(
            _lerp(0.75, 0.93, (g_hind.secondary + g_bone.primary) * 0.5),
            _lerp(0.82, 0.96, g_hind.secondary),
            humanity,
        )

        mlw = 0.5 * (flw + blw) * _lerp(0.84, 1.14, g_lextra.secondary)
        mlh = 0.5 * (flh + blh) * _lerp(0.92, 1.06, g_lextra.primary)
        mid_anchor = (_lerp(-3.0, 3.0, g_lextra.utr_val) * overall, 0.0)
        mid_knee_deg = _lerp(-12.0, 12.0, g_lextra.tertiary) * knee_damp_hum
        mid_knee_ratio = 0.5 * (front_knee_ratio + back_knee_ratio)
        mid_lower_scale = 0.5 * (front_lower_scale + back_lower_scale)
        leg_mid_rest = 0.0

        # Arms & Hands (continuous sizes, elbow bends, varied poses)
        arm_dosage_len = _clamp(0.90 + 0.22 * g_arm.dosage, 0.85, 1.24) if _active_strand("arm_dev", g_arm) else 1.0
        arm_dosage_w = _clamp(0.92 + 0.16 * g_arm.dosage, 0.88, 1.18) if _active_strand("arm_dev", g_arm) else 1.0
        arm_len_base = _lerp(48.0, _lerp(52.0, 48.0, humanity), erectness)
        arm_len = arm_len_base * (1.0 + 0.34 * centaur) * overall * _lerp(0.82, 1.18, g_arm.primary) * arm_dosage_len
        arm_w = _lerp(11.0, 10.5, humanity) * overall * stocky * _lerp(0.82, 1.18, g_arm.secondary) * arm_dosage_w
        af_size = (arm_w, arm_len * (1.0 if not arm_front_enabled else _lerp(0.72, 1.0, front_w)))
        ab_size = (arm_w, arm_len * (1.0 if not arm_back_enabled else _lerp(0.72, 1.0, back_w)))
        shoulder_y = _lerp(th * 0.16, 6.0 * overall, humanity)
        af_anchor = _mix2(
            (tw * 0.25, 4.0 * overall),
            (_lerp(tw * 0.36 - 4.0, tw * 0.46 - 6.0, humanity), shoulder_y),
            erectness,
        )
        ab_anchor = _mix2(
            (tw * 0.17, 6.0 * overall),
            (_lerp(-tw * 0.36 + 4.0, -tw * 0.46 + 6.0, humanity), shoulder_y),
            erectness,
        )
        max_arm_spread = _lerp(128.0, 84.0, humanity)
        af_rest = _lerp(
            _lerp(10.0, 26.0, g_arm.utr_val),
            -_lerp(20.0, max_arm_spread, g_arm.tertiary),
            pose,
        )
        ab_rest = _lerp(
            -_lerp(10.0, 26.0, g_arm.utr_val),
            _lerp(18.0, max_arm_spread, g_arm.utr_val),
            pose,
        )
        af_knee = _lerp(-12.0, 12.0, g_arm.secondary) * (1.0 + 0.35 * centaur)
        ab_knee = _lerp(-12.0, 12.0, g_arm.utr_val) * (1.0 + 0.35 * centaur)

        hand_enabled = (arm_front_enabled or arm_back_enabled) and (
            max(grasp, erectness, humanity) > 0.30
            or (_active_strand("arm_dev", g_arm) and "GTAC" in g_arm.any_motifs)
        )
        hand_span = 1.0 + 0.18 * centaur
        hand_size = (
            _lerp(10.0, 12.0, humanity) * overall * _lerp(0.85, 1.18, g_arm.secondary) * hand_span,
            _lerp(9.0, 10.5, humanity) * overall * _lerp(0.85, 1.15, g_arm.primary) * hand_span,
        )

        # Hooves & Tail
        hoof_w = max(blw + 2.0, 19.0 * app_scale * _lerp(0.86, 1.24, g_hoof.primary))
        hoof_h = 11.0 * app_scale * _lerp(0.82, 1.22, g_hoof.secondary)
        hoof_w *= _lerp(1.0, 2.4, lagomorph) * _lerp(1.0, 0.45, humanity)
        hoof_h *= _lerp(1.0, 1.4, lagomorph) * _lerp(1.0, 0.55, humanity)
        hoof_size = (hoof_w, hoof_h)

        tail_w = 60.0 * app_scale * _lerp(0.72, 1.32, g_tail.primary)
        tail_h = 9.0 * app_scale * _lerp(0.78, 1.72, g_tail.secondary)
        tail_w *= _lerp(1.0, 0.55, lagomorph)
        tail_h *= _lerp(1.0, 1.7, lagomorph)
        tail_styles = ("tapered", "bushy", "sleek", "flowing")
        tail_style = tail_styles[(int(g_tail.tertiary * 4.0) + g_caud.utr_code) % 4]
        tail_size = (tail_w, tail_h)
        tail_rest_deg = _lerp(-70.0, -38.0, g_tail.utr_val)
        tail_anchor_offset = (0.0, th * 0.72 * erectness)

        # Eyes sit large and forward on the head. 0.5 on the sentience UTR is this default.
        eye_place = 0.5 if abs(g_sent.utr_val - 0.5) < 0.06 else g_sent.utr_val
        eye_forward = _lerp(0.16, 0.40, eye_place)
        eye_offset = (
            hw * eye_forward,
            -hh * _lerp(0.12, 0.08, humanity),
        )
        # Horses keep the large forward eye. Ranchers and rabbits scale down
        # with the head, but only partway, so the eye still reads on the face.
        eye_radius = (
            max(3.0, _lerp(6.4, 5.6, humanity) * overall * _lerp(0.86, 1.16, g_eye.primary))
            * _lerp(1.0, 0.68, humanity)
            * _lerp(1.0, 1.28, lagomorph)
        )
        eye_pupil_offset = (
            eye_radius * 0.22,
            0.0,
        )
        eye_pupil_radius = eye_radius * _lerp(0.66, 0.60, humanity) * _lerp(0.86, 1.12, g_eye.secondary)

        # 5b. Hoof Shapes & Springy Hooves
        if hoof_enabled:
            hoof_styles = ("standard", "thick", "thin", "cloven", "rocker", "pointed")
            hoof_idx = int(g_hoof.tertiary * 6.0) % 6
            hoof_style = hoof_styles[hoof_idx]
            if hoof_style == "thick":
                hoof_size = (hoof_size[0] * 1.26, hoof_size[1] * 1.34)
                trait_tags.append("Thick-Hooves")
            elif hoof_style == "thin":
                hoof_size = (max(blw, hoof_size[0] * 0.72), hoof_size[1] * 1.15)
                trait_tags.append("Thin-Hooves")
            elif hoof_style in ("cloven", "rocker", "pointed"):
                trait_tags.append(f"{hoof_style.title()}-Hooves")

            springy_on = (
                (
                    "ATG" in (g_hoof.readout_a.seq[:3], g_hoof.readout_b.seq[:3])
                    and "GTAC" in g_hoof.any_motifs
                )
                or (_active_strand("hoof_dev", g_hoof) and "GTAC" in g_hoof.any_motifs)
                or ("GTAC" in g_hoof.shared_motifs and "CGCG" in g_hoof.any_motifs)
                or (g_hoof.utr_val > 0.92 and g_pow.primary > 0.72)
            )
            if springy_on:
                hoof_spring_bounce = _lerp(0.55, 0.95, g_hoof.utr_val)
                hoof_elasticity = 0.85
                trait_tags.append("Springy-Hooves")
            else:
                hoof_spring_bounce = 0.0
                hoof_elasticity = 0.05
        else:
            hoof_style = "standard"
            hoof_spring_bounce = 0.0
            hoof_elasticity = 0.0

        # 5c. Wings (unified across quadrupeds, hybrids, and humans!)
        wing_on = (
            False
            if _knocked_out_strand("wing_dev", g_wing)
            else (
                _active_strand("wing_dev", g_wing)
                or (_active_strand("wing_chrom", g_wchrom) and g_wing.active)
                or (
                    g_wing.active
                    and (
                        (
                            "ATG" in (g_wing.readout_a.seq[:3], g_wing.readout_b.seq[:3])
                            and "GGGG" in g_wing.any_motifs
                        )
                        or (
                            g_wing.readout_a.seq[:3] == "ATG"
                            and g_wing.readout_b.seq[:3] == "ATG"
                        )
                        or g_wing.primary > 0.94
                    )
                )
            )
        )
        if wing_on:
            wing_styles = ("feathery", "leathery", "swept", "rounded")
            wing_style = wing_styles[(int(g_wing.primary * 10.0) + g_wing.utr_code) % 4]
            wing_dosage_scale = _clamp(0.88 + 0.20 * g_wing.dosage, 0.82, 1.22) if "wing_dev" in strand_set else 1.0
            wing_span = _lerp(60.0, 122.0, g_wing.secondary) * app_scale * wing_dosage_scale
            wing_chord = _lerp(24.0, 48.0, g_wing.tertiary) * app_scale * (0.95 + 0.08 * wing_dosage_scale)
            if wing_style == "leathery":
                base_wcol = _rgb_lerp(coat_col_out, (52, 42, 58), 0.55)
                wing_color = _rgb_shift(
                    base_wcol,
                    (g_wchrom.primary - 0.5) * 85,
                    (g_wchrom.secondary - 0.5) * 65,
                    (g_wchrom.tertiary - 0.5) * 85,
                )
                wing_sec_color = _rgb_shift(wing_color, -28, -24, -22)
            else:
                if g_wchrom.primary > 0.68:
                    wing_color = _rgb_shift(
                        (244, 240, 232),
                        0,
                        (g_wchrom.secondary - 0.5) * 20,
                        (g_wchrom.tertiary - 0.5) * 25,
                    )
                elif g_wchrom.primary < 0.25:
                    wing_color = _rgb_shift(
                        (42, 40, 48),
                        (g_wchrom.secondary - 0.5) * 25,
                        0,
                        (g_wchrom.tertiary - 0.5) * 25,
                    )
                else:
                    wing_color = _rgb_lerp(coat_col_out, tail_col, g_wchrom.secondary)
                    wing_color = _rgb_shift(
                        wing_color,
                        (g_wchrom.secondary - 0.5) * 70,
                        (g_wchrom.tertiary - 0.5) * 70,
                        (g_wchrom.utr_val - 0.5) * 70,
                    )
                wing_sec_color = _rgb_lerp(wing_color, tail_col, 0.38)
            area_ratio = (wing_span * wing_chord) / max(1.0, 82.0 * 32.0 * app_scale * app_scale)
            wing_lift = _clamp((0.75 + 0.45 * area_ratio + 0.20 * g_wing.utr_val) * wing_dosage_scale, 0.55, 1.48)
            wing_flap_freq = _lerp(2.6, 4.4, 1.0 - 0.5 * g_wing.secondary)
            wing_drag = _lerp(0.16, 0.34, area_ratio * 0.7)
            trait_tags.append(f"{wing_style.title()}-Wings")
        else:
            wing_style = "feathery"
            wing_span = 0.0
            wing_chord = 0.0
            wing_color = coat_col_out
            wing_sec_color = tail_col
            wing_lift = 0.0
            wing_flap_freq = 3.0
            wing_drag = 0.0

        # 5d. Horns & Antlers (unified across quadrupeds, hybrids, and humans!)
        horn_on = head_enabled and (
            False
            if _knocked_out_strand("horn_dev", g_horn)
            else (
                _active_strand("horn_dev", g_horn)
                or (
                    g_horn.active
                    and (
                        (
                            "ATG" in (g_horn.readout_a.seq[:3], g_horn.readout_b.seq[:3])
                            and "ATAC" in g_horn.any_motifs
                        )
                        or (
                            g_horn.readout_a.seq[:3] == "ATG"
                            and g_horn.readout_b.seq[:3] == "ATG"
                        )
                        or g_horn.primary > 0.94
                    )
                )
            )
        )
        if horn_on:
            horn_kinds = ("pointed", "dull", "curved", "straight", "small_antlers", "branching_antlers")
            horn_kind = horn_kinds[(int(g_horn.primary * 12.0) + g_horn.utr_code) % 6]
            horn_dosage_scale = _clamp(0.86 + 0.22 * g_horn.dosage, 0.80, 1.25) if "horn_dev" in strand_set else 1.0
            is_antler = horn_kind in ("small_antlers", "branching_antlers")
            if horn_kind == "small_antlers":
                horn_length = _lerp(22.0, 34.0, g_horn.secondary) * app_scale * horn_dosage_scale
                horn_thickness = _lerp(3.5, 5.2, g_horn.tertiary) * app_scale * (0.95 + 0.06 * horn_dosage_scale)
                horn_tines = 2 if g_horn.utr_val < 0.5 else 3
                trait_tags.append("Small-Antlers")
            elif horn_kind == "branching_antlers":
                horn_length = _lerp(42.0, 68.0, g_horn.secondary) * app_scale * horn_dosage_scale
                horn_thickness = _lerp(4.8, 7.5, g_horn.tertiary) * app_scale * (0.95 + 0.06 * horn_dosage_scale)
                horn_tines = 4 + (g_horn.utr_code % 4)
                trait_tags.append("Tall-Antlers")
            else:
                horn_length = _lerp(22.0, 52.0, g_horn.secondary) * app_scale * horn_dosage_scale
                horn_thickness = _lerp(4.5, 9.5, g_horn.tertiary) * app_scale * (0.95 + 0.06 * horn_dosage_scale)
                horn_tines = 0
                trait_tags.append(f"{horn_kind.title()}-Horn")
            horn_curve = _lerp(-0.9, 0.9, g_horn.utr_val) if horn_kind == "curved" else 0.0
            horn_spread = _lerp(0.35, 0.95, g_horn.utr_val)
            if is_antler:
                horn_color = _rgb_shift(
                    (186, 152, 112),
                    (g_horn.tertiary - 0.5) * 28,
                    (g_horn.secondary - 0.5) * 20,
                    0,
                )
                horn_tip_color = _rgb_shift((234, 224, 198), 0, 0, 0)
            else:
                horn_color = _rgb_lerp((226, 214, 188), (68, 60, 56), g_horn.tertiary * 0.75)
                horn_tip_color = _rgb_shift(horn_color, -45, -45, -40)
            horn_seed_bytes = hashlib.blake2b(
                (g_horn.readout_a.seq + g_horn.readout_b.seq + g_cran.readout_a.seq).encode("ascii"),
                digest_size=4,
            ).digest()
            horn_seed = int.from_bytes(horn_seed_bytes, "big")
        else:
            horn_kind = "none"
            horn_length = 0.0
            horn_thickness = 0.0
            horn_curve = 0.0
            horn_tines = 0
            horn_spread = 0.5
            horn_color = (218, 206, 182)
            horn_tip_color = (86, 72, 62)
            horn_seed = 0

        crest_on = (
            False
            if _knocked_out_strand("crest_dev", g_crest)
            else (
                _active_strand("crest_dev", g_crest)
                or (
                    g_crest.active
                    and (
                        (
                            "ATG" in (g_crest.readout_a.seq[:3], g_crest.readout_b.seq[:3])
                            and "GGGG" in g_crest.any_motifs
                        )
                        or (
                            g_crest.readout_a.seq[:3] == "ATG"
                            and g_crest.readout_b.seq[:3] == "ATG"
                        )
                        or g_crest.primary > 0.92
                    )
                )
            )
        )
        if crest_on:
            cp = g_crest.primary
            if cp < 0.32:
                crest_style = "tuft"
                trait_tags.append("Tuft-Crest")
            elif cp < 0.64:
                crest_style = "crown_pom"
                trait_tags.append("Pom-Crown")
            elif cp < 0.84:
                crest_style = "mane_plume"
                trait_tags.append("Plume-Crest")
            else:
                crest_style = "spores"
                trait_tags.append("Spore-Crest")

            crest_dosage = _clamp(0.88 + 0.22 * g_crest.dosage, 0.82, 1.25) if "crest_dev" in strand_set else 1.0
            crest_size = _lerp(14.0, 38.0, g_crest.secondary) * app_scale * crest_dosage
            crest_spread = _lerp(0.35, 1.05, g_crest.tertiary)
            crest_count = 2 + int(g_crest.tertiary * 4.0)
            crest_has_poms = (g_crest.utr_val > 0.55) or ("GGGG" in g_crest.any_motifs)
            crest_branches = (crest_style == "crown_pom") and (g_crest.secondary > 0.62 or "ATAC" in g_crest.any_motifs)
            crest_color = _chroma_rgb(g_wchrom.primary, g_wchrom.secondary, g_wchrom.tertiary)
            crest_tip_color = _chroma_rgb(g_pcol.primary, g_pcol.secondary, g_pcol.tertiary)
            crest_seed_bytes = hashlib.blake2b(
                (g_crest.readout_a.seq + g_crest.readout_b.seq).encode("ascii"),
                digest_size=4,
            ).digest()
            crest_seed = int.from_bytes(crest_seed_bytes, "big")
        else:
            crest_style = "tuft"
            crest_size = 0.0
            crest_spread = 0.5
            crest_count = 3
            crest_color = (72, 168, 74)
            crest_tip_color = (224, 56, 68)
            crest_has_poms = False
            crest_branches = False
            crest_seed = 0

        # 6. Unified Joint Stiffness, Behavior & Gait Physics
        joint_stiffness_scale = rot_scale * _lerp(0.88, 1.15, g_bone.primary)
        joint_damping_scale = rot_scale * _lerp(0.88, 1.15, g_bone.secondary)

        leg_stiff_base = _lerp(1500000.0, 1200000.0, humanity)
        leg_front_stiff = leg_stiff_base * joint_stiffness_scale
        leg_back_stiff = leg_stiff_base * joint_stiffness_scale
        leg_mid_stiff = leg_stiff_base * joint_stiffness_scale
        leg_damp = 25000.0 * joint_damping_scale

        if not g_neuro.active:
            neuro_trait = "narcoleptic"
        else:
            np = g_neuro.primary
            if np < 0.22:
                neuro_trait = "narcoleptic"
            elif np < 0.40:
                neuro_trait = "bolter"
            elif np < 0.54:
                neuro_trait = "stubborn"
            elif np < 0.68:
                neuro_trait = "prancer"
            else:
                neuro_trait = "steady"
        if neuro_trait != "steady":
            trait_tags.append(neuro_trait.title())

        if not g_meta.active:
            metabolic_trait = "sedate"
        else:
            mp = g_meta.primary
            if mp < 0.24:
                metabolic_trait = "sedate"
            elif mp < 0.44:
                metabolic_trait = "front_runner"
            elif mp < 0.72:
                metabolic_trait = "balanced"
            elif mp < 0.86:
                metabolic_trait = "second_wind"
            else:
                metabolic_trait = "fiery"
        if metabolic_trait != "balanced":
            trait_tags.append(metabolic_trait.replace("_", "-").title())

        if not g_sense.active:
            reflex_trait = "focused"
        else:
            sp_val = g_sense.primary
            if sp_val < 0.26:
                reflex_trait = "skittish"
            elif sp_val < 0.54:
                reflex_trait = "focused"
            elif sp_val < 0.78:
                reflex_trait = "competitive"
            else:
                reflex_trait = "sure_footed"
        if reflex_trait != "focused":
            trait_tags.append(reflex_trait.replace("_", "-").title())

        if neuro_trait == "narcoleptic":
            neck_rest_deg -= 5.0
            head_rest_deg -= 4.0
        elif neuro_trait == "prancer":
            neck_rest_deg += 6.0
            tail_rest_deg += 12.0
        elif neuro_trait == "bolter":
            eye_radius *= 1.12
            eye_pupil_radius *= 0.85
        elif neuro_trait == "stubborn":
            nw *= 1.12

        if metabolic_trait == "second_wind":
            th *= 1.07
        elif metabolic_trait == "fiery":
            nose_col = _rgb_shift(nose_col, 42, -8, -10)
            tail_rest_deg += 10.0

        if reflex_trait == "sure_footed" and hoof_enabled:
            hoof_size = (hoof_size[0] * 1.12, hoof_size[1] * 1.08)

        if not g_beh.active:
            behavior = "gallop"
        else:
            bp = g_beh.primary
            # Humanoids keep a two-beat pace. Animal bipeds use the full gait set.
            if erectness >= 0.5 and humanity > 0.55:
                behavior = "gallop" if bp < 0.72 else "trot"
            elif bp < 0.44:
                behavior = "gallop"
            elif bp < 0.62:
                behavior = "trot"
            elif bp < 0.77:
                behavior = "bound"
            elif bp < 0.90:
                behavior = "pace"
            else:
                behavior = "pronk"
            if behavior != "gallop":
                trait_tags.append(behavior.title())

        cad_strand_mult = (
            (0.82 if not g_cad.active else _clamp(0.95 + 0.08 * g_cad.dosage, 0.92, 1.12))
            if "gait_cadence" in strand_set
            else 1.0
        )
        pow_strand_mult = (
            (0.82 if not g_pow.active else _clamp(0.95 + 0.08 * g_pow.dosage, 0.92, 1.12))
            if "gait_power" in strand_set
            else 1.0
        )
        bal_strand_mult = (
            (0.65 if not g_bal.active else _clamp(0.92 + 0.14 * g_bal.dosage, 0.88, 1.20))
            if "balance_core" in strand_set
            else 1.0
        )

        avg_leg_factor = ((flh if leg_front_enabled else 60.0) + (blh if leg_back_enabled else 60.0)) / 184.0
        walk_freq = (_lerp(0.80, 1.34, g_cad.primary) / (overall**0.20)) * cad_strand_mult
        gait_weight = 1.0 - _rise(humanity, 0.64, 0.80)
        stride_scale = 0.72 + 0.28 * gait_weight
        stride_deg = _lerp(9.5, 15.8, g_cad.secondary) * (0.96 + 0.04 * cad_strand_mult) * stride_scale
        run_freq = _lerp(1.62, 2.02, g_cad.tertiary) * cad_strand_mult
        run_stride_deg = _lerp(20.5, 25.5, g_pow.secondary) * (0.94 + 0.06 * pow_strand_mult) * stride_scale
        run_target_speed = (
            _lerp(290.0, 360.0, g_pow.primary)
            * math.sqrt(overall)
            * _clamp(0.75 + 0.25 * avg_leg_factor, 0.70, 1.15)
            * pow_strand_mult
            * _lerp(1.0, 0.62, lagomorph)
        )
        run_phase_offset_deg = _lerp(114.0, 136.0, g_pow.tertiary)
        tail_sway_deg = _lerp(3.5, 9.0, g_bal.tertiary)

        upright_bal_boost = _lerp(1.0, 1.0 + 0.85 * (1.0 - humanity), erectness)
        bal_mod = _lerp(0.86, 1.18, g_bal.primary) * upright_bal_boost * bal_strand_mult
        balance_stiffness = 550000.0 * rot_scale * bal_mod * (1.35 if neuro_trait == "stubborn" else 1.0)
        low_human = 1.0 - _rise(humanity, 0.42, 0.58)
        balance_damping = 55000.0 * rot_scale * _lerp(0.86, 1.18, g_bal.secondary) * _lerp(1.0, _lerp(1.0, 1.5, low_human), erectness)
        balance_max_torque = 320000.0 * rot_scale * bal_mod * (1.35 if neuro_trait == "stubborn" else 1.0)

        hoof_friction = _lerp(0.85, 1.12, g_pow.utr_val) if hoof_enabled else 0.75

        if lethal_white:
            coat_name = "White"
            coat_col = (242, 242, 236)
            coat_col_out = coat_col
            back_leg_out = (232, 232, 226)
            tail_col = (236, 236, 230)
            pat_style = "flat"
            eye_lid = "cross"
            eye_enabled = True

        base_desc = coat_name if pat_style == "flat" else f"{coat_name} ({pat_style})"
        if trait_tags:
            label = f"{base_desc} [{', '.join(trait_tags[:3])}]"
        else:
            label = base_desc

        return Phenotype(
            label=label,
            coat_name=coat_name,
            posture=posture,
            trait_tags=tuple(trait_tags),
            disabled_parts=tuple(disabled_parts),
            color_mutation=color_mutation,
            overall_scale=overall,
            stocky=stocky,
            mass_scale=mass_scale,
            torso_style=torso_style,
            contour_seed=contour_seed,
            torso_size=(tw, th),
            torso_mass=_lerp(24.0, 14.0, humanity) * mass_scale,
            torso_color=torso_color,
            neck_enabled=neck_enabled,
            neck_size=(nw, nh),
            neck_mass=_lerp(1.6, 0.5, humanity) * mass_scale,
            neck_anchor_offset=neck_anchor,
            neck_rest_deg=neck_rest_deg,
            neck_min_deg=neck_min_deg,
            neck_max_deg=neck_max_deg,
            neck_color=neck_color,
            head_enabled=head_enabled,
            head_size=(hw, hh),
            head_mass=_lerp(0.55, 0.50, humanity) * mass_scale,
            head_rest_deg=head_rest_deg,
            head_min_deg=head_min_deg,
            head_max_deg=head_max_deg,
            head_color=head_color,
            upper_jaw_enabled=upper_jaw_enabled,
            upper_jaw_size=(ujw, ujh),
            upper_jaw_mass=_lerp(0.20, 0.06, humanity) * mass_scale,
            upper_jaw_color=upper_jaw_color,
            lower_jaw_enabled=lower_jaw_enabled,
            lower_jaw_size=(ljw, ljh),
            lower_jaw_mass=_lerp(0.12, 0.04, humanity) * mass_scale,
            lower_jaw_jointed=lower_jaw_jointed,
            lower_jaw_color=lower_jaw_color,
            ear_enabled=ear_enabled,
            ear_size=ear_size,
            ear_mass=0.04 * mass_scale,
            ear_style=ear_style,
            ear_tip_offset=ear_tip,
            ear_color=ear_color,
            teeth_enabled=teeth_enabled,
            teeth_size=teeth_size,
            teeth_mass=0.002 * mass_scale,
            teeth_color=None,
            nose_enabled=nose_enabled,
            nose_size=nose_size,
            nose_mass=0.002 * mass_scale,
            nose_color=nose_col,
            leg_front_enabled=leg_front_enabled,
            leg_front_size=(flw, flh),
            leg_front_mass=_lerp(2.0, 2.2, humanity) * mass_scale,
            leg_front_anchor_offset=front_anchor,
            leg_front_knee_deg=front_knee_deg,
            leg_front_knee_ratio=front_knee_ratio,
            leg_front_lower_scale=front_lower_scale,
            leg_front_rest_deg=leg_front_rest,
            leg_front_stiffness=leg_front_stiff,
            leg_front_damping=leg_damp,
            leg_front_color=leg_front_color,
            leg_back_enabled=leg_back_enabled,
            leg_back_size=(blw, blh),
            leg_back_mass=_lerp(3.2, 2.2, humanity) * mass_scale,
            leg_back_anchor_offset=back_anchor,
            leg_back_knee_deg=back_knee_deg,
            leg_back_knee_ratio=back_knee_ratio,
            leg_back_lower_scale=back_lower_scale,
            leg_back_rest_deg=leg_back_rest,
            leg_back_stiffness=leg_back_stiff,
            leg_back_damping=leg_damp,
            leg_back_color=leg_back_color,
            leg_mid_enabled=leg_mid_enabled,
            leg_mid_size=(mlw, mlh),
            leg_mid_mass=_lerp(2.4, 2.0, humanity) * mass_scale,
            leg_mid_anchor_offset=mid_anchor,
            leg_mid_knee_deg=mid_knee_deg,
            leg_mid_knee_ratio=mid_knee_ratio,
            leg_mid_lower_scale=mid_lower_scale,
            leg_mid_rest_deg=leg_mid_rest,
            leg_mid_stiffness=leg_mid_stiff,
            leg_mid_damping=leg_damp,
            leg_mid_color=leg_back_color,
            arm_front_enabled=arm_front_enabled,
            arm_front_size=af_size,
            arm_front_mass=0.5 * mass_scale,
            arm_front_anchor_offset=af_anchor,
            arm_front_knee_deg=af_knee,
            arm_front_rest_deg=af_rest,
            arm_front_color=arm_front_color,
            arm_back_enabled=arm_back_enabled,
            arm_back_size=ab_size,
            arm_back_mass=0.5 * mass_scale,
            arm_back_anchor_offset=ab_anchor,
            arm_back_knee_deg=ab_knee,
            arm_back_rest_deg=ab_rest,
            arm_back_color=arm_back_color,
            hoof_enabled=hoof_enabled,
            hoof_size=hoof_size,
            hoof_mass=0.05 * mass_scale,
            hoof_friction=hoof_friction,
            hoof_style=hoof_style,
            hoof_elasticity=hoof_elasticity,
            hoof_spring_bounce=hoof_spring_bounce,
            hoof_front_color=hoof_f_col,
            hoof_back_color=hoof_b_col,
            hand_enabled=hand_enabled,
            hand_size=hand_size,
            hand_color=hand_color,
            hand_back_color=hand_back_color,
            tail_enabled=tail_enabled,
            tail_size=tail_size,
            tail_mass=0.9 * mass_scale,
            tail_anchor_offset=tail_anchor_offset,
            tail_style=tail_style,
            tail_rest_deg=tail_rest_deg,
            tail_color=tail_col,
            wing_enabled=wing_on,
            wing_style=wing_style,
            wing_span=wing_span,
            wing_chord=wing_chord,
            wing_color=wing_color,
            wing_secondary_color=wing_sec_color,
            wing_lift=wing_lift,
            wing_flap_freq=wing_flap_freq,
            wing_drag=wing_drag,
            horn_enabled=horn_on,
            horn_kind=horn_kind,
            horn_length=horn_length,
            horn_thickness=horn_thickness,
            horn_curve=horn_curve,
            horn_tines=horn_tines,
            horn_spread=horn_spread,
            horn_color=horn_color,
            horn_tip_color=horn_tip_color,
            horn_seed=horn_seed,
            crest_enabled=crest_on,
            crest_style=crest_style,
            crest_size=crest_size,
            crest_spread=crest_spread,
            crest_count=crest_count,
            crest_color=crest_color,
            crest_tip_color=crest_tip_color,
            crest_has_poms=crest_has_poms,
            crest_branches=crest_branches,
            crest_seed=crest_seed,
            eye_enabled=eye_enabled,
            eye_offset=eye_offset,
            eye_radius=eye_radius,
            eye_pupil_offset=eye_pupil_offset,
            eye_pupil_radius=eye_pupil_radius,
            eye_sclera_color=eye_sclera,
            eye_pupil_color=eye_pupil,
            coat_color=coat_col_out,
            back_leg_color=back_leg_out,
            tooth_color=(250, 250, 250),
            pattern_style=pat_style,
            pattern_color=pat_col,
            pattern_density=pat_density,
            pattern_scale=pat_scale,
            pattern_seed=pat_seed,
            gait_enabled=gait_weight > 0.15,
            behavior=behavior,
            neuro_trait=neuro_trait,
            metabolic_trait=metabolic_trait,
            reflex_trait=reflex_trait,
            walk_freq=walk_freq,
            stride_deg=stride_deg,
            run_freq=run_freq,
            run_stride_deg=run_stride_deg,
            run_target_speed=run_target_speed,
            run_phase_offset_deg=run_phase_offset_deg,
            tail_sway_deg=tail_sway_deg,
            balance_stiffness=balance_stiffness,
            balance_damping=balance_damping,
            balance_max_torque=balance_max_torque,
            joint_stiffness_scale=joint_stiffness_scale,
            joint_damping_scale=joint_damping_scale,
            strand_loci=self.strand_loci,
            pure_strand=self.pure_strand,
            incomplete_strand_loci=incomplete_strands,
            erectness=erectness,
            grasp=grasp,
            humanity=humanity,
            lagomorph=lagomorph,
            gait_weight=gait_weight,
            head_center=head_center,
            diet=diet,
            diet_score=diet_score,
            osteoderm_amp=osteo_amp,
            osteoderm_freq=osteo_freq,
            osteoderm_color=osteo_color,
            flex_leg=flex_leg,
            flex_neck=flex_neck,
            flex_arm=flex_arm,
            flex_tail=flex_tail,
            joint_looseness=joint_looseness,
            lifespan_penalty=lifespan_penalty,
            spasm=spasm,
            lethal_white=lethal_white,
            sentience=sentience,
            eye_lid=eye_lid,
            teeth_style=teeth_style,
            upper_teeth=upper_teeth,
            lower_teeth=lower_teeth,
            bite=bite,
        )


def sample_strands(donors: list[Genome], rng: random.Random | None = None) -> Genome:
    """Potion genome whose every strand is copied from a random donor.

    A single donor is copied intact. With several donors, each locus allele is
    drawn from one of them, and every donor contributes at least one strand
    when there are enough strand slots.
    """
    rng = rng or random.Random()
    if not donors:
        raise ValueError("sample_strands requires at least one donor")
    if len(donors) == 1:
        return donors[0].copy()

    slots = [(locus, side) for locus in ALL_LOCI for side in ("a", "b")]
    rng.shuffle(slots)
    chosen: dict[tuple[str, str], Genome] = {}
    for slot, donor in zip(slots, donors):
        chosen[slot] = donor
    for slot in slots[len(donors):]:
        chosen[slot] = rng.choice(donors)

    genes = {
        locus: Gene(
            locus,
            chosen[(locus, "a")].genes[locus].allele_a,
            chosen[(locus, "b")].genes[locus].allele_b,
        )
        for locus in ALL_LOCI
    }
    names: list[str] = []
    for donor in donors:
        if donor.lineage not in names:
            names.append(donor.lineage)
    return Genome(
        genes=genes,
        lineage="+".join(names[:4]),
        generation=max(donor.generation for donor in donors),
    )
