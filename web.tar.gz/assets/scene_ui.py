"""Track, truck, pen, and hover-card drawing."""
from __future__ import annotations

import math
import random
import pygame
import pymunk

from gene import (
    ALLELE_LENGTH,
    ALL_LOCI,
    Genome,
    rancher_genome,
)

from creature import (
    Creature,
    build_creature,
    config_from_genome,
)

from racing_constants import (
    FIELD_TOP_Y,
    HORSE_CANVAS_H,
    HORSE_CANVAS_W,
    HORSE_CENTER_X,
    HORSE_FLOOR_Y,
    LANE_BOUNDS,
    LANE_GROUND_Y,
    LANE_SCALES,
    NUM_LANES,
    SCENE_SCALE,
    SCREEN_H,
    SCREEN_W,
    STD_TRUCK_CAB_W,
    STD_TRUCK_TRAILER_H,
    STD_TRUCK_TRAILER_W,
    STRONGHORSE_SLOPE,
    TRACK_LENGTH,
    WORLD_SCALE_X,
)

from racing_models import (
    HorseEntry,
    LaneRuntime,
    entry_strands_functional,
    get_horse_back_x,
    get_horse_front_x,
)

from physics_scene import UnifiedPhysicsScene

def draw_standardized_truck_shell(screen: pygame.Surface, trailer_left_phys: float, floor_y_phys: float):
    """
    Draws the EXACT SAME standardized truck trailer + cab (larger interior, NO text)
    at physics coordinates converted via SCENE_SCALE.
    """
    tl_x = trailer_left_phys * SCENE_SCALE
    tr_w = STD_TRUCK_TRAILER_W * SCENE_SCALE
    tr_h = STD_TRUCK_TRAILER_H * SCENE_SCALE
    fl_y = floor_y_phys * SCENE_SCALE
    top_y = fl_y - tr_h

    # Trailer interior box
    pygame.draw.rect(screen, (58, 46, 36), (tl_x, top_y, tr_w, tr_h), border_radius=6)
    for frac in (0.22, 0.44, 0.66, 0.84):
        sy = top_y + tr_h * frac
        pygame.draw.line(screen, (74, 58, 45), (tl_x + 4, sy), (tl_x + tr_w - 4, sy), 2)
    # Wooden trailer floor & steel frame (open top visually matches open top drop-in)
    pygame.draw.rect(screen, (116, 86, 58), (tl_x, fl_y, tr_w, 12))
    pygame.draw.line(screen, (198, 206, 220), (tl_x, top_y), (tl_x, fl_y + 12), 5)
    pygame.draw.line(screen, (198, 206, 220), (tl_x + tr_w, top_y), (tl_x + tr_w, fl_y + 12), 5)
    pygame.draw.line(screen, (198, 206, 220), (tl_x, fl_y + 12), (tl_x + tr_w, fl_y + 12), 5)

    # Cab on right side
    cab_x = tl_x + tr_w + 2
    cab_w = STD_TRUCK_CAB_W * SCENE_SCALE
    pygame.draw.rect(screen, (194, 56, 48), (cab_x, fl_y - 118, cab_w, 130), border_radius=8)
    pygame.draw.rect(screen, (194, 56, 48), (cab_x, fl_y - 172, cab_w * 0.68, 66), border_radius=7)
    pygame.draw.rect(screen, (150, 208, 240), (cab_x + 10, fl_y - 160, cab_w * 0.44, 34), border_radius=4)
    pygame.draw.rect(screen, (236, 214, 124), (cab_x + cab_w - 8, fl_y - 52, 7, 16), border_radius=2)

    # Wheels
    for wx in (tl_x + 76, tl_x + 150, cab_x + cab_w * 0.55):
        pygame.draw.circle(screen, (24, 24, 30), (int(wx), int(fl_y + 20)), 16)
        pygame.draw.circle(screen, (156, 162, 176), (int(wx), int(fl_y + 20)), 7)


def draw_open_pen_fence(screen: pygame.Surface, x1_phys: float, x2_phys: float, floor_y_phys: float):
    """Draws an open wooden fenced dirt corral (no ceiling!)."""
    sx1 = x1_phys * SCENE_SCALE
    sx2 = x2_phys * SCENE_SCALE
    sy = floor_y_phys * SCENE_SCALE
    w = sx2 - sx1

    pygame.draw.rect(screen, (112, 86, 60), (sx1 - 12, sy - 16, w + 24, 28), border_radius=4)
    pygame.draw.line(screen, (152, 118, 78), (sx1, sy - 72), (sx2, sy - 72), 5)
    pygame.draw.line(screen, (152, 118, 78), (sx1, sy - 40), (sx2, sy - 40), 5)
    num_posts = max(3, int(w // 95))
    for i in range(num_posts + 1):
        px = sx1 + (w * i) / num_posts
        pygame.draw.rect(screen, (124, 92, 58), (px - 4, sy - 86, 8, 86), border_radius=2)

def draw_breeding_shed(
    screen: pygame.Surface,
    x1_phys: float,
    x2_phys: float,
    top_y_phys: float,
    floor_y_phys: float,
    doors_closed: bool,
    progress: float,
    font_small: pygame.font.Font,
    notice: str = "",
):
    """Draws the Breeding Shed in Your Ranch (open doorway on left unless doors_closed)."""
    sx1 = x1_phys * SCENE_SCALE
    sx2 = x2_phys * SCENE_SCALE
    sy_top = top_y_phys * SCENE_SCALE
    sy_floor = floor_y_phys * SCENE_SCALE
    w = sx2 - sx1
    h = sy_floor - sy_top

    # Back interior wall
    pygame.draw.rect(screen, (64, 44, 32), (sx1, sy_top, w, h))
    for frac in (0.25, 0.5, 0.75):
        pygame.draw.line(screen, (78, 56, 40), (sx1 + 4, sy_top + h * frac), (sx2 - 4, sy_top + h * frac), 2)

    # Pitched barn roof
    roof_pts = [
        (sx1 - 14, sy_top + 4),
        (sx1 + w * 0.5, sy_top - 48),
        (sx2 + 14, sy_top + 4),
    ]
    pygame.draw.polygon(screen, (152, 54, 44), roof_pts)
    pygame.draw.polygon(screen, (96, 34, 28), roof_pts, 3)

    # Side walls & floor beam
    pygame.draw.rect(screen, (124, 82, 50), (sx2 - 10, sy_top, 10, h))
    pygame.draw.rect(screen, (112, 86, 60), (sx1 - 8, sy_floor - 4, w + 16, 12))

    # Doorway frame on left
    pygame.draw.rect(screen, (142, 98, 60), (sx1 - 4, sy_top, 8, h))

    if doors_closed:
        # Closed double barn doors hiding the parents inside
        pygame.draw.rect(screen, (148, 66, 48), (sx1 + 4, sy_top + 6, w - 14, h - 10), border_radius=4)
        pygame.draw.rect(screen, (92, 38, 28), (sx1 + 4, sy_top + 6, w - 14, h - 10), 3, border_radius=4)
        mid_x = sx1 + (w - 6) * 0.5
        pygame.draw.line(screen, (92, 38, 28), (mid_x, sy_top + 6), (mid_x, sy_floor - 4), 3)
        # Progress bar on door
        bar_w = int((w - 60) * max(0.05, min(1.0, progress)))
        pygame.draw.rect(screen, (48, 28, 24), (sx1 + 30, sy_top + h * 0.5 - 8, w - 60, 16), border_radius=6)
        pygame.draw.rect(screen, (244, 186, 98), (sx1 + 30, sy_top + h * 0.5 - 8, bar_w, 16), border_radius=6)
    else:
        lbl = font_small.render("BREEDING SHED", True, (246, 232, 198))
        screen.blit(lbl, lbl.get_rect(center=(sx1 + w * 0.5, sy_top - 16)))
        if notice:
            ns = font_small.render(notice, True, (255, 206, 128))
            screen.blit(ns, ns.get_rect(center=(sx1 + w * 0.5, sy_top + 24)))


def draw_horse_hover_card(
    screen: pygame.Surface,
    entry: HorseEntry,
    anchor_sx: float,
    anchor_sy: float,
    font_name_large: pygame.font.Font,
    font_small: pygame.font.Font,
    owned_by_player: bool = False,
    mouse_pos: tuple[int, int] = (0, 0),
    renaming_text: str | None = None,
) -> tuple[pygame.Rect, pygame.Rect]:
    """
    Draws a dynamic hover box above a horse with its name in large text and
    10 age boxes that fill up as the horse gets older (0=Juvenile, 1-9=Adult, 10=Elder).
    Returns (card_rect, name_rect).
    """
    disp_name = (renaming_text + "|") if renaming_text is not None else entry.name
    name_surf = font_name_large.render(disp_name, True, entry.name_color)

    badges: list[tuple[str, tuple[int, int, int]]] = []
    if entry.is_dead:
        badges.append(("DEAD", (212, 86, 86)))
    elif entry.is_unconscious:
        badges.append(("KO", (212, 86, 86)))
    elif entry.drunk_level > 0:
        badges.append(("DRUNK", (204, 128, 248)))
    if not entry.is_dead:
        if entry.is_tired:
            badges.append(("TIRED", (134, 168, 214)))
        if entry.is_hungry:
            badges.append(("HUNGRY", (242, 166, 72)))
        if entry.is_frenzied:
            badges.append(("FRENZIED", (245, 76, 76)))
    if entry.is_champion:
        badges.append(("CHAMPION", (255, 192, 64)))
    elif entry.is_gladiator:
        badges.append(("GLADIATOR", (238, 108, 88)))
    elif entry.is_winner:
        badges.append(("WINNER", (248, 214, 92)))
    if not entry_strands_functional(entry):
        badges.append(("BROKEN STRAND", (236, 92, 98)))
    if entry.genome is not None and entry.genome.strand_loci:
        n_loci = len(entry.genome.strand_loci)
        if entry.is_strand:
            badges.append((f"STRAND ({n_loci} LOCI)" if n_loci > 1 else "STRAND", (198, 132, 248)))
        else:
            badges.append((f"+{n_loci} STRAND" if n_loci > 1 else "+STRAND", (174, 214, 255)))

    box_w, box_h, gap = 14, 12, 4
    boxes_total_w = 10 * box_w + 9 * gap
    pad_x, pad_y = 14, 10
    badges_str = "  ".join(b[0] for b in badges)
    badges_w = font_small.size(badges_str)[0] + 10 if badges else 0
    content_w = max(name_surf.get_width() + 12, boxes_total_w, badges_w)
    card_w = content_w + pad_x * 2
    card_h = name_surf.get_height() + box_h + pad_y * 2 + 14 + (20 if badges else 0)

    cx = max(8, min(SCREEN_W - card_w - 8, int(anchor_sx - card_w * 0.5)))
    cy = max(8, min(SCREEN_H - card_h - 8, int(anchor_sy - card_h - 10)))
    card_rect = pygame.Rect(cx, cy, card_w, card_h)

    bg = pygame.Surface((card_w, card_h), pygame.SRCALPHA)
    bg.fill((22, 24, 34, 224))
    pygame.draw.rect(bg, (152, 122, 82, 230), bg.get_rect(), 2, border_radius=8)
    screen.blit(bg, (cx, cy))

    name_rect = pygame.Rect(cx + pad_x - 4, cy + pad_y - 2, content_w + 8, name_surf.get_height() + 4)
    if renaming_text is not None:
        pygame.draw.rect(screen, (46, 52, 72), name_rect, border_radius=4)
        pygame.draw.rect(screen, (242, 212, 118), name_rect, 1, border_radius=4)
    elif owned_by_player and name_rect.collidepoint(mouse_pos):
        pygame.draw.rect(screen, (52, 58, 76), name_rect, border_radius=4)
        pygame.draw.rect(screen, (198, 176, 118), name_rect, 1, border_radius=4)

    screen.blit(name_surf, name_surf.get_rect(center=name_rect.center))

    # 10 age boxes
    boxes_x = cx + (card_w - boxes_total_w) // 2
    boxes_y = name_rect.bottom + 8
    age_clamped = max(0, min(10, entry.age))
    if age_clamped >= 10:
        fill_col = (245, 200, 78)  # Elder gold
    elif age_clamped >= 1:
        fill_col = (98, 212, 118)  # Adult green
    else:
        fill_col = (80, 86, 102)

    for i in range(10):
        bx = boxes_x + i * (box_w + gap)
        brect = pygame.Rect(bx, boxes_y, box_w, box_h)
        if i < age_clamped:
            pygame.draw.rect(screen, fill_col, brect, border_radius=2)
            pygame.draw.rect(screen, (236, 240, 246), brect, 1, border_radius=2)
        else:
            pygame.draw.rect(screen, (38, 40, 52), brect, border_radius=2)
            pygame.draw.rect(screen, (108, 112, 130), brect, 1, border_radius=2)

    if badges:
        cur_bx = cx + (card_w - badges_w + 10) // 2
        by = boxes_y + box_h + 6
        for btxt, bcol in badges:
            bs = font_small.render(btxt, True, bcol)
            screen.blit(bs, (cur_bx, by))
            cur_bx += bs.get_width() + 10

    return card_rect, name_rect


def draw_scene_status_badges(
    screen: pygame.Surface,
    phys_scene: UnifiedPhysicsScene,
    font_badge: pygame.font.Font,
):
    for sh in phys_scene.horses:
        tags: list[tuple[str, tuple[int, int, int]]] = []
        if sh.entry.is_dead:
            tags.append(("DEAD", (245, 116, 116)))
        elif sh.entry.is_unconscious:
            tags.append(("KO", (245, 116, 116)))
        elif sh.entry.drunk_level > 0:
            tags.append(("DRUNK", (216, 148, 255)))
        if not sh.entry.is_dead:
            if sh.entry.is_tired:
                tags.append(("Zzz", (166, 202, 248)))
            if sh.entry.is_hungry:
                tags.append(("HUNGRY", (255, 186, 92)))
        if not tags:
            continue
        torso = sh.creature.bodies["torso"]
        top_y_phys = min(s.bb.top for s in sh.creature.shapes.values())
        sx = int((torso.position.x - phys_scene.view_x) * SCENE_SCALE)
        if sx < -40 or sx > SCREEN_W + 40:
            continue
        sy = int(top_y_phys * SCENE_SCALE) - 14
        txt = " ".join(t[0] for t in tags)
        surf = font_badge.render(txt, True, tags[0][1])
        bg = pygame.Rect(0, 0, surf.get_width() + 10, 18)
        bg.center = (max(30, min(SCREEN_W - 30, sx)), max(16, sy))
        pygame.draw.rect(screen, (20, 22, 32), bg, border_radius=4)
        pygame.draw.rect(screen, (112, 98, 76), bg, 1, border_radius=4)
        screen.blit(surf, surf.get_rect(center=bg.center))


# --- RANCHER (SHARED UNIVERSAL GENOME IN UPRIGHT POSTURE) ---


def build_rancher_creature(space: pymunk.Space, x: float, floor_y: float) -> Creature:
    genome = rancher_genome(random.Random(42))
    cfg = config_from_genome(
        genome,
        spawn_x=x,
        floor_y=floor_y,
        mode="walk",
        collision_group=7,
    )
    return build_creature(space, cfg)

def draw_speech_bubble(
    screen: pygame.Surface,
    bubble: pygame.Rect,
    text: str,
    font: pygame.font.Font,
    max_lines: int = 5,
):
    words = text.split(" ")
    lines: list[str] = []
    cur = ""
    max_text_w = max(80, bubble.width - 32)
    for word in words:
        cand = (cur + " " + word).strip()
        if font.size(cand)[0] <= max_text_w:
            cur = cand
        else:
            if cur:
                lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    lines = lines[:max_lines]
    if not lines:
        return

    line_h = font.get_height() + 4
    text_w = max(font.size(ln)[0] for ln in lines)
    fit_w = max(110, min(bubble.width, text_w + 32))
    fit_h = max(44, len(lines) * line_h + 20)

    # Grow upward from bubble.bottom so short lines stay compact and long lines stay clear of the truck
    box = pygame.Rect(bubble.left, bubble.bottom - fit_h, fit_w, fit_h)
    tail_y = max(box.top + 14, min(box.bottom - 14, bubble.bottom - 24))

    pygame.draw.rect(screen, (20, 22, 30), box.move(3, 4), border_radius=10)
    pygame.draw.rect(screen, (250, 244, 228), box, border_radius=10)
    pygame.draw.rect(screen, (96, 72, 46), box, 3, border_radius=10)
    pygame.draw.rect(screen, (255, 252, 244), box.inflate(-6, -6), 1, border_radius=7)

    tail_pts = [(box.left + 2, tail_y - 8), (box.left - 16, tail_y + 2), (box.left + 2, tail_y + 10)]
    pygame.draw.polygon(screen, (250, 244, 228), tail_pts)
    pygame.draw.line(screen, (96, 72, 46), tail_pts[0], tail_pts[1], 3)
    pygame.draw.line(screen, (96, 72, 46), tail_pts[1], tail_pts[2], 3)

    for li, line in enumerate(lines):
        screen.blit(font.render(line, True, (36, 30, 26)), (box.left + 16, box.top + 10 + li * line_h))


# --- SIMPLE WOODEN SIGN & LASSO ICON HELPERS ---


def draw_wood_sign(
    screen: pygame.Surface,
    rect: pygame.Rect,
    text: str,
    font: pygame.font.Font,
    hover: bool = False,
    with_post: bool = True,
    text_color: tuple[int, int, int] = (248, 236, 206),
    board_color: tuple[int, int, int] = (118, 82, 48),
    subtext: str = "",
    subtext_font: pygame.font.Font | None = None,
    subtext_color: tuple[int, int, int] = (255, 224, 128),
):
    if with_post:
        pygame.draw.rect(screen, (82, 56, 34), (rect.centerx - 5, rect.bottom - 2, 10, 26))
    col = tuple(min(255, c + 20) for c in board_color) if hover else board_color
    pygame.draw.rect(screen, col, rect, border_radius=4)
    pygame.draw.rect(screen, (74, 48, 26), rect, 2, border_radius=4)
    surf = font.render(text, True, text_color)
    if subtext:
        sf = subtext_font or font
        sub_surf = sf.render(subtext, True, subtext_color)
        total_h = surf.get_height() + sub_surf.get_height() + 2
        top_y = rect.centery - total_h // 2
        screen.blit(surf, surf.get_rect(centerx=rect.centerx, top=top_y))
        screen.blit(sub_surf, sub_surf.get_rect(centerx=rect.centerx, top=top_y + surf.get_height() + 2))
    else:
        screen.blit(surf, surf.get_rect(center=rect.center))


def draw_lasso_button(
    screen: pygame.Surface,
    rect: pygame.Rect,
    armed: bool,
    hover: bool,
    count: int = 0,
    font_badge: pygame.font.Font | None = None,
    infinite: bool = False,
):
    if infinite:
        bg = (34, 96, 152) if armed else (28, 62, 106)
        border = (118, 224, 255) if armed else (74, 168, 232)
        rope_col = (146, 236, 255)
        knot_col = (84, 198, 255)
    else:
        bg = (132, 96, 46) if armed else (64, 52, 40)
        border = (255, 224, 118) if armed else (154, 128, 92)
        rope_col = (236, 206, 132)
        knot_col = (196, 152, 82)
    if hover:
        bg = tuple(min(255, c + 18) for c in bg)
    pygame.draw.rect(screen, bg, rect, border_radius=10)
    pygame.draw.rect(screen, border, rect, 3 if armed else 2, border_radius=10)
    cx, cy = rect.center
    pygame.draw.circle(screen, rope_col, (cx - 4, cy - 4), 14, 3)
    pygame.draw.line(screen, rope_col, (cx + 6, cy + 6), (cx + 18, cy + 18), 3)
    pygame.draw.circle(screen, knot_col, (cx + 6, cy + 6), 3)
    if font_badge is not None:
        if infinite:
            inf_s = font_badge.render("INF", True, (186, 244, 255))
            screen.blit(inf_s, (rect.left + 4, rect.bottom - inf_s.get_height() - 2))
        elif count > 0:
            cnt_s = font_badge.render(f"x{count}", True, (255, 236, 176))
            screen.blit(cnt_s, (rect.left + 4, rect.bottom - cnt_s.get_height() - 2))


# --- RACE TRACK RENDERING (GUI-FREE, SIMPLE SIGNS ONLY) ---


def _fit_bold_name(
    text: str,
    max_width: int,
    color: tuple[int, int, int],
    name_fonts: list[pygame.font.Font],
) -> pygame.Surface:
    for f in name_fonts:
        surf = f.render(text, True, color)
        if surf.get_width() <= max_width:
            return surf
    return name_fonts[-1].render(text, True, color)


def draw_field_background(
    screen: pygame.Surface,
    camera_x: float,
    selected_lane: int,
    state: str,
    font_small: pygame.font.Font,
    race_mode: str = "bet",
    track_len: float = TRACK_LENGTH,
):
    pygame.draw.rect(screen, (26, 33, 50), (0, 0, SCREEN_W, FIELD_TOP_Y))
    pygame.draw.rect(screen, (32, 41, 62), (0, 42, SCREEN_W, FIELD_TOP_Y - 42))

    hill_pts = [(0, FIELD_TOP_Y)]
    for sx in range(0, SCREEN_W + 24, 24):
        wx = sx + camera_x * WORLD_SCALE_X * 0.25
        hy = FIELD_TOP_Y - 26 - 14 * math.sin(wx * 0.010) - 8 * math.cos(wx * 0.023)
        hill_pts.append((sx, hy))
    hill_pts.append((SCREEN_W, FIELD_TOP_Y))
    pygame.draw.polygon(screen, (36, 48, 56), hill_pts)
    pygame.draw.rect(screen, (42, 68, 48), (0, FIELD_TOP_Y - 8, SCREEN_W, 10))

    if race_mode == "muddy_tracks":
        lane_dirt_colors = [
            (46, 32, 20),
            (50, 35, 22),
            (54, 38, 24),
            (58, 41, 26),
            (62, 44, 28),
        ]
    elif race_mode == "stronghorse":
        lane_dirt_colors = [
            (66, 62, 58),
            (70, 66, 62),
            (74, 70, 65),
            (78, 74, 68),
            (82, 78, 72),
        ]
    else:
        lane_dirt_colors = [
            (56, 45, 37),
            (60, 48, 39),
            (64, 51, 42),
            (68, 54, 44),
            (72, 57, 46),
        ]
    for i, (top, bot) in enumerate(LANE_BOUNDS):
        col = lane_dirt_colors[i]
        if state == "betting" and i == selected_lane:
            col = tuple(min(255, c + 12) for c in col)
        pygame.draw.rect(screen, col, (0, top, SCREEN_W, bot - top))
        if race_mode == "stronghorse":
            slope = STRONGHORSE_SLOPE
            y0 = LANE_GROUND_Y[i] - camera_x * slope * LANE_SCALES[i]
            y1 = LANE_GROUND_Y[i] - (camera_x + SCREEN_W / WORLD_SCALE_X) * slope * LANE_SCALES[i]
            pygame.draw.line(screen, (118, 112, 104), (0, y0), (SCREEN_W, y1), 3)

    for i in range(1, NUM_LANES):
        ly = LANE_BOUNDS[i][0]
        pygame.draw.line(screen, (116, 102, 88), (0, ly), (SCREEN_W, ly), 2)

    rail_top = FIELD_TOP_Y - 18
    pygame.draw.line(screen, (205, 210, 220), (0, rail_top + 5), (SCREEN_W, rail_top + 5), 3)
    pygame.draw.line(screen, (165, 172, 185), (0, rail_top + 12), (SCREEN_W, rail_top + 12), 2)
    post_spacing = 180
    first_post = math.floor(camera_x / post_spacing) * post_spacing
    for wx in range(int(first_post), int(camera_x + SCREEN_W / WORLD_SCALE_X + post_spacing), post_spacing):
        sx = (wx - camera_x) * WORLD_SCALE_X
        if -10 <= sx <= SCREEN_W + 10:
            pygame.draw.rect(screen, (215, 220, 228), (sx - 2, rail_top, 4, 20))

    first_mark = max(0, int(math.floor(camera_x / 500.0)) * 500)
    max_mark = int(track_len + 500)
    for wx in range(first_mark, max_mark + 1, 500):
        sx = (wx - camera_x) * WORLD_SCALE_X
        if sx < -40 or sx > SCREEN_W + 40:
            continue
        if 0 < wx < track_len:
            pygame.draw.line(screen, (88, 76, 65), (sx, FIELD_TOP_Y + 2), (sx, SCREEN_H), 1)
            lbl = font_small.render(f"{wx}", True, (168, 154, 138))
            screen.blit(lbl, (sx - lbl.get_width() // 2, FIELD_TOP_Y - 34))

    start_sx = (0.0 - camera_x) * WORLD_SCALE_X
    if -20 <= start_sx <= SCREEN_W + 20:
        pygame.draw.line(screen, (150, 198, 238), (start_sx, FIELD_TOP_Y), (start_sx, SCREEN_H), 3)

    finish_sx = (track_len - camera_x) * WORLD_SCALE_X
    if -30 <= finish_sx <= SCREEN_W + 30:
        pygame.draw.rect(screen, (220, 68, 68), (finish_sx - 3, FIELD_TOP_Y - 46, 6, 46))
        pygame.draw.circle(screen, (245, 235, 190), (int(finish_sx), FIELD_TOP_Y - 48), 5)

        sq = 8
        fx = int(finish_sx) - sq
        y_cur = FIELD_TOP_Y
        row = 0
        while y_cur < SCREEN_H:
            for col in range(2):
                c = (240, 240, 245) if (row + col) % 2 == 0 else (34, 34, 42)
                pygame.draw.rect(screen, c, (fx + col * sq, y_cur, sq, min(sq, SCREEN_H - y_cur)))
            y_cur += sq
            row += 1


def draw_lane_horse_and_sign(
    screen: pygame.Surface,
    horse_canvas: pygame.Surface,
    lane: LaneRuntime,
    camera_x: float,
    state: str,
    is_selected: bool,
    race_mode: str,
    name_fonts: list[pygame.font.Font],
    font_odds_small: pygame.font.Font,
    font_badge: pygame.font.Font,
) -> tuple[pygame.Rect, pygame.Rect | None]:
    i = lane.lane_index
    lane_top, lane_bot = LANE_BOUNDS[i]
    ground_y = LANE_GROUND_Y[i]
    lane_scale = LANE_SCALES[i]

    torso = lane.creature.bodies["torso"]
    front_x = get_horse_front_x(lane.creature)
    back_x = get_horse_back_x(lane.creature)

    front_canvas_x = HORSE_CENTER_X + (front_x - torso.position.x)
    target_front_sx = (front_x - camera_x) * WORLD_SCALE_X
    blit_x = target_front_sx - front_canvas_x * lane_scale
    blit_y = ground_y - HORSE_FLOOR_Y * lane_scale

    horse_center_sx = blit_x + HORSE_CENTER_X * lane_scale
    horse_left_sx = target_front_sx - (front_x - back_x) * lane_scale

    sign_name_rect: pygame.Rect | None = None
    if state == "betting":
        max_name_w = max(110, int(horse_left_sx - 36))
        name_surf = _fit_bold_name(lane.entry.name, max_name_w, lane.entry.name_color, name_fonts)
        name_x = max(20, int(horse_left_sx - 18 - name_surf.get_width()))

        lane_mid_y = (lane_top + lane_bot) // 2
        name_y = lane_mid_y - 16
        screen.blit(name_surf, (name_x, name_y))
        if lane.is_player_horse:
            sign_name_rect = pygame.Rect(name_x - 4, name_y - 2, name_surf.get_width() + 8, name_surf.get_height() + 4)

        if race_mode == "bet":
            sub_txt = f"{lane.odds:.1f}x" + ("  *" if is_selected else "")
        elif race_mode == "championship":
            sub_txt = "(YOUR WINNER)" if lane.is_player_horse else f"Winner - {lane.entry.origin_ranch}"
        else:
            sub_txt = "(YOUR HORSE)" if lane.is_player_horse else lane.entry.origin_ranch
        odds_col = (248, 232, 162) if (is_selected or lane.is_player_horse) else (206, 198, 182)
        odds_surf = font_odds_small.render(sub_txt, True, odds_col)
        odds_x = max(20, name_x + name_surf.get_width() - odds_surf.get_width())
        screen.blit(odds_surf, (odds_x, name_y + name_surf.get_height() + 2))

    horse_canvas.fill((0, 0, 0, 0))
    local_cam_x = torso.position.x - HORSE_CENTER_X
    if lane.stone_body is not None and lane.stone_shape is not None:
        tw_s = lane.creature.config.torso.size[0]
        h_pin = torso.local_to_world((-tw_s * 0.45, 0.0))
        s_pin = lane.stone_body.local_to_world((36.0, 0.0))
        pygame.draw.line(
            horse_canvas,
            (178, 146, 98),
            (h_pin[0] - local_cam_x, h_pin[1]),
            (s_pin[0] - local_cam_x, s_pin[1]),
            4,
        )
        s_pts = [
            (wx - local_cam_x, wy)
            for wx, wy in (lane.stone_body.local_to_world(v) for v in lane.stone_shape.get_vertices())
        ]
        pygame.draw.polygon(horse_canvas, (124, 128, 136), s_pts)
        pygame.draw.polygon(horse_canvas, (78, 82, 90), s_pts, 3)
    lane.creature.draw(horse_canvas, local_cam_x)

    s = getattr(screen, "scale", 1.0)
    scaled_w = int(round(HORSE_CANVAS_W * lane_scale * s))
    scaled_h = int(round(HORSE_CANVAS_H * lane_scale * s))
    scaled_horse = pygame.transform.smoothscale(horse_canvas, (scaled_w, scaled_h))
    if hasattr(screen, "_real"):
        screen._real.blit(scaled_horse, (screen._ox + int(round(blit_x * s)), screen._oy + int(round(blit_y * s))))
    else:
        screen.blit(scaled_horse, (blit_x, blit_y))

    horse_w_sx = max(48, int((front_x - back_x) * lane_scale) + 16)
    horse_h_sx = max(48, int(170 * lane_scale))
    horse_rect = pygame.Rect(int(horse_left_sx - 8), int(ground_y - horse_h_sx), horse_w_sx, horse_h_sx)

    if state in ("racing", "results") and (is_selected or lane.is_player_horse):
        marker_y = max(6, int(blit_y + 18 * lane_scale))
        pygame.draw.polygon(
            screen,
            lane.entry.name_color,
            [
                (horse_center_sx, marker_y + 9),
                (horse_center_sx - 6, marker_y),
                (horse_center_sx + 6, marker_y),
            ],
        )

    if state == "results" and lane.place is not None:
        place_str = {1: "1st", 2: "2nd", 3: "3rd", 4: "4th", 5: "5th"}[lane.place]
        col = (255, 224, 102) if lane.place == 1 else (210, 214, 224)
        p_surf = font_badge.render(f"{place_str} - {lane.entry.name}", True, col)
        screen.blit(p_surf, (18, (lane_top + lane_bot) // 2 - 8))

    return horse_rect, sign_name_rect


def compute_dna_pool_diversity(pool: list[Genome]) -> float:
    """Returns nucleotide diversity (0.0 - 100.0%) across all alleles in the DNA vat."""
    if not pool:
        return 0.0
    strands_per_locus: list[list[str]] = []
    for locus in ALL_LOCI:
        strands: list[str] = []
        for g in pool[:12]:
            gene = g.genes[locus]
            strands.append(gene.allele_a)
            strands.append(gene.allele_b)
        strands_per_locus.append(strands)

    total_pairs = 0
    total_diffs = 0
    for strands in strands_per_locus:
        n = len(strands)
        for i in range(n):
            sa = strands[i]
            for j in range(i + 1, n):
                sb = strands[j]
                total_pairs += ALLELE_LENGTH
                total_diffs += sum(1 for k in range(ALLELE_LENGTH) if sa[k] != sb[k])

    if total_pairs == 0:
        return 0.0
    pi = total_diffs / float(total_pairs)
    return max(0.0, min(100.0, (pi / 0.58) * 100.0))


def synthesize_dna_candidate(
    pool: list[Genome],
    elites: list[Genome],
    rng: random.Random,
    mut_rate: float = 0.022,
    elite_bias: float = 0.65,
) -> Genome:
    """Breeds a candidate horse Genome from the vat DNA pool and any round elites."""
    source = elites + pool if elites else pool
    if len(source) == 1:
        p1 = source[0]
        p2 = source[0]
    else:
        p1 = rng.choice(elites) if (elites and rng.random() < elite_bias) else rng.choice(pool)
        p2 = rng.choice(pool)
    return p1.breed(p2, point_mutation_rate=mut_rate, rng=rng)


# --- MAIN APPLICATION ---
