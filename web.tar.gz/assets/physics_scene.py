"""Shared Pymunk scene for trucks, pens, shops, and the racecourse hub."""
from __future__ import annotations

import math
import pygame
import pymunk

from gene import Genome

from racing_models import (
    HorseEntry,
    SceneHorse,
    SceneProp,
    sync_creature_state,
)

from racing_constants import (
    PHYS_H,
    PHYS_W,
    SCENE_SCALE,
    SCREEN_H,
    SCREEN_W,
    STD_TRUCK_TRAILER_H,
    STD_TRUCK_TRAILER_W,
)

from creature import (
    build_creature,
    compute_spawn_y,
)

from scene_art import (
    build_carcass_surface,
    build_fossil_surface,
    build_potion_flask_surface,
    draw_rancher_hat,
    fossil_visual_params,
)

# --- UNIFIED PHYSICS SCENE HELPER (100% CONSISTENT HORSES & PIVOTJOINT DRAG) ---


class UnifiedPhysicsScene:
    """
    Single unified Pymunk Space at SCENE_SCALE for Truck, Ranch, Your Ranch, Shop, and Racecourse Hub.
    All horses and shop/truck items are real physics objects grabbed and dragged via PivotJoint.
    """

    def __init__(self):
        self.space = pymunk.Space()
        self.space.gravity = (0, 900)
        self.space.iterations = 24
        self.static_shapes: list[pymunk.Shape] = []
        self.horses: list[SceneHorse] = []
        self.props: list[SceneProp] = []
        self.floors: list[pymunk.Shape] = []
        self.floor_slabs: list[tuple[pymunk.Shape, float, float, float]] = []  # (shape, x1, x2, top_y)
        self.mouse_body = pymunk.Body(body_type=pymunk.Body.KINEMATIC)
        self.mouse_joint: pymunk.PivotJoint | None = None
        self.dragged_horse: SceneHorse | None = None
        self.dragged_prop: SceneProp | None = None
        self.drag_start_pos: tuple[int, int] = (0, 0)
        self.view_x = 0.0
        self.phys_canvas = pygame.Surface((int(round(PHYS_W)), int(round(PHYS_H))), pygame.SRCALPHA)
        self._group_counter = 20

    def reset(self):
        if self.mouse_joint is not None and self.mouse_joint in self.space.constraints:
            self.space.remove(self.mouse_joint)
        self.mouse_joint = None
        self.dragged_horse = None
        self.dragged_prop = None
        for sh in self.horses:
            sh.creature.remove_from_space(self.space)
        self.horses.clear()
        for pr in self.props:
            if pr.shape in self.space.shapes:
                self.space.remove(pr.shape)
            if pr.body in self.space.bodies:
                self.space.remove(pr.body)
        self.props.clear()
        for st in self.static_shapes:
            if st in self.space.shapes:
                self.space.remove(st)
        self.static_shapes.clear()
        self.floors.clear()
        self.floor_slabs.clear()
        self.view_x = 0.0

    def add_box_collider(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        friction: float = 0.9,
        is_floor: bool = False,
    ) -> pymunk.Poly:
        verts = [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]
        poly = pymunk.Poly(self.space.static_body, verts)
        poly.friction = friction
        poly.filter = pymunk.ShapeFilter(categories=0b01, mask=0b110)
        self.space.add(poly)
        self.static_shapes.append(poly)
        if is_floor:
            self.floors.append(poly)
            self.floor_slabs.append((poly, min(x1, x2), max(x1, x2), min(y1, y2)))
        return poly

    def add_floor_slab(
        self,
        x1: float,
        x2: float,
        top_y: float,
        thickness: float = 40.0,
        friction: float = 0.95,
    ) -> pymunk.Poly:
        return self.add_box_collider(x1, top_y, x2, top_y + thickness, friction=friction, is_floor=True)

    def add_wall_segment(
        self,
        a: tuple[float, float],
        b: tuple[float, float],
        radius: float = 5.0,
        friction: float = 0.9,
        is_floor: bool = False,
    ) -> pymunk.Shape:
        if is_floor:
            x1, x2 = min(a[0], b[0]), max(a[0], b[0])
            top_y = min(a[1], b[1])
            return self.add_floor_slab(x1, x2, top_y, thickness=max(32.0, radius * 4.0), friction=friction)
        seg = pymunk.Segment(self.space.static_body, a, b, max(radius, 8.0))
        seg.friction = friction
        seg.filter = pymunk.ShapeFilter(categories=0b01, mask=0b110)
        self.space.add(seg)
        self.static_shapes.append(seg)
        return seg

    def add_screen_bounds(self, right_limit: float | None = None):
        # Solid thick bounds so horses/items never tunnel out of the scene or through the floor.
        # right_limit extends the world past one screen (the ranch rabbit pen sits one view to the right).
        right = PHYS_W if right_limit is None else right_limit
        self.add_box_collider(-140.0, -400.0, -10.0, PHYS_H + 200.0, friction=0.2, is_floor=False)
        self.add_box_collider(right + 10.0, -400.0, right + 140.0, PHYS_H + 200.0, friction=0.2, is_floor=False)
        self.add_floor_slab(-140.0, right + 140.0, PHYS_H + 8.0, thickness=140.0, friction=0.95)

    def spawn_horse(
        self,
        entry: HorseEntry,
        x: float,
        floor_y: float,
        owned_by_player: bool,
        run_mode: bool = False,
    ) -> SceneHorse:
        self._group_counter += 1
        grp = self._group_counter
        sy = compute_spawn_y(entry.config, floor_y=floor_y)
        cfg = entry.config.with_(
            spawn_pos=(x, sy),
            collision_group=grp,
            gait=entry.config.gait.with_(mode=("run" if run_mode else "walk"), enabled=run_mode),
        )
        cr = build_creature(self.space, cfg)
        sync_creature_state(entry, cr)
        h_filter = pymunk.ShapeFilter(group=grp, categories=0b10, mask=0b01)
        for sh in cr.shapes.values():
            sh.filter = h_filter
        sh_obj = SceneHorse(entry=entry, creature=cr, owned_by_player=owned_by_player)
        self.horses.append(sh_obj)
        return sh_obj

    def remove_horse(self, sh_obj: SceneHorse):
        if self.dragged_horse is sh_obj:
            self.release_drag()
        sh_obj.creature.remove_from_space(self.space)
        if sh_obj in self.horses:
            self.horses.remove(sh_obj)

    def spawn_prop(
        self,
        kind: str,
        x: float,
        y: float,
        from_shop: bool = False,
        home_pos: tuple[float, float] | None = None,
        price: int = 0,
        genome: Genome | None = None,
    ) -> SceneProp:
        if kind == "lasso":
            w, h, mass = 36.0, 32.0, 0.9
        elif kind == "infinite_lasso":
            w, h, mass = 42.0, 38.0, 0.9
        elif kind == "hay":
            w, h, mass = 46.0, 28.0, 1.4
        elif kind == "apple":
            w, h, mass = 24.0, 24.0, 0.45
        elif kind == "prickly_pear":
            w, h, mass = 24.0, 26.0, 0.45
        elif kind == "chili":
            w, h, mass = 28.0, 22.0, 0.40
        elif kind == "apple_crate":
            w, h, mass = 48.0, 42.0, 1.6
        elif kind == "meat":
            w, h, mass = 150.0, 96.0, 4.0
        elif kind == "fossil":
            w, h, mass = 42.0, 34.0, 1.5
        elif kind == "potion":
            w, h, mass = 40.0, 52.0, 0.9
        elif kind == "drive":
            w, h, mass = 36.0, 24.0, 0.6
        else:  # "beer"
            w, h, mass = 22.0, 38.0, 0.8
        moment = pymunk.moment_for_box(mass, (w, h))
        body = pymunk.Body(mass, moment)
        body.position = (x, y)
        shape = pymunk.Poly.create_box(body, (w, h), radius=2.0)
        shape.friction = 0.85
        shape.elasticity = 0.08
        shape.filter = pymunk.ShapeFilter(categories=0b100, mask=0b01)
        self.space.add(body, shape)
        prop = SceneProp(
            kind=kind,
            body=body,
            shape=shape,
            from_shop=from_shop,
            home_pos=home_pos if home_pos is not None else (x, y),
            price=price,
            genome=genome,
        )
        self.props.append(prop)
        return prop

    def remove_prop(self, prop: SceneProp):
        if self.dragged_prop is prop:
            self.release_drag()
        if prop.shape in self.space.shapes:
            self.space.remove(prop.shape)
        if prop.body in self.space.bodies:
            self.space.remove(prop.body)
        if prop in self.props:
            self.props.remove(prop)

    def move_prop_to(self, prop: SceneProp, x: float, y: float):
        prop.body.position = (x, y)
        prop.body.velocity = (0.0, 0.0)
        prop.body.angle = 0.0
        prop.body.angular_velocity = 0.0

    def find_horse_at_screen_pos(self, screen_pos: tuple[int, int], radius: float = 16.0) -> SceneHorse | None:
        wx = screen_pos[0] / SCENE_SCALE + self.view_x
        wy = screen_pos[1] / SCENE_SCALE
        hits = self.space.point_query((wx, wy), radius, pymunk.ShapeFilter(mask=0b10))
        if not hits:
            return None
        hit_shape = min(hits, key=lambda h: h.distance).shape
        for sh in reversed(self.horses):
            if hit_shape in sh.creature.shapes.values():
                return sh
        return None

    def find_horse_near_phys_point(self, wx: float, wy: float, margin: float = 34.0) -> SceneHorse | None:
        for sh in reversed(self.horses):
            for s in sh.creature.shapes.values():
                bb = s.bb
                if (bb.left - margin) <= wx <= (bb.right + margin) and (bb.top - margin) <= wy <= (bb.bottom + margin):
                    return sh
        return None

    def start_drag(self, screen_pos: tuple[int, int]) -> str | None:
        if self.mouse_joint is not None:
            return None
        self.drag_start_pos = screen_pos
        wx = screen_pos[0] / SCENE_SCALE + self.view_x
        wy = screen_pos[1] / SCENE_SCALE
        self.mouse_body.position = (wx, wy)

        # 1. Check draggable props first (small items inside truck or shop shelves)
        prop_hits = self.space.point_query((wx, wy), 18.0, pymunk.ShapeFilter(mask=0b100))
        if prop_hits:
            hit_shape = min(prop_hits, key=lambda h: h.distance).shape
            target_prop = next((p for p in reversed(self.props) if p.shape is hit_shape), None)
            if target_prop is not None and target_prop.locked:
                return None
            if target_prop is not None:
                self.dragged_prop = target_prop
                target_prop.shape.filter = pymunk.ShapeFilter(categories=0b100, mask=0)
                self.mouse_joint = pymunk.PivotJoint(self.mouse_body, target_prop.body, (wx, wy))
                self.mouse_joint.max_force = 120000.0
                self.mouse_joint.error_bias = (1.0 - 0.16) ** 60.0
                self.space.add(self.mouse_joint)
                return "prop"

        # 2. Query horse/rancher shapes (category 0b10)
        hits = self.space.point_query((wx, wy), 16.0, pymunk.ShapeFilter(mask=0b10))
        if not hits:
            return None
        hit_shape = min(hits, key=lambda h: h.distance).shape
        target_horse = None
        for sh in reversed(self.horses):
            if hit_shape in sh.creature.shapes.values():
                target_horse = sh
                break
        if target_horse is None:
            return None

        # Conscious NPCs (ranchers, shopkeeps, Jean) cannot be picked up until knocked out
        if target_horse.entry.is_rancher and not target_horse.owned_by_player and not target_horse.entry.is_unconscious:
            return "conscious_npc"

        self.dragged_horse = target_horse
        # While dragged, pause gait and pass cleanly through internal walls/floors
        target_horse.creature.config.gait.enabled = False
        for s in target_horse.creature.shapes.values():
            s.filter = pymunk.ShapeFilter(group=s.filter.group, categories=0b10, mask=0)

        self.mouse_joint = pymunk.PivotJoint(self.mouse_body, hit_shape.body, (wx, wy))
        self.mouse_joint.max_force = 220000.0
        self.mouse_joint.error_bias = (1.0 - 0.14) ** 60.0
        self.space.add(self.mouse_joint)
        return "horse"

    def update_drag(self, screen_pos: tuple[int, int]):
        wx = max(self.view_x + 30.0, min(self.view_x + PHYS_W - 30.0, screen_pos[0] / SCENE_SCALE + self.view_x))
        wy = max(30.0, min(PHYS_H - 30.0, screen_pos[1] / SCENE_SCALE))
        self.mouse_body.position = (wx, wy)

    def _lift_above_intersecting_floors(self, horse: SceneHorse):
        torso = horse.creature.bodies["torso"]
        # Iteratively lift if any feet/torso slightly overlap a floor slab from above
        for _ in range(3):
            bot_y = max(s.bb.bottom for s in horse.creature.shapes.values())
            left_x = min(s.bb.left for s in horse.creature.shapes.values())
            right_x = max(s.bb.right for s in horse.creature.shapes.values())
            lift = 0.0
            for _fl, x1, x2, top_y in self.floor_slabs:
                if right_x >= x1 and left_x <= x2:
                    if torso.position.y < top_y + 16.0 and bot_y > top_y - 1.0:
                        penetration = bot_y - top_y
                        if 0.0 < penetration < 120.0:
                            lift = max(lift, penetration + 2.0)
            if lift > 0.0:
                for b in set(horse.creature.bodies.values()):
                    b.position = (b.position.x, b.position.y - lift)
            else:
                break

    def _lift_prop_above_floors(self, prop: SceneProp):
        for _ in range(2):
            bb = prop.shape.bb
            lift = 0.0
            for _fl, x1, x2, top_y in self.floor_slabs:
                if bb.right >= x1 and bb.left <= x2:
                    if prop.body.position.y < top_y + 14.0 and bb.bottom > top_y - 1.0:
                        pen = bb.bottom - top_y
                        if 0.0 < pen < 70.0:
                            lift = max(lift, pen + 2.0)
            if lift > 0.0:
                prop.body.position = (prop.body.position.x, prop.body.position.y - lift)
            else:
                break

    def release_drag(self) -> tuple[str | None, SceneHorse | SceneProp | None]:
        if self.mouse_joint is not None and self.mouse_joint in self.space.constraints:
            self.space.remove(self.mouse_joint)
        self.mouse_joint = None

        if self.dragged_prop is not None:
            released_prop = self.dragged_prop
            self.dragged_prop = None
            self._lift_prop_above_floors(released_prop)
            released_prop.shape.filter = pymunk.ShapeFilter(categories=0b100, mask=0b01)
            released_prop.body.velocity = (
                max(-220.0, min(220.0, released_prop.body.velocity.x * 0.2)),
                max(-220.0, min(220.0, released_prop.body.velocity.y * 0.2)),
            )
            released_prop.body.angular_velocity *= 0.2
            return ("prop", released_prop)

        released = self.dragged_horse
        self.dragged_horse = None
        if released is not None:
            self._lift_above_intersecting_floors(released)
            for s in released.creature.shapes.values():
                s.filter = pymunk.ShapeFilter(group=s.filter.group, categories=0b10, mask=0b01)
            for b in set(released.creature.bodies.values()):
                vx = max(-350.0, min(350.0, b.velocity.x * 0.25))
                vy = max(-350.0, min(350.0, b.velocity.y * 0.25))
                b.velocity = (vx, vy)
                b.angular_velocity *= 0.25
            return ("horse", released)

        return (None, None)

    def _supporting_floor_for(self, torso: pymunk.Body) -> pymunk.Shape | None:
        tx, ty = torso.position.x, torso.position.y
        best_fl = None
        best_dist = 1e9
        for fl, x1, x2, top_y in self.floor_slabs:
            if x1 - 40.0 <= tx <= x2 + 40.0 and top_y >= ty - 20.0:
                d = top_y - ty
                if d < best_dist:
                    best_dist = d
                    best_fl = fl
        if best_fl is not None:
            return best_fl
        return self.floors[0] if self.floors else None

    def step(self, dt: float):
        substeps = 4
        sub_dt = dt / substeps
        for _ in range(substeps):
            for pr in self.props:
                if pr is self.dragged_prop:
                    pr.body.angular_velocity *= 0.92
                    pr.body.velocity = (pr.body.velocity.x * 0.96, pr.body.velocity.y * 0.96)

            for sh in self.horses:
                cr = sh.creature
                sync_creature_state(sh.entry, cr)
                torso = cr.bodies["torso"]

                if sh is self.dragged_horse:
                    for b in set(cr.bodies.values()):
                        b.angular_velocity *= 0.96
                        b.velocity = (b.velocity.x * 0.975, b.velocity.y * 0.975)
                    continue

                active_floor = self._supporting_floor_for(torso)
                if active_floor is not None:
                    cr.update(sub_dt, active_floor)

                if cr.unconscious:
                    continue

                drunk_sway = math.radians(7.0 * math.sin(cr.swirl_phase * 1.4)) if cr.drunk else 0.0
                if sh.entry.is_rancher and not sh.owned_by_player:
                    tilt = math.atan2(math.sin(torso.angle), math.cos(torso.angle))
                    hold = max(1_800_000.0, cr.total_mass * 50000.0)
                    torso.torque += -hold * (tilt - drunk_sway) - hold * 0.18 * torso.angular_velocity
                    anchor_x = 185.0 if sh.home_x is None else sh.home_x
                    torso.velocity = (-(torso.position.x - anchor_x) * 6.0, torso.velocity.y)
                elif not cr.config.gait.enabled:
                    tilt = math.atan2(math.sin(torso.angle), math.cos(torso.angle))
                    if sh.entry.is_rancher:
                        hold = max(380000.0, cr.total_mass * 22000.0)
                        damp = max(44000.0, cr.total_mass * 2400.0)
                    else:
                        hold = min(380000.0, max(1600.0, torso.moment * 5.2))
                        damp = min(44000.0, max(200.0, torso.moment * 0.72))
                    torso.torque += -hold * (tilt - drunk_sway) - damp * torso.angular_velocity
                    torso.velocity = (torso.velocity.x * 0.98, torso.velocity.y)

            self.space.step(sub_dt)

    def _draw_prop(self, surf: pygame.Surface, prop: SceneProp):
        b = prop.body
        cx, cy = b.position.x - self.view_x, b.position.y
        ang = -math.degrees(b.angle)
        if prop.kind == "lasso":
            sp = pygame.Surface((42, 38), pygame.SRCALPHA)
            pygame.draw.ellipse(sp, (226, 194, 118), (4, 5, 34, 24), 5)
            pygame.draw.ellipse(sp, (176, 138, 68), (8, 9, 26, 16), 2)
            pygame.draw.circle(sp, (148, 96, 48), (33, 25), 5)
            rot = pygame.transform.rotozoom(sp, ang, 1.0)
            surf.blit(rot, rot.get_rect(center=(cx, cy)))
        elif prop.kind == "hay":
            sp = pygame.Surface((50, 32), pygame.SRCALPHA)
            pygame.draw.rect(sp, (228, 192, 82), (2, 2, 46, 28), border_radius=4)
            pygame.draw.rect(sp, (178, 142, 48), (2, 2, 46, 28), 2, border_radius=4)
            pygame.draw.line(sp, (148, 96, 44), (15, 2), (15, 29), 3)
            pygame.draw.line(sp, (148, 96, 44), (35, 2), (35, 29), 3)
            pygame.draw.line(sp, (248, 224, 128), (6, 10), (42, 10), 2)
            pygame.draw.line(sp, (248, 224, 128), (8, 20), (40, 20), 2)
            rot = pygame.transform.rotozoom(sp, ang, 1.0)
            surf.blit(rot, rot.get_rect(center=(cx, cy)))
        elif prop.kind == "apple":
            sp = pygame.Surface((28, 28), pygame.SRCALPHA)
            pygame.draw.circle(sp, (212, 42, 46), (14, 15), 10)
            pygame.draw.circle(sp, (242, 92, 92), (11, 12), 3)
            pygame.draw.line(sp, (98, 62, 34), (14, 6), (16, 2), 2)
            pygame.draw.ellipse(sp, (74, 158, 62), (15, 2, 7, 4))
            rot = pygame.transform.rotozoom(sp, ang, 1.0)
            surf.blit(rot, rot.get_rect(center=(cx, cy)))
        elif prop.kind == "infinite_lasso":
            sp = pygame.Surface((52, 48), pygame.SRCALPHA)
            pygame.draw.ellipse(sp, (62, 186, 255, 75), (2, 4, 48, 36))
            pygame.draw.ellipse(sp, (84, 212, 255), (8, 8, 36, 26), 5)
            pygame.draw.ellipse(sp, (192, 244, 255), (12, 12, 28, 18), 2)
            pygame.draw.circle(sp, (148, 228, 255), (39, 29), 5)
            rot = pygame.transform.rotozoom(sp, ang, 1.0)
            surf.blit(rot, rot.get_rect(center=(cx, cy)))
        elif prop.kind == "prickly_pear":
            sp = pygame.Surface((28, 30), pygame.SRCALPHA)
            pygame.draw.ellipse(sp, (226, 74, 108), (5, 4, 18, 22))
            pygame.draw.ellipse(sp, (246, 132, 82), (8, 7, 7, 10))
            for sx, sy in ((8, 10), (19, 12), (10, 20), (18, 21)):
                pygame.draw.circle(sp, (248, 224, 146), (sx, sy), 1)
            rot = pygame.transform.rotozoom(sp, ang, 1.0)
            surf.blit(rot, rot.get_rect(center=(cx, cy)))
        elif prop.kind == "chili":
            sp = pygame.Surface((34, 28), pygame.SRCALPHA)
            pygame.draw.polygon(
                sp,
                (226, 36, 34),
                [(6, 12), (16, 8), (27, 13), (31, 22), (22, 19), (12, 19)],
            )
            pygame.draw.line(sp, (252, 118, 104), (11, 12), (22, 14), 2)
            pygame.draw.line(sp, (62, 168, 66), (4, 9), (9, 12), 3)
            rot = pygame.transform.rotozoom(sp, ang, 1.0)
            surf.blit(rot, rot.get_rect(center=(cx, cy)))
        elif prop.kind == "apple_crate":
            sp = pygame.Surface((52, 46), pygame.SRCALPHA)
            pygame.draw.circle(sp, (214, 44, 46), (14, 10), 7)
            pygame.draw.circle(sp, (214, 44, 46), (26, 9), 7)
            pygame.draw.circle(sp, (214, 44, 46), (38, 10), 7)
            pygame.draw.rect(sp, (162, 112, 62), (3, 12, 46, 32), border_radius=3)
            pygame.draw.rect(sp, (104, 68, 34), (3, 12, 46, 32), 2, border_radius=3)
            pygame.draw.line(sp, (124, 82, 42), (4, 22), (48, 22), 2)
            pygame.draw.line(sp, (124, 82, 42), (4, 33), (48, 33), 2)
            cnt_f = pygame.font.SysFont("sans-serif", 20, bold=True)
            cnt_s = cnt_f.render(str(max(0, prop.uses_left)), True, (255, 246, 206))
            sp.blit(cnt_s, cnt_s.get_rect(center=(26, 28)))
            rot = pygame.transform.rotozoom(sp, ang, 1.0)
            surf.blit(rot, rot.get_rect(center=(cx, cy)))
        elif prop.kind == "meat":
            sp = build_carcass_surface((168, 112)).copy()
            cnt_f = pygame.font.SysFont("sans-serif", 32, bold=True)
            cnt_s = cnt_f.render(str(max(0, prop.uses_left)), True, (255, 246, 224))
            badge_r = cnt_s.get_rect(center=(86, 62)).inflate(14, 4)
            pygame.draw.rect(sp, (48, 16, 20, 190), badge_r, border_radius=6)
            sp.blit(cnt_s, cnt_s.get_rect(center=badge_r.center))
            rot = pygame.transform.rotozoom(sp, ang, 1.0)
            surf.blit(rot, rot.get_rect(center=(cx, cy)))
        elif prop.kind == "fossil":
            f_var, f_seed = fossil_visual_params(prop.genome)
            sp = build_fossil_surface(f_var, f_seed, (48, 40))
            rot = pygame.transform.rotozoom(sp, ang, 1.0)
            surf.blit(rot, rot.get_rect(center=(cx, cy)))
        elif prop.kind == "potion":
            sp = build_potion_flask_surface(1.0)
            rot = pygame.transform.rotozoom(sp, ang, 1.0)
            surf.blit(rot, rot.get_rect(center=(cx, cy)))
        elif prop.kind == "drive":
            sp = pygame.Surface((42, 30), pygame.SRCALPHA)
            # Metal connector prongs on left
            pygame.draw.rect(sp, (218, 186, 84), (2, 8, 8, 14), border_radius=2)
            pygame.draw.rect(sp, (148, 122, 46), (4, 10, 4, 3))
            pygame.draw.rect(sp, (148, 122, 46), (4, 17, 4, 3))
            # Sleek Gene Drive body
            pygame.draw.rect(sp, (54, 68, 92), (9, 4, 31, 22), border_radius=4)
            pygame.draw.rect(sp, (124, 152, 194), (9, 4, 31, 22), 2, border_radius=4)
            pygame.draw.rect(sp, (92, 236, 224), (14, 9, 18, 5), border_radius=2)
            pygame.draw.circle(sp, (206, 112, 255), (32, 19), 3)
            rot = pygame.transform.rotozoom(sp, ang, 1.0)
            surf.blit(rot, rot.get_rect(center=(cx, cy)))
        else:  # "beer"
            sp = pygame.Surface((28, 44), pygame.SRCALPHA)
            pygame.draw.rect(sp, (174, 102, 38), (6, 14, 16, 27), border_radius=4)
            pygame.draw.rect(sp, (132, 74, 26), (9, 4, 10, 12), border_radius=2)
            pygame.draw.rect(sp, (244, 238, 222), (8, 2, 12, 4), border_radius=2)
            pygame.draw.rect(sp, (242, 224, 174), (8, 20, 12, 12), border_radius=2)
            pygame.draw.line(sp, (112, 62, 24), (10, 23), (18, 29), 2)
            pygame.draw.line(sp, (112, 62, 24), (18, 23), (10, 29), 2)
            rot = pygame.transform.rotozoom(sp, ang, 1.0)
            surf.blit(rot, rot.get_rect(center=(cx, cy)))

    def draw_horses(self, screen: pygame.Surface):
        self.phys_canvas.fill((0, 0, 0, 0))
        for sh in self.horses:
            sh.creature.draw(self.phys_canvas, self.view_x)
            if sh.entry.is_rancher:
                draw_rancher_hat(self.phys_canvas, sh.creature, self.view_x)
        for pr in self.props:
            self._draw_prop(self.phys_canvas, pr)
        if hasattr(screen, "_real"):
            vw = max(1, int(round(SCREEN_W * screen.scale)))
            vh = max(1, int(round(SCREEN_H * screen.scale)))
            scaled = pygame.transform.smoothscale(self.phys_canvas, (vw, vh))
            screen._real.blit(scaled, (screen._ox, screen._oy))
        else:
            scaled = pygame.transform.smoothscale(self.phys_canvas, (SCREEN_W, SCREEN_H))
            screen.blit(scaled, (0, 0))

def add_truck_walls(scene_phys: UnifiedPhysicsScene, trailer_left: float, floor_y: float):
    """Adds open-top solid floor slab + side walls for the Standardized Truck."""
    tr_right = trailer_left + STD_TRUCK_TRAILER_W
    tr_top = floor_y - STD_TRUCK_TRAILER_H
    scene_phys.add_floor_slab(trailer_left, tr_right, floor_y, thickness=70.0, friction=0.95)
    scene_phys.add_box_collider(trailer_left - 12.0, tr_top, trailer_left + 4.0, floor_y + 40.0, friction=0.2, is_floor=False)
    scene_phys.add_box_collider(tr_right - 4.0, tr_top, tr_right + 12.0, floor_y + 40.0, friction=0.2, is_floor=False)


def add_open_pen_walls(scene_phys: UnifiedPhysicsScene, x1: float, x2: float, floor_y: float):
    """Adds open-top solid floor slab + fence posts for a Pen (NO ceiling!)."""
    scene_phys.add_floor_slab(x1, x2, floor_y, thickness=18.0, friction=0.95)
    scene_phys.add_box_collider(x1 - 12.0, floor_y - 190.0, x1 + 4.0, floor_y + 18.0, friction=0.2, is_floor=False)
    scene_phys.add_box_collider(x2 - 4.0, floor_y - 190.0, x2 + 12.0, floor_y + 18.0, friction=0.2, is_floor=False)
