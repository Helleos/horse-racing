"""Horse records, the horse factory, and race-lineup setup."""
from __future__ import annotations

from dataclasses import dataclass, field
import math
import random
import pygame
import pymunk

from gene import (
    ALL_LOCI,
    Gene,
    Genome,
    encode_allele,
    carnivore_genome,
    prop_genome,
    rabbit_genome,
    rancher_genome,
    random_horse_genome,
)

from racing_constants import (
    BOLD_NAME_COLORS,
    HORSE_FIRST_NAMES,
    HORSE_FLOOR_Y,
    HORSE_LAST_NAMES,
    NUM_LANES,
    STRONGHORSE_SLOPE,
    TRACK_LENGTH,
)

from creature import (
    Creature,
    CreatureConfig,
    STRAND_SLOT_BY_LOCUS,
    build_creature,
    compute_spawn_y,
    config_from_genome,
    strand_creature_config,
)

# --- DATA STRUCTURES ---


@dataclass
class HorseEntry:
    entry_id: int
    name: str
    name_color: tuple[int, int, int]
    config: CreatureConfig
    genome: Genome | None = None
    age: int = 1  # 0=Juvenile, 1-9=Adult, 10=Elder
    trial_time: float = 0.0
    price: int = 100
    origin_ranch: str = "Wild"
    is_winner: bool = False
    is_champion: bool = False
    is_tired: bool = False
    is_hungry: bool = False
    drunk_level: int = 0
    is_rancher: bool = False
    hunger_clock: float = 0.0
    days_hungry: int = 0
    dead_days: int = 0
    is_strand: bool = False
    strand_locus: str = ""
    strand_num: int = 0
    source_drive: Genome | None = None
    is_rabbit: bool = False
    is_gladiator: bool = False
    is_frenzied: bool = False
    orange_boost: float = 0.0
    diet: str = "herbivore"
    lifespan_penalty: int = 0
    sentience: float = 0.0
    is_dead: bool = False

    @property
    def death_age(self) -> int:
        return max(1, 10 - max(0, self.lifespan_penalty))

    @property
    def is_drunk(self) -> bool:
        return 0 < self.drunk_level < 3

    @property
    def is_unconscious(self) -> bool:
        return self.drunk_level >= 3

    @is_unconscious.setter
    def is_unconscious(self, value: bool):
        if value:
            self.drunk_level = max(3, self.drunk_level)
        elif self.drunk_level >= 3:
            self.drunk_level = 0


@dataclass
class LaneRuntime:
    lane_index: int
    entry: HorseEntry
    odds: float
    space: pymunk.Space
    floor: pymunk.Segment
    creature: Creature
    is_player_horse: bool = False
    place: int | None = None
    stone_body: pymunk.Body | None = None
    stone_shape: pymunk.Poly | None = None
    stone_joint: pymunk.Constraint | None = None
    ramp_slope: float = 0.0


@dataclass
class WildHorse:
    entry: HorseEntry
    x: float
    y: float
    vx: float
    vy: float
    facing: int
    state: str
    state_timer: float
    flipped: bool = False
    being_lassoed: bool = False
    hunt_cooldown: float = 0.0


@dataclass
class TreeData:
    tree_id: int
    x: float
    y: float
    terrain: str  # "grass", "savanna", "deep_forest", "desert", "oasis"
    has_apples: bool
    apples: list[tuple[float, float]] = field(default_factory=list)
    scale: float = 1.0
    kind: str = "tree"  # "tree", "cactus", "pine", "palm", "acacia"


@dataclass
class WorldApple:
    x: float
    y: float
    vy: float = 0.0
    target_y: float = 0.0
    falling: bool = False
    kind: str = "apple"  # "apple" or "prickly_pear"


@dataclass
class WorldMeat:
    x: float
    y: float
    genome: Genome | None
    uses: int


@dataclass
class MeatCut:
    genome: Genome | None
    uses: list[int]


@dataclass
class FossilNode:
    fossil_id: int
    x: float
    y: float
    genome: Genome
    variant: int = 0


@dataclass
class RacecourseData:
    course_id: int
    name: str
    x: float
    y: float
    is_arena: bool = False


@dataclass
class RanchData:
    ranch_id: int
    name: str
    x: float
    y: float
    horses: list[HorseEntry]
    rancher_entry: HorseEntry | None = None
    has_rabbit_pen: bool = False
    rabbits: list[HorseEntry] = field(default_factory=list)


@dataclass
class ShopData:
    shop_id: int
    name: str
    x: float
    y: float
    stock: dict[str, int] = field(default_factory=lambda: {"lasso": 4, "hay": 8, "beer": 12})
    shopkeeper_entry: HorseEntry | None = None
    shop_kind: str = "outfitter"  # "outfitter" or "convenience"


@dataclass
class BusStationData:
    station_id: int
    name: str
    x: float
    y: float
    rancher_entry: HorseEntry | None = None


@dataclass
class BusDirectionSign:
    x: float
    y: float
    station_id: int
    direction: tuple[int, int]
    distance: int


@dataclass
class LassoAnim:
    target: WildHorse
    phase: str
    progress: float
    start_x: float
    start_y: float


@dataclass
class SceneHorse:
    entry: HorseEntry
    creature: Creature
    owned_by_player: bool
    home_x: float | None = None


@dataclass
class SceneProp:
    kind: str  # "lasso", "hay", "beer", "potion"
    body: pymunk.Body
    shape: pymunk.Shape
    from_shop: bool = False
    home_pos: tuple[float, float] = (0.0, 0.0)
    price: int = 0
    genome: Genome | None = None
    locked: bool = False
    uses_left: int = 0
    crate_ref: list[int] | None = None


@dataclass
class ActiveBite:
    prop: SceneProp
    horse: SceneHorse
    timer: float
    truck_left: float
    truck_floor: float


@dataclass
class MapGeneNode:
    locus: str
    locus_num: int
    x: float
    y: float
    vx: float
    vy: float
    being_lassoed: bool = False


@dataclass
class SpliceNucleotideNode:
    base: str
    slot: tuple[int, int] | None  # (strand_idx 0/1, nt_idx 0..23) or None if detached
    body: pymunk.Body
    shape: pymunk.Poly
    free_timer: float = 0.0


# --- HORSE FACTORY & TRIAL SIMULATION ---


PLANT_FOOD = frozenset({"hay", "apple", "prickly_pear", "apple_crate"})
REFUSAL_LINES = ("This is embarassing", "I don't want to do this", "This sucks")


def meat_portions(torso: tuple[float, float]) -> int:
    """Servings from the animal's torso area. A typical horse is near the top of 5..50."""
    area = max(1.0, torso[0] * torso[1])
    typical = 180.0 * 80.0
    return int(max(5, min(50, round(5.0 + 45.0 * min(1.0, area / typical)))))


def meat_from_kill(prey: WildHorse) -> WorldMeat:
    """Meat left by a kill. The cut keeps its own copy of that creature's DNA."""
    genome = prey.entry.genome.copy() if prey.entry.genome is not None else None
    return WorldMeat(
        x=prey.x,
        y=prey.y,
        genome=genome,
        uses=meat_portions(prey.entry.config.torso.size),
    )


def item_extract_genome(
    kind: str,
    genome: Genome | None,
    rng: random.Random | None = None,
) -> Genome | None:
    """DNA the gene extractor reads from an item in the glass box.

    Meat and fossils yield the creature genome stored on the item.
    Other foods synthesize a genome from the item kind.
    """
    if kind in ("meat", "fossil"):
        if genome is None:
            return None
        return genome.copy()
    return prop_genome(kind, rng=rng)


def diet_accepts(diet: str, kind: str) -> bool:
    if kind in PLANT_FOOD:
        return diet != "carnivore"
    if kind == "meat":
        return diet != "herbivore"
    return True


def stamp_life(entry: HorseEntry) -> HorseEntry:
    """Copy diet, lifespan, and sentience off the genome. A lethal-white foal is born dead."""
    if entry.genome is None:
        entry.diet = "omnivore" if entry.is_rancher else "herbivore"
        entry.sentience = 1.0 if entry.is_rancher else 0.0
        return entry
    pheno = entry.genome.evaluate(age=entry.age)
    entry.diet = pheno.diet
    entry.lifespan_penalty = pheno.lifespan_penalty
    entry.sentience = pheno.sentience
    if pheno.lethal_white:
        entry.is_dead = True
        entry.config = entry.config.with_(gait=entry.config.gait.with_(enabled=False, mode="walk"))
    return entry


class HorseFactory:
    def __init__(self, rng: random.Random):
        self.rng = rng
        self._next_id = 1
        self._used_names: set[str] = set()

    def release_name(self, name: str):
        self._used_names.discard(name)

    def next_unique_name(self) -> str:
        for _ in range(400):
            name = f"{self.rng.choice(HORSE_FIRST_NAMES)} {self.rng.choice(HORSE_LAST_NAMES)}"
            if name not in self._used_names:
                self._used_names.add(name)
                return name
        for _ in range(400):
            first = self.rng.choice(HORSE_FIRST_NAMES)
            mid = self.rng.choice(HORSE_FIRST_NAMES)
            last = self.rng.choice(HORSE_LAST_NAMES)
            if mid != first:
                name = f"{first} {mid} {last}"
                if name not in self._used_names:
                    self._used_names.add(name)
                    return name
        return f"{self.rng.choice(HORSE_FIRST_NAMES)} {self.rng.choice(HORSE_LAST_NAMES)}"

    def create_horse(
        self,
        origin: str = "Wild",
        age: int | None = None,
        genome: Genome | None = None,
    ) -> HorseEntry:
        mut_chance = 0.010 if origin == "Wild" else 0.003
        if genome is None:
            genome = random_horse_genome(rng=self.rng, rare_mutation_chance=mut_chance)
        if age is None:
            if origin == "Wild":
                age = self.rng.choices(
                    list(range(11)),
                    weights=[12, 10, 10, 10, 10, 9, 9, 8, 7, 6, 9],
                    k=1,
                )[0]
            else:
                age = self.rng.choices(
                    list(range(11)),
                    weights=[8, 12, 12, 12, 11, 10, 9, 8, 7, 6, 5],
                    k=1,
                )[0]
        age = max(0, min(10, age))
        cfg = config_from_genome(
            genome,
            spawn_x=0.0,
            floor_y=HORSE_FLOOR_Y,
            mode="walk",
            collision_group=1,
            age=age,
        )
        entry = HorseEntry(
            entry_id=self._next_id,
            name=self.next_unique_name(),
            name_color=self.rng.choice(BOLD_NAME_COLORS),
            config=cfg,
            genome=genome,
            age=age,
            price=self.rng.randint(50, 200),
            origin_ranch=origin,
            is_hungry=(self.rng.random() < (0.14 if origin == "Wild" else 0.08)),
        )
        self._next_id += 1
        return stamp_life(entry)

    def create_rabbit(self, origin: str = "Ranch") -> HorseEntry:
        """A ranch rabbit: horse-like genes with the saltatory axis pushed to the rabbit end."""
        genome = rabbit_genome(rng=self.rng)
        age = self.rng.choices(list(range(1, 10)), weights=[12, 12, 12, 11, 10, 9, 8, 7, 6], k=1)[0]
        cfg = config_from_genome(
            genome,
            spawn_x=0.0,
            floor_y=HORSE_FLOOR_Y,
            mode="walk",
            collision_group=1,
            age=age,
        )
        entry = HorseEntry(
            entry_id=self._next_id,
            name=self.next_unique_name(),
            name_color=self.rng.choice(BOLD_NAME_COLORS),
            config=cfg,
            genome=genome,
            age=age,
            price=self.rng.randint(25, 90),
            origin_ranch=origin,
            is_rabbit=True,
        )
        self._next_id += 1
        return stamp_life(entry)

    def create_foal(self, parent_a: HorseEntry, parent_b: HorseEntry, origin: str = "Your Ranch") -> HorseEntry:
        if parent_a.genome is not None and parent_b.genome is not None:
            genome = parent_a.genome.breed(parent_b.genome, point_mutation_rate=0.015, rng=self.rng)
        else:
            genome = random_horse_genome(rng=self.rng, rare_mutation_chance=0.05)

        if genome.pure_strand and genome.strand_loci:
            first_locus = next(
                (l for l in genome.strand_loci if STRAND_SLOT_BY_LOCUS.get(l, "tendril") not in ("wing", "horn", "tail")),
                genome.strand_loci[0],
            )
            locus_num = ALL_LOCI.index(first_locus) + 1
            g_obj = genome.genes[first_locus]
            cfg = strand_creature_config(
                locus_num,
                (g_obj.allele_a, g_obj.allele_b),
                spawn_x=0.0,
                floor_y=HORSE_FLOOR_Y,
                collision_group=1,
                genome=genome,
            )
            name = "#" + "+".join(str(ALL_LOCI.index(l) + 1) for l in genome.strand_loci[:4])
            if len(genome.strand_loci) > 4:
                name += "+"
            entry = HorseEntry(
                entry_id=self._next_id,
                name=name,
                name_color=(198, 132, 248),
                config=cfg,
                genome=genome,
                age=1,
                price=self.rng.randint(120, 260),
                origin_ranch=origin,
                is_strand=True,
                strand_locus=first_locus,
                strand_num=locus_num,
            )
            self._next_id += 1
            return entry

        cfg = config_from_genome(
            genome,
            spawn_x=0.0,
            floor_y=HORSE_FLOOR_Y,
            mode="walk",
            collision_group=1,
            age=0,
        )
        entry = HorseEntry(
            entry_id=self._next_id,
            name=self.next_unique_name(),
            name_color=self.rng.choice(BOLD_NAME_COLORS),
            config=cfg,
            genome=genome,
            age=0,
            price=self.rng.randint(80, 220),
            origin_ranch=origin,
            is_rabbit=genome.evaluate(age=0).lagomorph > 0.72,
        )
        self._next_id += 1
        return stamp_life(entry)

    def create_carnivore(self, origin: str = "Wild") -> HorseEntry:
        genome = carnivore_genome(rng=self.rng)
        age = self.rng.randint(2, 8)
        cfg = config_from_genome(
            genome,
            spawn_x=0.0,
            floor_y=HORSE_FLOOR_Y,
            mode="walk",
            collision_group=1,
            age=age,
        )
        entry = HorseEntry(
            entry_id=self._next_id,
            name=self.next_unique_name(),
            name_color=(176, 64, 52),
            config=cfg,
            genome=genome,
            age=age,
            price=self.rng.randint(40, 120),
            origin_ranch=origin,
            is_hungry=(self.rng.random() < 0.14),
        )
        self._next_id += 1
        return stamp_life(entry)

    def create_rancher(self, ranch_name: str) -> HorseEntry:
        r_rng = random.Random(self.rng.randint(1, 999999))
        genome = rancher_genome(r_rng, rare_mutation_chance=0.03)
        age = self.rng.randint(3, 8)
        cfg = config_from_genome(
            genome,
            spawn_x=0.0,
            floor_y=HORSE_FLOOR_Y,
            mode="walk",
            collision_group=7,
            age=age,
        )
        prefix = ranch_name.split()[0] if ranch_name else "Frontier"
        rancher_titles = ["Bill", "Jed", "Clem", "Hank", "Mae", "Wade", "Gus", "Otis"]
        name = f"{prefix} {self.rng.choice(rancher_titles)}"
        entry = HorseEntry(
            entry_id=self._next_id,
            name=name,
            name_color=(245, 208, 134),
            config=cfg,
            genome=genome,
            age=age,
            price=0,
            origin_ranch=ranch_name,
            is_rancher=True,
        )
        self._next_id += 1
        return stamp_life(entry)

    def create_shopkeep(self, shop_name: str = "Outfitter") -> HorseEntry:
        entry = self.create_rancher(shop_name)
        entry.name = "Shopkeep"
        entry.config = entry.config.with_(has_apron=True)
        return entry

    def create_strand(
        self,
        locus: str,
        gene: Gene,
        source_drive: Genome | None = None,
    ) -> HorseEntry:
        locus_num = ALL_LOCI.index(locus) + 1
        strand_genome = Genome(
            genes={locus: Gene(locus, gene.allele_a, gene.allele_b)},
            strand_loci=(locus,),
            pure_strand=True,
        )
        cfg = strand_creature_config(
            locus_num,
            (gene.allele_a, gene.allele_b),
            spawn_x=0.0,
            floor_y=HORSE_FLOOR_Y,
            collision_group=1,
            genome=strand_genome,
        )
        entry = HorseEntry(
            entry_id=self._next_id,
            name=f"#{locus_num}",
            name_color=(198, 132, 248),
            config=cfg,
            genome=strand_genome,
            age=3,
            price=120,
            origin_ranch="Gene Map",
            is_strand=True,
            strand_locus=locus,
            strand_num=locus_num,
            source_drive=source_drive,
        )
        self._next_id += 1
        return entry


def invalidate_preview_cache(entry_id: int):
    for key in [k for k in _PREVIEW_CACHE if k[0] == entry_id]:
        del _PREVIEW_CACHE[key]


def entry_strands_functional(entry: HorseEntry) -> bool:
    if entry.genome is None or not entry.genome.strand_loci:
        return True
    return all(
        entry.genome.genes[loc].is_complete()
        for loc in entry.genome.strand_loci
        if loc in entry.genome.genes
    )


def refresh_entry_config_for_age(entry: HorseEntry):
    if entry.is_strand and entry.genome is not None:
        loci = entry.genome.strand_loci
        loc = (
            next(
                (l for l in loci if STRAND_SLOT_BY_LOCUS.get(l, "tendril") not in ("wing", "horn", "tail")),
                loci[0],
            )
            if loci
            else entry.strand_locus
        )
        if loc and loc in entry.genome.genes:
            g_obj = entry.genome.genes[loc]
            l_num = ALL_LOCI.index(loc) + 1
            entry.strand_locus = loc
            entry.strand_num = l_num
            entry.config = strand_creature_config(
                l_num,
                (g_obj.allele_a, g_obj.allele_b),
                spawn_x=0.0,
                floor_y=HORSE_FLOOR_Y,
                collision_group=1,
                genome=entry.genome,
            )
    elif entry.genome is not None:
        has_apron = entry.config.has_apron
        cfg = config_from_genome(
            entry.genome,
            spawn_x=0.0,
            floor_y=HORSE_FLOOR_Y,
            mode="walk",
            collision_group=1,
            age=entry.age,
        ).with_(has_apron=has_apron)
        if entry.orange_boost > 0.0:
            t_o = min(1.0, entry.orange_boost) * 0.65

            def tint_orange(col: tuple[int, int, int] | None, target: tuple[int, int, int]) -> tuple[int, int, int] | None:
                if col is None:
                    return None
                return (
                    int(col[0] + (target[0] - col[0]) * t_o),
                    int(col[1] + (target[1] - col[1]) * t_o),
                    int(col[2] + (target[2] - col[2]) * t_o),
                )

            app = cfg.appearance.with_(
                coat_color=tint_orange(cfg.appearance.coat_color, (242, 126, 32)),
                back_leg_color=tint_orange(cfg.appearance.back_leg_color, (204, 96, 22)),
            )
            cfg = cfg.with_(
                appearance=app,
                torso=cfg.torso.with_(color=tint_orange(cfg.torso.color, (242, 126, 32))),
                neck=cfg.neck.with_(color=tint_orange(cfg.neck.color, (238, 122, 30))),
                head=cfg.head.with_(color=tint_orange(cfg.head.color, (242, 126, 32))),
                upper_jaw=cfg.upper_jaw.with_(color=tint_orange(cfg.upper_jaw.color, (242, 126, 32))),
                lower_jaw=cfg.lower_jaw.with_(color=tint_orange(cfg.lower_jaw.color, (230, 114, 28))),
                leg_front=cfg.leg_front.with_(color=tint_orange(cfg.leg_front.color, (242, 126, 32))),
                leg_back=cfg.leg_back.with_(color=tint_orange(cfg.leg_back.color, (204, 96, 22))),
            )
        entry.config = cfg
    entry.trial_time = 0.0
    invalidate_preview_cache(entry.entry_id)


def sync_creature_state(entry: HorseEntry, creature: Creature):
    creature.drunk = entry.is_drunk
    creature.unconscious = entry.is_unconscious
    creature.tired = entry.is_tired
    creature.hungry = entry.is_hungry
    creature.frenzied = entry.is_frenzied
    creature.dead = entry.is_dead
    if entry.is_unconscious or entry.is_dead:
        creature.config.gait.enabled = False


def get_horse_front_x(creature: Creature) -> float:
    return max(s.bb.right for s in creature.shapes.values())


def get_horse_back_x(creature: Creature) -> float:
    return min(s.bb.left for s in creature.shapes.values())


def simulate_preliminary_trial(
    trial_space: pymunk.Space,
    trial_floor: pymunk.Segment,
    cfg: CreatureConfig,
    seed: int,
    track_length: float = TRACK_LENGTH,
    heats: int = 1,
) -> float:
    dt = 1.0 / 60.0
    max_steps = 60 * 42
    total_time = 0.0

    for h in range(heats):
        spawn_y = compute_spawn_y(cfg, floor_y=HORSE_FLOOR_Y)
        trial_cfg = cfg.with_(
            spawn_pos=(0.0, spawn_y),
            gait=cfg.gait.with_(mode="run", enabled=True),
        )
        horse = build_creature(trial_space, trial_cfg)
        horse.gait_phase = random.Random(seed * 31 + h).uniform(0.0, 2.0 * math.pi)

        prev_x = get_horse_front_x(horse)
        finished_t: float | None = None

        try:
            for step in range(max_steps):
                horse.update(dt, trial_floor)
                trial_space.step(dt)
                curr_x = get_horse_front_x(horse)
                if curr_x >= track_length:
                    frac = (track_length - prev_x) / max(1e-6, curr_x - prev_x)
                    finished_t = (step + max(0.0, min(1.0, frac))) * dt
                    break
                prev_x = curr_x

            if finished_t is None:
                finished_t = 42.0 + max(0.0, track_length - get_horse_front_x(horse)) / 100.0
            total_time += finished_t
        finally:
            horse.remove_from_space(trial_space)

    return total_time / float(heats)


def compute_preliminary_odds(entries: list[HorseEntry]) -> list[float]:
    times = [e.trial_time for e in entries]
    min_t = min(times)
    max_t = max(times)
    spread = max_t - min_t
    temp = max(0.32, spread * 0.42)

    weights = [math.exp(-(t - min_t) / temp) for t in times]
    total_w = sum(weights) or 1.0
    probs = [w / total_w for w in weights]

    odds_list: list[float] = []
    for p in probs:
        mult = 1.28 / max(0.05, p)
        mult = max(1.6, min(18.0, mult))
        odds_list.append(round(mult, 1))
    return odds_list


def create_championship_opponent(
    factory: HorseFactory,
    ranches: list[RanchData],
    rng: random.Random,
) -> HorseEntry:
    base_genome = random_horse_genome(rng=rng, rare_mutation_chance=0.04)
    genes = dict(base_genome.genes)

    def set_elite(locus: str, p1: float, p2: float, p3: float, utr: str = "CAG"):
        s1 = encode_allele(p1, p2, p3, promoter="ATG", utr=utr)
        s2 = encode_allele(p1, p2, p3, promoter="ATG", utr=utr)
        genes[locus] = Gene(locus, s1, s2)

    # Keep all 4 legs intact and give top-tier championship athletic traits
    set_elite("hox_limb_gate", 0.65, 0.55, 0.55)
    set_elite("size_somatic", rng.uniform(0.86, 0.98), rng.random(), rng.random())
    set_elite("build_robust", rng.uniform(0.40, 0.58), rng.random(), rng.random())
    set_elite("limb_fore", rng.uniform(0.84, 0.97), rng.uniform(0.42, 0.58), rng.uniform(0.47, 0.53))
    set_elite("limb_hind", rng.uniform(0.84, 0.97), rng.uniform(0.42, 0.58), rng.uniform(0.47, 0.53))
    set_elite("gait_cadence", rng.uniform(0.74, 0.96), rng.uniform(0.74, 0.96), rng.uniform(0.92, 0.995))
    set_elite("gait_power", rng.uniform(0.93, 0.995), rng.uniform(0.91, 0.995), rng.uniform(0.44, 0.56), utr="TTT")
    set_elite("balance_core", rng.uniform(0.82, 0.96), rng.uniform(0.82, 0.96), rng.uniform(0.45, 0.65))
    set_elite("bone_density", rng.uniform(0.78, 0.95), rng.uniform(0.74, 0.92), rng.uniform(0.50, 0.80))
    set_elite("behavior_locus", rng.uniform(0.15, 0.42), rng.random(), rng.random())
    if rng.random() < 0.40:
        s_hoof = encode_allele(0.55, 0.55, 0.30, promoter="ATG", utr="TTT", motif_patch="GTAC")
        genes["hoof_dev"] = Gene("hoof_dev", s_hoof, s_hoof)

    elite_genome = Genome(genes=genes, lineage="ChampionCircuit", generation=rng.randint(2, 6))
    origin = rng.choice(ranches).name if ranches else "Grand Circuit"
    age = rng.randint(2, 6)
    entry = factory.create_horse(origin=origin, age=age, genome=elite_genome)
    entry.is_winner = True
    return entry


def prepare_race_lineup(
    ranches: list[RanchData],
    factory: HorseFactory,
    trial_space: pymunk.Space,
    trial_floor: pymunk.Segment,
    lane_spaces: list[tuple[pymunk.Space, pymunk.Segment]],
    old_lanes: list[LaneRuntime],
    rng: random.Random,
    player_horse: HorseEntry | None = None,
    extra_pool: list[HorseEntry] | None = None,
    championship: bool = False,
    race_kind: str = "standard",
) -> list[LaneRuntime]:
    for old in old_lanes:
        if old.stone_joint is not None and old.stone_joint in old.space.constraints:
            old.space.remove(old.stone_joint)
        if old.stone_shape is not None and old.stone_shape in old.space.shapes:
            old.space.remove(old.stone_shape)
        if old.stone_body is not None and old.stone_body in old.space.bodies:
            old.space.remove(old.stone_body)
        old.creature.remove_from_space(old.space)

    if player_horse is not None and (not (1 <= player_horse.age <= 9) or player_horse.is_champion):
        player_horse = None

    ranch_pool: list[HorseEntry] = []
    for r in ranches:
        ranch_pool.extend(
            h for h in r.horses
            if 1 <= h.age <= 9
            and not h.is_rancher
            and not h.is_champion
            and not h.is_unconscious
            and not h.is_tired
            and not h.is_hungry
        )
    if extra_pool:
        ranch_pool.extend(
            h for h in extra_pool
            if 1 <= h.age <= 9
            and not h.is_rancher
            and not h.is_champion
            and not h.is_unconscious
            and not h.is_tired
            and not h.is_hungry
        )

    needed_ranch = NUM_LANES - (1 if player_horse is not None else 0)

    if championship:
        # Build a fast pool of elite past winners and keep the 4 fastest by trial time
        ranch_winners = [h for h in ranch_pool if h.is_winner]
        elite_candidates = [create_championship_opponent(factory, ranches, rng) for _ in range(14)]
        cand_pool = ranch_winners + elite_candidates
        for entry in cand_pool:
            if entry.trial_time <= 0.0:
                pygame.event.pump()
                entry.trial_time = simulate_preliminary_trial(
                    trial_space, trial_floor, entry.config, entry.entry_id
                )
        cand_pool.sort(key=lambda h: h.trial_time)
        chosen = cand_pool[:needed_ranch]
        chosen_set = set(id(h) for h in chosen)
        for c in elite_candidates:
            if id(c) not in chosen_set:
                factory.release_name(c.name)
    elif len(ranch_pool) >= needed_ranch:
        chosen = rng.sample(ranch_pool, needed_ranch)
    else:
        chosen = list(ranch_pool)
        while len(chosen) < needed_ranch:
            chosen.append(factory.create_horse("Valley Ranch", age=rng.randint(1, 8)))

    if player_horse is not None:
        rng.shuffle(chosen)
        lineup_entries = chosen[:2] + [player_horse] + chosen[2:]
    else:
        lineup_entries = chosen
        rng.shuffle(lineup_entries)

    for entry in lineup_entries:
        if entry.trial_time <= 0.0:
            pygame.event.pump()
            entry.trial_time = simulate_preliminary_trial(
                trial_space, trial_floor, entry.config, entry.entry_id
            )

    used_colors: set[tuple[int, int, int]] = set()
    palette_cycle = list(BOLD_NAME_COLORS)
    rng.shuffle(palette_cycle)
    for entry in lineup_entries:
        if entry.name_color in used_colors:
            for c in palette_cycle:
                if c not in used_colors:
                    entry.name_color = c
                    break
        used_colors.add(entry.name_color)

    odds_list = compute_preliminary_odds(lineup_entries)

    lanes: list[LaneRuntime] = []
    for lane_idx, (entry, odds) in enumerate(zip(lineup_entries, odds_list)):
        space, floor = lane_spaces[lane_idx]
        ramp_slope = STRONGHORSE_SLOPE if race_kind == "stronghorse" else 0.0
        if race_kind == "stronghorse":
            floor.unsafe_set_endpoints(
                (-600.0, HORSE_FLOOR_Y + 600.0 * ramp_slope),
                (3200.0, HORSE_FLOOR_Y - 3200.0 * ramp_slope),
            )
            floor.friction = 1.5
        elif race_kind == "muddy_tracks":
            floor.unsafe_set_endpoints((-1000.0, HORSE_FLOOR_Y), (TRACK_LENGTH + 2000.0, HORSE_FLOOR_Y))
            floor.friction = 5.0
        else:
            floor.unsafe_set_endpoints((-1000.0, HORSE_FLOOR_Y), (TRACK_LENGTH + 2000.0, HORSE_FLOOR_Y))
            floor.friction = 1.0
        space.reindex_shape(floor)

        spawn_y = compute_spawn_y(entry.config, floor_y=HORSE_FLOOR_Y)
        stand_cfg = entry.config.with_(
            spawn_pos=(0.0, spawn_y),
            gait=entry.config.gait.with_(mode="walk", enabled=False),
        )
        creature = build_creature(space, stand_cfg)
        sync_creature_state(entry, creature)

        stone_body: pymunk.Body | None = None
        stone_shape: pymunk.Poly | None = None
        stone_joint: pymunk.Constraint | None = None
        if race_kind == "stronghorse":
            sw, sh = 72.0, 52.0
            smass = 55.0
            stone_body = pymunk.Body(smass, pymunk.moment_for_box(smass, (sw, sh)))
            stone_x = -125.0
            stone_y = HORSE_FLOOR_Y - stone_x * ramp_slope - sh * 0.5 - 2.0
            stone_body.position = (stone_x, stone_y)
            stone_body.angle = -math.atan(ramp_slope)
            stone_shape = pymunk.Poly.create_box(stone_body, (sw, sh), radius=3.0)
            stone_shape.friction = 0.20
            stone_shape.filter = pymunk.ShapeFilter(group=stand_cfg.collision_group)
            space.add(stone_body, stone_shape)
            tw = stand_cfg.torso.size[0]
            stone_joint = pymunk.SlideJoint(
                creature.bodies["torso"],
                stone_body,
                (-tw * 0.45, 0.0),
                (sw * 0.5, 0.0),
                0.0,
                52.0,
            )
            space.add(stone_joint)

        for _ in range(24):
            creature.update(1.0 / 60.0, floor)
            space.step(1.0 / 60.0)
            torso = creature.bodies["torso"]
            torso.velocity = (0.0, torso.velocity.y)
            torso.angular_velocity *= 0.8
            if stone_body is not None:
                stone_body.velocity = (0.0, stone_body.velocity.y)
                stone_body.angular_velocity *= 0.8

        lanes.append(
            LaneRuntime(
                lane_index=lane_idx,
                entry=entry,
                odds=odds,
                space=space,
                floor=floor,
                creature=creature,
                is_player_horse=(player_horse is not None and entry is player_horse),
                stone_body=stone_body,
                stone_shape=stone_shape,
                stone_joint=stone_joint,
                ramp_slope=ramp_slope,
            )
        )
    return lanes

_PREVIEW_CACHE: dict[tuple[int, int, int], pygame.Surface] = {}
